--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Debian 14.5-1.pgdg110+1)
-- Dumped by pg_dump version 14.6

-- Started on 2022-12-02 16:12:07 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4867 (class 1262 OID 16384)
-- Name: sensorthings; Type: DATABASE; Schema: -; Owner: sensorthings
--

\connect sensorthings

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4868 (class 0 OID 0)
-- Name: sensorthings; Type: DATABASE PROPERTIES; Schema: -; Owner: sensorthings
--

ALTER DATABASE sensorthings SET search_path TO '$user', 'public', 'topology', 'tiger';


\connect sensorthings

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


--
-- TOC entry 4869 (class 0 OID 0)
-- Dependencies: 8
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: sensorthings
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- TOC entry 4 (class 3079 OID 19181)
-- Name: fuzzystrmatch; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS fuzzystrmatch WITH SCHEMA public;


--
-- TOC entry 4870 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION fuzzystrmatch; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION fuzzystrmatch IS 'determine similarities and distance between strings';


--
-- TOC entry 2 (class 3079 OID 17989)
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- TOC entry 4871 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- TOC entry 5 (class 3079 OID 19193)
-- Name: postgis_tiger_geocoder; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_tiger_geocoder WITH SCHEMA tiger;


--
-- TOC entry 4872 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION postgis_tiger_geocoder; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_tiger_geocoder IS 'PostGIS tiger geocoder and reverse geocoder';


--
-- TOC entry 3 (class 3079 OID 19021)
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- TOC entry 4873 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- TOC entry 1186 (class 1255 OID 19626)
-- Name: count_estimate(text); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.count_estimate(query text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec   record;
    rows  integer;
BEGIN
    FOR rec IN EXECUTE 'EXPLAIN ' || query LOOP
        rows := substring(rec."QUERY PLAN" FROM ' rows=([[:digit:]]+)');
        EXIT WHEN rows IS NOT NULL;
    END LOOP;

    RETURN rows;
END
$$;


ALTER FUNCTION public.count_estimate(query text) OWNER TO sensorthings;

--
-- TOC entry 1189 (class 1255 OID 19810)
-- Name: datastreams_update_delete(); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.datastreams_update_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
declare
    "DS_ROW" "DATASTREAMS"%rowtype;
    queryset TEXT := '';
    delimitr char(1) := ' ';
begin

if (OLD."DATASTREAM_ID" is not null)
then
    select * into "DS_ROW" from "DATASTREAMS" where "DATASTREAMS"."ID"=OLD."DATASTREAM_ID";

    if (OLD."PHENOMENON_TIME_START" = "DS_ROW"."PHENOMENON_TIME_START"
        or coalesce(OLD."PHENOMENON_TIME_END", OLD."PHENOMENON_TIME_START") = "DS_ROW"."PHENOMENON_TIME_END")
    then
        queryset := queryset || delimitr || '"PHENOMENON_TIME_START" = (select min("PHENOMENON_TIME_START") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
        delimitr := ',';
        queryset := queryset || delimitr || '"PHENOMENON_TIME_END" = (select max(coalesce("PHENOMENON_TIME_END", "PHENOMENON_TIME_START")) from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
    end if;

    if (OLD."RESULT_TIME" = "DS_ROW"."RESULT_TIME_START")
    then
        queryset := queryset || delimitr || '"RESULT_TIME_START" = (select min("RESULT_TIME") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
        delimitr := ',';
    end if;
    if (OLD."RESULT_TIME" = "DS_ROW"."RESULT_TIME_END")
    then
        queryset := queryset || delimitr || '"RESULT_TIME_END" = (select max("RESULT_TIME") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
        delimitr := ',';
    end if;
    if (delimitr = ',') then
        EXECUTE 'update "DATASTREAMS" SET ' || queryset ||  ' where "DATASTREAMS"."ID"=$1."DATASTREAM_ID"' using OLD;
    end if;
end if;    

return NULL;
end
$_$;


ALTER FUNCTION public.datastreams_update_delete() OWNER TO sensorthings;

--
-- TOC entry 1187 (class 1255 OID 19806)
-- Name: datastreams_update_insert(); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.datastreams_update_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
declare
    "DS_ROW" RECORD;
    queryset TEXT := '';
    delimitr char(1) := ' ';
begin

if (NEW."DATASTREAM_ID" is not null)
then
    select "ID","PHENOMENON_TIME_START","PHENOMENON_TIME_END","RESULT_TIME_START","RESULT_TIME_END","OBSERVED_AREA","LAST_FOI_ID"
        into "DS_ROW" from "DATASTREAMS" where "DATASTREAMS"."ID"=NEW."DATASTREAM_ID";
    if (NEW."PHENOMENON_TIME_START"<"DS_ROW"."PHENOMENON_TIME_START" or "DS_ROW"."PHENOMENON_TIME_START" is null) then
        queryset := queryset || delimitr || '"PHENOMENON_TIME_START" = $1."PHENOMENON_TIME_START"';
        delimitr := ',';
    end if;
    if (coalesce(NEW."PHENOMENON_TIME_END", NEW."PHENOMENON_TIME_START") > "DS_ROW"."PHENOMENON_TIME_END" or "DS_ROW"."PHENOMENON_TIME_END" is null) then
        queryset := queryset || delimitr || '"PHENOMENON_TIME_END" = coalesce($1."PHENOMENON_TIME_END", $1."PHENOMENON_TIME_START")';
        delimitr := ',';
    end if;

    if (NEW."RESULT_TIME" is not null) then
        if (NEW."RESULT_TIME"<"DS_ROW"."RESULT_TIME_START" or "DS_ROW"."RESULT_TIME_START" is null) then
            queryset := queryset || delimitr || '"RESULT_TIME_START" = $1."RESULT_TIME"';
            delimitr := ',';
        end if;
        if (NEW."RESULT_TIME" > "DS_ROW"."RESULT_TIME_END" or "DS_ROW"."RESULT_TIME_END" is null) then
            queryset := queryset || delimitr || '"RESULT_TIME_END" = $1."RESULT_TIME"';
            delimitr := ',';
        end if;
    end if;

    if ("DS_ROW"."LAST_FOI_ID" is null or "DS_ROW"."LAST_FOI_ID" != NEW."FEATURE_ID") then
        queryset := queryset || delimitr || '"LAST_FOI_ID" = $1."FEATURE_ID"';
        queryset := queryset || ',"OBSERVED_AREA" = ST_ConvexHull(ST_Collect("OBSERVED_AREA", (select "GEOM" from "FEATURES" where "ID"=$1."FEATURE_ID")))';
        delimitr := ',';
    end if;
    if (delimitr = ',') then
        EXECUTE 'update "DATASTREAMS" SET ' || queryset ||  ' where "DATASTREAMS"."ID"=$1."DATASTREAM_ID"' using NEW;
    end if;
    return new;
end if;

return new;
END
$_$;


ALTER FUNCTION public.datastreams_update_insert() OWNER TO sensorthings;

--
-- TOC entry 1188 (class 1255 OID 19808)
-- Name: datastreams_update_update(); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.datastreams_update_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
declare
    "DS_ROW" "DATASTREAMS"%rowtype;
    queryset TEXT := '';
    delimitr char(1) := ' ';
begin

if (NEW."DATASTREAM_ID" is not null)
then
    if (NEW."PHENOMENON_TIME_START" != OLD."PHENOMENON_TIME_START" or NEW."PHENOMENON_TIME_END" != OLD."PHENOMENON_TIME_END") then
        for "DS_ROW" in select * from "DATASTREAMS" where "ID"=NEW."DATASTREAM_ID"
        loop
            if (NEW."PHENOMENON_TIME_START"<"DS_ROW"."PHENOMENON_TIME_START") then
                queryset := queryset || delimitr || '"PHENOMENON_TIME_START" = $1."PHENOMENON_TIME_START"';
                delimitr := ',';
            elseif (OLD."PHENOMENON_TIME_START" = "DS_ROW"."PHENOMENON_TIME_START") then
                queryset := queryset || delimitr || '"PHENOMENON_TIME_START" = (select min("PHENOMENON_TIME_START") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
                delimitr := ',';
            end if;
            if (coalesce(NEW."PHENOMENON_TIME_END", NEW."PHENOMENON_TIME_START") > "DS_ROW"."PHENOMENON_TIME_END") then
                queryset := queryset || delimitr || '"PHENOMENON_TIME_END" = coalesce($1."PHENOMENON_TIME_END", $1."PHENOMENON_TIME_START")';
                delimitr := ',';
            elseif (coalesce(OLD."PHENOMENON_TIME_END", OLD."PHENOMENON_TIME_START") = "DS_ROW"."PHENOMENON_TIME_END") then
                queryset := queryset || delimitr || '"PHENOMENON_TIME_END" = (select max(coalesce("PHENOMENON_TIME_END", "PHENOMENON_TIME_START")) from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
                delimitr := ',';
            end if;
        end loop;
    end if;


    if (NEW."RESULT_TIME" != OLD."RESULT_TIME") then
        for "DS_ROW" in select * from "DATASTREAMS" where "ID"=NEW."DATASTREAM_ID"
        loop
            if (NEW."RESULT_TIME" < "DS_ROW"."RESULT_TIME_START") then
                queryset := queryset || delimitr || '"RESULT_TIME_START" = $1."RESULT_TIME"';
                delimitr := ',';
            elseif (OLD."RESULT_TIME" = "DS_ROW"."RESULT_TIME_START") then
                queryset := queryset || delimitr || '"RESULT_TIME_START" = (select min("RESULT_TIME") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
                delimitr := ',';
            end if;
            if (NEW."RESULT_TIME" > "DS_ROW"."RESULT_TIME_END") then
                queryset := queryset || delimitr || '"RESULT_TIME_END" = $1."RESULT_TIME"';
                delimitr := ',';
            elseif (OLD."RESULT_TIME" = "DS_ROW"."RESULT_TIME_END") then
                queryset := queryset || delimitr || '"RESULT_TIME_END" = (select max("RESULT_TIME") from "OBSERVATIONS" where "OBSERVATIONS"."DATASTREAM_ID" = $1."DATASTREAM_ID")';
                delimitr := ',';
            end if;
        end loop;
    end if;
    if (delimitr = ',') then
        EXECUTE 'update "DATASTREAMS" SET ' || queryset ||  ' where "DATASTREAMS"."ID"=$1."DATASTREAM_ID"' using NEW;
    end if;
end if;


return new;
END
$_$;


ALTER FUNCTION public.datastreams_update_update() OWNER TO sensorthings;

--
-- TOC entry 1185 (class 1255 OID 19625)
-- Name: safe_cast_to_boolean(jsonb); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.safe_cast_to_boolean(v_input jsonb) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE v_bool_value BOOLEAN DEFAULT NULL;
BEGIN
    IF jsonb_typeof(v_input) = 'boolean' THEN
        RETURN (v_input#>>'{}')::boolean;
    ELSE
        RETURN NULL;
    END IF;
END;
$$;


ALTER FUNCTION public.safe_cast_to_boolean(v_input jsonb) OWNER TO sensorthings;

--
-- TOC entry 1184 (class 1255 OID 19624)
-- Name: safe_cast_to_numeric(jsonb); Type: FUNCTION; Schema: public; Owner: sensorthings
--

CREATE FUNCTION public.safe_cast_to_numeric(v_input jsonb) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE v_num_value NUMERIC DEFAULT NULL;
BEGIN
    IF jsonb_typeof(v_input) = 'number' THEN
        RETURN (v_input#>>'{}')::numeric;
    ELSE
        RETURN NULL;
    END IF;
END;
$$;


ALTER FUNCTION public.safe_cast_to_numeric(v_input jsonb) OWNER TO sensorthings;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 280 (class 1259 OID 19627)
-- Name: DATASTREAMS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."DATASTREAMS" (
    "NAME" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "OBSERVATION_TYPE" text,
    "PHENOMENON_TIME_START" timestamp with time zone,
    "PHENOMENON_TIME_END" timestamp with time zone,
    "RESULT_TIME_START" timestamp with time zone,
    "RESULT_TIME_END" timestamp with time zone,
    "OBSERVED_AREA" public.geometry(Geometry,4326),
    "SENSOR_ID" bigint NOT NULL,
    "OBS_PROPERTY_ID" bigint NOT NULL,
    "THING_ID" bigint NOT NULL,
    "UNIT_NAME" character varying(255),
    "UNIT_SYMBOL" character varying(255),
    "UNIT_DEFINITION" character varying(255),
    "LAST_FOI_ID" bigint,
    "ID" bigint NOT NULL
);


ALTER TABLE public."DATASTREAMS" OWNER TO sensorthings;

--
-- TOC entry 281 (class 1259 OID 19632)
-- Name: DATASTREAMS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."DATASTREAMS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."DATASTREAMS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 282 (class 1259 OID 19644)
-- Name: FEATURES; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."FEATURES" (
    "NAME" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "ENCODING_TYPE" text,
    "FEATURE" text,
    "GEOM" public.geometry(Geometry,4326),
    "ID" bigint NOT NULL
);


ALTER TABLE public."FEATURES" OWNER TO sensorthings;

--
-- TOC entry 283 (class 1259 OID 19649)
-- Name: FEATURES_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."FEATURES" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."FEATURES_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 284 (class 1259 OID 19658)
-- Name: HIST_LOCATIONS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."HIST_LOCATIONS" (
    "TIME" timestamp with time zone,
    "THING_ID" bigint NOT NULL,
    "ID" bigint NOT NULL
);


ALTER TABLE public."HIST_LOCATIONS" OWNER TO sensorthings;

--
-- TOC entry 285 (class 1259 OID 19661)
-- Name: HIST_LOCATIONS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."HIST_LOCATIONS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."HIST_LOCATIONS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 286 (class 1259 OID 19669)
-- Name: LOCATIONS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."LOCATIONS" (
    "NAME" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "ENCODING_TYPE" text,
    "LOCATION" text,
    "GEOM" public.geometry(Geometry,4326),
    "GEN_FOI_ID" bigint,
    "ID" bigint NOT NULL
);


ALTER TABLE public."LOCATIONS" OWNER TO sensorthings;

--
-- TOC entry 288 (class 1259 OID 19683)
-- Name: LOCATIONS_HIST_LOCATIONS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."LOCATIONS_HIST_LOCATIONS" (
    "LOCATION_ID" bigint NOT NULL,
    "HIST_LOCATION_ID" bigint NOT NULL
);


ALTER TABLE public."LOCATIONS_HIST_LOCATIONS" OWNER TO sensorthings;

--
-- TOC entry 287 (class 1259 OID 19674)
-- Name: LOCATIONS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."LOCATIONS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."LOCATIONS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 291 (class 1259 OID 19704)
-- Name: OBSERVATIONS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."OBSERVATIONS" (
    "PHENOMENON_TIME_START" timestamp with time zone,
    "PHENOMENON_TIME_END" timestamp with time zone,
    "RESULT_TIME" timestamp with time zone,
    "RESULT_TYPE" smallint,
    "RESULT_NUMBER" double precision,
    "RESULT_BOOLEAN" boolean,
    "RESULT_JSON" jsonb,
    "RESULT_STRING" text,
    "RESULT_QUALITY" jsonb,
    "VALID_TIME_START" timestamp with time zone,
    "VALID_TIME_END" timestamp with time zone,
    "PARAMETERS" jsonb,
    "DATASTREAM_ID" bigint NOT NULL,
    "FEATURE_ID" bigint NOT NULL,
    "ID" bigint NOT NULL
);


ALTER TABLE public."OBSERVATIONS" OWNER TO sensorthings;

--
-- TOC entry 292 (class 1259 OID 19709)
-- Name: OBSERVATIONS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."OBSERVATIONS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."OBSERVATIONS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 289 (class 1259 OID 19690)
-- Name: OBS_PROPERTIES; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."OBS_PROPERTIES" (
    "NAME" text,
    "DEFINITION" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "ID" bigint NOT NULL
);


ALTER TABLE public."OBS_PROPERTIES" OWNER TO sensorthings;

--
-- TOC entry 290 (class 1259 OID 19695)
-- Name: OBS_PROPERTIES_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."OBS_PROPERTIES" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."OBS_PROPERTIES_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 293 (class 1259 OID 19720)
-- Name: SENSORS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."SENSORS" (
    "NAME" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "ENCODING_TYPE" text,
    "METADATA" text,
    "ID" bigint NOT NULL
);


ALTER TABLE public."SENSORS" OWNER TO sensorthings;

--
-- TOC entry 294 (class 1259 OID 19725)
-- Name: SENSORS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."SENSORS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."SENSORS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 295 (class 1259 OID 19734)
-- Name: THINGS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."THINGS" (
    "NAME" text,
    "DESCRIPTION" text,
    "PROPERTIES" jsonb,
    "ID" bigint NOT NULL
);


ALTER TABLE public."THINGS" OWNER TO sensorthings;

--
-- TOC entry 296 (class 1259 OID 19739)
-- Name: THINGS_ID_seq; Type: SEQUENCE; Schema: public; Owner: sensorthings
--

ALTER TABLE public."THINGS" ALTER COLUMN "ID" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."THINGS_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 297 (class 1259 OID 19748)
-- Name: THINGS_LOCATIONS; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public."THINGS_LOCATIONS" (
    "THING_ID" bigint NOT NULL,
    "LOCATION_ID" bigint NOT NULL
);


ALTER TABLE public."THINGS_LOCATIONS" OWNER TO sensorthings;

--
-- TOC entry 279 (class 1259 OID 19619)
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO sensorthings;

--
-- TOC entry 278 (class 1259 OID 19614)
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: sensorthings
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO sensorthings;

--
-- TOC entry 4844 (class 0 OID 19627)
-- Dependencies: 280
-- Data for Name: DATASTREAMS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."DATASTREAMS" ("NAME", "DESCRIPTION", "PROPERTIES", "OBSERVATION_TYPE", "PHENOMENON_TIME_START", "PHENOMENON_TIME_END", "RESULT_TIME_START", "RESULT_TIME_END", "OBSERVED_AREA", "SENSOR_ID", "OBS_PROPERTY_ID", "THING_ID", "UNIT_NAME", "UNIT_SYMBOL", "UNIT_DEFINITION", "LAST_FOI_ID", "ID") FROM stdin;
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/9"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2012-06-22 07:00:00+00	2019-10-22 07:00:00+00	2012-06-22 07:00:00+00	2019-10-22 07:00:00+00	0101000020E610000077BE9F1A2F655AC025068195435B4240	1	1	5	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	5	9
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/10"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2012-06-22 07:00:00+00	2019-10-22 07:00:00+00	2012-06-22 07:00:00+00	2019-10-22 07:00:00+00	0101000020E610000077BE9F1A2F655AC025068195435B4240	1	2	5	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	5	10
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/11"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-04 12:00:00+00	2020-01-09 17:53:00+00	1982-08-04 12:00:00+00	2020-01-09 17:53:00+00	0101000020E610000035EF384547125BC050FC1873D7DA4140	1	1	6	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	6	11
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/13"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-04 12:00:00+00	2020-01-09 17:38:00+00	1982-08-04 12:00:00+00	2020-01-09 17:38:00+00	0101000020E610000035EF384547125BC050FC1873D7DA4140	1	1	7	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	7	13
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/14"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-04 12:00:00+00	2020-01-09 17:38:00+00	1982-08-04 12:00:00+00	2020-01-09 17:38:00+00	0101000020E610000035EF384547125BC050FC1873D7DA4140	1	2	7	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	7	14
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/15"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-05-25 15:39:00+00	2019-12-13 17:10:00+00	2011-05-25 15:39:00+00	2019-12-13 17:10:00+00	0101000020E610000099BB96900F1A5BC07D3F355EBA694240	1	1	8	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	8	15
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/23"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-05 12:00:00+00	2020-01-08 18:38:00+00	1982-08-05 12:00:00+00	2020-01-08 18:38:00+00	0101000020E6100000FF21FDF675FC5AC0BBB88D06F0CE4140	1	1	12	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	12	23
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/24"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-05 12:00:00+00	2020-01-08 18:38:00+00	1982-08-05 12:00:00+00	2020-01-08 18:38:00+00	0101000020E6100000FF21FDF675FC5AC0BBB88D06F0CE4140	1	2	12	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	12	24
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/27"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1969-06-18 12:00:00+00	2018-02-05 23:45:00+00	1969-06-18 12:00:00+00	2018-02-05 23:45:00+00	0101000020E6100000BF0E9C33A2D45AC08CB96B09F9E84140	1	1	14	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	14	27
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/37"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1973-06-11 07:00:00+00	2019-09-24 07:00:00+00	1973-06-11 07:00:00+00	2019-09-24 07:00:00+00	0101000020E610000023DBF97E6A845AC0DE02098A1FCB4140	1	1	19	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	19	37
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/38"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1973-06-11 07:00:00+00	2019-09-24 07:00:00+00	1973-06-11 07:00:00+00	2019-09-24 07:00:00+00	0101000020E610000023DBF97E6A845AC0DE02098A1FCB4140	1	2	19	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	19	38
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/52"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1953-02-20 12:00:00+00	2020-01-06 23:54:00+00	1953-02-20 12:00:00+00	2020-01-06 23:54:00+00	0101000020E610000039454772F9F75AC0A301BC0512944140	1	2	26	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	26	52
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/46"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-06-25 07:00:00+00	2020-03-12 07:00:00+00	1980-06-25 07:00:00+00	2020-03-12 07:00:00+00	0101000020E61000002DB29DEFA7FE5AC04850FC1873074140	1	2	23	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	23	46
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/47"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1944-10-14 12:00:00+00	2020-01-06 23:11:00+00	1944-10-14 12:00:00+00	2020-01-06 23:11:00+00	0101000020E610000051DA1B7C61FA5AC0598638D6C59D4140	1	1	24	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	24	47
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/49"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1977-12-15 07:00:00+00	2020-03-11 07:00:00+00	1977-12-15 07:00:00+00	2020-03-11 07:00:00+00	0101000020E6100000DD24068195EB5AC0DE02098A1F1B4140	1	1	25	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	25	49
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/51"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1953-02-20 12:00:00+00	2020-01-06 23:54:00+00	1953-02-20 12:00:00+00	2020-01-06 23:54:00+00	0101000020E610000039454772F9F75AC0A301BC0512944140	1	1	26	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	26	51
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/53"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-05-02 07:00:00+00	2020-03-11 07:00:00+00	1980-05-02 07:00:00+00	2020-03-11 07:00:00+00	0101000020E6100000560E2DB29DE75AC00C93A98251094140	1	1	27	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	27	53
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/54"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-05-02 07:00:00+00	2020-03-11 07:00:00+00	1980-05-02 07:00:00+00	2020-03-11 07:00:00+00	0101000020E6100000560E2DB29DE75AC00C93A98251094140	1	2	27	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	27	54
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/61"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2013-06-06 07:00:00+00	2020-03-10 07:00:00+00	2013-06-06 07:00:00+00	2020-03-10 07:00:00+00	0101000020E61000004C37894160CD5AC046B6F3FDD4104140	1	1	31	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	31	61
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/63"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1975-07-08 12:00:00+00	2020-02-27 16:40:00+00	1975-07-08 12:00:00+00	2020-02-27 16:40:00+00	0101000020E6100000713D0AD7A3B85AC0931804560E2D4140	1	1	32	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	32	63
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/65"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-10-02 22:33:00+00	2020-06-22 00:00:00+00	1998-10-02 22:33:00+00	2020-06-22 00:00:00+00	0101000020E6100000448B6CE7FBAD5AC0E25817B7D1504140	1	1	33	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	33	65
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/81"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1974-06-25 12:00:00+00	2019-02-01 18:40:00+00	1974-06-25 12:00:00+00	2019-02-01 18:40:00+00	0101000020E61000002041F163CCC15AC05A643BDF4F054040	1	1	41	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	41	81
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/89"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	45	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	89
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/90"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	45	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	90
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/92"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	46	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	92
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/97"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	49	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	97
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/98"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	49	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	98
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/99"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	50	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	99
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/101"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	51	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	101
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/102"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	51	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	102
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/103"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	52	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	103
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/104"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	52	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	104
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/105"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	53	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	105
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/107"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	54	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	107
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/108"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	54	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	108
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/109"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	55	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	109
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/110"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	55	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	110
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/113"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	57	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	113
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/114"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	57	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	114
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/115"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	58	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	115
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/117"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	59	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	117
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/4"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-03-15 07:00:00+00	2019-10-23 07:00:00+00	2011-03-15 07:00:00+00	2019-10-23 07:00:00+00	0101000020E61000007F6ABC7493685AC022FDF675E02C4240	1	2	2	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	2	4
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/6"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-04-21 07:00:00+00	2019-10-23 07:00:00+00	2011-04-21 07:00:00+00	2019-10-23 07:00:00+00	0101000020E6100000A245B6F3FD6C5AC0AF946588632D4240	1	2	3	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	3	6
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/28"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1969-06-18 12:00:00+00	2018-02-05 23:45:00+00	1969-06-18 12:00:00+00	2018-02-05 23:45:00+00	0101000020E6100000BF0E9C33A2D45AC08CB96B09F9E84140	1	2	14	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	14	28
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/33"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-10-09 17:41:00+00	2020-06-21 00:00:00+00	1998-10-09 17:41:00+00	2020-06-21 00:00:00+00	0101000020E61000005DDC460378975AC048BF7D1D38D74140	1	1	17	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	17	33
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/34"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-10-09 17:41:00+00	2020-06-21 00:00:00+00	1998-10-09 17:41:00+00	2020-06-21 00:00:00+00	0101000020E61000005DDC460378975AC048BF7D1D38D74140	1	2	17	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	17	34
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/118"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	59	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	118
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/36"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2003-10-24 12:00:00+00	2020-06-11 15:47:00+00	2003-10-24 12:00:00+00	2020-06-11 15:47:00+00	0101000020E61000008FE4F21FD2875AC0E8D9ACFA5CE54140	1	2	18	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	18	36
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/39"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2004-05-14 12:00:00+00	2020-06-11 19:57:00+00	2004-05-14 12:00:00+00	2020-06-11 19:57:00+00	0101000020E61000008638D6C56D845AC052B81E85EBD14140	1	1	20	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	20	39
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/40"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2004-05-14 12:00:00+00	2020-06-11 19:57:00+00	2004-05-14 12:00:00+00	2020-06-11 19:57:00+00	0101000020E61000008638D6C56D845AC052B81E85EBD14140	1	2	20	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	20	40
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/41"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2005-07-06 12:00:00+00	2020-06-11 19:12:00+00	2005-07-06 12:00:00+00	2020-06-11 19:12:00+00	0101000020E61000009A779CA223855AC0ED0DBE3099DA4140	1	1	21	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	21	41
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/42"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2005-07-06 12:00:00+00	2020-06-11 19:12:00+00	2005-07-06 12:00:00+00	2020-06-11 19:12:00+00	0101000020E61000009A779CA223855AC0ED0DBE3099DA4140	1	2	21	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	21	42
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/44"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1986-09-26 12:00:00+00	2020-04-02 15:37:00+00	1986-09-26 12:00:00+00	2020-04-02 15:37:00+00	0101000020E6100000C4B12E6EA37D5AC0CDCCCCCCCCD44140	1	2	22	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	22	44
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/56"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1949-06-14 12:00:00+00	2017-12-12 18:02:00+00	1949-06-14 12:00:00+00	2017-12-12 18:02:00+00	0101000020E61000008E06F01648F45AC04D158C4AEA8C4140	1	2	28	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	28	56
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/57"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2013-06-17 07:00:00+00	2020-05-29 07:00:00+00	2013-06-17 07:00:00+00	2020-05-29 07:00:00+00	0101000020E6100000E17A14AE47D15AC005A3923A010D4140	1	1	29	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	29	57
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/58"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2013-06-17 07:00:00+00	2020-05-29 07:00:00+00	2013-06-17 07:00:00+00	2020-05-29 07:00:00+00	0101000020E6100000E17A14AE47D15AC005A3923A010D4140	1	2	29	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	29	58
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/60"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1963-08-27 12:00:00+00	2020-01-06 17:09:00+00	1963-08-27 12:00:00+00	2020-01-06 17:09:00+00	0101000020E6100000AAF1D24D62DC5AC0029A081B9E864140	1	2	30	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	30	60
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/62"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2013-06-06 07:00:00+00	2020-03-10 07:00:00+00	2013-06-06 07:00:00+00	2020-03-10 07:00:00+00	0101000020E61000004C37894160CD5AC046B6F3FDD4104140	1	2	31	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	31	62
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/75"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-06-06 16:00:00+00	2020-06-05 00:00:00+00	1997-06-06 16:00:00+00	2020-06-05 00:00:00+00	0101000020E61000006C09F9A067A35AC080B74082E2974140	1	1	38	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	38	75
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/76"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-06-06 16:00:00+00	2020-06-05 00:00:00+00	1997-06-06 16:00:00+00	2020-06-05 00:00:00+00	0101000020E61000006C09F9A067A35AC080B74082E2974140	1	2	38	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	38	76
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/82"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1974-06-25 12:00:00+00	2019-02-01 18:40:00+00	1974-06-25 12:00:00+00	2019-02-01 18:40:00+00	0101000020E61000002041F163CCC15AC05A643BDF4F054040	1	2	41	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	41	82
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/83"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-01-22 12:00:00+00	2019-02-05 22:28:00+00	1982-01-22 12:00:00+00	2019-02-05 22:28:00+00	0101000020E6100000A301BC0512C05AC0E02D90A0F8294040	1	1	42	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	42	83
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/85"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1955-07-07 12:00:00+00	2019-01-29 22:25:00+00	1955-07-07 12:00:00+00	2019-01-29 22:25:00+00	0101000020E6100000A5BDC11726B75AC03D2CD49AE6CD3F40	1	1	43	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	43	85
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/87"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1985-03-06 00:00:00+00	2001-07-01 00:00:00+00	1985-03-06 00:00:00+00	2001-07-01 00:00:00+00	0101000020E61000001D38674469B35AC004560E2DB2254040	1	1	44	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	44	87
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/35"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2003-10-24 12:00:00+00	2020-06-11 15:47:00+00	2003-10-24 12:00:00+00	2020-06-11 15:47:00+00	0101000020E61000008FE4F21FD2875AC0E8D9ACFA5CE54140	1	1	18	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	18	35
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/43"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1986-09-26 12:00:00+00	2020-04-02 15:37:00+00	1986-09-26 12:00:00+00	2020-04-02 15:37:00+00	0101000020E6100000C4B12E6EA37D5AC0CDCCCCCCCCD44140	1	1	22	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	22	43
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/45"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-06-25 07:00:00+00	2020-03-12 07:00:00+00	1980-06-25 07:00:00+00	2020-03-12 07:00:00+00	0101000020E61000002DB29DEFA7FE5AC04850FC1873074140	1	1	23	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	23	45
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/50"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1977-12-15 07:00:00+00	2020-03-11 07:00:00+00	1977-12-15 07:00:00+00	2020-03-11 07:00:00+00	0101000020E6100000DD24068195EB5AC0DE02098A1F1B4140	1	2	25	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	25	50
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/55"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1949-06-14 12:00:00+00	2017-12-12 18:02:00+00	1949-06-14 12:00:00+00	2017-12-12 18:02:00+00	0101000020E61000008E06F01648F45AC04D158C4AEA8C4140	1	1	28	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	28	55
Test Stream	Temperature measurement	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/120"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	5	4	61	Celsius	C	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Celsius	\N	120
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/1"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1954-09-10 12:00:00+00	2019-12-13 21:26:00+00	1954-09-10 12:00:00+00	2019-12-13 21:26:00+00	0101000020E610000032E6AE25E42F5BC03D2CD49AE6D54140	1	1	1	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	1	1
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/5"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-04-21 07:00:00+00	2019-10-23 07:00:00+00	2011-04-21 07:00:00+00	2019-10-23 07:00:00+00	0101000020E6100000A245B6F3FD6C5AC0AF946588632D4240	1	1	3	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	3	5
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/7"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2012-11-07 07:00:00+00	2019-10-22 07:00:00+00	2012-11-07 07:00:00+00	2019-10-22 07:00:00+00	0101000020E6100000F4FDD478E9665AC0FED478E926594240	1	1	4	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	4	7
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/12"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-08-04 12:00:00+00	2020-01-09 17:53:00+00	1982-08-04 12:00:00+00	2020-01-09 17:53:00+00	0101000020E610000035EF384547125BC050FC1873D7DA4140	1	2	6	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	6	12
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/16"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-05-25 15:39:00+00	2019-12-13 17:10:00+00	2011-05-25 15:39:00+00	2019-12-13 17:10:00+00	0101000020E610000099BB96900F1A5BC07D3F355EBA694240	1	2	8	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	8	16
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/25"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1993-09-21 12:00:00+00	2019-12-12 15:35:00+00	1993-09-21 12:00:00+00	2019-12-12 15:35:00+00	0101000020E6100000CBA145B6F3055BC07AC7293A925B4240	1	1	13	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	13	25
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/32"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1999-09-02 16:02:00+00	2020-05-04 18:27:00+00	1999-09-02 16:02:00+00	2020-05-04 18:27:00+00	0101000020E6100000F241CF66D5A35AC0C976BE9F1AA74140	1	2	16	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	16	32
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/64"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1975-07-08 12:00:00+00	2020-02-27 16:40:00+00	1975-07-08 12:00:00+00	2020-02-27 16:40:00+00	0101000020E6100000713D0AD7A3B85AC0931804560E2D4140	1	2	32	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	32	64
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/69"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-08-21 20:13:00+00	2020-06-22 00:00:00+00	1998-08-21 20:13:00+00	2020-06-22 00:00:00+00	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	1	1	35	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	35	69
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/84"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1982-01-22 12:00:00+00	2019-02-05 22:28:00+00	1982-01-22 12:00:00+00	2019-02-05 22:28:00+00	0101000020E6100000A301BC0512C05AC0E02D90A0F8294040	1	2	42	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	42	84
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/86"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1955-07-07 12:00:00+00	2019-01-29 22:25:00+00	1955-07-07 12:00:00+00	2019-01-29 22:25:00+00	0101000020E6100000A5BDC11726B75AC03D2CD49AE6CD3F40	1	2	43	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	43	86
Test Stream	Temperature measurement	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/119"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2021-01-31 01:58:08+00	2021-02-09 15:55:01+00	2021-01-31 01:58:08+00	2021-02-09 15:55:01+00	0101000020E6100000C898BB9690BB53C0D5E76A2BF6FF4140	4	3	60	Celsius	C	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Celsius	45	119
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/71"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-08-21 20:16:00+00	2020-06-22 00:00:00+00	1998-08-21 20:16:00+00	2020-06-22 00:00:00+00	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	1	1	36	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	36	71
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/72"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-08-21 20:16:00+00	2020-06-22 00:00:00+00	1998-08-21 20:16:00+00	2020-06-22 00:00:00+00	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	1	2	36	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	36	72
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/80"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-01-09 12:00:00+00	2020-01-14 21:05:00+00	1980-01-09 12:00:00+00	2020-01-14 21:05:00+00	0101000020E6100000A1D634EF38E559C0B81E85EB51484140	1	2	40	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	40	80
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/88"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1985-03-06 00:00:00+00	2001-07-02 00:00:00+00	1985-03-06 00:00:00+00	2001-07-02 00:00:00+00	0101000020E61000001D38674469B35AC004560E2DB2254040	1	2	44	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	44	88
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/91"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	46	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	91
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/94"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	47	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	94
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/100"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	50	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	100
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/106"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	53	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	106
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/111"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	56	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	111
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/116"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	58	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	116
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/17"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-01-25 20:50:00+00	2019-12-12 22:23:00+00	2011-01-25 20:50:00+00	2019-12-12 22:23:00+00	0101000020E6100000E8D9ACFA5C195BC03A92CB7F48674240	1	1	9	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	9	17
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/19"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1973-06-05 12:00:00+00	2019-12-12 21:05:00+00	1973-06-05 12:00:00+00	2019-12-12 21:05:00+00	0101000020E6100000D34D621058195BC0613255302A694240	1	1	10	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	10	19
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/20"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1973-06-05 12:00:00+00	2019-12-12 21:05:00+00	1973-06-05 12:00:00+00	2019-12-12 21:05:00+00	0101000020E6100000D34D621058195BC0613255302A694240	1	2	10	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	10	20
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/21"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1981-09-21 12:00:00+00	2020-01-08 18:01:00+00	1981-09-21 12:00:00+00	2020-01-08 18:01:00+00	0101000020E6100000780B24287EFC5AC090A0F831E6CE4140	1	1	11	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	11	21
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/48"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1944-10-14 12:00:00+00	2020-01-06 23:11:00+00	1944-10-14 12:00:00+00	2020-01-06 23:11:00+00	0101000020E610000051DA1B7C61FA5AC0598638D6C59D4140	1	2	24	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	24	48
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/66"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-10-02 22:33:00+00	2020-06-22 00:00:00+00	1998-10-02 22:33:00+00	2020-06-22 00:00:00+00	0101000020E6100000448B6CE7FBAD5AC0E25817B7D1504140	1	2	33	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	33	66
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/59"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1963-08-27 12:00:00+00	2020-01-06 17:09:00+00	1963-08-27 12:00:00+00	2020-01-06 17:09:00+00	0101000020E6100000AAF1D24D62DC5AC0029A081B9E864140	1	1	30	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	30	59
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/67"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2001-06-07 12:00:00+00	2020-02-26 17:08:00+00	2001-06-07 12:00:00+00	2020-02-26 17:08:00+00	0101000020E6100000AB3E575BB1B35AC0E63FA4DFBE964140	1	1	34	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	34	67
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/68"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2001-06-07 12:00:00+00	2020-02-26 17:08:00+00	2001-06-07 12:00:00+00	2020-02-26 17:08:00+00	0101000020E6100000AB3E575BB1B35AC0E63FA4DFBE964140	1	2	34	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	34	68
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/77"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2007-12-14 07:00:00+00	2019-11-12 07:00:00+00	2007-12-14 07:00:00+00	2019-11-12 07:00:00+00	0101000020E6100000931804560E755AC012143FC6DCD54040	1	1	39	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	39	77
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/78"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2007-12-14 07:00:00+00	2019-11-12 07:00:00+00	2007-12-14 07:00:00+00	2019-11-12 07:00:00+00	0101000020E6100000931804560E755AC012143FC6DCD54040	1	2	39	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	39	78
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/79"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1980-01-09 12:00:00+00	2020-01-14 21:05:00+00	1980-01-09 12:00:00+00	2020-01-14 21:05:00+00	0101000020E6100000A1D634EF38E559C0B81E85EB51484140	1	1	40	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	40	79
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/93"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	47	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	93
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/95"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	1	48	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	95
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/96"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	48	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	96
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/112"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	\N	\N	\N	\N	\N	1	2	56	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	\N	112
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/2"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1954-09-10 12:00:00+00	2019-12-13 21:26:00+00	1954-09-10 12:00:00+00	2019-12-13 21:26:00+00	0101000020E610000032E6AE25E42F5BC03D2CD49AE6D54140	1	2	1	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	1	2
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/3"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-03-15 07:00:00+00	2019-10-23 07:00:00+00	2011-03-15 07:00:00+00	2019-10-23 07:00:00+00	0101000020E61000007F6ABC7493685AC022FDF675E02C4240	1	1	2	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	2	3
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/8"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2012-11-07 07:00:00+00	2019-10-22 07:00:00+00	2012-11-07 07:00:00+00	2019-10-22 07:00:00+00	0101000020E6100000F4FDD478E9665AC0FED478E926594240	1	2	4	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	4	8
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/18"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	2011-01-25 20:50:00+00	2019-12-12 22:23:00+00	2011-01-25 20:50:00+00	2019-12-12 22:23:00+00	0101000020E6100000E8D9ACFA5C195BC03A92CB7F48674240	1	2	9	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	9	18
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/22"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1981-09-21 12:00:00+00	2020-01-08 18:01:00+00	1981-09-21 12:00:00+00	2020-01-08 18:01:00+00	0101000020E6100000780B24287EFC5AC090A0F831E6CE4140	1	2	11	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	11	22
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/26"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1993-09-21 12:00:00+00	2019-12-12 15:35:00+00	1993-09-21 12:00:00+00	2019-12-12 15:35:00+00	0101000020E6100000CBA145B6F3055BC07AC7293A925B4240	1	2	13	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	13	26
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/29"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-09-10 12:00:00+00	2020-05-19 18:31:00+00	1997-09-10 12:00:00+00	2020-05-19 18:31:00+00	0101000020E6100000569FABADD8AB5AC0545227A089A04140	1	1	15	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	15	29
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/30"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-09-10 12:00:00+00	2020-05-19 18:31:00+00	1997-09-10 12:00:00+00	2020-05-19 18:31:00+00	0101000020E6100000569FABADD8AB5AC0545227A089A04140	1	2	15	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	15	30
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/31"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1999-09-02 16:02:00+00	2020-05-04 18:27:00+00	1999-09-02 16:02:00+00	2020-05-04 18:27:00+00	0101000020E6100000F241CF66D5A35AC0C976BE9F1AA74140	1	1	16	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	16	31
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/70"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1998-08-21 20:13:00+00	2020-06-22 00:00:00+00	1998-08-21 20:13:00+00	2020-06-22 00:00:00+00	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	1	2	35	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	35	70
Depth Below Surface	Estimated depth to water table below ground surface	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/73"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-09-17 17:40:00+00	2020-05-26 14:34:00+00	1997-09-17 17:40:00+00	2020-05-26 14:34:00+00	0101000020E610000088F4DBD781A75AC0D200DE0209824140	1	1	37	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	37	73
Water level (NGVD29)	Measured water level relative to National Geodetic Vertical Datum of 1929	{"uri": "https://geoconnex.us/iow/sta-demo/timeseries/74"}	http://www.opengis.net/def/observationType/OGC-OM/2.0/OM_Measurement	1997-09-17 17:40:00+00	2020-05-26 14:34:00+00	1997-09-17 17:40:00+00	2020-05-26 14:34:00+00	0101000020E610000088F4DBD781A75AC0D200DE0209824140	1	2	37	feet	ft	http://www.qudt.org/qudt/owl/1.0.0/unit/Instances.html#Foot	37	74
\.


--
-- TOC entry 4846 (class 0 OID 19644)
-- Dependencies: 282
-- Data for Name: FEATURES; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."FEATURES" ("NAME", "DESCRIPTION", "PROPERTIES", "ENCODING_TYPE", "FEATURE", "GEOM", "ID") FROM stdin;
FoI for location 5	Generated from location 5	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.581,36.713]}	0101000020E610000077BE9F1A2F655AC025068195435B4240	5
FoI for location 6	Generated from location 6	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.2856,35.7097]}	0101000020E610000035EF384547125BC050FC1873D7DA4140	6
FoI for location 7	Generated from location 7	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.2856,35.7097]}	0101000020E610000035EF384547125BC050FC1873D7DA4140	7
FoI for location 8	Generated from location 8	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.4072,36.826]}	0101000020E610000099BB96900F1A5BC07D3F355EBA694240	8
FoI for location 12	Generated from location 12	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9447,35.6167]}	0101000020E6100000FF21FDF675FC5AC0BBB88D06F0CE4140	12
FoI for location 14	Generated from location 14	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.3224,35.8201]}	0101000020E6100000BF0E9C33A2D45AC08CB96B09F9E84140	14
FoI for location 19	Generated from location 19	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.069,35.5869]}	0101000020E610000023DBF97E6A845AC0DE02098A1FCB4140	19
FoI for location 26	Generated from location 26	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.8746,35.1568]}	0101000020E610000039454772F9F75AC0A301BC0512944140	26
FoI for location 23	Generated from location 23	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.979,34.0582]}	0101000020E61000002DB29DEFA7FE5AC04850FC1873074140	23
FoI for location 24	Generated from location 24	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9122,35.2326]}	0101000020E610000051DA1B7C61FA5AC0598638D6C59D4140	24
FoI for location 25	Generated from location 25	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.681,34.2119]}	0101000020E6100000DD24068195EB5AC0DE02098A1F1B4140	25
FoI for location 27	Generated from location 27	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.619,34.0728]}	0101000020E6100000560E2DB29DE75AC00C93A98251094140	27
FoI for location 31	Generated from location 31	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.209,34.1315]}	0101000020E61000004C37894160CD5AC046B6F3FDD4104140	31
FoI for location 32	Generated from location 32	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.885,34.352]}	0101000020E6100000713D0AD7A3B85AC0931804560E2D4140	32
FoI for location 33	Generated from location 33	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.7185,34.6314]}	0101000020E6100000448B6CE7FBAD5AC0E25817B7D1504140	33
FoI for location 41	Generated from location 41	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.0281,32.0415]}	0101000020E61000002041F163CCC15AC05A643BDF4F054040	41
FoI for location 2	Generated from location 2	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.634,36.3506]}	0101000020E61000007F6ABC7493685AC022FDF675E02C4240	2
FoI for location 3	Generated from location 3	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.703,36.3546]}	0101000020E6100000A245B6F3FD6C5AC0AF946588632D4240	3
FoI for location 17	Generated from location 17	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.3667,35.6814]}	0101000020E61000005DDC460378975AC048BF7D1D38D74140	17
FoI for location 18	Generated from location 18	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.1222,35.7919]}	0101000020E61000008FE4F21FD2875AC0E8D9ACFA5CE54140	18
FoI for location 20	Generated from location 20	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.0692,35.64]}	0101000020E61000008638D6C56D845AC052B81E85EBD14140	20
FoI for location 21	Generated from location 21	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.0803,35.7078]}	0101000020E61000009A779CA223855AC0ED0DBE3099DA4140	21
FoI for location 22	Generated from location 22	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.9631,35.6625]}	0101000020E6100000C4B12E6EA37D5AC0CDCCCCCCCCD44140	22
FoI for location 28	Generated from location 28	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.8169,35.1009]}	0101000020E61000008E06F01648F45AC04D158C4AEA8C4140	28
FoI for location 29	Generated from location 29	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.27,34.1016]}	0101000020E6100000E17A14AE47D15AC005A3923A010D4140	29
FoI for location 30	Generated from location 30	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.4435,35.0517]}	0101000020E6100000AAF1D24D62DC5AC0029A081B9E864140	30
FoI for location 38	Generated from location 38	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.5532,35.1866]}	0101000020E61000006C09F9A067A35AC080B74082E2974140	38
FoI for location 42	Generated from location 42	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.0011,32.3279]}	0101000020E6100000A301BC0512C05AC0E02D90A0F8294040	42
FoI for location 43	Generated from location 43	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8617,31.8043]}	0101000020E6100000A5BDC11726B75AC03D2CD49AE6CD3F40	43
FoI for location 44	Generated from location 44	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8033,32.2945]}	0101000020E61000001D38674469B35AC004560E2DB2254040	44
FoI for location 1	Generated from location 1	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.7483,35.6711]}	0101000020E610000032E6AE25E42F5BC03D2CD49AE6D54140	1
FoI for location 4	Generated from location 4	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.608,36.6965]}	0101000020E6100000F4FDD478E9665AC0FED478E926594240	4
FoI for location 13	Generated from location 13	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.093,36.7154]}	0101000020E6100000CBA145B6F3055BC07AC7293A925B4240	13
FoI for location 16	Generated from location 16	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.5599,35.3055]}	0101000020E6100000F241CF66D5A35AC0C976BE9F1AA74140	16
FoI for location 35	Generated from location 35	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6624,34.7418]}	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	35
FoI for location 60	Generated from location 60	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-78.9307,35.9997]}	0101000020E6100000C898BB9690BB53C0D5E76A2BF6FF4140	45
FoI for location 36	Generated from location 36	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6624,34.7418]}	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	36
FoI for location 40	Generated from location 40	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.5816,34.565]}	0101000020E6100000A1D634EF38E559C0B81E85EB51484140	40
FoI for location 9	Generated from location 9	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.3963,36.8069]}	0101000020E6100000E8D9ACFA5C195BC03A92CB7F48674240	9
FoI for location 10	Generated from location 10	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.396,36.8216]}	0101000020E6100000D34D621058195BC0613255302A694240	10
FoI for location 11	Generated from location 11	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9452,35.6164]}	0101000020E6100000780B24287EFC5AC090A0F831E6CE4140	11
FoI for location 34	Generated from location 34	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8077,35.1777]}	0101000020E6100000AB3E575BB1B35AC0E63FA4DFBE964140	34
FoI for location 39	Generated from location 39	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.829,33.6708]}	0101000020E6100000931804560E755AC012143FC6DCD54040	39
FoI for location 15	Generated from location 15	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6851,35.2542]}	0101000020E6100000569FABADD8AB5AC0545227A089A04140	15
FoI for location 37	Generated from location 37	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6173,35.0159]}	0101000020E610000088F4DBD781A75AC0D200DE0209824140	37
\.


--
-- TOC entry 4848 (class 0 OID 19658)
-- Dependencies: 284
-- Data for Name: HIST_LOCATIONS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."HIST_LOCATIONS" ("TIME", "THING_ID", "ID") FROM stdin;
2020-06-24 17:54:58.153+00	5	5
2020-06-24 17:54:58.21+00	6	6
2020-06-24 17:54:58.268+00	7	7
2020-06-24 17:54:58.339+00	8	8
2020-06-24 17:54:58.553+00	12	12
2020-06-24 17:54:58.664+00	14	14
2020-06-24 17:54:59.016+00	19	19
2020-06-24 17:54:59.388+00	26	26
2020-06-24 17:54:59.233+00	23	23
2020-06-24 17:54:59.285+00	24	24
2020-06-24 17:54:59.339+00	25	25
2020-06-24 17:54:59.434+00	27	27
2020-06-24 17:54:59.635+00	31	31
2020-06-24 17:54:59.69+00	32	32
2020-06-24 17:54:59.741+00	33	33
2020-06-24 17:55:00.168+00	41	41
2020-06-24 17:55:00.371+00	45	45
2020-06-24 17:55:00.415+00	46	46
2020-06-24 17:55:00.581+00	49	49
2020-06-24 17:55:00.625+00	50	50
2020-06-24 17:55:00.676+00	51	51
2020-06-24 17:55:00.745+00	52	52
2020-06-24 17:55:00.785+00	53	53
2020-06-24 17:55:00.835+00	54	54
2020-06-24 17:55:00.881+00	55	55
2020-06-24 17:55:00.983+00	57	57
2020-06-24 17:55:01.031+00	58	58
2020-06-24 17:55:01.083+00	59	59
2022-12-02 16:07:17.435+00	2	2
2022-12-02 16:07:17.593+00	3	3
2022-12-02 16:07:18.585+00	17	17
2022-12-02 16:07:18.711+00	18	18
2022-12-02 16:07:18.762+00	20	20
2022-12-02 16:07:19.885+00	21	62
2022-12-02 16:07:18.8+00	21	21
2022-12-02 16:07:20.043+00	22	63
2022-12-02 16:07:18.891+00	22	22
2022-12-02 16:07:20.121+00	28	64
2022-12-02 16:07:19.019+00	28	28
2022-12-02 16:07:20.152+00	29	65
2022-12-02 16:07:19.055+00	29	29
2022-12-02 16:07:20.198+00	30	66
2022-12-02 16:07:19.071+00	30	30
2022-12-02 16:07:20.267+00	38	67
2022-12-02 16:07:19.154+00	38	38
2022-12-02 16:07:20.458+00	42	68
2022-12-02 16:07:19.196+00	42	42
2022-12-02 16:07:20.491+00	43	69
2022-12-02 16:07:19.209+00	43	43
2022-12-02 16:07:20.532+00	44	70
2022-12-02 16:07:19.217+00	44	44
2022-12-02 16:07:20.835+00	61	71
2022-12-02 16:07:19.713+00	61	61
2022-12-02 16:07:20.842+00	1	72
2022-12-02 16:07:17.256+00	1	1
2022-12-02 16:07:20.882+00	4	73
2022-12-02 16:07:17.818+00	4	4
2022-12-02 16:07:20.981+00	13	74
2022-12-02 16:07:18.316+00	13	13
2022-12-02 16:07:21.016+00	16	75
2022-12-02 16:07:18.485+00	16	16
2022-12-02 16:07:21.158+00	35	76
2022-12-02 16:07:19.116+00	35	35
2022-12-02 16:07:21.304+00	60	77
2022-12-02 16:07:19.618+00	60	60
2022-12-02 16:07:21.378+00	36	78
2022-12-02 16:07:19.124+00	36	36
2022-12-02 16:07:21.529+00	40	79
2022-12-02 16:07:19.176+00	40	40
2022-12-02 16:07:21.696+00	47	80
2022-12-02 16:07:19.239+00	47	47
2022-12-02 16:07:21.716+00	56	81
2022-12-02 16:07:19.41+00	56	56
2022-12-02 16:07:23.065+00	9	82
2022-12-02 16:07:17.912+00	9	9
2022-12-02 16:07:23.093+00	10	83
2022-12-02 16:07:18.026+00	10	10
2022-12-02 16:07:23.142+00	11	84
2022-12-02 16:07:18.069+00	11	11
2022-12-02 16:07:23.435+00	34	85
2022-12-02 16:07:19.102+00	34	34
2022-12-02 16:07:23.548+00	39	86
2022-12-02 16:07:19.162+00	39	39
2022-12-02 16:07:23.694+00	48	87
2022-12-02 16:07:19.277+00	48	48
2022-12-02 16:07:23.939+00	15	88
2022-12-02 16:07:18.437+00	15	15
2022-12-02 16:07:24.259+00	37	89
2022-12-02 16:07:19.139+00	37	37
\.


--
-- TOC entry 4850 (class 0 OID 19669)
-- Dependencies: 286
-- Data for Name: LOCATIONS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."LOCATIONS" ("NAME", "DESCRIPTION", "PROPERTIES", "ENCODING_TYPE", "LOCATION", "GEOM", "GEN_FOI_ID", "ID") FROM stdin;
QU-004	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.581,36.713]}	0101000020E610000077BE9F1A2F655AC025068195435B4240	\N	5
17N.14W.13.1144C	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.2856,35.7097]}	0101000020E610000035EF384547125BC050FC1873D7DA4140	\N	6
17N.14W.13.1144B	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.2856,35.7097]}	0101000020E610000035EF384547125BC050FC1873D7DA4140	\N	7
30N.15W.10.32 G3	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.4072,36.826]}	0101000020E610000099BB96900F1A5BC07D3F355EBA694240	\N	8
16N.10W.18.133B	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9447,35.6167]}	0101000020E6100000FF21FDF675FC5AC0BBB88D06F0CE4140	\N	12
18N.05W.01.1344	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.3224,35.8201]}	0101000020E6100000BF0E9C33A2D45AC08CB96B09F9E84140	\N	14
EB-220	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.069,35.5869]}	0101000020E610000023DBF97E6A845AC0DE02098A1FCB4140	\N	19
11N.10W.27.241	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.8746,35.1568]}	0101000020E610000039454772F9F75AC0A301BC0512944140	\N	26
SA-0034	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.979,34.0582]}	0101000020E61000002DB29DEFA7FE5AC04850FC1873074140	\N	23
12N.10W.32.434	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9122,35.2326]}	0101000020E610000051DA1B7C61FA5AC0598638D6C59D4140	\N	24
SA-0009	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.681,34.2119]}	0101000020E6100000DD24068195EB5AC0DE02098A1F1B4140	\N	25
SA-0076	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.619,34.0728]}	0101000020E6100000560E2DB29DE75AC00C93A98251094140	\N	27
MG-038	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.209,34.1315]}	0101000020E61000004C37894160CD5AC046B6F3FDD4104140	\N	31
02N.01E.31.313 SEVILLETA HQ	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.885,34.352]}	0101000020E6100000713D0AD7A3B85AC0931804560E2D4140	\N	32
05N.03E.28.411A NANCY LOPEZ2	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.7185,34.6314]}	0101000020E6100000448B6CE7FBAD5AC0E25817B7D1504140	\N	33
MBOWN-117 - 26S.02W.15.434	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.0281,32.0415]}	0101000020E61000002041F163CCC15AC05A643BDF4F054040	\N	41
MBOWN-208 - 29S.02E.13.113A	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6997,31.7893]}	0101000020E6100000B84082E2C7AC5AC099BB96900FCA3F40	\N	45
MBOWN-70 - 24S.02E.16.124A (M-4A)	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.7442,32.2257]}	0101000020E6100000BA6B09F9A0AF5AC0865AD3BCE31C4040	\N	46
TB-0029	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.062,33.2699]}	0101000020E61000008716D9CEF7835AC05F984C158CA24040	\N	49
TB-0071	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.0389,33.2103]}	0101000020E61000001FF46C567D825AC0A52C431CEB9A4040	\N	50
SM-0049	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.795,32.8542]}	0101000020E61000007B14AE47E1725AC0211FF46C566D4040	\N	51
17S.14E.08.12111	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.5371,32.8534]}	0101000020E61000009FABADD85F625AC0053411363C6D4040	\N	52
09S.14E.25.34221 FT STANTON CRN WELL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.5307,33.4946]}	0101000020E61000002EFF21FDF6615AC0014D840D4FBF4040	\N	53
SM-0246	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.178,32.8777]}	0101000020E610000008AC1C5A644B5AC07FD93D7958704040	\N	54
18S.26E.06.442221 A	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-104.4133,32.7733]}	0101000020E6100000F5DBD781731A5AC097FF907EFB624040	\N	55
17S.33E.13.34122	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.6191,32.8309]}	0101000020E6100000083D9B559FE759C08A1F63EE5A6A4040	\N	57
14S.35E.28.111133	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.4212,33.082]}	0101000020E6100000D044D8F0F4DA59C0D122DBF97E8A4040	\N	58
11S.32E.24.113222 CAPROCK CRN WELL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.6778,33.3567]}	0101000020E6100000A54E401361EB59C0D93D7958A8AD4040	\N	59
TV-157	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.634,36.3506]}	0101000020E61000007F6ABC7493685AC022FDF675E02C4240	\N	2
TV-196	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.703,36.3546]}	0101000020E6100000A245B6F3FD6C5AC0AF946588632D4240	\N	3
17N.05E.24.344 DOME ROAD CRN WELL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.3667,35.6814]}	0101000020E61000005DDC460378975AC048BF7D1D38D74140	\N	17
T18N.R08E.17.111B  Buckman Well Middle Piezo.	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.1222,35.7919]}	0101000020E61000008FE4F21FD2875AC0E8D9ACFA5CE54140	\N	18
T16N.R08E.2.343B NMOSE County Well-Middle Piez	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.0692,35.64]}	0101000020E61000008638D6C56D845AC052B81E85EBD14140	\N	20
T17N.R08E.15.233B  Las Campanas  Middle Piezo.	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.0803,35.7078]}	0101000020E61000009A779CA223855AC0ED0DBE3099DA4140	\N	21
17N.09E.35.1314B  Santa Fe 1  Middle Piezo.	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.9631,35.6625]}	0101000020E6100000C4B12E6EA37D5AC0CDCCCCCCCCD44140	\N	22
10N.09W.17.113	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.8169,35.1009]}	0101000020E61000008E06F01648F45AC04D158C4AEA8C4140	\N	28
MG-030	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.27,34.1016]}	0101000020E6100000E17A14AE47D15AC005A3923A010D4140	\N	29
10N.06W.35.322 Pueblo Test 1	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.4435,35.0517]}	0101000020E6100000AAF1D24D62DC5AC0029A081B9E864140	\N	30
11N.04E.18.222A NOR ESTE	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.5532,35.1866]}	0101000020E61000006C09F9A067A35AC080B74082E2974140	\N	38
MBOWN-16 - 23S.02W.12.122	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.0011,32.3279]}	0101000020E6100000A301BC0512C05AC0E02D90A0F8294040	\N	42
MBOWN-206 - 29S.01E.08.124	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8617,31.8043]}	0101000020E6100000A5BDC11726B75AC03D2CD49AE6CD3F40	\N	43
MBOWN-33 - 23S.01E.23.244A (LC-3A)	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8033,32.2945]}	0101000020E61000001D38674469B35AC004560E2DB2254040	\N	44
NIEPS	NIEPS Office	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-78.9307,35.9997]}	0101000020E6100000C898BB9690BB53C0D5E76A2BF6FF4140	\N	61
17N.18W.27.332	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.7483,35.6711]}	0101000020E610000032E6AE25E42F5BC03D2CD49AE6D54140	\N	1
QU-100	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.608,36.6965]}	0101000020E6100000F4FDD478E9665AC0FED478E926594240	\N	4
29N.12W.22.1321A LEE ACRES BLM-15	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.093,36.7154]}	0101000020E6100000CBA145B6F3055BC07AC7293A925B4240	\N	13
13N.04E.31.343A BERNALILLO SITE PIEZ 2	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.5599,35.3055]}	0101000020E6100000F241CF66D5A35AC0C976BE9F1AA74140	\N	16
06N.03E.18.442A TOME SITE	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6624,34.7418]}	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	\N	35
NIEPS	NIEPS Office	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-78.9307,35.9997]}	0101000020E6100000C898BB9690BB53C0D5E76A2BF6FF4140	\N	60
06N.03E.18.442B TOME SITE CRN WELL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6624,34.7418]}	0101000020E6100000B537F8C264AA5AC01E166A4DF35E4140	\N	36
04N.32E.22.111114	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.5816,34.565]}	0101000020E6100000A1D634EF38E559C0B81E85EB51484140	\N	40
22S.04E.15.331 BLM CRN WELL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.5303,32.3897]}	0101000020E61000006744696FF0A15AC027A089B0E1314040	\N	47
26S.36E.29.314412 J-4	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-103.292,32.0115]}	0101000020E6100000A69BC420B0D259C0B6F3FDD478014040	\N	56
30N15WS15 2221 GC	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.3963,36.8069]}	0101000020E6100000E8D9ACFA5C195BC03A92CB7F48674240	\N	9
30N.15W.10.4444 GA	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-108.396,36.8216]}	0101000020E6100000D34D621058195BC0613255302A694240	\N	10
16N.10W.18.133D	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-107.9452,35.6164]}	0101000020E6100000780B24287EFC5AC090A0F831E6CE4140	\N	11
11N.01E.14.342 Paradise Road	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.8077,35.1777]}	0101000020E6100000AB3E575BB1B35AC0E63FA4DFBE964140	\N	34
TB-0203	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-105.829,33.6708]}	0101000020E6100000931804560E755AC012143FC6DCD54040	\N	39
TB-0084	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.026,32.8994]}	0101000020E61000008B6CE7FBA9815AC0DE02098A1F734040	\N	48
12N.02E.24.144A LINCOLN MIDDLE SCHOOL	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6851,35.2542]}	0101000020E6100000569FABADD8AB5AC0545227A089A04140	\N	15
09N.03E.10.334A MONTESSA SITE	WELL	\N	application/vnd.geo+json	{"type":"Point","coordinates":[-106.6173,35.0159]}	0101000020E610000088F4DBD781A75AC0D200DE0209824140	\N	37
\.


--
-- TOC entry 4852 (class 0 OID 19683)
-- Dependencies: 288
-- Data for Name: LOCATIONS_HIST_LOCATIONS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."LOCATIONS_HIST_LOCATIONS" ("LOCATION_ID", "HIST_LOCATION_ID") FROM stdin;
5	1
6	2
7	3
8	4
12	9
14	10
19	11
26	13
23	15
24	16
25	17
27	18
31	20
32	21
33	22
41	28
45	29
46	30
49	34
50	35
51	36
52	37
53	38
54	39
55	40
57	42
58	43
59	44
2	47
3	48
17	56
18	60
20	61
21	62
22	63
28	64
29	65
30	66
38	67
42	68
43	69
44	70
61	71
1	72
4	73
13	74
16	75
35	76
60	77
36	78
40	79
47	80
56	81
9	82
10	83
11	84
34	85
39	86
48	87
15	88
37	89
\.


--
-- TOC entry 4855 (class 0 OID 19704)
-- Dependencies: 291
-- Data for Name: OBSERVATIONS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."OBSERVATIONS" ("PHENOMENON_TIME_START", "PHENOMENON_TIME_END", "RESULT_TIME", "RESULT_TYPE", "RESULT_NUMBER", "RESULT_BOOLEAN", "RESULT_JSON", "RESULT_STRING", "RESULT_QUALITY", "VALID_TIME_START", "VALID_TIME_END", "PARAMETERS", "DATASTREAM_ID", "FEATURE_ID", "ID") FROM stdin;
2012-06-22 07:00:00+00	2012-06-22 07:00:00+00	2012-06-22 07:00:00+00	0	7475	\N	\N	7475	\N	\N	\N	\N	9	5	156
2012-12-13 07:00:00+00	2012-12-13 07:00:00+00	2012-12-13 07:00:00+00	0	7472	\N	\N	7472	\N	\N	\N	\N	9	5	158
2013-02-15 07:00:00+00	2013-02-15 07:00:00+00	2013-02-15 07:00:00+00	0	7471	\N	\N	7471	\N	\N	\N	\N	9	5	160
2013-04-27 07:00:00+00	2013-04-27 07:00:00+00	2013-04-27 07:00:00+00	0	7471	\N	\N	7471	\N	\N	\N	\N	9	5	162
2013-06-23 07:00:00+00	2013-06-23 07:00:00+00	2013-06-23 07:00:00+00	0	7472	\N	\N	7472	\N	\N	\N	\N	9	5	164
2013-09-20 07:00:00+00	2013-09-20 07:00:00+00	2013-09-20 07:00:00+00	0	7471	\N	\N	7471	\N	\N	\N	\N	9	5	166
2013-12-16 07:00:00+00	2013-12-16 07:00:00+00	2013-12-16 07:00:00+00	0	7471	\N	\N	7471	\N	\N	\N	\N	9	5	168
2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	0	7472	\N	\N	7472	\N	\N	\N	\N	9	5	170
2014-07-01 07:00:00+00	2014-07-01 07:00:00+00	2014-07-01 07:00:00+00	0	7476	\N	\N	7476	\N	\N	\N	\N	9	5	172
2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	0	7474	\N	\N	7474	\N	\N	\N	\N	9	5	174
2014-12-09 07:00:00+00	2014-12-09 07:00:00+00	2014-12-09 07:00:00+00	0	7474	\N	\N	7474	\N	\N	\N	\N	9	5	176
2015-03-17 07:00:00+00	2015-03-17 07:00:00+00	2015-03-17 07:00:00+00	0	7473	\N	\N	7473	\N	\N	\N	\N	9	5	178
2015-06-03 07:00:00+00	2015-06-03 07:00:00+00	2015-06-03 07:00:00+00	0	7475	\N	\N	7475	\N	\N	\N	\N	9	5	180
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	7473	\N	\N	7473	\N	\N	\N	\N	9	5	182
2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	0	7472	\N	\N	7472	\N	\N	\N	\N	9	5	184
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	7472	\N	\N	7472	\N	\N	\N	\N	9	5	186
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	7473	\N	\N	7473	\N	\N	\N	\N	9	5	188
2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	0	7473	\N	\N	7473	\N	\N	\N	\N	9	5	190
2012-06-22 07:00:00+00	2012-06-22 07:00:00+00	2012-06-22 07:00:00+00	0	49.35	\N	\N	49.35	\N	\N	\N	\N	10	5	155
2012-12-13 07:00:00+00	2012-12-13 07:00:00+00	2012-12-13 07:00:00+00	0	52.14	\N	\N	52.14	\N	\N	\N	\N	10	5	157
2013-02-15 07:00:00+00	2013-02-15 07:00:00+00	2013-02-15 07:00:00+00	0	52.83	\N	\N	52.83	\N	\N	\N	\N	10	5	159
2013-04-27 07:00:00+00	2013-04-27 07:00:00+00	2013-04-27 07:00:00+00	0	53.21	\N	\N	53.21	\N	\N	\N	\N	10	5	161
2013-06-23 07:00:00+00	2013-06-23 07:00:00+00	2013-06-23 07:00:00+00	0	52.24	\N	\N	52.24	\N	\N	\N	\N	10	5	163
2013-09-20 07:00:00+00	2013-09-20 07:00:00+00	2013-09-20 07:00:00+00	0	53.21	\N	\N	53.21	\N	\N	\N	\N	10	5	165
2013-12-16 07:00:00+00	2013-12-16 07:00:00+00	2013-12-16 07:00:00+00	0	53.47	\N	\N	53.47	\N	\N	\N	\N	10	5	167
2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	0	52.12	\N	\N	52.12	\N	\N	\N	\N	10	5	169
2014-07-01 07:00:00+00	2014-07-01 07:00:00+00	2014-07-01 07:00:00+00	0	48.23	\N	\N	48.23	\N	\N	\N	\N	10	5	171
2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	0	49.55	\N	\N	49.55	\N	\N	\N	\N	10	5	173
2014-12-09 07:00:00+00	2014-12-09 07:00:00+00	2014-12-09 07:00:00+00	0	50.25	\N	\N	50.25	\N	\N	\N	\N	10	5	175
2015-03-17 07:00:00+00	2015-03-17 07:00:00+00	2015-03-17 07:00:00+00	0	51.15	\N	\N	51.15	\N	\N	\N	\N	10	5	177
2015-06-03 07:00:00+00	2015-06-03 07:00:00+00	2015-06-03 07:00:00+00	0	48.7	\N	\N	48.7	\N	\N	\N	\N	10	5	179
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	51.19	\N	\N	51.19	\N	\N	\N	\N	10	5	181
2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	0	51.63	\N	\N	51.63	\N	\N	\N	\N	10	5	183
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	52.02	\N	\N	52.02	\N	\N	\N	\N	10	5	185
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	50.66	\N	\N	50.66	\N	\N	\N	\N	10	5	187
2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	0	51.09	\N	\N	51.09	\N	\N	\N	\N	10	5	189
1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	0	6681.5	\N	\N	6681.5	\N	\N	\N	\N	11	6	192
1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	0	6675.3	\N	\N	6675.3	\N	\N	\N	\N	11	6	194
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	6670.2	\N	\N	6670.2	\N	\N	\N	\N	11	6	196
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	6662.8	\N	\N	6662.8	\N	\N	\N	\N	11	6	198
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	6658.8	\N	\N	6658.8	\N	\N	\N	\N	11	6	200
1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	0	6656.3	\N	\N	6656.3	\N	\N	\N	\N	11	6	202
1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	0	6655.3	\N	\N	6655.3	\N	\N	\N	\N	11	6	204
1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	0	6651.4	\N	\N	6651.4	\N	\N	\N	\N	11	6	206
1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	0	6647.7	\N	\N	6647.7	\N	\N	\N	\N	11	6	208
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	6646.1	\N	\N	6646.1	\N	\N	\N	\N	11	6	210
1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	0	6642.8	\N	\N	6642.8	\N	\N	\N	\N	11	6	212
1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	0	6641.1	\N	\N	6641.1	\N	\N	\N	\N	11	6	214
1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	0	6638.6	\N	\N	6638.6	\N	\N	\N	\N	11	6	216
1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	0	6641	\N	\N	6641	\N	\N	\N	\N	11	6	218
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	6635.5	\N	\N	6635.5	\N	\N	\N	\N	11	6	220
1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	0	6634.1	\N	\N	6634.1	\N	\N	\N	\N	11	6	222
1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	0	6632.3	\N	\N	6632.3	\N	\N	\N	\N	11	6	224
1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	0	6632	\N	\N	6632	\N	\N	\N	\N	11	6	226
1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	0	6631.6	\N	\N	6631.6	\N	\N	\N	\N	11	6	228
1994-03-19 12:00:00+00	1994-03-19 12:00:00+00	1994-03-19 12:00:00+00	0	6631.5	\N	\N	6631.5	\N	\N	\N	\N	11	6	230
1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	0	6631.4	\N	\N	6631.4	\N	\N	\N	\N	11	6	232
1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	0	6631.4	\N	\N	6631.4	\N	\N	\N	\N	11	6	234
1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	0	6631.4	\N	\N	6631.4	\N	\N	\N	\N	11	6	236
1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	0	6631.7	\N	\N	6631.7	\N	\N	\N	\N	11	6	238
1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	0	6631.8	\N	\N	6631.8	\N	\N	\N	\N	11	6	240
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	6632.2	\N	\N	6632.2	\N	\N	\N	\N	11	6	242
1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	0	6632.2	\N	\N	6632.2	\N	\N	\N	\N	11	6	244
1998-02-23 12:00:00+00	1998-02-23 12:00:00+00	1998-02-23 12:00:00+00	0	6632.7	\N	\N	6632.7	\N	\N	\N	\N	11	6	246
1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	0	6632.7	\N	\N	6632.7	\N	\N	\N	\N	11	6	248
1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	0	6632.7	\N	\N	6632.7	\N	\N	\N	\N	11	6	250
1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	0	6633	\N	\N	6633	\N	\N	\N	\N	11	6	252
1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	0	6633.2	\N	\N	6633.2	\N	\N	\N	\N	11	6	254
2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	0	6633.5	\N	\N	6633.5	\N	\N	\N	\N	11	6	256
2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	0	6633.5	\N	\N	6633.5	\N	\N	\N	\N	11	6	258
2001-02-07 22:25:00+00	2001-02-07 22:25:00+00	2001-02-07 22:25:00+00	0	6634.1	\N	\N	6634.1	\N	\N	\N	\N	11	6	260
2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	0	6633.7	\N	\N	6633.7	\N	\N	\N	\N	11	6	262
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	6633.7	\N	\N	6633.7	\N	\N	\N	\N	11	6	264
2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	0	6633.8	\N	\N	6633.8	\N	\N	\N	\N	11	6	266
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	6634	\N	\N	6634	\N	\N	\N	\N	11	6	268
2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	0	6633.9	\N	\N	6633.9	\N	\N	\N	\N	11	6	270
2004-03-03 20:47:00+00	2004-03-03 20:47:00+00	2004-03-03 20:47:00+00	0	6634.1	\N	\N	6634.1	\N	\N	\N	\N	11	6	272
2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	0	6633.8	\N	\N	6633.8	\N	\N	\N	\N	11	6	274
2005-03-09 12:00:00+00	2005-03-09 12:00:00+00	2005-03-09 12:00:00+00	0	6633.7	\N	\N	6633.7	\N	\N	\N	\N	11	6	276
2005-09-21 17:25:00+00	2005-09-21 17:25:00+00	2005-09-21 17:25:00+00	0	6633.7	\N	\N	6633.7	\N	\N	\N	\N	11	6	278
2006-02-15 17:31:00+00	2006-02-15 17:31:00+00	2006-02-15 17:31:00+00	0	6634	\N	\N	6634	\N	\N	\N	\N	11	6	280
2007-02-13 19:18:00+00	2007-02-13 19:18:00+00	2007-02-13 19:18:00+00	0	6633.9	\N	\N	6633.9	\N	\N	\N	\N	11	6	282
2007-08-09 19:30:00+00	2007-08-09 19:30:00+00	2007-08-09 19:30:00+00	0	6634.2	\N	\N	6634.2	\N	\N	\N	\N	11	6	284
2008-03-06 23:45:00+00	2008-03-06 23:45:00+00	2008-03-06 23:45:00+00	0	6634.1	\N	\N	6634.1	\N	\N	\N	\N	11	6	286
2008-08-11 22:55:00+00	2008-08-11 22:55:00+00	2008-08-11 22:55:00+00	0	6633.8	\N	\N	6633.8	\N	\N	\N	\N	11	6	288
2009-03-25 15:20:00+00	2009-03-25 15:20:00+00	2009-03-25 15:20:00+00	0	6633.9	\N	\N	6633.9	\N	\N	\N	\N	11	6	290
2009-08-04 21:00:00+00	2009-08-04 21:00:00+00	2009-08-04 21:00:00+00	0	6634.6	\N	\N	6634.6	\N	\N	\N	\N	11	6	292
2010-03-18 19:15:00+00	2010-03-18 19:15:00+00	2010-03-18 19:15:00+00	0	6633.1	\N	\N	6633.1	\N	\N	\N	\N	11	6	294
2010-09-01 22:40:00+00	2010-09-01 22:40:00+00	2010-09-01 22:40:00+00	0	6632.8	\N	\N	6632.8	\N	\N	\N	\N	11	6	296
2011-03-10 01:00:00+00	2011-03-10 01:00:00+00	2011-03-10 01:00:00+00	0	6632.5	\N	\N	6632.5	\N	\N	\N	\N	11	6	298
2011-08-02 19:53:00+00	2011-08-02 19:53:00+00	2011-08-02 19:53:00+00	0	6632.5	\N	\N	6632.5	\N	\N	\N	\N	11	6	300
2012-03-13 23:00:00+00	2012-03-13 23:00:00+00	2012-03-13 23:00:00+00	0	6628.6	\N	\N	6628.6	\N	\N	\N	\N	11	6	302
2012-07-19 21:15:00+00	2012-07-19 21:15:00+00	2012-07-19 21:15:00+00	0	6632.5	\N	\N	6632.5	\N	\N	\N	\N	11	6	304
2013-04-04 19:30:00+00	2013-04-04 19:30:00+00	2013-04-04 19:30:00+00	0	6632.9	\N	\N	6632.9	\N	\N	\N	\N	11	6	306
2013-08-15 21:40:00+00	2013-08-15 21:40:00+00	2013-08-15 21:40:00+00	0	6632.9	\N	\N	6632.9	\N	\N	\N	\N	11	6	308
2014-03-20 18:10:00+00	2014-03-20 18:10:00+00	2014-03-20 18:10:00+00	0	6633	\N	\N	6633	\N	\N	\N	\N	11	6	310
2014-08-08 21:10:00+00	2014-08-08 21:10:00+00	2014-08-08 21:10:00+00	0	6636.4	\N	\N	6636.4	\N	\N	\N	\N	11	6	312
2015-02-27 21:45:00+00	2015-02-27 21:45:00+00	2015-02-27 21:45:00+00	0	6632.7	\N	\N	6632.7	\N	\N	\N	\N	11	6	314
2015-07-23 17:15:00+00	2015-07-23 17:15:00+00	2015-07-23 17:15:00+00	0	6633.6	\N	\N	6633.6	\N	\N	\N	\N	11	6	316
2016-02-24 21:30:00+00	2016-02-24 21:30:00+00	2016-02-24 21:30:00+00	0	6633.8	\N	\N	6633.8	\N	\N	\N	\N	11	6	318
2016-07-27 18:15:00+00	2016-07-27 18:15:00+00	2016-07-27 18:15:00+00	0	6634.6	\N	\N	6634.6	\N	\N	\N	\N	11	6	320
2016-08-11 01:42:00+00	2016-08-11 01:42:00+00	2016-08-11 01:42:00+00	0	6628.7	\N	\N	6628.7	\N	\N	\N	\N	11	6	322
2017-03-31 21:04:00+00	2017-03-31 21:04:00+00	2017-03-31 21:04:00+00	0	6634.7	\N	\N	6634.7	\N	\N	\N	\N	11	6	324
2017-08-02 19:32:00+00	2017-08-02 19:32:00+00	2017-08-02 19:32:00+00	0	6634.6	\N	\N	6634.6	\N	\N	\N	\N	11	6	326
2018-02-07 22:47:00+00	2018-02-07 22:47:00+00	2018-02-07 22:47:00+00	0	6634.9	\N	\N	6634.9	\N	\N	\N	\N	11	6	328
2019-03-25 23:57:00+00	2019-03-25 23:57:00+00	2019-03-25 23:57:00+00	0	6635.7	\N	\N	6635.7	\N	\N	\N	\N	11	6	330
2020-01-09 17:53:00+00	2020-01-09 17:53:00+00	2020-01-09 17:53:00+00	0	6636.1	\N	\N	6636.1	\N	\N	\N	\N	11	6	332
1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	0	6424.7	\N	\N	6424.7	\N	\N	\N	\N	13	7	334
1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	0	6413.3	\N	\N	6413.3	\N	\N	\N	\N	13	7	336
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	6414	\N	\N	6414	\N	\N	\N	\N	13	7	338
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	6410.5	\N	\N	6410.5	\N	\N	\N	\N	13	7	340
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	6409.7	\N	\N	6409.7	\N	\N	\N	\N	13	7	342
1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	0	6408.7	\N	\N	6408.7	\N	\N	\N	\N	13	7	344
1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	0	6408.4	\N	\N	6408.4	\N	\N	\N	\N	13	7	346
1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	0	6407.4	\N	\N	6407.4	\N	\N	\N	\N	13	7	348
1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	0	6406.7	\N	\N	6406.7	\N	\N	\N	\N	13	7	350
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	6407.8	\N	\N	6407.8	\N	\N	\N	\N	13	7	352
1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	0	6413	\N	\N	6413	\N	\N	\N	\N	13	7	354
1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	0	6418.6	\N	\N	6418.6	\N	\N	\N	\N	13	7	356
1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	0	6432.6	\N	\N	6432.6	\N	\N	\N	\N	13	7	358
1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	0	6446.2	\N	\N	6446.2	\N	\N	\N	\N	13	7	360
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	6456.6	\N	\N	6456.6	\N	\N	\N	\N	13	7	362
1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	0	6467.2	\N	\N	6467.2	\N	\N	\N	\N	13	7	364
1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	0	6492.4	\N	\N	6492.4	\N	\N	\N	\N	13	7	366
1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	0	6499.9	\N	\N	6499.9	\N	\N	\N	\N	13	7	368
1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	0	6501.7	\N	\N	6501.7	\N	\N	\N	\N	13	7	370
1994-03-10 12:00:00+00	1994-03-10 12:00:00+00	1994-03-10 12:00:00+00	0	6503.2	\N	\N	6503.2	\N	\N	\N	\N	13	7	372
1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	0	6504.9	\N	\N	6504.9	\N	\N	\N	\N	13	7	374
1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	0	6506.6	\N	\N	6506.6	\N	\N	\N	\N	13	7	376
1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	0	6508.4	\N	\N	6508.4	\N	\N	\N	\N	13	7	378
1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	0	6510.2	\N	\N	6510.2	\N	\N	\N	\N	13	7	380
1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	0	6511.7	\N	\N	6511.7	\N	\N	\N	\N	13	7	382
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	6512.8	\N	\N	6512.8	\N	\N	\N	\N	13	7	384
1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	0	6513.6	\N	\N	6513.6	\N	\N	\N	\N	13	7	386
1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	0	6515.2	\N	\N	6515.2	\N	\N	\N	\N	13	7	388
1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	0	6515.3	\N	\N	6515.3	\N	\N	\N	\N	13	7	390
1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	0	6515.8	\N	\N	6515.8	\N	\N	\N	\N	13	7	392
1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	0	6515.9	\N	\N	6515.9	\N	\N	\N	\N	13	7	394
2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	0	6517.1	\N	\N	6517.1	\N	\N	\N	\N	13	7	396
2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	0	6516.4	\N	\N	6516.4	\N	\N	\N	\N	13	7	398
2001-02-07 22:15:00+00	2001-02-07 22:15:00+00	2001-02-07 22:15:00+00	0	6516.5	\N	\N	6516.5	\N	\N	\N	\N	13	7	400
2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	0	6516.7	\N	\N	6516.7	\N	\N	\N	\N	13	7	402
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	6516.4	\N	\N	6516.4	\N	\N	\N	\N	13	7	404
2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	0	6516.9	\N	\N	6516.9	\N	\N	\N	\N	13	7	406
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	6517.5	\N	\N	6517.5	\N	\N	\N	\N	13	7	408
2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	0	6518.1	\N	\N	6518.1	\N	\N	\N	\N	13	7	410
2004-03-03 20:43:00+00	2004-03-03 20:43:00+00	2004-03-03 20:43:00+00	0	6519.3	\N	\N	6519.3	\N	\N	\N	\N	13	7	412
2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	0	6520.2	\N	\N	6520.2	\N	\N	\N	\N	13	7	414
2005-09-21 17:15:00+00	2005-09-21 17:15:00+00	2005-09-21 17:15:00+00	0	6522.3	\N	\N	6522.3	\N	\N	\N	\N	13	7	416
2006-02-15 17:20:00+00	2006-02-15 17:20:00+00	2006-02-15 17:20:00+00	0	6522.8	\N	\N	6522.8	\N	\N	\N	\N	13	7	418
2007-02-13 18:50:00+00	2007-02-13 18:50:00+00	2007-02-13 18:50:00+00	0	6523.9	\N	\N	6523.9	\N	\N	\N	\N	13	7	420
2007-08-09 19:20:00+00	2007-08-09 19:20:00+00	2007-08-09 19:20:00+00	0	6525.2	\N	\N	6525.2	\N	\N	\N	\N	13	7	422
2008-03-06 23:30:00+00	2008-03-06 23:30:00+00	2008-03-06 23:30:00+00	0	6525.9	\N	\N	6525.9	\N	\N	\N	\N	13	7	424
2008-08-11 22:45:00+00	2008-08-11 22:45:00+00	2008-08-11 22:45:00+00	0	6535.4	\N	\N	6535.4	\N	\N	\N	\N	13	7	426
2009-03-25 15:10:00+00	2009-03-25 15:10:00+00	2009-03-25 15:10:00+00	0	6523	\N	\N	6523	\N	\N	\N	\N	13	7	428
2009-08-04 21:10:00+00	2009-08-04 21:10:00+00	2009-08-04 21:10:00+00	0	6533.3	\N	\N	6533.3	\N	\N	\N	\N	13	7	430
2010-03-18 19:00:00+00	2010-03-18 19:00:00+00	2010-03-18 19:00:00+00	0	6520.8	\N	\N	6520.8	\N	\N	\N	\N	13	7	432
2010-09-01 22:30:00+00	2010-09-01 22:30:00+00	2010-09-01 22:30:00+00	0	6519.2	\N	\N	6519.2	\N	\N	\N	\N	13	7	434
2011-03-10 01:10:00+00	2011-03-10 01:10:00+00	2011-03-10 01:10:00+00	0	6530.1	\N	\N	6530.1	\N	\N	\N	\N	13	7	436
2011-08-02 20:04:00+00	2011-08-02 20:04:00+00	2011-08-02 20:04:00+00	0	6526.7	\N	\N	6526.7	\N	\N	\N	\N	13	7	438
2012-03-13 22:40:00+00	2012-03-13 22:40:00+00	2012-03-13 22:40:00+00	0	6528.1	\N	\N	6528.1	\N	\N	\N	\N	13	7	440
2013-04-04 19:40:00+00	2013-04-04 19:40:00+00	2013-04-04 19:40:00+00	0	6527.3	\N	\N	6527.3	\N	\N	\N	\N	13	7	442
2013-08-15 21:30:00+00	2013-08-15 21:30:00+00	2013-08-15 21:30:00+00	0	6529	\N	\N	6529	\N	\N	\N	\N	13	7	444
2014-03-20 18:00:00+00	2014-03-20 18:00:00+00	2014-03-20 18:00:00+00	0	6526.9	\N	\N	6526.9	\N	\N	\N	\N	13	7	446
2014-08-08 21:00:00+00	2014-08-08 21:00:00+00	2014-08-08 21:00:00+00	0	6528.8	\N	\N	6528.8	\N	\N	\N	\N	13	7	448
2015-02-27 21:30:00+00	2015-02-27 21:30:00+00	2015-02-27 21:30:00+00	0	6525.7	\N	\N	6525.7	\N	\N	\N	\N	13	7	450
2015-07-23 17:00:00+00	2015-07-23 17:00:00+00	2015-07-23 17:00:00+00	0	6540.8	\N	\N	6540.8	\N	\N	\N	\N	13	7	452
2016-02-24 21:40:00+00	2016-02-24 21:40:00+00	2016-02-24 21:40:00+00	0	6546.4	\N	\N	6546.4	\N	\N	\N	\N	13	7	454
2016-08-11 01:00:00+00	2016-08-11 01:00:00+00	2016-08-11 01:00:00+00	0	6551	\N	\N	6551	\N	\N	\N	\N	13	7	456
2017-03-31 21:37:00+00	2017-03-31 21:37:00+00	2017-03-31 21:37:00+00	0	6551.3	\N	\N	6551.3	\N	\N	\N	\N	13	7	458
2017-08-02 19:15:00+00	2017-08-02 19:15:00+00	2017-08-02 19:15:00+00	0	6551.1	\N	\N	6551.1	\N	\N	\N	\N	13	7	460
2018-02-07 22:33:00+00	2018-02-07 22:33:00+00	2018-02-07 22:33:00+00	0	6528.9	\N	\N	6528.9	\N	\N	\N	\N	13	7	462
2019-03-21 23:28:00+00	2019-03-21 23:28:00+00	2019-03-21 23:28:00+00	0	6544.4	\N	\N	6544.4	\N	\N	\N	\N	13	7	464
2020-01-09 17:38:00+00	2020-01-09 17:38:00+00	2020-01-09 17:38:00+00	0	6549.4	\N	\N	6549.4	\N	\N	\N	\N	13	7	466
1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	0	332.43	\N	\N	332.43	\N	\N	\N	\N	14	7	333
1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	0	343.85	\N	\N	343.85	\N	\N	\N	\N	14	7	335
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	343.15	\N	\N	343.15	\N	\N	\N	\N	14	7	337
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	346.57	\N	\N	346.57	\N	\N	\N	\N	14	7	339
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	347.43	\N	\N	347.43	\N	\N	\N	\N	14	7	341
1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	0	348.42	\N	\N	348.42	\N	\N	\N	\N	14	7	343
1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	0	348.74	\N	\N	348.74	\N	\N	\N	\N	14	7	345
1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	0	349.69	\N	\N	349.69	\N	\N	\N	\N	14	7	347
1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	0	350.38	\N	\N	350.38	\N	\N	\N	\N	14	7	349
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	349.28	\N	\N	349.28	\N	\N	\N	\N	14	7	351
1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	0	344.08	\N	\N	344.08	\N	\N	\N	\N	14	7	353
1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	0	338.55	\N	\N	338.55	\N	\N	\N	\N	14	7	355
1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	0	324.54	\N	\N	324.54	\N	\N	\N	\N	14	7	357
1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	0	310.89	\N	\N	310.89	\N	\N	\N	\N	14	7	359
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	300.55	\N	\N	300.55	\N	\N	\N	\N	14	7	361
1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	0	289.87	\N	\N	289.87	\N	\N	\N	\N	14	7	363
1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	0	264.72	\N	\N	264.72	\N	\N	\N	\N	14	7	365
1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	0	257.24	\N	\N	257.24	\N	\N	\N	\N	14	7	367
1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	0	255.44	\N	\N	255.44	\N	\N	\N	\N	14	7	369
1994-03-10 12:00:00+00	1994-03-10 12:00:00+00	1994-03-10 12:00:00+00	0	253.94	\N	\N	253.94	\N	\N	\N	\N	14	7	371
1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	0	252.25	\N	\N	252.25	\N	\N	\N	\N	14	7	373
1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	0	250.54	\N	\N	250.54	\N	\N	\N	\N	14	7	375
1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	0	248.75	\N	\N	248.75	\N	\N	\N	\N	14	7	377
1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	0	246.86	\N	\N	246.86	\N	\N	\N	\N	14	7	379
1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	0	245.39	\N	\N	245.39	\N	\N	\N	\N	14	7	381
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	244.32	\N	\N	244.32	\N	\N	\N	\N	14	7	383
1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	0	243.49	\N	\N	243.49	\N	\N	\N	\N	14	7	385
1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	0	241.91	\N	\N	241.91	\N	\N	\N	\N	14	7	387
1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	0	241.83	\N	\N	241.83	\N	\N	\N	\N	14	7	389
1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	0	241.28	\N	\N	241.28	\N	\N	\N	\N	14	7	391
1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	0	241.2	\N	\N	241.2	\N	\N	\N	\N	14	7	393
2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	0	240.05	\N	\N	240.05	\N	\N	\N	\N	14	7	395
2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	0	240.68	\N	\N	240.68	\N	\N	\N	\N	14	7	397
2001-02-07 22:15:00+00	2001-02-07 22:15:00+00	2001-02-07 22:15:00+00	0	240.6	\N	\N	240.6	\N	\N	\N	\N	14	7	399
2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	0	240.39	\N	\N	240.39	\N	\N	\N	\N	14	7	401
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	240.72	\N	\N	240.72	\N	\N	\N	\N	14	7	403
2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	0	240.18	\N	\N	240.18	\N	\N	\N	\N	14	7	405
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	239.63	\N	\N	239.63	\N	\N	\N	\N	14	7	407
2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	0	239	\N	\N	239	\N	\N	\N	\N	14	7	409
2004-03-03 20:43:00+00	2004-03-03 20:43:00+00	2004-03-03 20:43:00+00	0	237.8	\N	\N	237.8	\N	\N	\N	\N	14	7	411
2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	0	236.9	\N	\N	236.9	\N	\N	\N	\N	14	7	413
2005-09-21 17:15:00+00	2005-09-21 17:15:00+00	2005-09-21 17:15:00+00	0	234.76	\N	\N	234.76	\N	\N	\N	\N	14	7	415
2006-02-15 17:20:00+00	2006-02-15 17:20:00+00	2006-02-15 17:20:00+00	0	234.32	\N	\N	234.32	\N	\N	\N	\N	14	7	417
2007-02-13 18:50:00+00	2007-02-13 18:50:00+00	2007-02-13 18:50:00+00	0	233.19	\N	\N	233.19	\N	\N	\N	\N	14	7	419
2007-08-09 19:20:00+00	2007-08-09 19:20:00+00	2007-08-09 19:20:00+00	0	231.91	\N	\N	231.91	\N	\N	\N	\N	14	7	421
2008-03-06 23:30:00+00	2008-03-06 23:30:00+00	2008-03-06 23:30:00+00	0	231.18	\N	\N	231.18	\N	\N	\N	\N	14	7	423
2008-08-11 22:45:00+00	2008-08-11 22:45:00+00	2008-08-11 22:45:00+00	0	221.72	\N	\N	221.72	\N	\N	\N	\N	14	7	425
2009-03-25 15:10:00+00	2009-03-25 15:10:00+00	2009-03-25 15:10:00+00	0	234.09	\N	\N	234.09	\N	\N	\N	\N	14	7	427
2009-08-04 21:10:00+00	2009-08-04 21:10:00+00	2009-08-04 21:10:00+00	0	223.81	\N	\N	223.81	\N	\N	\N	\N	14	7	429
2010-03-18 19:00:00+00	2010-03-18 19:00:00+00	2010-03-18 19:00:00+00	0	236.33	\N	\N	236.33	\N	\N	\N	\N	14	7	431
2010-09-01 22:30:00+00	2010-09-01 22:30:00+00	2010-09-01 22:30:00+00	0	237.87	\N	\N	237.87	\N	\N	\N	\N	14	7	433
2011-03-10 01:10:00+00	2011-03-10 01:10:00+00	2011-03-10 01:10:00+00	0	227.01	\N	\N	227.01	\N	\N	\N	\N	14	7	435
2011-08-02 20:04:00+00	2011-08-02 20:04:00+00	2011-08-02 20:04:00+00	0	230.38	\N	\N	230.38	\N	\N	\N	\N	14	7	437
2012-03-13 22:40:00+00	2012-03-13 22:40:00+00	2012-03-13 22:40:00+00	0	229	\N	\N	229	\N	\N	\N	\N	14	7	439
2013-04-04 19:40:00+00	2013-04-04 19:40:00+00	2013-04-04 19:40:00+00	0	229.8	\N	\N	229.8	\N	\N	\N	\N	14	7	441
2013-08-15 21:30:00+00	2013-08-15 21:30:00+00	2013-08-15 21:30:00+00	0	228.1	\N	\N	228.1	\N	\N	\N	\N	14	7	443
2014-03-20 18:00:00+00	2014-03-20 18:00:00+00	2014-03-20 18:00:00+00	0	230.22	\N	\N	230.22	\N	\N	\N	\N	14	7	445
2014-08-08 21:00:00+00	2014-08-08 21:00:00+00	2014-08-08 21:00:00+00	0	228.28	\N	\N	228.28	\N	\N	\N	\N	14	7	447
2015-02-27 21:30:00+00	2015-02-27 21:30:00+00	2015-02-27 21:30:00+00	0	231.45	\N	\N	231.45	\N	\N	\N	\N	14	7	449
2015-07-23 17:00:00+00	2015-07-23 17:00:00+00	2015-07-23 17:00:00+00	0	216.32	\N	\N	216.32	\N	\N	\N	\N	14	7	451
2016-02-24 21:40:00+00	2016-02-24 21:40:00+00	2016-02-24 21:40:00+00	0	210.68	\N	\N	210.68	\N	\N	\N	\N	14	7	453
2016-08-11 01:00:00+00	2016-08-11 01:00:00+00	2016-08-11 01:00:00+00	0	206.12	\N	\N	206.12	\N	\N	\N	\N	14	7	455
2017-03-31 21:37:00+00	2017-03-31 21:37:00+00	2017-03-31 21:37:00+00	0	205.8	\N	\N	205.8	\N	\N	\N	\N	14	7	457
2017-08-02 19:15:00+00	2017-08-02 19:15:00+00	2017-08-02 19:15:00+00	0	205.99	\N	\N	205.99	\N	\N	\N	\N	14	7	459
2018-02-07 22:33:00+00	2018-02-07 22:33:00+00	2018-02-07 22:33:00+00	0	228.16	\N	\N	228.16	\N	\N	\N	\N	14	7	461
2019-03-21 23:28:00+00	2019-03-21 23:28:00+00	2019-03-21 23:28:00+00	0	212.7	\N	\N	212.7	\N	\N	\N	\N	14	7	463
2020-01-09 17:38:00+00	2020-01-09 17:38:00+00	2020-01-09 17:38:00+00	0	207.66	\N	\N	207.66	\N	\N	\N	\N	14	7	465
2011-05-25 15:39:00+00	2011-05-25 15:39:00+00	2011-05-25 15:39:00+00	0	5170.24	\N	\N	5170.24	\N	\N	\N	\N	15	8	468
2011-06-22 19:10:00+00	2011-06-22 19:10:00+00	2011-06-22 19:10:00+00	0	5170.21	\N	\N	5170.21	\N	\N	\N	\N	15	8	470
2011-07-26 21:00:00+00	2011-07-26 21:00:00+00	2011-07-26 21:00:00+00	0	5170.38	\N	\N	5170.38	\N	\N	\N	\N	15	8	472
2011-09-01 18:10:00+00	2011-09-01 18:10:00+00	2011-09-01 18:10:00+00	0	5170.4	\N	\N	5170.4	\N	\N	\N	\N	15	8	474
2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	0	5169.73	\N	\N	5169.73	\N	\N	\N	\N	15	8	476
2011-11-08 21:45:00+00	2011-11-08 21:45:00+00	2011-11-08 21:45:00+00	0	5169.82	\N	\N	5169.82	\N	\N	\N	\N	15	8	478
2011-12-08 16:30:00+00	2011-12-08 16:30:00+00	2011-12-08 16:30:00+00	0	5169.78	\N	\N	5169.78	\N	\N	\N	\N	15	8	480
2012-01-10 16:40:00+00	2012-01-10 16:40:00+00	2012-01-10 16:40:00+00	0	5169.98	\N	\N	5169.98	\N	\N	\N	\N	15	8	482
2012-02-07 23:30:00+00	2012-02-07 23:30:00+00	2012-02-07 23:30:00+00	0	5170.03	\N	\N	5170.03	\N	\N	\N	\N	15	8	484
2012-03-06 22:40:00+00	2012-03-06 22:40:00+00	2012-03-06 22:40:00+00	0	5170.26	\N	\N	5170.26	\N	\N	\N	\N	15	8	486
2012-04-12 22:20:00+00	2012-04-12 22:20:00+00	2012-04-12 22:20:00+00	0	5169.36	\N	\N	5169.36	\N	\N	\N	\N	15	8	488
2012-05-08 22:30:00+00	2012-05-08 22:30:00+00	2012-05-08 22:30:00+00	0	5170.95	\N	\N	5170.95	\N	\N	\N	\N	15	8	490
2012-08-14 23:00:00+00	2012-08-14 23:00:00+00	2012-08-14 23:00:00+00	0	5171.23	\N	\N	5171.23	\N	\N	\N	\N	15	8	492
2012-10-09 17:20:00+00	2012-10-09 17:20:00+00	2012-10-09 17:20:00+00	0	5171.44	\N	\N	5171.44	\N	\N	\N	\N	15	8	494
2013-02-27 00:10:00+00	2013-02-27 00:10:00+00	2013-02-27 00:10:00+00	0	5171.93	\N	\N	5171.93	\N	\N	\N	\N	15	8	496
2013-04-03 16:50:00+00	2013-04-03 16:50:00+00	2013-04-03 16:50:00+00	0	5172	\N	\N	5172	\N	\N	\N	\N	15	8	498
2013-07-10 23:30:00+00	2013-07-10 23:30:00+00	2013-07-10 23:30:00+00	0	5172.21	\N	\N	5172.21	\N	\N	\N	\N	15	8	500
2013-12-11 21:35:00+00	2013-12-11 21:35:00+00	2013-12-11 21:35:00+00	0	5172.76	\N	\N	5172.76	\N	\N	\N	\N	15	8	502
2016-08-12 22:20:00+00	2016-08-12 22:20:00+00	2016-08-12 22:20:00+00	0	5176.42	\N	\N	5176.42	\N	\N	\N	\N	15	8	504
2018-02-06 17:55:00+00	2018-02-06 17:55:00+00	2018-02-06 17:55:00+00	0	5178.04	\N	\N	5178.04	\N	\N	\N	\N	15	8	506
2018-12-18 23:06:00+00	2018-12-18 23:06:00+00	2018-12-18 23:06:00+00	0	5177.85	\N	\N	5177.85	\N	\N	\N	\N	15	8	508
2019-12-13 17:10:00+00	2019-12-13 17:10:00+00	2019-12-13 17:10:00+00	0	5178.09	\N	\N	5178.09	\N	\N	\N	\N	15	8	510
1982-08-05 12:00:00+00	1982-08-05 12:00:00+00	1982-08-05 12:00:00+00	0	6573.5	\N	\N	6573.5	\N	\N	\N	\N	23	12	694
1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	0	6568.84	\N	\N	6568.84	\N	\N	\N	\N	23	12	696
1983-10-22 12:00:00+00	1983-10-22 12:00:00+00	1983-10-22 12:00:00+00	0	6564.15	\N	\N	6564.15	\N	\N	\N	\N	23	12	698
1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	0	6559.4	\N	\N	6559.4	\N	\N	\N	\N	23	12	700
1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	0	6558.92	\N	\N	6558.92	\N	\N	\N	\N	23	12	702
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	6557.6	\N	\N	6557.6	\N	\N	\N	\N	23	12	704
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	6555.91	\N	\N	6555.91	\N	\N	\N	\N	23	12	706
1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	0	6552.8	\N	\N	6552.8	\N	\N	\N	\N	23	12	708
1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	0	6553.55	\N	\N	6553.55	\N	\N	\N	\N	23	12	710
1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	0	6552.54	\N	\N	6552.54	\N	\N	\N	\N	23	12	712
1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	0	6562.08	\N	\N	6562.08	\N	\N	\N	\N	23	12	714
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	6551.32	\N	\N	6551.32	\N	\N	\N	\N	23	12	716
1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	0	6548.57	\N	\N	6548.57	\N	\N	\N	\N	23	12	718
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	6547.37	\N	\N	6547.37	\N	\N	\N	\N	23	12	720
1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	0	6545.28	\N	\N	6545.28	\N	\N	\N	\N	23	12	722
1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	0	6544.22	\N	\N	6544.22	\N	\N	\N	\N	23	12	724
1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	0	6541.91	\N	\N	6541.91	\N	\N	\N	\N	23	12	726
1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	0	6540.95	\N	\N	6540.95	\N	\N	\N	\N	23	12	728
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	6540.54	\N	\N	6540.54	\N	\N	\N	\N	23	12	730
1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	0	6538.82	\N	\N	6538.82	\N	\N	\N	\N	23	12	732
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	6535.03	\N	\N	6535.03	\N	\N	\N	\N	23	12	734
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	6529.66	\N	\N	6529.66	\N	\N	\N	\N	23	12	736
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	6531.05	\N	\N	6531.05	\N	\N	\N	\N	23	12	738
2004-03-03 22:28:00+00	2004-03-03 22:28:00+00	2004-03-03 22:28:00+00	0	6530.72	\N	\N	6530.72	\N	\N	\N	\N	23	12	740
2005-03-07 23:25:00+00	2005-03-07 23:25:00+00	2005-03-07 23:25:00+00	0	6530.4	\N	\N	6530.4	\N	\N	\N	\N	23	12	742
2006-02-14 16:26:00+00	2006-02-14 16:26:00+00	2006-02-14 16:26:00+00	0	6530.43	\N	\N	6530.43	\N	\N	\N	\N	23	12	744
2007-02-13 22:05:00+00	2007-02-13 22:05:00+00	2007-02-13 22:05:00+00	0	6530.94	\N	\N	6530.94	\N	\N	\N	\N	23	12	746
2008-03-04 22:20:00+00	2008-03-04 22:20:00+00	2008-03-04 22:20:00+00	0	6530.35	\N	\N	6530.35	\N	\N	\N	\N	23	12	748
2010-03-17 22:45:00+00	2010-03-17 22:45:00+00	2010-03-17 22:45:00+00	0	6530.4	\N	\N	6530.4	\N	\N	\N	\N	23	12	750
2011-03-09 22:15:00+00	2011-03-09 22:15:00+00	2011-03-09 22:15:00+00	0	6525.37	\N	\N	6525.37	\N	\N	\N	\N	23	12	752
2012-03-13 20:15:00+00	2012-03-13 20:15:00+00	2012-03-13 20:15:00+00	0	6530.35	\N	\N	6530.35	\N	\N	\N	\N	23	12	754
2013-04-04 23:40:00+00	2013-04-04 23:40:00+00	2013-04-04 23:40:00+00	0	6530.31	\N	\N	6530.31	\N	\N	\N	\N	23	12	756
2014-03-20 22:00:00+00	2014-03-20 22:00:00+00	2014-03-20 22:00:00+00	0	6530.83	\N	\N	6530.83	\N	\N	\N	\N	23	12	758
2015-02-28 21:00:00+00	2015-02-28 21:00:00+00	2015-02-28 21:00:00+00	0	6531.65	\N	\N	6531.65	\N	\N	\N	\N	23	12	760
2016-02-25 00:30:00+00	2016-02-25 00:30:00+00	2016-02-25 00:30:00+00	0	6531.49	\N	\N	6531.49	\N	\N	\N	\N	23	12	762
2016-08-10 23:00:00+00	2016-08-10 23:00:00+00	2016-08-10 23:00:00+00	0	6532.42	\N	\N	6532.42	\N	\N	\N	\N	23	12	764
2018-02-08 20:00:00+00	2018-02-08 20:00:00+00	2018-02-08 20:00:00+00	0	6532.41	\N	\N	6532.41	\N	\N	\N	\N	23	12	766
2019-03-07 20:16:00+00	2019-03-07 20:16:00+00	2019-03-07 20:16:00+00	0	6532.92	\N	\N	6532.92	\N	\N	\N	\N	23	12	768
2020-01-08 18:38:00+00	2020-01-08 18:38:00+00	2020-01-08 18:38:00+00	0	6532.68	\N	\N	6532.68	\N	\N	\N	\N	23	12	770
1982-08-05 12:00:00+00	1982-08-05 12:00:00+00	1982-08-05 12:00:00+00	0	350.47	\N	\N	350.47	\N	\N	\N	\N	24	12	693
1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	0	355.13	\N	\N	355.13	\N	\N	\N	\N	24	12	695
1983-10-22 12:00:00+00	1983-10-22 12:00:00+00	1983-10-22 12:00:00+00	0	359.82	\N	\N	359.82	\N	\N	\N	\N	24	12	697
1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	0	364.57	\N	\N	364.57	\N	\N	\N	\N	24	12	699
1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	0	365.05	\N	\N	365.05	\N	\N	\N	\N	24	12	701
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	366.37	\N	\N	366.37	\N	\N	\N	\N	24	12	703
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	368.06	\N	\N	368.06	\N	\N	\N	\N	24	12	705
1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	0	371.17	\N	\N	371.17	\N	\N	\N	\N	24	12	707
1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	0	370.42	\N	\N	370.42	\N	\N	\N	\N	24	12	709
1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	0	371.43	\N	\N	371.43	\N	\N	\N	\N	24	12	711
1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	0	361.89	\N	\N	361.89	\N	\N	\N	\N	24	12	713
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	372.65	\N	\N	372.65	\N	\N	\N	\N	24	12	715
1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	0	375.4	\N	\N	375.4	\N	\N	\N	\N	24	12	717
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	376.6	\N	\N	376.6	\N	\N	\N	\N	24	12	719
1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	0	378.69	\N	\N	378.69	\N	\N	\N	\N	24	12	721
1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	0	379.75	\N	\N	379.75	\N	\N	\N	\N	24	12	723
1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	0	382.06	\N	\N	382.06	\N	\N	\N	\N	24	12	725
1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	0	383.02	\N	\N	383.02	\N	\N	\N	\N	24	12	727
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	383.43	\N	\N	383.43	\N	\N	\N	\N	24	12	729
1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	0	385.15	\N	\N	385.15	\N	\N	\N	\N	24	12	731
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	388.94	\N	\N	388.94	\N	\N	\N	\N	24	12	733
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	394.31	\N	\N	394.31	\N	\N	\N	\N	24	12	735
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	392.92	\N	\N	392.92	\N	\N	\N	\N	24	12	737
2004-03-03 22:28:00+00	2004-03-03 22:28:00+00	2004-03-03 22:28:00+00	0	393.25	\N	\N	393.25	\N	\N	\N	\N	24	12	739
2005-03-07 23:25:00+00	2005-03-07 23:25:00+00	2005-03-07 23:25:00+00	0	393.57	\N	\N	393.57	\N	\N	\N	\N	24	12	741
2006-02-14 16:26:00+00	2006-02-14 16:26:00+00	2006-02-14 16:26:00+00	0	393.54	\N	\N	393.54	\N	\N	\N	\N	24	12	743
2007-02-13 22:05:00+00	2007-02-13 22:05:00+00	2007-02-13 22:05:00+00	0	393.03	\N	\N	393.03	\N	\N	\N	\N	24	12	745
2008-03-04 22:20:00+00	2008-03-04 22:20:00+00	2008-03-04 22:20:00+00	0	393.62	\N	\N	393.62	\N	\N	\N	\N	24	12	747
2010-03-17 22:45:00+00	2010-03-17 22:45:00+00	2010-03-17 22:45:00+00	0	393.57	\N	\N	393.57	\N	\N	\N	\N	24	12	749
2011-03-09 22:15:00+00	2011-03-09 22:15:00+00	2011-03-09 22:15:00+00	0	398.6	\N	\N	398.6	\N	\N	\N	\N	24	12	751
2012-03-13 20:15:00+00	2012-03-13 20:15:00+00	2012-03-13 20:15:00+00	0	393.62	\N	\N	393.62	\N	\N	\N	\N	24	12	753
2013-04-04 23:40:00+00	2013-04-04 23:40:00+00	2013-04-04 23:40:00+00	0	393.66	\N	\N	393.66	\N	\N	\N	\N	24	12	755
2014-03-20 22:00:00+00	2014-03-20 22:00:00+00	2014-03-20 22:00:00+00	0	393.14	\N	\N	393.14	\N	\N	\N	\N	24	12	757
2015-02-28 21:00:00+00	2015-02-28 21:00:00+00	2015-02-28 21:00:00+00	0	392.32	\N	\N	392.32	\N	\N	\N	\N	24	12	759
2016-02-25 00:30:00+00	2016-02-25 00:30:00+00	2016-02-25 00:30:00+00	0	392.48	\N	\N	392.48	\N	\N	\N	\N	24	12	761
2016-08-10 23:00:00+00	2016-08-10 23:00:00+00	2016-08-10 23:00:00+00	0	391.55	\N	\N	391.55	\N	\N	\N	\N	24	12	763
2018-02-08 20:00:00+00	2018-02-08 20:00:00+00	2018-02-08 20:00:00+00	0	391.56	\N	\N	391.56	\N	\N	\N	\N	24	12	765
2019-03-07 20:16:00+00	2019-03-07 20:16:00+00	2019-03-07 20:16:00+00	0	391.05	\N	\N	391.05	\N	\N	\N	\N	24	12	767
2020-01-08 18:38:00+00	2020-01-08 18:38:00+00	2020-01-08 18:38:00+00	0	391.29	\N	\N	391.29	\N	\N	\N	\N	24	12	769
1969-06-18 12:00:00+00	1969-06-18 12:00:00+00	1969-06-18 12:00:00+00	0	6473	\N	\N	6473	\N	\N	\N	\N	27	14	852
1986-06-11 12:00:00+00	1986-06-11 12:00:00+00	1986-06-11 12:00:00+00	0	6448	\N	\N	6448	\N	\N	\N	\N	27	14	854
1997-02-27 12:00:00+00	1997-02-27 12:00:00+00	1997-02-27 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	27	14	856
2002-03-16 12:00:00+00	2002-03-16 12:00:00+00	2002-03-16 12:00:00+00	0	6391	\N	\N	6391	\N	\N	\N	\N	27	14	858
2003-03-21 12:00:00+00	2003-03-21 12:00:00+00	2003-03-21 12:00:00+00	0	6383	\N	\N	6383	\N	\N	\N	\N	27	14	860
2004-03-05 15:25:00+00	2004-03-05 15:25:00+00	2004-03-05 15:25:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	27	14	862
2005-03-07 16:04:00+00	2005-03-07 16:04:00+00	2005-03-07 16:04:00+00	0	6491	\N	\N	6491	\N	\N	\N	\N	27	14	864
2006-02-16 22:30:00+00	2006-02-16 22:30:00+00	2006-02-16 22:30:00+00	0	6472	\N	\N	6472	\N	\N	\N	\N	27	14	866
2007-03-05 18:01:00+00	2007-03-05 18:01:00+00	2007-03-05 18:01:00+00	0	6448	\N	\N	6448	\N	\N	\N	\N	27	14	868
2008-03-24 19:15:00+00	2008-03-24 19:15:00+00	2008-03-24 19:15:00+00	0	6464	\N	\N	6464	\N	\N	\N	\N	27	14	870
2009-03-24 22:23:00+00	2009-03-24 22:23:00+00	2009-03-24 22:23:00+00	0	6467	\N	\N	6467	\N	\N	\N	\N	27	14	872
2010-03-15 20:00:00+00	2010-03-15 20:00:00+00	2010-03-15 20:00:00+00	0	6491	\N	\N	6491	\N	\N	\N	\N	27	14	874
2011-01-24 20:30:00+00	2011-01-24 20:30:00+00	2011-01-24 20:30:00+00	0	6433	\N	\N	6433	\N	\N	\N	\N	27	14	876
2012-03-17 20:30:00+00	2012-03-17 20:30:00+00	2012-03-17 20:30:00+00	0	6432	\N	\N	6432	\N	\N	\N	\N	27	14	878
2013-04-08 22:30:00+00	2013-04-08 22:30:00+00	2013-04-08 22:30:00+00	0	6432	\N	\N	6432	\N	\N	\N	\N	27	14	880
2014-03-17 14:30:00+00	2014-03-17 14:30:00+00	2014-03-17 14:30:00+00	0	6434	\N	\N	6434	\N	\N	\N	\N	27	14	882
2015-02-24 00:00:00+00	2015-02-24 00:00:00+00	2015-02-24 00:00:00+00	0	6488	\N	\N	6488	\N	\N	\N	\N	27	14	884
2016-02-22 21:15:00+00	2016-02-22 21:15:00+00	2016-02-22 21:15:00+00	0	6490	\N	\N	6490	\N	\N	\N	\N	27	14	886
2016-08-29 22:30:00+00	2016-08-29 22:30:00+00	2016-08-29 22:30:00+00	0	6499	\N	\N	6499	\N	\N	\N	\N	27	14	888
2017-08-03 18:47:00+00	2017-08-03 18:47:00+00	2017-08-03 18:47:00+00	0	6489	\N	\N	6489	\N	\N	\N	\N	27	14	890
2018-02-05 23:45:00+00	2018-02-05 23:45:00+00	2018-02-05 23:45:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	27	14	892
1973-06-11 07:00:00+00	1973-06-11 07:00:00+00	1973-06-11 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56210
1974-06-28 07:00:00+00	1974-06-28 07:00:00+00	1974-06-28 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56212
1974-07-02 07:00:00+00	1974-07-02 07:00:00+00	1974-07-02 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56214
1974-10-16 07:00:00+00	1974-10-16 07:00:00+00	1974-10-16 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56216
1975-02-12 07:00:00+00	1975-02-12 07:00:00+00	1975-02-12 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56218
1975-08-05 07:00:00+00	1975-08-05 07:00:00+00	1975-08-05 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56220
1976-02-10 07:00:00+00	1976-02-10 07:00:00+00	1976-02-10 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56222
1976-08-17 07:00:00+00	1976-08-17 07:00:00+00	1976-08-17 07:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	37	19	56224
1977-01-11 07:00:00+00	1977-01-11 07:00:00+00	1977-01-11 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56226
1977-07-25 07:00:00+00	1977-07-25 07:00:00+00	1977-07-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56228
1978-01-11 07:00:00+00	1978-01-11 07:00:00+00	1978-01-11 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56230
1978-02-09 07:00:00+00	1978-02-09 07:00:00+00	1978-02-09 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56232
1978-07-23 07:00:00+00	1978-07-23 07:00:00+00	1978-07-23 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56234
1978-12-13 07:00:00+00	1978-12-13 07:00:00+00	1978-12-13 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56236
1979-01-09 07:00:00+00	1979-01-09 07:00:00+00	1979-01-09 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56238
1979-02-06 07:00:00+00	1979-02-06 07:00:00+00	1979-02-06 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56240
1979-03-07 07:00:00+00	1979-03-07 07:00:00+00	1979-03-07 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56242
1979-04-06 07:00:00+00	1979-04-06 07:00:00+00	1979-04-06 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56244
1979-04-30 07:00:00+00	1979-04-30 07:00:00+00	1979-04-30 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56246
1979-06-02 07:00:00+00	1979-06-02 07:00:00+00	1979-06-02 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56248
1979-07-02 07:00:00+00	1979-07-02 07:00:00+00	1979-07-02 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56250
1979-07-24 07:00:00+00	1979-07-24 07:00:00+00	1979-07-24 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56252
1979-07-25 07:00:00+00	1979-07-25 07:00:00+00	1979-07-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56254
1979-07-31 07:00:00+00	1979-07-31 07:00:00+00	1979-07-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56256
1979-08-05 07:00:00+00	1979-08-05 07:00:00+00	1979-08-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56258
1979-08-10 07:00:00+00	1979-08-10 07:00:00+00	1979-08-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56260
1979-08-15 07:00:00+00	1979-08-15 07:00:00+00	1979-08-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56262
1979-08-20 07:00:00+00	1979-08-20 07:00:00+00	1979-08-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56264
1979-08-23 07:00:00+00	1979-08-23 07:00:00+00	1979-08-23 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56266
1979-08-25 07:00:00+00	1979-08-25 07:00:00+00	1979-08-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56268
1979-08-31 07:00:00+00	1979-08-31 07:00:00+00	1979-08-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56270
1979-09-05 07:00:00+00	1979-09-05 07:00:00+00	1979-09-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56272
1979-09-10 07:00:00+00	1979-09-10 07:00:00+00	1979-09-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56274
1979-09-20 07:00:00+00	1979-09-20 07:00:00+00	1979-09-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56276
1979-09-24 07:00:00+00	1979-09-24 07:00:00+00	1979-09-24 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56278
1979-09-25 07:00:00+00	1979-09-25 07:00:00+00	1979-09-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56280
1979-10-04 07:00:00+00	1979-10-04 07:00:00+00	1979-10-04 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56282
1979-10-05 07:00:00+00	1979-10-05 07:00:00+00	1979-10-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56284
1979-10-10 07:00:00+00	1979-10-10 07:00:00+00	1979-10-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56286
1979-10-15 07:00:00+00	1979-10-15 07:00:00+00	1979-10-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56288
1979-10-20 07:00:00+00	1979-10-20 07:00:00+00	1979-10-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56290
1979-10-23 07:00:00+00	1979-10-23 07:00:00+00	1979-10-23 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56292
1979-10-25 07:00:00+00	1979-10-25 07:00:00+00	1979-10-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56294
1979-10-31 07:00:00+00	1979-10-31 07:00:00+00	1979-10-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56296
1979-11-05 07:00:00+00	1979-11-05 07:00:00+00	1979-11-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56298
1979-11-14 07:00:00+00	1979-11-14 07:00:00+00	1979-11-14 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56300
1979-12-12 07:00:00+00	1979-12-12 07:00:00+00	1979-12-12 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56302
1979-12-15 07:00:00+00	1979-12-15 07:00:00+00	1979-12-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56304
1979-12-20 07:00:00+00	1979-12-20 07:00:00+00	1979-12-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56306
1979-12-25 07:00:00+00	1979-12-25 07:00:00+00	1979-12-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56308
1979-12-31 07:00:00+00	1979-12-31 07:00:00+00	1979-12-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56310
1980-01-05 07:00:00+00	1980-01-05 07:00:00+00	1980-01-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56312
1980-01-14 07:00:00+00	1980-01-14 07:00:00+00	1980-01-14 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56314
1980-01-15 07:00:00+00	1980-01-15 07:00:00+00	1980-01-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56316
1980-01-20 07:00:00+00	1980-01-20 07:00:00+00	1980-01-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56318
1980-02-11 07:00:00+00	1980-02-11 07:00:00+00	1980-02-11 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56320
1980-03-10 07:00:00+00	1980-03-10 07:00:00+00	1980-03-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56322
1980-04-08 07:00:00+00	1980-04-08 07:00:00+00	1980-04-08 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56324
1980-04-10 07:00:00+00	1980-04-10 07:00:00+00	1980-04-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56326
1980-04-15 07:00:00+00	1980-04-15 07:00:00+00	1980-04-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56328
1980-04-20 07:00:00+00	1980-04-20 07:00:00+00	1980-04-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56330
1980-04-25 07:00:00+00	1980-04-25 07:00:00+00	1980-04-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56332
1980-04-30 07:00:00+00	1980-04-30 07:00:00+00	1980-04-30 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56334
1980-05-06 07:00:00+00	1980-05-06 07:00:00+00	1980-05-06 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56336
1980-05-10 07:00:00+00	1980-05-10 07:00:00+00	1980-05-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56338
1980-05-15 07:00:00+00	1980-05-15 07:00:00+00	1980-05-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56340
1980-05-20 07:00:00+00	1980-05-20 07:00:00+00	1980-05-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56342
1980-05-25 07:00:00+00	1980-05-25 07:00:00+00	1980-05-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56344
1980-05-31 07:00:00+00	1980-05-31 07:00:00+00	1980-05-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56346
1980-06-05 07:00:00+00	1980-06-05 07:00:00+00	1980-06-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56348
1980-06-10 07:00:00+00	1980-06-10 07:00:00+00	1980-06-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56350
1980-06-15 07:00:00+00	1980-06-15 07:00:00+00	1980-06-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56352
1980-06-20 07:00:00+00	1980-06-20 07:00:00+00	1980-06-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56354
1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56356
1980-06-30 07:00:00+00	1980-06-30 07:00:00+00	1980-06-30 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56358
1980-07-05 07:00:00+00	1980-07-05 07:00:00+00	1980-07-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56360
1980-07-10 07:00:00+00	1980-07-10 07:00:00+00	1980-07-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56362
1980-07-15 07:00:00+00	1980-07-15 07:00:00+00	1980-07-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56364
1980-07-20 07:00:00+00	1980-07-20 07:00:00+00	1980-07-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56366
1980-07-25 07:00:00+00	1980-07-25 07:00:00+00	1980-07-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56368
1980-07-31 07:00:00+00	1980-07-31 07:00:00+00	1980-07-31 07:00:00+00	0	6132	\N	\N	6132	\N	\N	\N	\N	37	19	56370
1980-08-05 07:00:00+00	1980-08-05 07:00:00+00	1980-08-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56372
1980-08-10 07:00:00+00	1980-08-10 07:00:00+00	1980-08-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56374
1980-08-15 07:00:00+00	1980-08-15 07:00:00+00	1980-08-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56376
1980-08-20 07:00:00+00	1980-08-20 07:00:00+00	1980-08-20 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56378
1980-08-25 07:00:00+00	1980-08-25 07:00:00+00	1980-08-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56380
1980-08-27 07:00:00+00	1980-08-27 07:00:00+00	1980-08-27 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56382
1980-08-31 07:00:00+00	1980-08-31 07:00:00+00	1980-08-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56384
1980-09-05 07:00:00+00	1980-09-05 07:00:00+00	1980-09-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56386
1980-09-10 07:00:00+00	1980-09-10 07:00:00+00	1980-09-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56388
1980-09-15 07:00:00+00	1980-09-15 07:00:00+00	1980-09-15 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56390
1980-09-23 07:00:00+00	1980-09-23 07:00:00+00	1980-09-23 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56392
1980-10-25 07:00:00+00	1980-10-25 07:00:00+00	1980-10-25 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56394
1980-10-31 07:00:00+00	1980-10-31 07:00:00+00	1980-10-31 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56396
1980-11-05 07:00:00+00	1980-11-05 07:00:00+00	1980-11-05 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56398
1980-11-10 07:00:00+00	1980-11-10 07:00:00+00	1980-11-10 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56400
1980-11-18 07:00:00+00	1980-11-18 07:00:00+00	1980-11-18 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56402
1981-01-13 07:00:00+00	1981-01-13 07:00:00+00	1981-01-13 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56404
1981-02-12 07:00:00+00	1981-02-12 07:00:00+00	1981-02-12 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56406
1981-03-11 07:00:00+00	1981-03-11 07:00:00+00	1981-03-11 07:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	37	19	56408
1973-06-11 07:00:00+00	1973-06-11 07:00:00+00	1973-06-11 07:00:00+00	0	125.62	\N	\N	125.62	\N	\N	\N	\N	38	19	56209
1974-06-28 07:00:00+00	1974-06-28 07:00:00+00	1974-06-28 07:00:00+00	0	125.93	\N	\N	125.93	\N	\N	\N	\N	38	19	56211
1974-07-02 07:00:00+00	1974-07-02 07:00:00+00	1974-07-02 07:00:00+00	0	125.87	\N	\N	125.87	\N	\N	\N	\N	38	19	56213
1974-10-16 07:00:00+00	1974-10-16 07:00:00+00	1974-10-16 07:00:00+00	0	126.03	\N	\N	126.03	\N	\N	\N	\N	38	19	56215
1975-02-12 07:00:00+00	1975-02-12 07:00:00+00	1975-02-12 07:00:00+00	0	126.11	\N	\N	126.11	\N	\N	\N	\N	38	19	56217
1975-08-05 07:00:00+00	1975-08-05 07:00:00+00	1975-08-05 07:00:00+00	0	126.16	\N	\N	126.16	\N	\N	\N	\N	38	19	56219
1976-02-10 07:00:00+00	1976-02-10 07:00:00+00	1976-02-10 07:00:00+00	0	126.35	\N	\N	126.35	\N	\N	\N	\N	38	19	56221
1976-08-17 07:00:00+00	1976-08-17 07:00:00+00	1976-08-17 07:00:00+00	0	126.39	\N	\N	126.39	\N	\N	\N	\N	38	19	56223
1977-01-11 07:00:00+00	1977-01-11 07:00:00+00	1977-01-11 07:00:00+00	0	126.62	\N	\N	126.62	\N	\N	\N	\N	38	19	56225
1977-07-25 07:00:00+00	1977-07-25 07:00:00+00	1977-07-25 07:00:00+00	0	126.65	\N	\N	126.65	\N	\N	\N	\N	38	19	56227
1978-01-11 07:00:00+00	1978-01-11 07:00:00+00	1978-01-11 07:00:00+00	0	126.77	\N	\N	126.77	\N	\N	\N	\N	38	19	56229
1978-02-09 07:00:00+00	1978-02-09 07:00:00+00	1978-02-09 07:00:00+00	0	126.78	\N	\N	126.78	\N	\N	\N	\N	38	19	56231
1978-07-23 07:00:00+00	1978-07-23 07:00:00+00	1978-07-23 07:00:00+00	0	126.86	\N	\N	126.86	\N	\N	\N	\N	38	19	56233
1978-12-13 07:00:00+00	1978-12-13 07:00:00+00	1978-12-13 07:00:00+00	0	127.03	\N	\N	127.03	\N	\N	\N	\N	38	19	56235
1979-01-09 07:00:00+00	1979-01-09 07:00:00+00	1979-01-09 07:00:00+00	0	126.95	\N	\N	126.95	\N	\N	\N	\N	38	19	56237
1979-02-06 07:00:00+00	1979-02-06 07:00:00+00	1979-02-06 07:00:00+00	0	126.62	\N	\N	126.62	\N	\N	\N	\N	38	19	56239
1979-03-07 07:00:00+00	1979-03-07 07:00:00+00	1979-03-07 07:00:00+00	0	127	\N	\N	127	\N	\N	\N	\N	38	19	56241
1979-04-06 07:00:00+00	1979-04-06 07:00:00+00	1979-04-06 07:00:00+00	0	126.55	\N	\N	126.55	\N	\N	\N	\N	38	19	56243
1979-04-30 07:00:00+00	1979-04-30 07:00:00+00	1979-04-30 07:00:00+00	0	126.98	\N	\N	126.98	\N	\N	\N	\N	38	19	56245
1979-06-02 07:00:00+00	1979-06-02 07:00:00+00	1979-06-02 07:00:00+00	0	127.04	\N	\N	127.04	\N	\N	\N	\N	38	19	56247
1979-07-02 07:00:00+00	1979-07-02 07:00:00+00	1979-07-02 07:00:00+00	0	127.03	\N	\N	127.03	\N	\N	\N	\N	38	19	56249
1979-07-24 07:00:00+00	1979-07-24 07:00:00+00	1979-07-24 07:00:00+00	0	127.17	\N	\N	127.17	\N	\N	\N	\N	38	19	56251
1979-07-25 07:00:00+00	1979-07-25 07:00:00+00	1979-07-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56253
1979-07-31 07:00:00+00	1979-07-31 07:00:00+00	1979-07-31 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56255
1979-08-05 07:00:00+00	1979-08-05 07:00:00+00	1979-08-05 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56257
1979-08-10 07:00:00+00	1979-08-10 07:00:00+00	1979-08-10 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56259
1979-08-15 07:00:00+00	1979-08-15 07:00:00+00	1979-08-15 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56261
1979-08-20 07:00:00+00	1979-08-20 07:00:00+00	1979-08-20 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56263
1979-08-23 07:00:00+00	1979-08-23 07:00:00+00	1979-08-23 07:00:00+00	0	127.14	\N	\N	127.14	\N	\N	\N	\N	38	19	56265
1979-08-25 07:00:00+00	1979-08-25 07:00:00+00	1979-08-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56267
1979-08-31 07:00:00+00	1979-08-31 07:00:00+00	1979-08-31 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56269
1979-09-05 07:00:00+00	1979-09-05 07:00:00+00	1979-09-05 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56271
1979-09-10 07:00:00+00	1979-09-10 07:00:00+00	1979-09-10 07:00:00+00	0	127.15	\N	\N	127.15	\N	\N	\N	\N	38	19	56273
1979-09-20 07:00:00+00	1979-09-20 07:00:00+00	1979-09-20 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56275
1979-09-24 07:00:00+00	1979-09-24 07:00:00+00	1979-09-24 07:00:00+00	0	127.22	\N	\N	127.22	\N	\N	\N	\N	38	19	56277
1979-09-25 07:00:00+00	1979-09-25 07:00:00+00	1979-09-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56279
1979-10-04 07:00:00+00	1979-10-04 07:00:00+00	1979-10-04 07:00:00+00	0	127.18	\N	\N	127.18	\N	\N	\N	\N	38	19	56281
1979-10-05 07:00:00+00	1979-10-05 07:00:00+00	1979-10-05 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56283
1979-10-10 07:00:00+00	1979-10-10 07:00:00+00	1979-10-10 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56285
1979-10-15 07:00:00+00	1979-10-15 07:00:00+00	1979-10-15 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56287
1979-10-20 07:00:00+00	1979-10-20 07:00:00+00	1979-10-20 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56289
1979-10-23 07:00:00+00	1979-10-23 07:00:00+00	1979-10-23 07:00:00+00	0	127.13	\N	\N	127.13	\N	\N	\N	\N	38	19	56291
1979-10-25 07:00:00+00	1979-10-25 07:00:00+00	1979-10-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56293
1979-10-31 07:00:00+00	1979-10-31 07:00:00+00	1979-10-31 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56295
1979-11-05 07:00:00+00	1979-11-05 07:00:00+00	1979-11-05 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56297
1979-11-14 07:00:00+00	1979-11-14 07:00:00+00	1979-11-14 07:00:00+00	0	127.25	\N	\N	127.25	\N	\N	\N	\N	38	19	56299
1979-12-12 07:00:00+00	1979-12-12 07:00:00+00	1979-12-12 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56301
1979-12-15 07:00:00+00	1979-12-15 07:00:00+00	1979-12-15 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56303
1979-12-20 07:00:00+00	1979-12-20 07:00:00+00	1979-12-20 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56305
1979-12-25 07:00:00+00	1979-12-25 07:00:00+00	1979-12-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56307
1979-12-31 07:00:00+00	1979-12-31 07:00:00+00	1979-12-31 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56309
1980-01-05 07:00:00+00	1980-01-05 07:00:00+00	1980-01-05 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56311
1980-01-14 07:00:00+00	1980-01-14 07:00:00+00	1980-01-14 07:00:00+00	0	127.25	\N	\N	127.25	\N	\N	\N	\N	38	19	56313
1980-01-15 07:00:00+00	1980-01-15 07:00:00+00	1980-01-15 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56315
1980-01-20 07:00:00+00	1980-01-20 07:00:00+00	1980-01-20 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56317
1980-02-11 07:00:00+00	1980-02-11 07:00:00+00	1980-02-11 07:00:00+00	0	127.16	\N	\N	127.16	\N	\N	\N	\N	38	19	56319
1980-03-10 07:00:00+00	1980-03-10 07:00:00+00	1980-03-10 07:00:00+00	0	127.19	\N	\N	127.19	\N	\N	\N	\N	38	19	56321
1980-04-08 07:00:00+00	1980-04-08 07:00:00+00	1980-04-08 07:00:00+00	0	127.13	\N	\N	127.13	\N	\N	\N	\N	38	19	56323
1980-04-10 07:00:00+00	1980-04-10 07:00:00+00	1980-04-10 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56325
1980-04-15 07:00:00+00	1980-04-15 07:00:00+00	1980-04-15 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56327
1980-04-20 07:00:00+00	1980-04-20 07:00:00+00	1980-04-20 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56329
1980-04-25 07:00:00+00	1980-04-25 07:00:00+00	1980-04-25 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56331
1980-04-30 07:00:00+00	1980-04-30 07:00:00+00	1980-04-30 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56333
1980-05-06 07:00:00+00	1980-05-06 07:00:00+00	1980-05-06 07:00:00+00	0	127.11	\N	\N	127.11	\N	\N	\N	\N	38	19	56335
1980-05-10 07:00:00+00	1980-05-10 07:00:00+00	1980-05-10 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56337
1980-05-15 07:00:00+00	1980-05-15 07:00:00+00	1980-05-15 07:00:00+00	0	127.1	\N	\N	127.1	\N	\N	\N	\N	38	19	56339
1980-05-20 07:00:00+00	1980-05-20 07:00:00+00	1980-05-20 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56341
1980-05-25 07:00:00+00	1980-05-25 07:00:00+00	1980-05-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56343
1980-05-31 07:00:00+00	1980-05-31 07:00:00+00	1980-05-31 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56345
1980-06-05 07:00:00+00	1980-06-05 07:00:00+00	1980-06-05 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56347
1980-06-10 07:00:00+00	1980-06-10 07:00:00+00	1980-06-10 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56349
1980-06-15 07:00:00+00	1980-06-15 07:00:00+00	1980-06-15 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56351
1980-06-20 07:00:00+00	1980-06-20 07:00:00+00	1980-06-20 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56353
1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56355
1980-06-30 07:00:00+00	1980-06-30 07:00:00+00	1980-06-30 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56357
1980-07-05 07:00:00+00	1980-07-05 07:00:00+00	1980-07-05 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56359
1980-07-10 07:00:00+00	1980-07-10 07:00:00+00	1980-07-10 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56361
1980-07-15 07:00:00+00	1980-07-15 07:00:00+00	1980-07-15 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56363
1980-07-20 07:00:00+00	1980-07-20 07:00:00+00	1980-07-20 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56365
1980-07-25 07:00:00+00	1980-07-25 07:00:00+00	1980-07-25 07:00:00+00	0	127.5	\N	\N	127.5	\N	\N	\N	\N	38	19	56367
1980-07-31 07:00:00+00	1980-07-31 07:00:00+00	1980-07-31 07:00:00+00	0	127.6	\N	\N	127.6	\N	\N	\N	\N	38	19	56369
1980-08-05 07:00:00+00	1980-08-05 07:00:00+00	1980-08-05 07:00:00+00	0	127.5	\N	\N	127.5	\N	\N	\N	\N	38	19	56371
1980-08-10 07:00:00+00	1980-08-10 07:00:00+00	1980-08-10 07:00:00+00	0	127.5	\N	\N	127.5	\N	\N	\N	\N	38	19	56373
1980-08-15 07:00:00+00	1980-08-15 07:00:00+00	1980-08-15 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56375
1980-08-20 07:00:00+00	1980-08-20 07:00:00+00	1980-08-20 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56377
1980-08-25 07:00:00+00	1980-08-25 07:00:00+00	1980-08-25 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56379
1980-08-27 07:00:00+00	1980-08-27 07:00:00+00	1980-08-27 07:00:00+00	0	127.29	\N	\N	127.29	\N	\N	\N	\N	38	19	56381
1980-08-31 07:00:00+00	1980-08-31 07:00:00+00	1980-08-31 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56383
1980-09-05 07:00:00+00	1980-09-05 07:00:00+00	1980-09-05 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56385
1980-09-10 07:00:00+00	1980-09-10 07:00:00+00	1980-09-10 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56387
1980-09-15 07:00:00+00	1980-09-15 07:00:00+00	1980-09-15 07:00:00+00	0	127.3	\N	\N	127.3	\N	\N	\N	\N	38	19	56389
1980-09-23 07:00:00+00	1980-09-23 07:00:00+00	1980-09-23 07:00:00+00	0	127.36	\N	\N	127.36	\N	\N	\N	\N	38	19	56391
1980-10-25 07:00:00+00	1980-10-25 07:00:00+00	1980-10-25 07:00:00+00	0	127.2	\N	\N	127.2	\N	\N	\N	\N	38	19	56393
1980-10-31 07:00:00+00	1980-10-31 07:00:00+00	1980-10-31 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56395
1980-11-05 07:00:00+00	1980-11-05 07:00:00+00	1980-11-05 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56397
1980-11-10 07:00:00+00	1980-11-10 07:00:00+00	1980-11-10 07:00:00+00	0	127.4	\N	\N	127.4	\N	\N	\N	\N	38	19	56399
1980-11-18 07:00:00+00	1980-11-18 07:00:00+00	1980-11-18 07:00:00+00	0	127.38	\N	\N	127.38	\N	\N	\N	\N	38	19	56401
1981-01-13 07:00:00+00	1981-01-13 07:00:00+00	1981-01-13 07:00:00+00	0	127.36	\N	\N	127.36	\N	\N	\N	\N	38	19	56403
1981-02-12 07:00:00+00	1981-02-12 07:00:00+00	1981-02-12 07:00:00+00	0	127.47	\N	\N	127.47	\N	\N	\N	\N	38	19	56405
1981-03-11 07:00:00+00	1981-03-11 07:00:00+00	1981-03-11 07:00:00+00	0	127.42	\N	\N	127.42	\N	\N	\N	\N	38	19	56407
1953-02-20 12:00:00+00	1953-02-20 12:00:00+00	1953-02-20 12:00:00+00	0	19.86	\N	\N	19.86	\N	\N	\N	\N	52	26	95117
1953-04-16 12:00:00+00	1953-04-16 12:00:00+00	1953-04-16 12:00:00+00	0	20.34	\N	\N	20.34	\N	\N	\N	\N	52	26	95119
1953-10-09 12:00:00+00	1953-10-09 12:00:00+00	1953-10-09 12:00:00+00	0	29.45	\N	\N	29.45	\N	\N	\N	\N	52	26	95121
1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	0	23.45	\N	\N	23.45	\N	\N	\N	\N	52	26	95123
1954-02-09 12:00:00+00	1954-02-09 12:00:00+00	1954-02-09 12:00:00+00	0	21.85	\N	\N	21.85	\N	\N	\N	\N	52	26	95125
1954-04-06 12:00:00+00	1954-04-06 12:00:00+00	1954-04-06 12:00:00+00	0	21.35	\N	\N	21.35	\N	\N	\N	\N	52	26	95127
1954-06-14 12:00:00+00	1954-06-14 12:00:00+00	1954-06-14 12:00:00+00	0	26.28	\N	\N	26.28	\N	\N	\N	\N	52	26	95129
1954-12-03 12:00:00+00	1954-12-03 12:00:00+00	1954-12-03 12:00:00+00	0	23.63	\N	\N	23.63	\N	\N	\N	\N	52	26	95131
1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	0	22.28	\N	\N	22.28	\N	\N	\N	\N	52	26	95133
1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	0	21.6	\N	\N	21.6	\N	\N	\N	\N	52	26	95135
1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	0	26.31	\N	\N	26.31	\N	\N	\N	\N	52	26	95137
1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	0	26.08	\N	\N	26.08	\N	\N	\N	\N	52	26	95139
1956-02-08 12:00:00+00	1956-02-08 12:00:00+00	1956-02-08 12:00:00+00	0	24.75	\N	\N	24.75	\N	\N	\N	\N	52	26	95141
1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	0	24.58	\N	\N	24.58	\N	\N	\N	\N	52	26	95143
1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	0	27.3	\N	\N	27.3	\N	\N	\N	\N	52	26	95145
1956-06-27 12:00:00+00	1956-06-27 12:00:00+00	1956-06-27 12:00:00+00	0	29.33	\N	\N	29.33	\N	\N	\N	\N	52	26	95147
1956-08-02 12:00:00+00	1956-08-02 12:00:00+00	1956-08-02 12:00:00+00	0	30.19	\N	\N	30.19	\N	\N	\N	\N	52	26	95149
1956-12-11 12:00:00+00	1956-12-11 12:00:00+00	1956-12-11 12:00:00+00	0	29.15	\N	\N	29.15	\N	\N	\N	\N	52	26	95151
1957-02-12 12:00:00+00	1957-02-12 12:00:00+00	1957-02-12 12:00:00+00	0	28.15	\N	\N	28.15	\N	\N	\N	\N	52	26	95153
1957-05-06 12:00:00+00	1957-05-06 12:00:00+00	1957-05-06 12:00:00+00	0	28.94	\N	\N	28.94	\N	\N	\N	\N	52	26	95155
1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	0	31.49	\N	\N	31.49	\N	\N	\N	\N	52	26	95157
1958-02-05 12:00:00+00	1958-02-05 12:00:00+00	1958-02-05 12:00:00+00	0	28.6	\N	\N	28.6	\N	\N	\N	\N	52	26	95159
1958-05-15 12:00:00+00	1958-05-15 12:00:00+00	1958-05-15 12:00:00+00	0	28.78	\N	\N	28.78	\N	\N	\N	\N	52	26	95161
1958-08-18 12:00:00+00	1958-08-18 12:00:00+00	1958-08-18 12:00:00+00	0	32.77	\N	\N	32.77	\N	\N	\N	\N	52	26	95163
1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	0	32.13	\N	\N	32.13	\N	\N	\N	\N	52	26	95165
1959-02-17 12:00:00+00	1959-02-17 12:00:00+00	1959-02-17 12:00:00+00	0	31.13	\N	\N	31.13	\N	\N	\N	\N	52	26	95167
1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	0	31.9	\N	\N	31.9	\N	\N	\N	\N	52	26	95169
1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	0	34.05	\N	\N	34.05	\N	\N	\N	\N	52	26	95171
1959-11-04 12:00:00+00	1959-11-04 12:00:00+00	1959-11-04 12:00:00+00	0	34.73	\N	\N	34.73	\N	\N	\N	\N	52	26	95173
1960-02-08 12:00:00+00	1960-02-08 12:00:00+00	1960-02-08 12:00:00+00	0	31.79	\N	\N	31.79	\N	\N	\N	\N	52	26	95175
1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	0	32.35	\N	\N	32.35	\N	\N	\N	\N	52	26	95177
1960-08-26 12:00:00+00	1960-08-26 12:00:00+00	1960-08-26 12:00:00+00	0	36.3	\N	\N	36.3	\N	\N	\N	\N	52	26	95179
1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	0	35.47	\N	\N	35.47	\N	\N	\N	\N	52	26	95181
1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	0	33.59	\N	\N	33.59	\N	\N	\N	\N	52	26	95183
1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	0	33.58	\N	\N	33.58	\N	\N	\N	\N	52	26	95185
1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	0	38.42	\N	\N	38.42	\N	\N	\N	\N	52	26	95187
1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	0	36.82	\N	\N	36.82	\N	\N	\N	\N	52	26	95189
1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	0	36.22	\N	\N	36.22	\N	\N	\N	\N	52	26	95191
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	36.44	\N	\N	36.44	\N	\N	\N	\N	52	26	95193
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	36.52	\N	\N	36.52	\N	\N	\N	\N	52	26	95195
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	33.1	\N	\N	33.1	\N	\N	\N	\N	52	26	95197
1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	0	33.25	\N	\N	33.25	\N	\N	\N	\N	52	26	95199
1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	0	30.05	\N	\N	30.05	\N	\N	\N	\N	52	26	95201
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	31.64	\N	\N	31.64	\N	\N	\N	\N	52	26	95203
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	28.25	\N	\N	28.25	\N	\N	\N	\N	52	26	95205
1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	0	29.31	\N	\N	29.31	\N	\N	\N	\N	52	26	95207
1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	0	27.1	\N	\N	27.1	\N	\N	\N	\N	52	26	95209
1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	0	27.25	\N	\N	27.25	\N	\N	\N	\N	52	26	95211
1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	0	25.78	\N	\N	25.78	\N	\N	\N	\N	52	26	95213
1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	0	25.6	\N	\N	25.6	\N	\N	\N	\N	52	26	95215
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	28.54	\N	\N	28.54	\N	\N	\N	\N	52	26	95217
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	27.84	\N	\N	27.84	\N	\N	\N	\N	52	26	95219
1970-08-18 12:00:00+00	1970-08-18 12:00:00+00	1970-08-18 12:00:00+00	0	33.23	\N	\N	33.23	\N	\N	\N	\N	52	26	95221
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	31.25	\N	\N	31.25	\N	\N	\N	\N	52	26	95223
1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	0	33.99	\N	\N	33.99	\N	\N	\N	\N	52	26	95225
1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	0	35.27	\N	\N	35.27	\N	\N	\N	\N	52	26	95227
1973-08-28 12:00:00+00	1973-08-28 12:00:00+00	1973-08-28 12:00:00+00	0	36.57	\N	\N	36.57	\N	\N	\N	\N	52	26	95229
1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	0	33.84	\N	\N	33.84	\N	\N	\N	\N	52	26	95231
1974-08-06 12:00:00+00	1974-08-06 12:00:00+00	1974-08-06 12:00:00+00	0	35.18	\N	\N	35.18	\N	\N	\N	\N	52	26	95233
1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	0	32.46	\N	\N	32.46	\N	\N	\N	\N	52	26	95235
1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	0	30.96	\N	\N	30.96	\N	\N	\N	\N	52	26	95237
1976-08-11 12:00:00+00	1976-08-11 12:00:00+00	1976-08-11 12:00:00+00	0	31.01	\N	\N	31.01	\N	\N	\N	\N	52	26	95239
1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	0	28.64	\N	\N	28.64	\N	\N	\N	\N	52	26	95241
1977-08-16 12:00:00+00	1977-08-16 12:00:00+00	1977-08-16 12:00:00+00	0	34.62	\N	\N	34.62	\N	\N	\N	\N	52	26	95243
1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	0	32.98	\N	\N	32.98	\N	\N	\N	\N	52	26	95245
1978-08-07 12:00:00+00	1978-08-07 12:00:00+00	1978-08-07 12:00:00+00	0	36.98	\N	\N	36.98	\N	\N	\N	\N	52	26	95247
1979-03-07 12:00:00+00	1979-03-07 12:00:00+00	1979-03-07 12:00:00+00	0	34.22	\N	\N	34.22	\N	\N	\N	\N	52	26	95249
1979-07-17 12:00:00+00	1979-07-17 12:00:00+00	1979-07-17 12:00:00+00	0	38.44	\N	\N	38.44	\N	\N	\N	\N	52	26	95251
1980-07-15 12:00:00+00	1980-07-15 12:00:00+00	1980-07-15 12:00:00+00	0	34.61	\N	\N	34.61	\N	\N	\N	\N	52	26	95253
1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	0	30.95	\N	\N	30.95	\N	\N	\N	\N	52	26	95255
1981-07-20 12:00:00+00	1981-07-20 12:00:00+00	1981-07-20 12:00:00+00	0	32.64	\N	\N	32.64	\N	\N	\N	\N	52	26	95257
1982-02-23 12:00:00+00	1982-02-23 12:00:00+00	1982-02-23 12:00:00+00	0	28.51	\N	\N	28.51	\N	\N	\N	\N	52	26	95259
1982-09-07 12:00:00+00	1982-09-07 12:00:00+00	1982-09-07 12:00:00+00	0	28.59	\N	\N	28.59	\N	\N	\N	\N	52	26	95261
1983-01-17 12:00:00+00	1983-01-17 12:00:00+00	1983-01-17 12:00:00+00	0	25.74	\N	\N	25.74	\N	\N	\N	\N	52	26	95263
1983-08-12 12:00:00+00	1983-08-12 12:00:00+00	1983-08-12 12:00:00+00	0	24.98	\N	\N	24.98	\N	\N	\N	\N	52	26	95265
1984-01-11 12:00:00+00	1984-01-11 12:00:00+00	1984-01-11 12:00:00+00	0	22.55	\N	\N	22.55	\N	\N	\N	\N	52	26	95267
1984-08-14 12:00:00+00	1984-08-14 12:00:00+00	1984-08-14 12:00:00+00	0	25.39	\N	\N	25.39	\N	\N	\N	\N	52	26	95269
1985-02-06 12:00:00+00	1985-02-06 12:00:00+00	1985-02-06 12:00:00+00	0	20.97	\N	\N	20.97	\N	\N	\N	\N	52	26	95271
1985-08-08 12:00:00+00	1985-08-08 12:00:00+00	1985-08-08 12:00:00+00	0	21.58	\N	\N	21.58	\N	\N	\N	\N	52	26	95273
1985-09-01 12:00:00+00	1985-09-01 12:00:00+00	1985-09-01 12:00:00+00	0	21.88	\N	\N	21.88	\N	\N	\N	\N	52	26	95275
1985-09-12 12:00:00+00	1985-09-12 12:00:00+00	1985-09-12 12:00:00+00	0	21.84	\N	\N	21.84	\N	\N	\N	\N	52	26	95277
1985-10-01 12:00:00+00	1985-10-01 12:00:00+00	1985-10-01 12:00:00+00	0	20.14	\N	\N	20.14	\N	\N	\N	\N	52	26	95279
1985-11-01 12:00:00+00	1985-11-01 12:00:00+00	1985-11-01 12:00:00+00	0	19.59	\N	\N	19.59	\N	\N	\N	\N	52	26	95281
1985-12-01 12:00:00+00	1985-12-01 12:00:00+00	1985-12-01 12:00:00+00	0	19.51	\N	\N	19.51	\N	\N	\N	\N	52	26	95283
1986-01-01 12:00:00+00	1986-01-01 12:00:00+00	1986-01-01 12:00:00+00	0	19.68	\N	\N	19.68	\N	\N	\N	\N	52	26	95285
1986-01-06 12:00:00+00	1986-01-06 12:00:00+00	1986-01-06 12:00:00+00	0	19.98	\N	\N	19.98	\N	\N	\N	\N	52	26	95287
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	20.06	\N	\N	20.06	\N	\N	\N	\N	52	26	95289
1986-03-01 12:00:00+00	1986-03-01 12:00:00+00	1986-03-01 12:00:00+00	0	19.91	\N	\N	19.91	\N	\N	\N	\N	52	26	95291
1986-04-17 12:00:00+00	1986-04-17 12:00:00+00	1986-04-17 12:00:00+00	0	20.14	\N	\N	20.14	\N	\N	\N	\N	52	26	95293
1986-05-01 12:00:00+00	1986-05-01 12:00:00+00	1986-05-01 12:00:00+00	0	20.83	\N	\N	20.83	\N	\N	\N	\N	52	26	95295
1986-06-01 12:00:00+00	1986-06-01 12:00:00+00	1986-06-01 12:00:00+00	0	20.33	\N	\N	20.33	\N	\N	\N	\N	52	26	95297
1986-07-01 12:00:00+00	1986-07-01 12:00:00+00	1986-07-01 12:00:00+00	0	21.14	\N	\N	21.14	\N	\N	\N	\N	52	26	95299
1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	0	21.34	\N	\N	21.34	\N	\N	\N	\N	52	26	95301
1986-09-01 12:00:00+00	1986-09-01 12:00:00+00	1986-09-01 12:00:00+00	0	19.92	\N	\N	19.92	\N	\N	\N	\N	52	26	95303
1986-10-01 12:00:00+00	1986-10-01 12:00:00+00	1986-10-01 12:00:00+00	0	19.31	\N	\N	19.31	\N	\N	\N	\N	52	26	95305
1986-11-01 12:00:00+00	1986-11-01 12:00:00+00	1986-11-01 12:00:00+00	0	19.18	\N	\N	19.18	\N	\N	\N	\N	52	26	95307
1987-08-11 12:00:00+00	1987-08-11 12:00:00+00	1987-08-11 12:00:00+00	0	19.75	\N	\N	19.75	\N	\N	\N	\N	52	26	95309
1988-01-06 12:00:00+00	1988-01-06 12:00:00+00	1988-01-06 12:00:00+00	0	19.37	\N	\N	19.37	\N	\N	\N	\N	52	26	95311
1988-09-29 12:00:00+00	1988-09-29 12:00:00+00	1988-09-29 12:00:00+00	0	19.23	\N	\N	19.23	\N	\N	\N	\N	52	26	95313
1989-03-28 12:00:00+00	1989-03-28 12:00:00+00	1989-03-28 12:00:00+00	0	19.57	\N	\N	19.57	\N	\N	\N	\N	52	26	95315
1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	0	190.67	\N	\N	190.67	\N	\N	\N	\N	46	23	94651
1991-02-25 07:00:00+00	1991-02-25 07:00:00+00	1991-02-25 07:00:00+00	0	190.44	\N	\N	190.44	\N	\N	\N	\N	46	23	94653
1992-02-19 07:00:00+00	1992-02-19 07:00:00+00	1992-02-19 07:00:00+00	0	196.48	\N	\N	196.48	\N	\N	\N	\N	46	23	94655
1993-02-23 07:00:00+00	1993-02-23 07:00:00+00	1993-02-23 07:00:00+00	0	190.23	\N	\N	190.23	\N	\N	\N	\N	46	23	94657
1994-02-28 07:00:00+00	1994-02-28 07:00:00+00	1994-02-28 07:00:00+00	0	190.5	\N	\N	190.5	\N	\N	\N	\N	46	23	94659
1995-02-21 07:00:00+00	1995-02-21 07:00:00+00	1995-02-21 07:00:00+00	0	190.58	\N	\N	190.58	\N	\N	\N	\N	46	23	94661
1996-02-07 07:00:00+00	1996-02-07 07:00:00+00	1996-02-07 07:00:00+00	0	190.37	\N	\N	190.37	\N	\N	\N	\N	46	23	94663
1997-02-19 07:00:00+00	1997-02-19 07:00:00+00	1997-02-19 07:00:00+00	0	190.94	\N	\N	190.94	\N	\N	\N	\N	46	23	94665
2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	0	190.1	\N	\N	190.1	\N	\N	\N	\N	46	23	94667
2008-05-13 07:00:00+00	2008-05-13 07:00:00+00	2008-05-13 07:00:00+00	0	190.39	\N	\N	190.39	\N	\N	\N	\N	46	23	94669
2008-09-24 07:00:00+00	2008-09-24 07:00:00+00	2008-09-24 07:00:00+00	0	190.49	\N	\N	190.49	\N	\N	\N	\N	46	23	94671
2009-02-09 07:00:00+00	2009-02-09 07:00:00+00	2009-02-09 07:00:00+00	0	190.45	\N	\N	190.45	\N	\N	\N	\N	46	23	94673
2009-12-09 07:00:00+00	2009-12-09 07:00:00+00	2009-12-09 07:00:00+00	0	190.3	\N	\N	190.3	\N	\N	\N	\N	46	23	94675
2010-03-24 07:00:00+00	2010-03-24 07:00:00+00	2010-03-24 07:00:00+00	0	190.26	\N	\N	190.26	\N	\N	\N	\N	46	23	94677
2010-05-11 07:00:00+00	2010-05-11 07:00:00+00	2010-05-11 07:00:00+00	0	190.17	\N	\N	190.17	\N	\N	\N	\N	46	23	94679
2010-07-14 07:00:00+00	2010-07-14 07:00:00+00	2010-07-14 07:00:00+00	0	190.29	\N	\N	190.29	\N	\N	\N	\N	46	23	94681
2010-09-20 07:00:00+00	2010-09-20 07:00:00+00	2010-09-20 07:00:00+00	0	190.1	\N	\N	190.1	\N	\N	\N	\N	46	23	94683
2010-11-10 07:00:00+00	2010-11-10 07:00:00+00	2010-11-10 07:00:00+00	0	190.13	\N	\N	190.13	\N	\N	\N	\N	46	23	94685
2011-01-12 07:00:00+00	2011-01-12 07:00:00+00	2011-01-12 07:00:00+00	0	190.36	\N	\N	190.36	\N	\N	\N	\N	46	23	94687
2011-05-17 07:00:00+00	2011-05-17 07:00:00+00	2011-05-17 07:00:00+00	0	190.17	\N	\N	190.17	\N	\N	\N	\N	46	23	94689
2011-07-14 07:00:00+00	2011-07-14 07:00:00+00	2011-07-14 07:00:00+00	0	190.31	\N	\N	190.31	\N	\N	\N	\N	46	23	94691
2011-11-11 07:00:00+00	2011-11-11 07:00:00+00	2011-11-11 07:00:00+00	0	190.27	\N	\N	190.27	\N	\N	\N	\N	46	23	94693
2012-02-27 07:00:00+00	2012-02-27 07:00:00+00	2012-02-27 07:00:00+00	0	190.25	\N	\N	190.25	\N	\N	\N	\N	46	23	94695
2013-02-27 07:00:00+00	2013-02-27 07:00:00+00	2013-02-27 07:00:00+00	0	190.39	\N	\N	190.39	\N	\N	\N	\N	46	23	94697
2015-02-25 07:00:00+00	2015-02-25 07:00:00+00	2015-02-25 07:00:00+00	0	190.23	\N	\N	190.23	\N	\N	\N	\N	46	23	94699
2016-02-18 07:00:00+00	2016-02-18 07:00:00+00	2016-02-18 07:00:00+00	0	190.13	\N	\N	190.13	\N	\N	\N	\N	46	23	94701
2017-02-20 07:00:00+00	2017-02-20 07:00:00+00	2017-02-20 07:00:00+00	0	190.49	\N	\N	190.49	\N	\N	\N	\N	46	23	94703
2018-06-06 07:00:00+00	2018-06-06 07:00:00+00	2018-06-06 07:00:00+00	0	190.54	\N	\N	190.54	\N	\N	\N	\N	46	23	94705
2018-11-13 07:00:00+00	2018-11-13 07:00:00+00	2018-11-13 07:00:00+00	0	190.66	\N	\N	190.66	\N	\N	\N	\N	46	23	94707
2019-02-20 07:00:00+00	2019-02-20 07:00:00+00	2019-02-20 07:00:00+00	0	190.36	\N	\N	190.36	\N	\N	\N	\N	46	23	94709
2020-03-12 07:00:00+00	2020-03-12 07:00:00+00	2020-03-12 07:00:00+00	0	190.6	\N	\N	190.6	\N	\N	\N	\N	46	23	94711
1944-10-14 12:00:00+00	1944-10-14 12:00:00+00	1944-10-14 12:00:00+00	0	6496	\N	\N	6496	\N	\N	\N	\N	47	24	94714
1946-02-26 12:00:00+00	1946-02-26 12:00:00+00	1946-02-26 12:00:00+00	0	6492	\N	\N	6492	\N	\N	\N	\N	47	24	94716
1946-07-12 12:00:00+00	1946-07-12 12:00:00+00	1946-07-12 12:00:00+00	0	6492	\N	\N	6492	\N	\N	\N	\N	47	24	94718
1946-09-04 12:00:00+00	1946-09-04 12:00:00+00	1946-09-04 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	47	24	94720
1946-10-01 12:00:00+00	1946-10-01 12:00:00+00	1946-10-01 12:00:00+00	0	6486	\N	\N	6486	\N	\N	\N	\N	47	24	94722
1946-11-06 12:00:00+00	1946-11-06 12:00:00+00	1946-11-06 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94724
1946-12-03 12:00:00+00	1946-12-03 12:00:00+00	1946-12-03 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94726
1947-01-04 12:00:00+00	1947-01-04 12:00:00+00	1947-01-04 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94728
1947-02-03 12:00:00+00	1947-02-03 12:00:00+00	1947-02-03 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94730
1947-03-11 12:00:00+00	1947-03-11 12:00:00+00	1947-03-11 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94732
1947-04-07 12:00:00+00	1947-04-07 12:00:00+00	1947-04-07 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	47	24	94734
1947-09-02 12:00:00+00	1947-09-02 12:00:00+00	1947-09-02 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	47	24	94736
1947-10-02 12:00:00+00	1947-10-02 12:00:00+00	1947-10-02 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94738
1947-12-10 12:00:00+00	1947-12-10 12:00:00+00	1947-12-10 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94740
1948-02-02 12:00:00+00	1948-02-02 12:00:00+00	1948-02-02 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94742
1948-04-05 12:00:00+00	1948-04-05 12:00:00+00	1948-04-05 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94744
1948-10-05 12:00:00+00	1948-10-05 12:00:00+00	1948-10-05 12:00:00+00	0	6482	\N	\N	6482	\N	\N	\N	\N	47	24	94746
1948-12-09 12:00:00+00	1948-12-09 12:00:00+00	1948-12-09 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	47	24	94748
1949-02-10 12:00:00+00	1949-02-10 12:00:00+00	1949-02-10 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	47	24	94750
1949-04-11 12:00:00+00	1949-04-11 12:00:00+00	1949-04-11 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94752
1949-06-09 12:00:00+00	1949-06-09 12:00:00+00	1949-06-09 12:00:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	47	24	94754
1949-08-18 12:00:00+00	1949-08-18 12:00:00+00	1949-08-18 12:00:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	47	24	94756
1949-10-12 12:00:00+00	1949-10-12 12:00:00+00	1949-10-12 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94758
1949-12-14 12:00:00+00	1949-12-14 12:00:00+00	1949-12-14 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94760
1950-02-08 12:00:00+00	1950-02-08 12:00:00+00	1950-02-08 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	47	24	94762
1950-04-18 12:00:00+00	1950-04-18 12:00:00+00	1950-04-18 12:00:00+00	0	6481	\N	\N	6481	\N	\N	\N	\N	47	24	94764
1950-06-27 12:00:00+00	1950-06-27 12:00:00+00	1950-06-27 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94766
1950-08-24 12:00:00+00	1950-08-24 12:00:00+00	1950-08-24 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94768
1950-10-16 12:00:00+00	1950-10-16 12:00:00+00	1950-10-16 12:00:00+00	0	6475	\N	\N	6475	\N	\N	\N	\N	47	24	94770
1950-12-12 12:00:00+00	1950-12-12 12:00:00+00	1950-12-12 12:00:00+00	0	6477	\N	\N	6477	\N	\N	\N	\N	47	24	94772
1951-02-15 12:00:00+00	1951-02-15 12:00:00+00	1951-02-15 12:00:00+00	0	6478	\N	\N	6478	\N	\N	\N	\N	47	24	94774
1951-04-18 12:00:00+00	1951-04-18 12:00:00+00	1951-04-18 12:00:00+00	0	6476	\N	\N	6476	\N	\N	\N	\N	47	24	94776
1951-06-21 12:00:00+00	1951-06-21 12:00:00+00	1951-06-21 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94778
1951-08-15 12:00:00+00	1951-08-15 12:00:00+00	1951-08-15 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94780
1951-10-31 12:00:00+00	1951-10-31 12:00:00+00	1951-10-31 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94782
1951-12-24 12:00:00+00	1951-12-24 12:00:00+00	1951-12-24 12:00:00+00	0	6473	\N	\N	6473	\N	\N	\N	\N	47	24	94784
1952-02-26 12:00:00+00	1952-02-26 12:00:00+00	1952-02-26 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94786
1952-04-24 12:00:00+00	1952-04-24 12:00:00+00	1952-04-24 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94788
1952-06-25 12:00:00+00	1952-06-25 12:00:00+00	1952-06-25 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94790
1952-12-16 12:00:00+00	1952-12-16 12:00:00+00	1952-12-16 12:00:00+00	0	6474	\N	\N	6474	\N	\N	\N	\N	47	24	94792
1953-02-17 12:00:00+00	1953-02-17 12:00:00+00	1953-02-17 12:00:00+00	0	6475	\N	\N	6475	\N	\N	\N	\N	47	24	94794
1953-04-15 12:00:00+00	1953-04-15 12:00:00+00	1953-04-15 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94796
1953-06-10 12:00:00+00	1953-06-10 12:00:00+00	1953-06-10 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94798
1953-08-11 12:00:00+00	1953-08-11 12:00:00+00	1953-08-11 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94800
1953-10-08 12:00:00+00	1953-10-08 12:00:00+00	1953-10-08 12:00:00+00	0	6465	\N	\N	6465	\N	\N	\N	\N	47	24	94802
1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	0	6469	\N	\N	6469	\N	\N	\N	\N	47	24	94804
1954-02-11 12:00:00+00	1954-02-11 12:00:00+00	1954-02-11 12:00:00+00	0	6471	\N	\N	6471	\N	\N	\N	\N	47	24	94806
1954-04-07 12:00:00+00	1954-04-07 12:00:00+00	1954-04-07 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94808
1954-06-11 12:00:00+00	1954-06-11 12:00:00+00	1954-06-11 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94810
1954-08-27 12:00:00+00	1954-08-27 12:00:00+00	1954-08-27 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94812
1954-10-13 12:00:00+00	1954-10-13 12:00:00+00	1954-10-13 12:00:00+00	0	6467	\N	\N	6467	\N	\N	\N	\N	47	24	94814
1954-12-01 12:00:00+00	1954-12-01 12:00:00+00	1954-12-01 12:00:00+00	0	6469	\N	\N	6469	\N	\N	\N	\N	47	24	94816
1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	0	6470	\N	\N	6470	\N	\N	\N	\N	47	24	94818
1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94820
1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94822
1955-08-10 12:00:00+00	1955-08-10 12:00:00+00	1955-08-10 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94824
1955-10-10 12:00:00+00	1955-10-10 12:00:00+00	1955-10-10 12:00:00+00	0	6463	\N	\N	6463	\N	\N	\N	\N	47	24	94826
1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	0	6466	\N	\N	6466	\N	\N	\N	\N	47	24	94828
1956-02-07 12:00:00+00	1956-02-07 12:00:00+00	1956-02-07 12:00:00+00	0	6467	\N	\N	6467	\N	\N	\N	\N	47	24	94830
1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	0	6466	\N	\N	6466	\N	\N	\N	\N	47	24	94832
1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94834
1956-08-01 12:00:00+00	1956-08-01 12:00:00+00	1956-08-01 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94836
1956-10-02 12:00:00+00	1956-10-02 12:00:00+00	1956-10-02 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94838
1956-12-12 12:00:00+00	1956-12-12 12:00:00+00	1956-12-12 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94840
1957-02-13 12:00:00+00	1957-02-13 12:00:00+00	1957-02-13 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94842
1957-05-07 12:00:00+00	1957-05-07 12:00:00+00	1957-05-07 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94844
1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94846
1957-11-14 12:00:00+00	1957-11-14 12:00:00+00	1957-11-14 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94848
1958-02-04 12:00:00+00	1958-02-04 12:00:00+00	1958-02-04 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94850
1958-05-14 12:00:00+00	1958-05-14 12:00:00+00	1958-05-14 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94852
1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94854
1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94856
1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94858
1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94860
1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	47	24	94862
1960-02-09 12:00:00+00	1960-02-09 12:00:00+00	1960-02-09 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94864
1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94866
1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	47	24	94868
1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94870
1961-02-15 12:00:00+00	1961-02-15 12:00:00+00	1961-02-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94872
1961-05-10 12:00:00+00	1961-05-10 12:00:00+00	1961-05-10 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94874
1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94876
1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94878
1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94880
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94882
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94884
1962-11-27 12:00:00+00	1962-11-27 12:00:00+00	1962-11-27 12:00:00+00	0	6461	\N	\N	6461	\N	\N	\N	\N	47	24	94886
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94888
1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94890
1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	0	6461	\N	\N	6461	\N	\N	\N	\N	47	24	94892
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	6461	\N	\N	6461	\N	\N	\N	\N	47	24	94894
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	6465	\N	\N	6465	\N	\N	\N	\N	47	24	94896
1965-08-06 12:00:00+00	1965-08-06 12:00:00+00	1965-08-06 12:00:00+00	0	6464	\N	\N	6464	\N	\N	\N	\N	47	24	94898
1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	47	24	94900
1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	0	6467	\N	\N	6467	\N	\N	\N	\N	47	24	94902
1968-04-03 12:00:00+00	1968-04-03 12:00:00+00	1968-04-03 12:00:00+00	0	6466	\N	\N	6466	\N	\N	\N	\N	47	24	94904
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	6464	\N	\N	6464	\N	\N	\N	\N	47	24	94906
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	6465	\N	\N	6465	\N	\N	\N	\N	47	24	94908
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94910
1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	47	24	94912
1977-12-15 07:00:00+00	1977-12-15 07:00:00+00	1977-12-15 07:00:00+00	0	6766	\N	\N	6766	\N	\N	\N	\N	49	25	95084
1991-02-11 07:00:00+00	1991-02-11 07:00:00+00	1991-02-11 07:00:00+00	0	6798	\N	\N	6798	\N	\N	\N	\N	49	25	95086
1996-02-08 07:00:00+00	1996-02-08 07:00:00+00	1996-02-08 07:00:00+00	0	6801	\N	\N	6801	\N	\N	\N	\N	49	25	95088
2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95090
2008-05-08 07:00:00+00	2008-05-08 07:00:00+00	2008-05-08 07:00:00+00	0	6800	\N	\N	6800	\N	\N	\N	\N	49	25	95092
2008-09-17 07:00:00+00	2008-09-17 07:00:00+00	2008-09-17 07:00:00+00	0	6783	\N	\N	6783	\N	\N	\N	\N	49	25	95094
2009-02-23 07:00:00+00	2009-02-23 07:00:00+00	2009-02-23 07:00:00+00	0	6782	\N	\N	6782	\N	\N	\N	\N	49	25	95096
2010-02-10 07:00:00+00	2010-02-10 07:00:00+00	2010-02-10 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95098
2011-03-22 07:00:00+00	2011-03-22 07:00:00+00	2011-03-22 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95100
2012-03-07 07:00:00+00	2012-03-07 07:00:00+00	2012-03-07 07:00:00+00	0	6800	\N	\N	6800	\N	\N	\N	\N	49	25	95102
2013-03-15 07:00:00+00	2013-03-15 07:00:00+00	2013-03-15 07:00:00+00	0	6795	\N	\N	6795	\N	\N	\N	\N	49	25	95104
2015-03-11 07:00:00+00	2015-03-11 07:00:00+00	2015-03-11 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95106
2016-02-19 07:00:00+00	2016-02-19 07:00:00+00	2016-02-19 07:00:00+00	0	6798	\N	\N	6798	\N	\N	\N	\N	49	25	95108
2017-02-23 07:00:00+00	2017-02-23 07:00:00+00	2017-02-23 07:00:00+00	0	6797	\N	\N	6797	\N	\N	\N	\N	49	25	95110
2018-02-19 07:00:00+00	2018-02-19 07:00:00+00	2018-02-19 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95112
2019-02-19 07:00:00+00	2019-02-19 07:00:00+00	2019-02-19 07:00:00+00	0	6797	\N	\N	6797	\N	\N	\N	\N	49	25	95114
2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	49	25	95116
1953-02-20 12:00:00+00	1953-02-20 12:00:00+00	1953-02-20 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95118
1953-04-16 12:00:00+00	1953-04-16 12:00:00+00	1953-04-16 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95120
1953-10-09 12:00:00+00	1953-10-09 12:00:00+00	1953-10-09 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95122
1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	51	26	95124
1954-02-09 12:00:00+00	1954-02-09 12:00:00+00	1954-02-09 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95126
1954-04-06 12:00:00+00	1954-04-06 12:00:00+00	1954-04-06 12:00:00+00	0	6457	\N	\N	6457	\N	\N	\N	\N	51	26	95128
1954-06-14 12:00:00+00	1954-06-14 12:00:00+00	1954-06-14 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95130
1954-12-03 12:00:00+00	1954-12-03 12:00:00+00	1954-12-03 12:00:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	51	26	95132
1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95134
1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95136
1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95138
1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95140
1956-02-08 12:00:00+00	1956-02-08 12:00:00+00	1956-02-08 12:00:00+00	0	6453	\N	\N	6453	\N	\N	\N	\N	51	26	95142
1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	0	6453	\N	\N	6453	\N	\N	\N	\N	51	26	95144
1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	0	6451	\N	\N	6451	\N	\N	\N	\N	51	26	95146
1956-06-27 12:00:00+00	1956-06-27 12:00:00+00	1956-06-27 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95148
1956-08-02 12:00:00+00	1956-08-02 12:00:00+00	1956-08-02 12:00:00+00	0	6448	\N	\N	6448	\N	\N	\N	\N	51	26	95150
1956-12-11 12:00:00+00	1956-12-11 12:00:00+00	1956-12-11 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95152
1957-02-12 12:00:00+00	1957-02-12 12:00:00+00	1957-02-12 12:00:00+00	0	6450	\N	\N	6450	\N	\N	\N	\N	51	26	95154
1957-05-06 12:00:00+00	1957-05-06 12:00:00+00	1957-05-06 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95156
1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95158
1958-02-05 12:00:00+00	1958-02-05 12:00:00+00	1958-02-05 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95160
1958-05-15 12:00:00+00	1958-05-15 12:00:00+00	1958-05-15 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95162
1958-08-18 12:00:00+00	1958-08-18 12:00:00+00	1958-08-18 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95164
1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95166
1959-02-17 12:00:00+00	1959-02-17 12:00:00+00	1959-02-17 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95168
1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95170
1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95172
1959-11-04 12:00:00+00	1959-11-04 12:00:00+00	1959-11-04 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95174
1960-02-08 12:00:00+00	1960-02-08 12:00:00+00	1960-02-08 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95176
1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95178
1960-08-26 12:00:00+00	1960-08-26 12:00:00+00	1960-08-26 12:00:00+00	0	6442	\N	\N	6442	\N	\N	\N	\N	51	26	95180
1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95182
1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95184
1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95186
1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	0	6440	\N	\N	6440	\N	\N	\N	\N	51	26	95188
1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	0	6441	\N	\N	6441	\N	\N	\N	\N	51	26	95190
1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	0	6442	\N	\N	6442	\N	\N	\N	\N	51	26	95192
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	6442	\N	\N	6442	\N	\N	\N	\N	51	26	95194
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	6441	\N	\N	6441	\N	\N	\N	\N	51	26	95196
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95198
1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95200
1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	0	6448	\N	\N	6448	\N	\N	\N	\N	51	26	95202
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95204
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	6450	\N	\N	6450	\N	\N	\N	\N	51	26	95206
1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95208
1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	0	6451	\N	\N	6451	\N	\N	\N	\N	51	26	95210
1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	0	6451	\N	\N	6451	\N	\N	\N	\N	51	26	95212
1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95214
1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95216
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95218
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	6450	\N	\N	6450	\N	\N	\N	\N	51	26	95220
1970-08-18 12:00:00+00	1970-08-18 12:00:00+00	1970-08-18 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95222
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95224
1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95226
1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95228
1973-08-28 12:00:00+00	1973-08-28 12:00:00+00	1973-08-28 12:00:00+00	0	6441	\N	\N	6441	\N	\N	\N	\N	51	26	95230
1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95232
1974-08-06 12:00:00+00	1974-08-06 12:00:00+00	1974-08-06 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95234
1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	0	6446	\N	\N	6446	\N	\N	\N	\N	51	26	95236
1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95238
1976-08-11 12:00:00+00	1976-08-11 12:00:00+00	1976-08-11 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95240
1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95242
1977-08-16 12:00:00+00	1977-08-16 12:00:00+00	1977-08-16 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95244
1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95246
1978-08-07 12:00:00+00	1978-08-07 12:00:00+00	1978-08-07 12:00:00+00	0	6441	\N	\N	6441	\N	\N	\N	\N	51	26	95248
1979-03-07 12:00:00+00	1979-03-07 12:00:00+00	1979-03-07 12:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	51	26	95250
1979-07-17 12:00:00+00	1979-07-17 12:00:00+00	1979-07-17 12:00:00+00	0	6440	\N	\N	6440	\N	\N	\N	\N	51	26	95252
1980-07-15 12:00:00+00	1980-07-15 12:00:00+00	1980-07-15 12:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	51	26	95254
1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	0	6447	\N	\N	6447	\N	\N	\N	\N	51	26	95256
1981-07-20 12:00:00+00	1981-07-20 12:00:00+00	1981-07-20 12:00:00+00	0	6445	\N	\N	6445	\N	\N	\N	\N	51	26	95258
1982-02-23 12:00:00+00	1982-02-23 12:00:00+00	1982-02-23 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95260
1982-09-07 12:00:00+00	1982-09-07 12:00:00+00	1982-09-07 12:00:00+00	0	6449	\N	\N	6449	\N	\N	\N	\N	51	26	95262
1983-01-17 12:00:00+00	1983-01-17 12:00:00+00	1983-01-17 12:00:00+00	0	6452	\N	\N	6452	\N	\N	\N	\N	51	26	95264
1983-08-12 12:00:00+00	1983-08-12 12:00:00+00	1983-08-12 12:00:00+00	0	6453	\N	\N	6453	\N	\N	\N	\N	51	26	95266
1984-01-11 12:00:00+00	1984-01-11 12:00:00+00	1984-01-11 12:00:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	51	26	95268
1984-08-14 12:00:00+00	1984-08-14 12:00:00+00	1984-08-14 12:00:00+00	0	6453	\N	\N	6453	\N	\N	\N	\N	51	26	95270
1985-02-06 12:00:00+00	1985-02-06 12:00:00+00	1985-02-06 12:00:00+00	0	6457	\N	\N	6457	\N	\N	\N	\N	51	26	95272
1985-08-08 12:00:00+00	1985-08-08 12:00:00+00	1985-08-08 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95274
1985-09-01 12:00:00+00	1985-09-01 12:00:00+00	1985-09-01 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95276
1985-09-12 12:00:00+00	1985-09-12 12:00:00+00	1985-09-12 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	51	26	95278
1985-10-01 12:00:00+00	1985-10-01 12:00:00+00	1985-10-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95280
1985-11-01 12:00:00+00	1985-11-01 12:00:00+00	1985-11-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95282
1985-12-01 12:00:00+00	1985-12-01 12:00:00+00	1985-12-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95284
1986-01-01 12:00:00+00	1986-01-01 12:00:00+00	1986-01-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95286
1986-01-06 12:00:00+00	1986-01-06 12:00:00+00	1986-01-06 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95288
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95290
1986-03-01 12:00:00+00	1986-03-01 12:00:00+00	1986-03-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95292
1986-04-17 12:00:00+00	1986-04-17 12:00:00+00	1986-04-17 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95294
1986-05-01 12:00:00+00	1986-05-01 12:00:00+00	1986-05-01 12:00:00+00	0	6457	\N	\N	6457	\N	\N	\N	\N	51	26	95296
1986-06-01 12:00:00+00	1986-06-01 12:00:00+00	1986-06-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95298
1986-07-01 12:00:00+00	1986-07-01 12:00:00+00	1986-07-01 12:00:00+00	0	6457	\N	\N	6457	\N	\N	\N	\N	51	26	95300
1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	0	6457	\N	\N	6457	\N	\N	\N	\N	51	26	95302
1986-09-01 12:00:00+00	1986-09-01 12:00:00+00	1986-09-01 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95304
1986-10-01 12:00:00+00	1986-10-01 12:00:00+00	1986-10-01 12:00:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	51	26	95306
1986-11-01 12:00:00+00	1986-11-01 12:00:00+00	1986-11-01 12:00:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	51	26	95308
1987-08-11 12:00:00+00	1987-08-11 12:00:00+00	1987-08-11 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95310
1988-01-06 12:00:00+00	1988-01-06 12:00:00+00	1988-01-06 12:00:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	51	26	95312
1988-09-29 12:00:00+00	1988-09-29 12:00:00+00	1988-09-29 12:00:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	51	26	95314
1989-03-28 12:00:00+00	1989-03-28 12:00:00+00	1989-03-28 12:00:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	51	26	95316
1980-05-02 07:00:00+00	1980-05-02 07:00:00+00	1980-05-02 07:00:00+00	0	6801	\N	\N	6801	\N	\N	\N	\N	53	27	95450
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95452
2013-03-13 07:00:00+00	2013-03-13 07:00:00+00	2013-03-13 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95454
2015-02-13 07:00:00+00	2015-02-13 07:00:00+00	2015-02-13 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95456
2016-02-17 07:00:00+00	2016-02-17 07:00:00+00	2016-02-17 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95458
2017-02-28 07:00:00+00	2017-02-28 07:00:00+00	2017-02-28 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95460
2018-02-21 07:00:00+00	2018-02-21 07:00:00+00	2018-02-21 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95462
2019-02-21 07:00:00+00	2019-02-21 07:00:00+00	2019-02-21 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95464
2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95466
2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	0	6799	\N	\N	6799	\N	\N	\N	\N	53	27	95468
1980-05-02 07:00:00+00	1980-05-02 07:00:00+00	1980-05-02 07:00:00+00	0	176.71	\N	\N	176.71	\N	\N	\N	\N	54	27	95449
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	178.86	\N	\N	178.86	\N	\N	\N	\N	54	27	95451
2013-03-13 07:00:00+00	2013-03-13 07:00:00+00	2013-03-13 07:00:00+00	0	179.03	\N	\N	179.03	\N	\N	\N	\N	54	27	95453
2015-02-13 07:00:00+00	2015-02-13 07:00:00+00	2015-02-13 07:00:00+00	0	178.98	\N	\N	178.98	\N	\N	\N	\N	54	27	95455
2016-02-17 07:00:00+00	2016-02-17 07:00:00+00	2016-02-17 07:00:00+00	0	178.95	\N	\N	178.95	\N	\N	\N	\N	54	27	95457
2017-02-28 07:00:00+00	2017-02-28 07:00:00+00	2017-02-28 07:00:00+00	0	179.02	\N	\N	179.02	\N	\N	\N	\N	54	27	95459
2018-02-21 07:00:00+00	2018-02-21 07:00:00+00	2018-02-21 07:00:00+00	0	179.21	\N	\N	179.21	\N	\N	\N	\N	54	27	95461
2019-02-21 07:00:00+00	2019-02-21 07:00:00+00	2019-02-21 07:00:00+00	0	179.16	\N	\N	179.16	\N	\N	\N	\N	54	27	95463
2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	0	179.28	\N	\N	179.28	\N	\N	\N	\N	54	27	95465
2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	0	179.41	\N	\N	179.41	\N	\N	\N	\N	54	27	95467
2013-06-06 07:00:00+00	2013-06-06 07:00:00+00	2013-06-06 07:00:00+00	0	6268	\N	\N	6268	\N	\N	\N	\N	61	31	95642
2013-06-13 07:00:00+00	2013-06-13 07:00:00+00	2013-06-13 07:00:00+00	0	6271	\N	\N	6271	\N	\N	\N	\N	61	31	95644
2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	0	6282	\N	\N	6282	\N	\N	\N	\N	61	31	95646
2014-02-18 07:00:00+00	2014-02-18 07:00:00+00	2014-02-18 07:00:00+00	0	6292	\N	\N	6292	\N	\N	\N	\N	61	31	95648
2014-03-12 07:00:00+00	2014-03-12 07:00:00+00	2014-03-12 07:00:00+00	0	6294	\N	\N	6294	\N	\N	\N	\N	61	31	95650
2014-04-01 07:00:00+00	2014-04-01 07:00:00+00	2014-04-01 07:00:00+00	0	6294	\N	\N	6294	\N	\N	\N	\N	61	31	95652
2014-04-28 07:00:00+00	2014-04-28 07:00:00+00	2014-04-28 07:00:00+00	0	6296	\N	\N	6296	\N	\N	\N	\N	61	31	95654
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	6297	\N	\N	6297	\N	\N	\N	\N	61	31	95656
2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	0	6297	\N	\N	6297	\N	\N	\N	\N	61	31	95658
2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	0	6297	\N	\N	6297	\N	\N	\N	\N	61	31	95660
2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	0	6299	\N	\N	6299	\N	\N	\N	\N	61	31	95662
2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	0	6302	\N	\N	6302	\N	\N	\N	\N	61	31	95664
2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	0	6305	\N	\N	6305	\N	\N	\N	\N	61	31	95666
2015-12-02 07:00:00+00	2015-12-02 07:00:00+00	2015-12-02 07:00:00+00	0	6306	\N	\N	6306	\N	\N	\N	\N	61	31	95668
2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	0	6303	\N	\N	6303	\N	\N	\N	\N	61	31	95670
2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	0	6302	\N	\N	6302	\N	\N	\N	\N	61	31	95672
2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	0	6305	\N	\N	6305	\N	\N	\N	\N	61	31	95674
2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	0	6301	\N	\N	6301	\N	\N	\N	\N	61	31	95676
2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	0	6296	\N	\N	6296	\N	\N	\N	\N	61	31	95678
2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	0	6289	\N	\N	6289	\N	\N	\N	\N	61	31	95680
2018-12-07 07:00:00+00	2018-12-07 07:00:00+00	2018-12-07 07:00:00+00	0	6290	\N	\N	6290	\N	\N	\N	\N	61	31	95682
2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	0	6288	\N	\N	6288	\N	\N	\N	\N	61	31	95684
2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	0	6285	\N	\N	6285	\N	\N	\N	\N	61	31	95686
2020-03-10 07:00:00+00	2020-03-10 07:00:00+00	2020-03-10 07:00:00+00	0	6284	\N	\N	6284	\N	\N	\N	\N	61	31	95688
1975-07-08 12:00:00+00	1975-07-08 12:00:00+00	1975-07-08 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95690
1982-12-16 12:00:00+00	1982-12-16 12:00:00+00	1982-12-16 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95692
1983-01-27 12:00:00+00	1983-01-27 12:00:00+00	1983-01-27 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95694
1983-02-24 12:00:00+00	1983-02-24 12:00:00+00	1983-02-24 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95696
1983-03-30 12:00:00+00	1983-03-30 12:00:00+00	1983-03-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95698
1983-04-26 12:00:00+00	1983-04-26 12:00:00+00	1983-04-26 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95700
1983-05-31 12:00:00+00	1983-05-31 12:00:00+00	1983-05-31 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95702
1983-07-11 12:00:00+00	1983-07-11 12:00:00+00	1983-07-11 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95704
1983-08-01 12:00:00+00	1983-08-01 12:00:00+00	1983-08-01 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95706
1983-10-07 12:00:00+00	1983-10-07 12:00:00+00	1983-10-07 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95708
1983-12-02 12:00:00+00	1983-12-02 12:00:00+00	1983-12-02 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95710
1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95712
1984-03-01 12:00:00+00	1984-03-01 12:00:00+00	1984-03-01 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95714
1984-04-30 12:00:00+00	1984-04-30 12:00:00+00	1984-04-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95716
1984-06-10 12:00:00+00	1984-06-10 12:00:00+00	1984-06-10 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95718
1984-07-30 12:00:00+00	1984-07-30 12:00:00+00	1984-07-30 12:00:00+00	0	4721	\N	\N	4721	\N	\N	\N	\N	63	32	95720
1985-02-28 12:00:00+00	1985-02-28 12:00:00+00	1985-02-28 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95722
1985-04-23 12:00:00+00	1985-04-23 12:00:00+00	1985-04-23 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95724
1985-09-05 12:00:00+00	1985-09-05 12:00:00+00	1985-09-05 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95726
1986-01-29 12:00:00+00	1986-01-29 12:00:00+00	1986-01-29 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95728
1986-05-30 12:00:00+00	1986-05-30 12:00:00+00	1986-05-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95730
1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	0	4724	\N	\N	4724	\N	\N	\N	\N	63	32	95732
1987-01-21 12:00:00+00	1987-01-21 12:00:00+00	1987-01-21 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95734
1987-06-30 12:00:00+00	1987-06-30 12:00:00+00	1987-06-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95736
1987-07-30 12:00:00+00	1987-07-30 12:00:00+00	1987-07-30 12:00:00+00	0	4721	\N	\N	4721	\N	\N	\N	\N	63	32	95738
1987-12-30 12:00:00+00	1987-12-30 12:00:00+00	1987-12-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95740
1988-07-26 12:00:00+00	1988-07-26 12:00:00+00	1988-07-26 12:00:00+00	0	4720	\N	\N	4720	\N	\N	\N	\N	63	32	95742
1989-01-30 12:00:00+00	1989-01-30 12:00:00+00	1989-01-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95744
1989-07-07 12:00:00+00	1989-07-07 12:00:00+00	1989-07-07 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95746
1990-02-09 12:00:00+00	1990-02-09 12:00:00+00	1990-02-09 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95748
1990-07-06 12:00:00+00	1990-07-06 12:00:00+00	1990-07-06 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95750
1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95752
1991-07-02 12:00:00+00	1991-07-02 12:00:00+00	1991-07-02 12:00:00+00	0	4721	\N	\N	4721	\N	\N	\N	\N	63	32	95754
1991-07-20 12:00:00+00	1991-07-20 12:00:00+00	1991-07-20 12:00:00+00	0	4721	\N	\N	4721	\N	\N	\N	\N	63	32	95756
1991-10-02 12:00:00+00	1991-10-02 12:00:00+00	1991-10-02 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95758
1992-01-09 12:00:00+00	1992-01-09 12:00:00+00	1992-01-09 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95760
1992-07-14 12:00:00+00	1992-07-14 12:00:00+00	1992-07-14 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95762
1993-01-12 12:00:00+00	1993-01-12 12:00:00+00	1993-01-12 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95764
1993-06-30 12:00:00+00	1993-06-30 12:00:00+00	1993-06-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95766
1993-12-30 12:00:00+00	1993-12-30 12:00:00+00	1993-12-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95768
1994-06-30 12:00:00+00	1994-06-30 12:00:00+00	1994-06-30 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95770
1995-01-20 12:00:00+00	1995-01-20 12:00:00+00	1995-01-20 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95772
1995-06-29 12:00:00+00	1995-06-29 12:00:00+00	1995-06-29 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95774
1995-10-31 12:00:00+00	1995-10-31 12:00:00+00	1995-10-31 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95776
1996-01-25 12:00:00+00	1996-01-25 12:00:00+00	1996-01-25 12:00:00+00	0	4724	\N	\N	4724	\N	\N	\N	\N	63	32	95778
1996-09-24 12:00:00+00	1996-09-24 12:00:00+00	1996-09-24 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95780
1997-04-29 12:00:00+00	1997-04-29 12:00:00+00	1997-04-29 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95782
1998-02-12 12:00:00+00	1998-02-12 12:00:00+00	1998-02-12 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95784
1998-07-29 12:00:00+00	1998-07-29 12:00:00+00	1998-07-29 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95786
1999-07-20 12:00:00+00	1999-07-20 12:00:00+00	1999-07-20 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95788
2000-02-10 12:00:00+00	2000-02-10 12:00:00+00	2000-02-10 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95790
2000-08-23 12:00:00+00	2000-08-23 12:00:00+00	2000-08-23 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95792
2000-12-11 12:00:00+00	2000-12-11 12:00:00+00	2000-12-11 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95794
2001-06-11 12:00:00+00	2001-06-11 12:00:00+00	2001-06-11 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95796
2001-12-19 12:00:00+00	2001-12-19 12:00:00+00	2001-12-19 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95798
2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95800
2003-09-29 12:00:00+00	2003-09-29 12:00:00+00	2003-09-29 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95802
2004-03-08 12:00:00+00	2004-03-08 12:00:00+00	2004-03-08 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95804
2004-09-16 12:00:00+00	2004-09-16 12:00:00+00	2004-09-16 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95806
2005-03-18 12:00:00+00	2005-03-18 12:00:00+00	2005-03-18 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95808
2005-09-08 12:00:00+00	2005-09-08 12:00:00+00	2005-09-08 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95810
2006-02-23 12:00:00+00	2006-02-23 12:00:00+00	2006-02-23 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95812
2006-09-11 12:00:00+00	2006-09-11 12:00:00+00	2006-09-11 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95814
2007-03-05 12:00:00+00	2007-03-05 12:00:00+00	2007-03-05 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95816
2007-08-26 12:00:00+00	2007-08-26 12:00:00+00	2007-08-26 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95818
2008-03-28 12:00:00+00	2008-03-28 12:00:00+00	2008-03-28 12:00:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95820
2008-08-28 12:00:00+00	2008-08-28 12:00:00+00	2008-08-28 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95822
2009-02-23 12:00:00+00	2009-02-23 12:00:00+00	2009-02-23 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95824
2009-08-24 12:00:00+00	2009-08-24 12:00:00+00	2009-08-24 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95826
2010-02-23 12:00:00+00	2010-02-23 12:00:00+00	2010-02-23 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95828
2010-08-30 12:00:00+00	2010-08-30 12:00:00+00	2010-08-30 12:00:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95830
2011-02-16 17:02:00+00	2011-02-16 17:02:00+00	2011-02-16 17:02:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95832
2011-09-09 15:57:00+00	2011-09-09 15:57:00+00	2011-09-09 15:57:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95834
2012-03-02 16:03:00+00	2012-03-02 16:03:00+00	2012-03-02 16:03:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95836
2012-08-24 16:13:00+00	2012-08-24 16:13:00+00	2012-08-24 16:13:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95838
2013-02-26 16:34:00+00	2013-02-26 16:34:00+00	2013-02-26 16:34:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95840
2013-09-03 15:40:00+00	2013-09-03 15:40:00+00	2013-09-03 15:40:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95842
2014-02-25 16:27:00+00	2014-02-25 16:27:00+00	2014-02-25 16:27:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95844
2014-08-25 15:17:00+00	2014-08-25 15:17:00+00	2014-08-25 15:17:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95846
2015-03-03 16:16:00+00	2015-03-03 16:16:00+00	2015-03-03 16:16:00+00	0	4723	\N	\N	4723	\N	\N	\N	\N	63	32	95848
2015-08-27 16:40:00+00	2015-08-27 16:40:00+00	2015-08-27 16:40:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95850
2016-02-29 17:17:00+00	2016-02-29 17:17:00+00	2016-02-29 17:17:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95852
2016-08-23 14:31:00+00	2016-08-23 14:31:00+00	2016-08-23 14:31:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95854
2017-02-27 16:03:00+00	2017-02-27 16:03:00+00	2017-02-27 16:03:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95856
2017-08-21 16:04:00+00	2017-08-21 16:04:00+00	2017-08-21 16:04:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95858
2018-03-05 16:42:00+00	2018-03-05 16:42:00+00	2018-03-05 16:42:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95860
2018-08-27 14:54:00+00	2018-08-27 14:54:00+00	2018-08-27 14:54:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95862
2019-03-04 16:05:00+00	2019-03-04 16:05:00+00	2019-03-04 16:05:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95864
2019-08-21 14:26:00+00	2019-08-21 14:26:00+00	2019-08-21 14:26:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95866
2020-02-27 16:40:00+00	2020-02-27 16:40:00+00	2020-02-27 16:40:00+00	0	4722	\N	\N	4722	\N	\N	\N	\N	63	32	95868
1999-02-05 00:00:00+00	1999-02-05 00:00:00+00	1999-02-05 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95870
1999-02-06 00:00:00+00	1999-02-06 00:00:00+00	1999-02-06 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95872
1999-02-07 00:00:00+00	1999-02-07 00:00:00+00	1999-02-07 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95874
1999-02-08 00:00:00+00	1999-02-08 00:00:00+00	1999-02-08 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95876
1999-02-09 00:00:00+00	1999-02-09 00:00:00+00	1999-02-09 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95878
1999-02-10 00:00:00+00	1999-02-10 00:00:00+00	1999-02-10 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95880
1999-02-11 00:00:00+00	1999-02-11 00:00:00+00	1999-02-11 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95882
1999-02-12 00:00:00+00	1999-02-12 00:00:00+00	1999-02-12 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95884
1999-02-13 00:00:00+00	1999-02-13 00:00:00+00	1999-02-13 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95886
1999-02-14 00:00:00+00	1999-02-14 00:00:00+00	1999-02-14 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95888
1999-02-15 00:00:00+00	1999-02-15 00:00:00+00	1999-02-15 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95890
1999-02-16 00:00:00+00	1999-02-16 00:00:00+00	1999-02-16 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95892
1999-02-17 00:00:00+00	1999-02-17 00:00:00+00	1999-02-17 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95894
1999-02-18 00:00:00+00	1999-02-18 00:00:00+00	1999-02-18 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95896
1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95898
1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95900
1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95902
1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95904
1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95906
1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95908
1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95910
1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95912
1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95914
1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95916
1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95918
1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95920
1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95922
1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95924
1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95926
1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95928
1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95930
1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95932
1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95934
1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95936
1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95938
1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95940
1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95942
1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95944
1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95946
1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95948
1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95950
1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95952
1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95954
1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95956
1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95958
1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95960
1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95962
1999-03-24 00:00:00+00	1999-03-24 00:00:00+00	1999-03-24 00:00:00+00	0	4797	\N	\N	4797	\N	\N	\N	\N	65	33	95964
1999-04-20 00:00:00+00	1999-04-20 00:00:00+00	1999-04-20 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95966
1999-04-21 00:00:00+00	1999-04-21 00:00:00+00	1999-04-21 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95968
1999-04-22 00:00:00+00	1999-04-22 00:00:00+00	1999-04-22 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95970
1999-04-23 00:00:00+00	1999-04-23 00:00:00+00	1999-04-23 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95972
1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95974
1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95976
1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95978
1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95980
1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95982
1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95984
1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95986
1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95988
1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95990
1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95992
1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95994
1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95996
1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	95998
1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96000
1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96002
1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96004
1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96006
1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96008
1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96010
1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96012
1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96014
1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96016
1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96018
1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96020
1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96022
1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96024
1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96026
1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96028
1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96030
1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96032
1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96034
1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96036
1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96038
1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96040
1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96042
1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96044
1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96046
1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96048
1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96050
1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96052
1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96054
1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96056
1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96058
1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96060
1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96062
1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96064
1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96066
1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	0	4796	\N	\N	4796	\N	\N	\N	\N	65	33	96068
1974-06-25 12:00:00+00	1974-06-25 12:00:00+00	1974-06-25 12:00:00+00	0	3834	\N	\N	3834	\N	\N	\N	\N	81	41	172790
1983-03-02 12:00:00+00	1983-03-02 12:00:00+00	1983-03-02 12:00:00+00	0	3961	\N	\N	3961	\N	\N	\N	\N	81	41	172792
1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172794
1986-03-24 12:00:00+00	1986-03-24 12:00:00+00	1986-03-24 12:00:00+00	0	3840	\N	\N	3840	\N	\N	\N	\N	81	41	172796
1987-02-11 12:00:00+00	1987-02-11 12:00:00+00	1987-02-11 12:00:00+00	0	3842	\N	\N	3842	\N	\N	\N	\N	81	41	172798
1988-02-10 12:00:00+00	1988-02-10 12:00:00+00	1988-02-10 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172800
1989-02-27 12:00:00+00	1989-02-27 12:00:00+00	1989-02-27 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172802
1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172804
1991-02-15 12:00:00+00	1991-02-15 12:00:00+00	1991-02-15 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172806
1992-02-03 12:00:00+00	1992-02-03 12:00:00+00	1992-02-03 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172808
1993-02-11 12:00:00+00	1993-02-11 12:00:00+00	1993-02-11 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172810
1994-02-07 12:00:00+00	1994-02-07 12:00:00+00	1994-02-07 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172812
1995-02-07 12:00:00+00	1995-02-07 12:00:00+00	1995-02-07 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172814
1996-02-05 12:00:00+00	1996-02-05 12:00:00+00	1996-02-05 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172816
1997-02-17 12:00:00+00	1997-02-17 12:00:00+00	1997-02-17 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172818
1998-02-11 12:00:00+00	1998-02-11 12:00:00+00	1998-02-11 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172820
1999-01-27 18:15:00+00	1999-01-27 18:15:00+00	1999-01-27 18:15:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172822
2000-02-14 17:30:00+00	2000-02-14 17:30:00+00	2000-02-14 17:30:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172824
2001-02-20 12:00:00+00	2001-02-20 12:00:00+00	2001-02-20 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172826
2002-02-11 12:00:00+00	2002-02-11 12:00:00+00	2002-02-11 12:00:00+00	0	3840	\N	\N	3840	\N	\N	\N	\N	81	41	172828
2003-02-12 12:00:00+00	2003-02-12 12:00:00+00	2003-02-12 12:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172830
2004-02-16 12:00:00+00	2004-02-16 12:00:00+00	2004-02-16 12:00:00+00	0	3840	\N	\N	3840	\N	\N	\N	\N	81	41	172832
2005-03-24 21:25:00+00	2005-03-24 21:25:00+00	2005-03-24 21:25:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172834
2006-03-28 19:34:00+00	2006-03-28 19:34:00+00	2006-03-28 19:34:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172836
2007-03-20 20:56:00+00	2007-03-20 20:56:00+00	2007-03-20 20:56:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172838
2009-02-25 20:36:00+00	2009-02-25 20:36:00+00	2009-02-25 20:36:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172840
2010-02-05 00:00:00+00	2010-02-05 00:00:00+00	2010-02-05 00:00:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172842
2011-03-16 18:04:00+00	2011-03-16 18:04:00+00	2011-03-16 18:04:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172844
2012-03-21 19:32:00+00	2012-03-21 19:32:00+00	2012-03-21 19:32:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172846
2013-01-22 20:03:00+00	2013-01-22 20:03:00+00	2013-01-22 20:03:00+00	0	3840	\N	\N	3840	\N	\N	\N	\N	81	41	172848
2015-03-03 23:37:00+00	2015-03-03 23:37:00+00	2015-03-03 23:37:00+00	0	3841	\N	\N	3841	\N	\N	\N	\N	81	41	172850
2019-02-01 18:40:00+00	2019-02-01 18:40:00+00	2019-02-01 18:40:00+00	0	3840	\N	\N	3840	\N	\N	\N	\N	81	41	172852
2011-03-15 07:00:00+00	2011-03-15 07:00:00+00	2011-03-15 07:00:00+00	0	152.33	\N	\N	152.33	\N	\N	\N	\N	4	2	35
2011-06-03 07:00:00+00	2011-06-03 07:00:00+00	2011-06-03 07:00:00+00	0	152.79	\N	\N	152.79	\N	\N	\N	\N	4	2	37
2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	0	152.85	\N	\N	152.85	\N	\N	\N	\N	4	2	39
2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	0	153	\N	\N	153	\N	\N	\N	\N	4	2	41
2011-12-14 07:00:00+00	2011-12-14 07:00:00+00	2011-12-14 07:00:00+00	0	152.65	\N	\N	152.65	\N	\N	\N	\N	4	2	43
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	153.14	\N	\N	153.14	\N	\N	\N	\N	4	2	45
2012-06-05 07:00:00+00	2012-06-05 07:00:00+00	2012-06-05 07:00:00+00	0	153.44	\N	\N	153.44	\N	\N	\N	\N	4	2	47
2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	0	153.94	\N	\N	153.94	\N	\N	\N	\N	4	2	49
2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	0	154.59	\N	\N	154.59	\N	\N	\N	\N	4	2	51
2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	0	154.89	\N	\N	154.89	\N	\N	\N	\N	4	2	53
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	154.86	\N	\N	154.86	\N	\N	\N	\N	4	2	55
2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	0	155.05	\N	\N	155.05	\N	\N	\N	\N	4	2	57
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	155.31	\N	\N	155.31	\N	\N	\N	\N	4	2	59
2014-08-04 07:00:00+00	2014-08-04 07:00:00+00	2014-08-04 07:00:00+00	0	155.27	\N	\N	155.27	\N	\N	\N	\N	4	2	61
2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	0	154.87	\N	\N	154.87	\N	\N	\N	\N	4	2	63
2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	0	154.75	\N	\N	154.75	\N	\N	\N	\N	4	2	65
2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	0	155.15	\N	\N	155.15	\N	\N	\N	\N	4	2	67
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	154.69	\N	\N	154.69	\N	\N	\N	\N	4	2	69
2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	0	154.48	\N	\N	154.48	\N	\N	\N	\N	4	2	71
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	153.29	\N	\N	153.29	\N	\N	\N	\N	4	2	73
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	155.32	\N	\N	155.32	\N	\N	\N	\N	4	2	75
2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	0	155.47	\N	\N	155.47	\N	\N	\N	\N	4	2	77
2011-04-21 07:00:00+00	2011-04-21 07:00:00+00	2011-04-21 07:00:00+00	0	252.33	\N	\N	252.33	\N	\N	\N	\N	6	3	79
2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	0	252.54	\N	\N	252.54	\N	\N	\N	\N	6	3	81
2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	0	252.78	\N	\N	252.78	\N	\N	\N	\N	6	3	83
2011-12-16 07:00:00+00	2011-12-16 07:00:00+00	2011-12-16 07:00:00+00	0	252.78	\N	\N	252.78	\N	\N	\N	\N	6	3	85
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	252.67	\N	\N	252.67	\N	\N	\N	\N	6	3	87
2012-06-06 07:00:00+00	2012-06-06 07:00:00+00	2012-06-06 07:00:00+00	0	252.48	\N	\N	252.48	\N	\N	\N	\N	6	3	89
2012-09-22 07:00:00+00	2012-09-22 07:00:00+00	2012-09-22 07:00:00+00	0	252.5	\N	\N	252.5	\N	\N	\N	\N	6	3	91
2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	0	252.57	\N	\N	252.57	\N	\N	\N	\N	6	3	93
2013-03-12 07:00:00+00	2013-03-12 07:00:00+00	2013-03-12 07:00:00+00	0	252.82	\N	\N	252.82	\N	\N	\N	\N	6	3	95
2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	0	252.73	\N	\N	252.73	\N	\N	\N	\N	6	3	97
2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	0	252.75	\N	\N	252.75	\N	\N	\N	\N	6	3	99
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	252.6	\N	\N	252.6	\N	\N	\N	\N	6	3	101
2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	0	252.51	\N	\N	252.51	\N	\N	\N	\N	6	3	103
2014-06-05 07:00:00+00	2014-06-05 07:00:00+00	2014-06-05 07:00:00+00	0	252.56	\N	\N	252.56	\N	\N	\N	\N	6	3	105
2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	0	252.45	\N	\N	252.45	\N	\N	\N	\N	6	3	107
2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	0	252.76	\N	\N	252.76	\N	\N	\N	\N	6	3	109
2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	0	252.6	\N	\N	252.6	\N	\N	\N	\N	6	3	111
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	252.61	\N	\N	252.61	\N	\N	\N	\N	6	3	113
2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	0	252.66	\N	\N	252.66	\N	\N	\N	\N	6	3	115
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	252.73	\N	\N	252.73	\N	\N	\N	\N	6	3	117
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	252.64	\N	\N	252.64	\N	\N	\N	\N	6	3	119
2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	0	252.49	\N	\N	252.49	\N	\N	\N	\N	6	3	121
1969-06-18 12:00:00+00	1969-06-18 12:00:00+00	1969-06-18 12:00:00+00	0	189.5	\N	\N	189.5	\N	\N	\N	\N	28	14	851
1986-06-11 12:00:00+00	1986-06-11 12:00:00+00	1986-06-11 12:00:00+00	0	214.46	\N	\N	214.46	\N	\N	\N	\N	28	14	853
1997-02-27 12:00:00+00	1997-02-27 12:00:00+00	1997-02-27 12:00:00+00	0	178.58	\N	\N	178.58	\N	\N	\N	\N	28	14	855
2002-03-16 12:00:00+00	2002-03-16 12:00:00+00	2002-03-16 12:00:00+00	0	271.4	\N	\N	271.4	\N	\N	\N	\N	28	14	857
2003-03-21 12:00:00+00	2003-03-21 12:00:00+00	2003-03-21 12:00:00+00	0	278.95	\N	\N	278.95	\N	\N	\N	\N	28	14	859
2004-03-05 15:25:00+00	2004-03-05 15:25:00+00	2004-03-05 15:25:00+00	0	207.35	\N	\N	207.35	\N	\N	\N	\N	28	14	861
2005-03-07 16:04:00+00	2005-03-07 16:04:00+00	2005-03-07 16:04:00+00	0	171.09	\N	\N	171.09	\N	\N	\N	\N	28	14	863
2006-02-16 22:30:00+00	2006-02-16 22:30:00+00	2006-02-16 22:30:00+00	0	190.33	\N	\N	190.33	\N	\N	\N	\N	28	14	865
2007-03-05 18:01:00+00	2007-03-05 18:01:00+00	2007-03-05 18:01:00+00	0	214.02	\N	\N	214.02	\N	\N	\N	\N	28	14	867
2008-03-24 19:15:00+00	2008-03-24 19:15:00+00	2008-03-24 19:15:00+00	0	197.97	\N	\N	197.97	\N	\N	\N	\N	28	14	869
2009-03-24 22:23:00+00	2009-03-24 22:23:00+00	2009-03-24 22:23:00+00	0	195.01	\N	\N	195.01	\N	\N	\N	\N	28	14	871
2010-03-15 20:00:00+00	2010-03-15 20:00:00+00	2010-03-15 20:00:00+00	0	171.12	\N	\N	171.12	\N	\N	\N	\N	28	14	873
2011-01-24 20:30:00+00	2011-01-24 20:30:00+00	2011-01-24 20:30:00+00	0	228.78	\N	\N	228.78	\N	\N	\N	\N	28	14	875
2012-03-17 20:30:00+00	2012-03-17 20:30:00+00	2012-03-17 20:30:00+00	0	230.41	\N	\N	230.41	\N	\N	\N	\N	28	14	877
2013-04-08 22:30:00+00	2013-04-08 22:30:00+00	2013-04-08 22:30:00+00	0	229.91	\N	\N	229.91	\N	\N	\N	\N	28	14	879
2014-03-17 14:30:00+00	2014-03-17 14:30:00+00	2014-03-17 14:30:00+00	0	228.17	\N	\N	228.17	\N	\N	\N	\N	28	14	881
2015-02-24 00:00:00+00	2015-02-24 00:00:00+00	2015-02-24 00:00:00+00	0	174.18	\N	\N	174.18	\N	\N	\N	\N	28	14	883
2016-02-22 21:15:00+00	2016-02-22 21:15:00+00	2016-02-22 21:15:00+00	0	172.19	\N	\N	172.19	\N	\N	\N	\N	28	14	885
2016-08-29 22:30:00+00	2016-08-29 22:30:00+00	2016-08-29 22:30:00+00	0	163.34	\N	\N	163.34	\N	\N	\N	\N	28	14	887
2017-08-03 18:47:00+00	2017-08-03 18:47:00+00	2017-08-03 18:47:00+00	0	173.2	\N	\N	173.2	\N	\N	\N	\N	28	14	889
2018-02-05 23:45:00+00	2018-02-05 23:45:00+00	2018-02-05 23:45:00+00	0	216.99	\N	\N	216.99	\N	\N	\N	\N	28	14	891
1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29012
1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29014
1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29016
1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29018
1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29020
1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29022
1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29024
1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29026
1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29028
1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29030
1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29032
1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29034
1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29036
1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29038
1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29040
1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29042
1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29044
1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29046
1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29048
1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29050
1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29052
1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29054
1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29056
1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29058
1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29060
1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29062
1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29064
1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29066
1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29068
1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29070
1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29072
1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29074
1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29076
1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	0	5202	\N	\N	5202	\N	\N	\N	\N	33	17	29078
1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29080
1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29082
1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29084
1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29086
1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29088
1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29090
1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29092
1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29094
1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29096
1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29098
1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29100
1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29102
1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29104
1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29106
1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29108
1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29110
1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29112
1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29114
1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29116
1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29118
1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29120
1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29122
1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29124
1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29126
1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29128
1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29130
1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29132
1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29134
1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29136
1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29138
1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29140
1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29142
1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29144
1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29146
1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29148
1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29150
1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29152
1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29154
1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29156
1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29158
1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29160
1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29162
1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29164
1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29166
1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29168
1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29170
1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29172
1999-06-11 00:00:00+00	1999-06-11 00:00:00+00	1999-06-11 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29174
1999-06-12 00:00:00+00	1999-06-12 00:00:00+00	1999-06-12 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29176
1999-06-13 00:00:00+00	1999-06-13 00:00:00+00	1999-06-13 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29178
1999-06-14 00:00:00+00	1999-06-14 00:00:00+00	1999-06-14 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29180
1999-06-15 00:00:00+00	1999-06-15 00:00:00+00	1999-06-15 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29182
1999-06-16 00:00:00+00	1999-06-16 00:00:00+00	1999-06-16 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29184
1999-06-17 00:00:00+00	1999-06-17 00:00:00+00	1999-06-17 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29186
1999-06-18 00:00:00+00	1999-06-18 00:00:00+00	1999-06-18 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29188
1999-06-19 00:00:00+00	1999-06-19 00:00:00+00	1999-06-19 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29190
1999-06-20 00:00:00+00	1999-06-20 00:00:00+00	1999-06-20 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29192
1999-06-24 00:00:00+00	1999-06-24 00:00:00+00	1999-06-24 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29194
1999-06-25 00:00:00+00	1999-06-25 00:00:00+00	1999-06-25 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29196
1999-06-26 00:00:00+00	1999-06-26 00:00:00+00	1999-06-26 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29198
1999-06-27 00:00:00+00	1999-06-27 00:00:00+00	1999-06-27 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29200
1999-06-28 00:00:00+00	1999-06-28 00:00:00+00	1999-06-28 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29202
1999-06-29 00:00:00+00	1999-06-29 00:00:00+00	1999-06-29 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29204
1999-06-30 00:00:00+00	1999-06-30 00:00:00+00	1999-06-30 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29206
1999-07-01 00:00:00+00	1999-07-01 00:00:00+00	1999-07-01 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29208
1999-07-02 00:00:00+00	1999-07-02 00:00:00+00	1999-07-02 00:00:00+00	0	5203	\N	\N	5203	\N	\N	\N	\N	33	17	29210
1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	0	593.63	\N	\N	593.63	\N	\N	\N	\N	34	17	29011
1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	0	593.86	\N	\N	593.86	\N	\N	\N	\N	34	17	29013
1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	0	593.89	\N	\N	593.89	\N	\N	\N	\N	34	17	29015
1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	0	593.79	\N	\N	593.79	\N	\N	\N	\N	34	17	29017
1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	0	593.83	\N	\N	593.83	\N	\N	\N	\N	34	17	29019
1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	0	593.83	\N	\N	593.83	\N	\N	\N	\N	34	17	29021
1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	0	593.8	\N	\N	593.8	\N	\N	\N	\N	34	17	29023
1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	0	593.72	\N	\N	593.72	\N	\N	\N	\N	34	17	29025
1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	0	593.87	\N	\N	593.87	\N	\N	\N	\N	34	17	29027
1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	0	593.87	\N	\N	593.87	\N	\N	\N	\N	34	17	29029
1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	0	593.86	\N	\N	593.86	\N	\N	\N	\N	34	17	29031
1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	0	593.88	\N	\N	593.88	\N	\N	\N	\N	34	17	29033
1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	0	593.88	\N	\N	593.88	\N	\N	\N	\N	34	17	29035
1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	0	593.68	\N	\N	593.68	\N	\N	\N	\N	34	17	29037
1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	0	593.74	\N	\N	593.74	\N	\N	\N	\N	34	17	29039
1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	0	593.86	\N	\N	593.86	\N	\N	\N	\N	34	17	29041
1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	0	593.83	\N	\N	593.83	\N	\N	\N	\N	34	17	29043
1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	0	593.72	\N	\N	593.72	\N	\N	\N	\N	34	17	29045
1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	0	593.75	\N	\N	593.75	\N	\N	\N	\N	34	17	29047
1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	0	593.76	\N	\N	593.76	\N	\N	\N	\N	34	17	29049
1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	0	593.73	\N	\N	593.73	\N	\N	\N	\N	34	17	29051
1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	0	593.74	\N	\N	593.74	\N	\N	\N	\N	34	17	29053
1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	0	593.89	\N	\N	593.89	\N	\N	\N	\N	34	17	29055
1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	0	593.91	\N	\N	593.91	\N	\N	\N	\N	34	17	29057
1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	0	593.9	\N	\N	593.9	\N	\N	\N	\N	34	17	29059
1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	0	593.83	\N	\N	593.83	\N	\N	\N	\N	34	17	29061
1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	0	593.94	\N	\N	593.94	\N	\N	\N	\N	34	17	29063
1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	0	593.97	\N	\N	593.97	\N	\N	\N	\N	34	17	29065
1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	0	594.04	\N	\N	594.04	\N	\N	\N	\N	34	17	29067
1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	0	594.08	\N	\N	594.08	\N	\N	\N	\N	34	17	29069
1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	0	594.04	\N	\N	594.04	\N	\N	\N	\N	34	17	29071
1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	0	593.86	\N	\N	593.86	\N	\N	\N	\N	34	17	29073
1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	0	593.88	\N	\N	593.88	\N	\N	\N	\N	34	17	29075
1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	0	594.56	\N	\N	594.56	\N	\N	\N	\N	34	17	29077
1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	0	594.45	\N	\N	594.45	\N	\N	\N	\N	34	17	29079
1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	0	594.41	\N	\N	594.41	\N	\N	\N	\N	34	17	29081
1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	0	594.47	\N	\N	594.47	\N	\N	\N	\N	34	17	29083
1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	0	594.39	\N	\N	594.39	\N	\N	\N	\N	34	17	29085
1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	0	594.34	\N	\N	594.34	\N	\N	\N	\N	34	17	29087
1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	0	594.3	\N	\N	594.3	\N	\N	\N	\N	34	17	29089
1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	0	594.3	\N	\N	594.3	\N	\N	\N	\N	34	17	29091
1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	0	594.27	\N	\N	594.27	\N	\N	\N	\N	34	17	29093
1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	0	594.17	\N	\N	594.17	\N	\N	\N	\N	34	17	29095
1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	0	594.06	\N	\N	594.06	\N	\N	\N	\N	34	17	29097
1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	0	594.2	\N	\N	594.2	\N	\N	\N	\N	34	17	29099
1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	0	594.29	\N	\N	594.29	\N	\N	\N	\N	34	17	29101
1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	0	594.28	\N	\N	594.28	\N	\N	\N	\N	34	17	29103
1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	0	594.26	\N	\N	594.26	\N	\N	\N	\N	34	17	29105
1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	0	594.18	\N	\N	594.18	\N	\N	\N	\N	34	17	29107
1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	0	594.11	\N	\N	594.11	\N	\N	\N	\N	34	17	29109
1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	0	594.19	\N	\N	594.19	\N	\N	\N	\N	34	17	29111
1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	0	594.25	\N	\N	594.25	\N	\N	\N	\N	34	17	29113
1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	0	594.15	\N	\N	594.15	\N	\N	\N	\N	34	17	29115
1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	0	594.13	\N	\N	594.13	\N	\N	\N	\N	34	17	29117
1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	0	594.13	\N	\N	594.13	\N	\N	\N	\N	34	17	29119
1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	0	594.12	\N	\N	594.12	\N	\N	\N	\N	34	17	29121
1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	0	594.22	\N	\N	594.22	\N	\N	\N	\N	34	17	29123
1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	0	594.27	\N	\N	594.27	\N	\N	\N	\N	34	17	29125
1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	0	594.12	\N	\N	594.12	\N	\N	\N	\N	34	17	29127
1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	0	593.97	\N	\N	593.97	\N	\N	\N	\N	34	17	29129
1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	0	594.06	\N	\N	594.06	\N	\N	\N	\N	34	17	29131
1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	0	594.09	\N	\N	594.09	\N	\N	\N	\N	34	17	29133
1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	0	594.18	\N	\N	594.18	\N	\N	\N	\N	34	17	29135
1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	0	594.17	\N	\N	594.17	\N	\N	\N	\N	34	17	29137
1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	0	594.04	\N	\N	594.04	\N	\N	\N	\N	34	17	29139
1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	0	594.08	\N	\N	594.08	\N	\N	\N	\N	34	17	29141
1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	0	594.12	\N	\N	594.12	\N	\N	\N	\N	34	17	29143
1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	0	594.11	\N	\N	594.11	\N	\N	\N	\N	34	17	29145
1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	0	594.04	\N	\N	594.04	\N	\N	\N	\N	34	17	29147
1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	0	594.05	\N	\N	594.05	\N	\N	\N	\N	34	17	29149
1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	0	593.99	\N	\N	593.99	\N	\N	\N	\N	34	17	29151
1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	0	593.95	\N	\N	593.95	\N	\N	\N	\N	34	17	29153
1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	0	593.92	\N	\N	593.92	\N	\N	\N	\N	34	17	29155
1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	0	593.91	\N	\N	593.91	\N	\N	\N	\N	34	17	29157
1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	0	593.85	\N	\N	593.85	\N	\N	\N	\N	34	17	29159
1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	0	593.88	\N	\N	593.88	\N	\N	\N	\N	34	17	29161
1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	0	593.96	\N	\N	593.96	\N	\N	\N	\N	34	17	29163
1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	0	593.98	\N	\N	593.98	\N	\N	\N	\N	34	17	29165
1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	0	593.93	\N	\N	593.93	\N	\N	\N	\N	34	17	29167
1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	0	593.91	\N	\N	593.91	\N	\N	\N	\N	34	17	29169
1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	0	593.93	\N	\N	593.93	\N	\N	\N	\N	34	17	29171
1999-06-11 00:00:00+00	1999-06-11 00:00:00+00	1999-06-11 00:00:00+00	0	593.96	\N	\N	593.96	\N	\N	\N	\N	34	17	29173
1999-06-12 00:00:00+00	1999-06-12 00:00:00+00	1999-06-12 00:00:00+00	0	594.08	\N	\N	594.08	\N	\N	\N	\N	34	17	29175
1999-06-13 00:00:00+00	1999-06-13 00:00:00+00	1999-06-13 00:00:00+00	0	594.15	\N	\N	594.15	\N	\N	\N	\N	34	17	29177
1999-06-14 00:00:00+00	1999-06-14 00:00:00+00	1999-06-14 00:00:00+00	0	594.2	\N	\N	594.2	\N	\N	\N	\N	34	17	29179
1999-06-15 00:00:00+00	1999-06-15 00:00:00+00	1999-06-15 00:00:00+00	0	594.08	\N	\N	594.08	\N	\N	\N	\N	34	17	29181
1999-06-16 00:00:00+00	1999-06-16 00:00:00+00	1999-06-16 00:00:00+00	0	594.05	\N	\N	594.05	\N	\N	\N	\N	34	17	29183
1999-06-17 00:00:00+00	1999-06-17 00:00:00+00	1999-06-17 00:00:00+00	0	594.03	\N	\N	594.03	\N	\N	\N	\N	34	17	29185
1999-06-18 00:00:00+00	1999-06-18 00:00:00+00	1999-06-18 00:00:00+00	0	594	\N	\N	594	\N	\N	\N	\N	34	17	29187
1999-06-19 00:00:00+00	1999-06-19 00:00:00+00	1999-06-19 00:00:00+00	0	593.96	\N	\N	593.96	\N	\N	\N	\N	34	17	29189
1999-06-20 00:00:00+00	1999-06-20 00:00:00+00	1999-06-20 00:00:00+00	0	593.97	\N	\N	593.97	\N	\N	\N	\N	34	17	29191
1999-06-24 00:00:00+00	1999-06-24 00:00:00+00	1999-06-24 00:00:00+00	0	593.92	\N	\N	593.92	\N	\N	\N	\N	34	17	29193
1999-06-25 00:00:00+00	1999-06-25 00:00:00+00	1999-06-25 00:00:00+00	0	593.89	\N	\N	593.89	\N	\N	\N	\N	34	17	29195
1999-06-26 00:00:00+00	1999-06-26 00:00:00+00	1999-06-26 00:00:00+00	0	593.86	\N	\N	593.86	\N	\N	\N	\N	34	17	29197
1999-06-27 00:00:00+00	1999-06-27 00:00:00+00	1999-06-27 00:00:00+00	0	593.89	\N	\N	593.89	\N	\N	\N	\N	34	17	29199
1999-06-28 00:00:00+00	1999-06-28 00:00:00+00	1999-06-28 00:00:00+00	0	593.94	\N	\N	593.94	\N	\N	\N	\N	34	17	29201
1999-06-29 00:00:00+00	1999-06-29 00:00:00+00	1999-06-29 00:00:00+00	0	593.91	\N	\N	593.91	\N	\N	\N	\N	34	17	29203
1999-06-30 00:00:00+00	1999-06-30 00:00:00+00	1999-06-30 00:00:00+00	0	593.84	\N	\N	593.84	\N	\N	\N	\N	34	17	29205
1999-07-01 00:00:00+00	1999-07-01 00:00:00+00	1999-07-01 00:00:00+00	0	593.84	\N	\N	593.84	\N	\N	\N	\N	34	17	29207
1999-07-02 00:00:00+00	1999-07-02 00:00:00+00	1999-07-02 00:00:00+00	0	593.84	\N	\N	593.84	\N	\N	\N	\N	34	17	29209
2003-12-31 00:00:00+00	2003-12-31 00:00:00+00	2003-12-31 00:00:00+00	0	175.24	\N	\N	175.24	\N	\N	\N	\N	36	18	44361
2004-01-01 00:00:00+00	2004-01-01 00:00:00+00	2004-01-01 00:00:00+00	0	175.41	\N	\N	175.41	\N	\N	\N	\N	36	18	44363
2004-01-02 00:00:00+00	2004-01-02 00:00:00+00	2004-01-02 00:00:00+00	0	175.47	\N	\N	175.47	\N	\N	\N	\N	36	18	44365
2004-01-03 00:00:00+00	2004-01-03 00:00:00+00	2004-01-03 00:00:00+00	0	175.61	\N	\N	175.61	\N	\N	\N	\N	36	18	44367
2004-01-04 00:00:00+00	2004-01-04 00:00:00+00	2004-01-04 00:00:00+00	0	175.85	\N	\N	175.85	\N	\N	\N	\N	36	18	44369
2004-01-05 00:00:00+00	2004-01-05 00:00:00+00	2004-01-05 00:00:00+00	0	176.06	\N	\N	176.06	\N	\N	\N	\N	36	18	44371
2004-01-06 00:00:00+00	2004-01-06 00:00:00+00	2004-01-06 00:00:00+00	0	176.17	\N	\N	176.17	\N	\N	\N	\N	36	18	44373
2004-01-07 00:00:00+00	2004-01-07 00:00:00+00	2004-01-07 00:00:00+00	0	176.26	\N	\N	176.26	\N	\N	\N	\N	36	18	44375
2004-01-08 00:00:00+00	2004-01-08 00:00:00+00	2004-01-08 00:00:00+00	0	176.45	\N	\N	176.45	\N	\N	\N	\N	36	18	44377
2004-01-09 00:00:00+00	2004-01-09 00:00:00+00	2004-01-09 00:00:00+00	0	176.59	\N	\N	176.59	\N	\N	\N	\N	36	18	44379
2004-01-10 00:00:00+00	2004-01-10 00:00:00+00	2004-01-10 00:00:00+00	0	176.65	\N	\N	176.65	\N	\N	\N	\N	36	18	44381
2004-01-11 00:00:00+00	2004-01-11 00:00:00+00	2004-01-11 00:00:00+00	0	176.8	\N	\N	176.8	\N	\N	\N	\N	36	18	44383
2004-01-12 00:00:00+00	2004-01-12 00:00:00+00	2004-01-12 00:00:00+00	0	177.11	\N	\N	177.11	\N	\N	\N	\N	36	18	44385
2004-01-13 00:00:00+00	2004-01-13 00:00:00+00	2004-01-13 00:00:00+00	0	177.42	\N	\N	177.42	\N	\N	\N	\N	36	18	44387
2004-01-14 00:00:00+00	2004-01-14 00:00:00+00	2004-01-14 00:00:00+00	0	177.66	\N	\N	177.66	\N	\N	\N	\N	36	18	44389
2004-01-15 00:00:00+00	2004-01-15 00:00:00+00	2004-01-15 00:00:00+00	0	177.88	\N	\N	177.88	\N	\N	\N	\N	36	18	44391
2004-01-16 00:00:00+00	2004-01-16 00:00:00+00	2004-01-16 00:00:00+00	0	178.23	\N	\N	178.23	\N	\N	\N	\N	36	18	44393
2004-01-17 00:00:00+00	2004-01-17 00:00:00+00	2004-01-17 00:00:00+00	0	178.69	\N	\N	178.69	\N	\N	\N	\N	36	18	44395
2004-01-18 00:00:00+00	2004-01-18 00:00:00+00	2004-01-18 00:00:00+00	0	179.07	\N	\N	179.07	\N	\N	\N	\N	36	18	44397
2004-01-19 00:00:00+00	2004-01-19 00:00:00+00	2004-01-19 00:00:00+00	0	179.37	\N	\N	179.37	\N	\N	\N	\N	36	18	44399
2004-01-20 00:00:00+00	2004-01-20 00:00:00+00	2004-01-20 00:00:00+00	0	179.76	\N	\N	179.76	\N	\N	\N	\N	36	18	44401
2004-01-21 00:00:00+00	2004-01-21 00:00:00+00	2004-01-21 00:00:00+00	0	180.19	\N	\N	180.19	\N	\N	\N	\N	36	18	44403
2004-01-22 00:00:00+00	2004-01-22 00:00:00+00	2004-01-22 00:00:00+00	0	180.53	\N	\N	180.53	\N	\N	\N	\N	36	18	44405
2004-01-23 00:00:00+00	2004-01-23 00:00:00+00	2004-01-23 00:00:00+00	0	180.75	\N	\N	180.75	\N	\N	\N	\N	36	18	44407
2004-01-24 00:00:00+00	2004-01-24 00:00:00+00	2004-01-24 00:00:00+00	0	180.94	\N	\N	180.94	\N	\N	\N	\N	36	18	44409
2004-01-25 00:00:00+00	2004-01-25 00:00:00+00	2004-01-25 00:00:00+00	0	181.26	\N	\N	181.26	\N	\N	\N	\N	36	18	44411
2004-01-26 00:00:00+00	2004-01-26 00:00:00+00	2004-01-26 00:00:00+00	0	181.74	\N	\N	181.74	\N	\N	\N	\N	36	18	44413
2004-01-27 00:00:00+00	2004-01-27 00:00:00+00	2004-01-27 00:00:00+00	0	182	\N	\N	182	\N	\N	\N	\N	36	18	44415
2004-01-28 00:00:00+00	2004-01-28 00:00:00+00	2004-01-28 00:00:00+00	0	182.19	\N	\N	182.19	\N	\N	\N	\N	36	18	44417
2004-01-29 00:00:00+00	2004-01-29 00:00:00+00	2004-01-29 00:00:00+00	0	182.45	\N	\N	182.45	\N	\N	\N	\N	36	18	44419
2004-01-30 00:00:00+00	2004-01-30 00:00:00+00	2004-01-30 00:00:00+00	0	182.55	\N	\N	182.55	\N	\N	\N	\N	36	18	44421
2004-01-31 00:00:00+00	2004-01-31 00:00:00+00	2004-01-31 00:00:00+00	0	182.65	\N	\N	182.65	\N	\N	\N	\N	36	18	44423
2004-02-01 00:00:00+00	2004-02-01 00:00:00+00	2004-02-01 00:00:00+00	0	182.98	\N	\N	182.98	\N	\N	\N	\N	36	18	44425
2004-02-02 00:00:00+00	2004-02-02 00:00:00+00	2004-02-02 00:00:00+00	0	183.12	\N	\N	183.12	\N	\N	\N	\N	36	18	44427
2004-02-03 00:00:00+00	2004-02-03 00:00:00+00	2004-02-03 00:00:00+00	0	183.11	\N	\N	183.11	\N	\N	\N	\N	36	18	44429
2004-02-04 00:00:00+00	2004-02-04 00:00:00+00	2004-02-04 00:00:00+00	0	183.23	\N	\N	183.23	\N	\N	\N	\N	36	18	44431
2004-02-05 00:00:00+00	2004-02-05 00:00:00+00	2004-02-05 00:00:00+00	0	183.47	\N	\N	183.47	\N	\N	\N	\N	36	18	44433
2004-02-06 00:00:00+00	2004-02-06 00:00:00+00	2004-02-06 00:00:00+00	0	183.62	\N	\N	183.62	\N	\N	\N	\N	36	18	44435
2004-02-07 00:00:00+00	2004-02-07 00:00:00+00	2004-02-07 00:00:00+00	0	183.65	\N	\N	183.65	\N	\N	\N	\N	36	18	44437
2004-02-08 00:00:00+00	2004-02-08 00:00:00+00	2004-02-08 00:00:00+00	0	183.69	\N	\N	183.69	\N	\N	\N	\N	36	18	44439
2004-02-09 00:00:00+00	2004-02-09 00:00:00+00	2004-02-09 00:00:00+00	0	183.75	\N	\N	183.75	\N	\N	\N	\N	36	18	44441
2004-02-10 00:00:00+00	2004-02-10 00:00:00+00	2004-02-10 00:00:00+00	0	183.77	\N	\N	183.77	\N	\N	\N	\N	36	18	44443
2004-02-11 00:00:00+00	2004-02-11 00:00:00+00	2004-02-11 00:00:00+00	0	183.76	\N	\N	183.76	\N	\N	\N	\N	36	18	44445
2004-02-12 00:00:00+00	2004-02-12 00:00:00+00	2004-02-12 00:00:00+00	0	183.88	\N	\N	183.88	\N	\N	\N	\N	36	18	44447
2004-02-13 00:00:00+00	2004-02-13 00:00:00+00	2004-02-13 00:00:00+00	0	183.87	\N	\N	183.87	\N	\N	\N	\N	36	18	44449
2004-02-14 00:00:00+00	2004-02-14 00:00:00+00	2004-02-14 00:00:00+00	0	183.96	\N	\N	183.96	\N	\N	\N	\N	36	18	44451
2004-02-15 00:00:00+00	2004-02-15 00:00:00+00	2004-02-15 00:00:00+00	0	184.08	\N	\N	184.08	\N	\N	\N	\N	36	18	44453
2004-02-16 00:00:00+00	2004-02-16 00:00:00+00	2004-02-16 00:00:00+00	0	184.3	\N	\N	184.3	\N	\N	\N	\N	36	18	44455
2004-02-17 00:00:00+00	2004-02-17 00:00:00+00	2004-02-17 00:00:00+00	0	184.37	\N	\N	184.37	\N	\N	\N	\N	36	18	44457
2004-02-18 00:00:00+00	2004-02-18 00:00:00+00	2004-02-18 00:00:00+00	0	184.54	\N	\N	184.54	\N	\N	\N	\N	36	18	44459
2004-02-19 00:00:00+00	2004-02-19 00:00:00+00	2004-02-19 00:00:00+00	0	184.2	\N	\N	184.2	\N	\N	\N	\N	36	18	44461
2004-02-20 00:00:00+00	2004-02-20 00:00:00+00	2004-02-20 00:00:00+00	0	183.97	\N	\N	183.97	\N	\N	\N	\N	36	18	44463
2004-02-21 00:00:00+00	2004-02-21 00:00:00+00	2004-02-21 00:00:00+00	0	183.81	\N	\N	183.81	\N	\N	\N	\N	36	18	44465
2004-02-22 00:00:00+00	2004-02-22 00:00:00+00	2004-02-22 00:00:00+00	0	183.52	\N	\N	183.52	\N	\N	\N	\N	36	18	44467
2004-02-23 00:00:00+00	2004-02-23 00:00:00+00	2004-02-23 00:00:00+00	0	183.44	\N	\N	183.44	\N	\N	\N	\N	36	18	44469
2004-02-24 00:00:00+00	2004-02-24 00:00:00+00	2004-02-24 00:00:00+00	0	183.38	\N	\N	183.38	\N	\N	\N	\N	36	18	44471
2004-02-25 00:00:00+00	2004-02-25 00:00:00+00	2004-02-25 00:00:00+00	0	183.42	\N	\N	183.42	\N	\N	\N	\N	36	18	44473
2004-02-26 00:00:00+00	2004-02-26 00:00:00+00	2004-02-26 00:00:00+00	0	183.41	\N	\N	183.41	\N	\N	\N	\N	36	18	44475
2004-02-27 00:00:00+00	2004-02-27 00:00:00+00	2004-02-27 00:00:00+00	0	183.32	\N	\N	183.32	\N	\N	\N	\N	36	18	44477
2004-02-28 00:00:00+00	2004-02-28 00:00:00+00	2004-02-28 00:00:00+00	0	183.17	\N	\N	183.17	\N	\N	\N	\N	36	18	44479
2004-02-29 00:00:00+00	2004-02-29 00:00:00+00	2004-02-29 00:00:00+00	0	183.11	\N	\N	183.11	\N	\N	\N	\N	36	18	44481
2004-03-01 00:00:00+00	2004-03-01 00:00:00+00	2004-03-01 00:00:00+00	0	183.09	\N	\N	183.09	\N	\N	\N	\N	36	18	44483
2004-03-02 00:00:00+00	2004-03-02 00:00:00+00	2004-03-02 00:00:00+00	0	183.07	\N	\N	183.07	\N	\N	\N	\N	36	18	44485
2004-03-03 00:00:00+00	2004-03-03 00:00:00+00	2004-03-03 00:00:00+00	0	183.02	\N	\N	183.02	\N	\N	\N	\N	36	18	44487
2004-03-04 00:00:00+00	2004-03-04 00:00:00+00	2004-03-04 00:00:00+00	0	182.91	\N	\N	182.91	\N	\N	\N	\N	36	18	44489
2004-03-05 00:00:00+00	2004-03-05 00:00:00+00	2004-03-05 00:00:00+00	0	183.01	\N	\N	183.01	\N	\N	\N	\N	36	18	44491
2004-03-06 00:00:00+00	2004-03-06 00:00:00+00	2004-03-06 00:00:00+00	0	183.16	\N	\N	183.16	\N	\N	\N	\N	36	18	44493
2004-03-07 00:00:00+00	2004-03-07 00:00:00+00	2004-03-07 00:00:00+00	0	183.26	\N	\N	183.26	\N	\N	\N	\N	36	18	44495
2004-03-08 00:00:00+00	2004-03-08 00:00:00+00	2004-03-08 00:00:00+00	0	183.26	\N	\N	183.26	\N	\N	\N	\N	36	18	44497
2004-03-09 00:00:00+00	2004-03-09 00:00:00+00	2004-03-09 00:00:00+00	0	183.29	\N	\N	183.29	\N	\N	\N	\N	36	18	44499
2004-03-10 00:00:00+00	2004-03-10 00:00:00+00	2004-03-10 00:00:00+00	0	183.21	\N	\N	183.21	\N	\N	\N	\N	36	18	44501
2004-03-11 00:00:00+00	2004-03-11 00:00:00+00	2004-03-11 00:00:00+00	0	183.31	\N	\N	183.31	\N	\N	\N	\N	36	18	44503
2004-03-12 00:00:00+00	2004-03-12 00:00:00+00	2004-03-12 00:00:00+00	0	183.29	\N	\N	183.29	\N	\N	\N	\N	36	18	44505
2004-03-13 00:00:00+00	2004-03-13 00:00:00+00	2004-03-13 00:00:00+00	0	183.58	\N	\N	183.58	\N	\N	\N	\N	36	18	44507
2004-03-14 00:00:00+00	2004-03-14 00:00:00+00	2004-03-14 00:00:00+00	0	183.82	\N	\N	183.82	\N	\N	\N	\N	36	18	44509
2004-03-15 00:00:00+00	2004-03-15 00:00:00+00	2004-03-15 00:00:00+00	0	184.04	\N	\N	184.04	\N	\N	\N	\N	36	18	44511
2004-03-16 00:00:00+00	2004-03-16 00:00:00+00	2004-03-16 00:00:00+00	0	184.15	\N	\N	184.15	\N	\N	\N	\N	36	18	44513
2004-03-17 00:00:00+00	2004-03-17 00:00:00+00	2004-03-17 00:00:00+00	0	184.49	\N	\N	184.49	\N	\N	\N	\N	36	18	44515
2004-03-18 00:00:00+00	2004-03-18 00:00:00+00	2004-03-18 00:00:00+00	0	184.64	\N	\N	184.64	\N	\N	\N	\N	36	18	44517
2004-03-19 00:00:00+00	2004-03-19 00:00:00+00	2004-03-19 00:00:00+00	0	184.73	\N	\N	184.73	\N	\N	\N	\N	36	18	44519
2004-03-20 00:00:00+00	2004-03-20 00:00:00+00	2004-03-20 00:00:00+00	0	184.92	\N	\N	184.92	\N	\N	\N	\N	36	18	44521
2004-03-21 00:00:00+00	2004-03-21 00:00:00+00	2004-03-21 00:00:00+00	0	184.97	\N	\N	184.97	\N	\N	\N	\N	36	18	44523
2004-03-22 00:00:00+00	2004-03-22 00:00:00+00	2004-03-22 00:00:00+00	0	185.05	\N	\N	185.05	\N	\N	\N	\N	36	18	44525
2004-03-23 00:00:00+00	2004-03-23 00:00:00+00	2004-03-23 00:00:00+00	0	185.3	\N	\N	185.3	\N	\N	\N	\N	36	18	44527
2004-03-24 00:00:00+00	2004-03-24 00:00:00+00	2004-03-24 00:00:00+00	0	185.43	\N	\N	185.43	\N	\N	\N	\N	36	18	44529
2004-03-25 00:00:00+00	2004-03-25 00:00:00+00	2004-03-25 00:00:00+00	0	185.54	\N	\N	185.54	\N	\N	\N	\N	36	18	44531
2004-03-26 00:00:00+00	2004-03-26 00:00:00+00	2004-03-26 00:00:00+00	0	185.56	\N	\N	185.56	\N	\N	\N	\N	36	18	44533
2004-03-27 00:00:00+00	2004-03-27 00:00:00+00	2004-03-27 00:00:00+00	0	185.62	\N	\N	185.62	\N	\N	\N	\N	36	18	44535
2004-03-28 00:00:00+00	2004-03-28 00:00:00+00	2004-03-28 00:00:00+00	0	185.77	\N	\N	185.77	\N	\N	\N	\N	36	18	44537
2004-03-29 00:00:00+00	2004-03-29 00:00:00+00	2004-03-29 00:00:00+00	0	185.8	\N	\N	185.8	\N	\N	\N	\N	36	18	44539
2004-03-30 00:00:00+00	2004-03-30 00:00:00+00	2004-03-30 00:00:00+00	0	185.83	\N	\N	185.83	\N	\N	\N	\N	36	18	44541
2004-03-31 00:00:00+00	2004-03-31 00:00:00+00	2004-03-31 00:00:00+00	0	185.79	\N	\N	185.79	\N	\N	\N	\N	36	18	44543
2004-04-01 00:00:00+00	2004-04-01 00:00:00+00	2004-04-01 00:00:00+00	0	185.75	\N	\N	185.75	\N	\N	\N	\N	36	18	44545
2004-04-02 00:00:00+00	2004-04-02 00:00:00+00	2004-04-02 00:00:00+00	0	185.84	\N	\N	185.84	\N	\N	\N	\N	36	18	44547
2004-04-03 00:00:00+00	2004-04-03 00:00:00+00	2004-04-03 00:00:00+00	0	185.86	\N	\N	185.86	\N	\N	\N	\N	36	18	44549
2004-04-04 00:00:00+00	2004-04-04 00:00:00+00	2004-04-04 00:00:00+00	0	185.87	\N	\N	185.87	\N	\N	\N	\N	36	18	44551
2004-04-05 00:00:00+00	2004-04-05 00:00:00+00	2004-04-05 00:00:00+00	0	185.88	\N	\N	185.88	\N	\N	\N	\N	36	18	44553
2004-04-06 00:00:00+00	2004-04-06 00:00:00+00	2004-04-06 00:00:00+00	0	185.89	\N	\N	185.89	\N	\N	\N	\N	36	18	44555
2004-04-07 00:00:00+00	2004-04-07 00:00:00+00	2004-04-07 00:00:00+00	0	185.95	\N	\N	185.95	\N	\N	\N	\N	36	18	44557
2004-04-08 00:00:00+00	2004-04-08 00:00:00+00	2004-04-08 00:00:00+00	0	185.96	\N	\N	185.96	\N	\N	\N	\N	36	18	44559
2004-05-15 00:00:00+00	2004-05-15 00:00:00+00	2004-05-15 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56724
2004-05-16 00:00:00+00	2004-05-16 00:00:00+00	2004-05-16 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56726
2004-05-17 00:00:00+00	2004-05-17 00:00:00+00	2004-05-17 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56728
2004-05-18 00:00:00+00	2004-05-18 00:00:00+00	2004-05-18 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56730
2004-05-19 00:00:00+00	2004-05-19 00:00:00+00	2004-05-19 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56732
2004-05-20 00:00:00+00	2004-05-20 00:00:00+00	2004-05-20 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56734
2004-05-21 00:00:00+00	2004-05-21 00:00:00+00	2004-05-21 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56736
2004-05-22 00:00:00+00	2004-05-22 00:00:00+00	2004-05-22 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56738
2004-05-23 00:00:00+00	2004-05-23 00:00:00+00	2004-05-23 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56740
2004-05-24 00:00:00+00	2004-05-24 00:00:00+00	2004-05-24 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56742
2004-05-25 00:00:00+00	2004-05-25 00:00:00+00	2004-05-25 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56744
2004-05-26 00:00:00+00	2004-05-26 00:00:00+00	2004-05-26 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56746
2004-05-27 00:00:00+00	2004-05-27 00:00:00+00	2004-05-27 00:00:00+00	0	6160	\N	\N	6160	\N	\N	\N	\N	39	20	56748
2004-05-28 00:00:00+00	2004-05-28 00:00:00+00	2004-05-28 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56750
2004-05-29 00:00:00+00	2004-05-29 00:00:00+00	2004-05-29 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56752
2004-05-30 00:00:00+00	2004-05-30 00:00:00+00	2004-05-30 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56754
2004-05-31 00:00:00+00	2004-05-31 00:00:00+00	2004-05-31 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56756
2004-06-01 00:00:00+00	2004-06-01 00:00:00+00	2004-06-01 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56758
2004-06-02 00:00:00+00	2004-06-02 00:00:00+00	2004-06-02 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56760
2004-06-03 00:00:00+00	2004-06-03 00:00:00+00	2004-06-03 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56762
2004-06-04 00:00:00+00	2004-06-04 00:00:00+00	2004-06-04 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56764
2004-06-05 00:00:00+00	2004-06-05 00:00:00+00	2004-06-05 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56766
2004-06-06 00:00:00+00	2004-06-06 00:00:00+00	2004-06-06 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56768
2004-06-07 00:00:00+00	2004-06-07 00:00:00+00	2004-06-07 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56770
2004-06-08 00:00:00+00	2004-06-08 00:00:00+00	2004-06-08 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56772
2004-06-09 00:00:00+00	2004-06-09 00:00:00+00	2004-06-09 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56774
2004-06-10 00:00:00+00	2004-06-10 00:00:00+00	2004-06-10 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56776
2004-06-11 00:00:00+00	2004-06-11 00:00:00+00	2004-06-11 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56778
2004-06-12 00:00:00+00	2004-06-12 00:00:00+00	2004-06-12 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56780
2004-06-13 00:00:00+00	2004-06-13 00:00:00+00	2004-06-13 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56782
2004-06-14 00:00:00+00	2004-06-14 00:00:00+00	2004-06-14 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56784
2004-06-15 00:00:00+00	2004-06-15 00:00:00+00	2004-06-15 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56786
2004-06-16 00:00:00+00	2004-06-16 00:00:00+00	2004-06-16 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56788
2004-06-17 00:00:00+00	2004-06-17 00:00:00+00	2004-06-17 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56790
2004-06-18 00:00:00+00	2004-06-18 00:00:00+00	2004-06-18 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56792
2004-06-19 00:00:00+00	2004-06-19 00:00:00+00	2004-06-19 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56794
2004-06-20 00:00:00+00	2004-06-20 00:00:00+00	2004-06-20 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56796
2004-06-21 00:00:00+00	2004-06-21 00:00:00+00	2004-06-21 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56798
2004-06-22 00:00:00+00	2004-06-22 00:00:00+00	2004-06-22 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56800
2004-06-23 00:00:00+00	2004-06-23 00:00:00+00	2004-06-23 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56802
2004-06-24 00:00:00+00	2004-06-24 00:00:00+00	2004-06-24 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56804
2004-06-25 00:00:00+00	2004-06-25 00:00:00+00	2004-06-25 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56806
2004-06-26 00:00:00+00	2004-06-26 00:00:00+00	2004-06-26 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56808
2004-06-27 00:00:00+00	2004-06-27 00:00:00+00	2004-06-27 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56810
2004-06-28 00:00:00+00	2004-06-28 00:00:00+00	2004-06-28 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56812
2004-06-29 00:00:00+00	2004-06-29 00:00:00+00	2004-06-29 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56814
2004-06-30 00:00:00+00	2004-06-30 00:00:00+00	2004-06-30 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56816
2004-07-01 00:00:00+00	2004-07-01 00:00:00+00	2004-07-01 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56818
2004-07-02 00:00:00+00	2004-07-02 00:00:00+00	2004-07-02 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56820
2004-07-03 00:00:00+00	2004-07-03 00:00:00+00	2004-07-03 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56822
2004-07-04 00:00:00+00	2004-07-04 00:00:00+00	2004-07-04 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56824
2004-07-05 00:00:00+00	2004-07-05 00:00:00+00	2004-07-05 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56826
2004-07-06 00:00:00+00	2004-07-06 00:00:00+00	2004-07-06 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56828
2004-07-07 00:00:00+00	2004-07-07 00:00:00+00	2004-07-07 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56830
2004-07-08 00:00:00+00	2004-07-08 00:00:00+00	2004-07-08 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56832
2004-07-09 00:00:00+00	2004-07-09 00:00:00+00	2004-07-09 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56834
2004-07-10 00:00:00+00	2004-07-10 00:00:00+00	2004-07-10 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56836
2004-07-11 00:00:00+00	2004-07-11 00:00:00+00	2004-07-11 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56838
2004-07-12 00:00:00+00	2004-07-12 00:00:00+00	2004-07-12 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56840
2004-07-13 00:00:00+00	2004-07-13 00:00:00+00	2004-07-13 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56842
2004-07-14 00:00:00+00	2004-07-14 00:00:00+00	2004-07-14 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56844
2004-07-15 00:00:00+00	2004-07-15 00:00:00+00	2004-07-15 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56846
2004-07-16 00:00:00+00	2004-07-16 00:00:00+00	2004-07-16 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56848
2004-07-17 00:00:00+00	2004-07-17 00:00:00+00	2004-07-17 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56850
2004-07-18 00:00:00+00	2004-07-18 00:00:00+00	2004-07-18 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56852
2004-07-19 00:00:00+00	2004-07-19 00:00:00+00	2004-07-19 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56854
2004-07-20 00:00:00+00	2004-07-20 00:00:00+00	2004-07-20 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56856
2004-07-21 00:00:00+00	2004-07-21 00:00:00+00	2004-07-21 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56858
2004-07-22 00:00:00+00	2004-07-22 00:00:00+00	2004-07-22 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56860
2004-07-23 00:00:00+00	2004-07-23 00:00:00+00	2004-07-23 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56862
2004-07-24 00:00:00+00	2004-07-24 00:00:00+00	2004-07-24 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56864
2004-07-25 00:00:00+00	2004-07-25 00:00:00+00	2004-07-25 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56866
2004-07-30 00:00:00+00	2004-07-30 00:00:00+00	2004-07-30 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56868
2004-07-31 00:00:00+00	2004-07-31 00:00:00+00	2004-07-31 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56870
2004-08-01 00:00:00+00	2004-08-01 00:00:00+00	2004-08-01 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56872
2004-08-02 00:00:00+00	2004-08-02 00:00:00+00	2004-08-02 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56874
2004-08-03 00:00:00+00	2004-08-03 00:00:00+00	2004-08-03 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56876
2004-08-04 00:00:00+00	2004-08-04 00:00:00+00	2004-08-04 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56878
2004-08-05 00:00:00+00	2004-08-05 00:00:00+00	2004-08-05 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56880
2004-08-06 00:00:00+00	2004-08-06 00:00:00+00	2004-08-06 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56882
2004-08-07 00:00:00+00	2004-08-07 00:00:00+00	2004-08-07 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56884
2004-08-08 00:00:00+00	2004-08-08 00:00:00+00	2004-08-08 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56886
2004-08-09 00:00:00+00	2004-08-09 00:00:00+00	2004-08-09 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56888
2004-08-10 00:00:00+00	2004-08-10 00:00:00+00	2004-08-10 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56890
2004-08-11 00:00:00+00	2004-08-11 00:00:00+00	2004-08-11 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56892
2004-08-12 00:00:00+00	2004-08-12 00:00:00+00	2004-08-12 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56894
2004-08-13 00:00:00+00	2004-08-13 00:00:00+00	2004-08-13 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56896
2004-08-14 00:00:00+00	2004-08-14 00:00:00+00	2004-08-14 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56898
2004-08-15 00:00:00+00	2004-08-15 00:00:00+00	2004-08-15 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56900
2004-08-16 00:00:00+00	2004-08-16 00:00:00+00	2004-08-16 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56902
2004-08-17 00:00:00+00	2004-08-17 00:00:00+00	2004-08-17 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56904
2004-08-18 00:00:00+00	2004-08-18 00:00:00+00	2004-08-18 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56906
2004-08-19 00:00:00+00	2004-08-19 00:00:00+00	2004-08-19 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56908
2004-08-20 00:00:00+00	2004-08-20 00:00:00+00	2004-08-20 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56910
2004-08-21 00:00:00+00	2004-08-21 00:00:00+00	2004-08-21 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56912
2004-08-22 00:00:00+00	2004-08-22 00:00:00+00	2004-08-22 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56914
2004-08-23 00:00:00+00	2004-08-23 00:00:00+00	2004-08-23 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56916
2004-08-24 00:00:00+00	2004-08-24 00:00:00+00	2004-08-24 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56918
2004-08-25 00:00:00+00	2004-08-25 00:00:00+00	2004-08-25 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56920
2004-08-26 00:00:00+00	2004-08-26 00:00:00+00	2004-08-26 00:00:00+00	0	6161	\N	\N	6161	\N	\N	\N	\N	39	20	56922
2004-05-15 00:00:00+00	2004-05-15 00:00:00+00	2004-05-15 00:00:00+00	0	204.4	\N	\N	204.4	\N	\N	\N	\N	40	20	56723
2004-05-16 00:00:00+00	2004-05-16 00:00:00+00	2004-05-16 00:00:00+00	0	204.32	\N	\N	204.32	\N	\N	\N	\N	40	20	56725
2004-05-17 00:00:00+00	2004-05-17 00:00:00+00	2004-05-17 00:00:00+00	0	204.28	\N	\N	204.28	\N	\N	\N	\N	40	20	56727
2004-05-18 00:00:00+00	2004-05-18 00:00:00+00	2004-05-18 00:00:00+00	0	204.34	\N	\N	204.34	\N	\N	\N	\N	40	20	56729
2004-05-19 00:00:00+00	2004-05-19 00:00:00+00	2004-05-19 00:00:00+00	0	204.49	\N	\N	204.49	\N	\N	\N	\N	40	20	56731
2004-05-20 00:00:00+00	2004-05-20 00:00:00+00	2004-05-20 00:00:00+00	0	204.71	\N	\N	204.71	\N	\N	\N	\N	40	20	56733
2004-05-21 00:00:00+00	2004-05-21 00:00:00+00	2004-05-21 00:00:00+00	0	204.92	\N	\N	204.92	\N	\N	\N	\N	40	20	56735
2004-05-22 00:00:00+00	2004-05-22 00:00:00+00	2004-05-22 00:00:00+00	0	204.92	\N	\N	204.92	\N	\N	\N	\N	40	20	56737
2004-05-23 00:00:00+00	2004-05-23 00:00:00+00	2004-05-23 00:00:00+00	0	204.85	\N	\N	204.85	\N	\N	\N	\N	40	20	56739
2004-05-24 00:00:00+00	2004-05-24 00:00:00+00	2004-05-24 00:00:00+00	0	204.82	\N	\N	204.82	\N	\N	\N	\N	40	20	56741
2004-05-25 00:00:00+00	2004-05-25 00:00:00+00	2004-05-25 00:00:00+00	0	204.73	\N	\N	204.73	\N	\N	\N	\N	40	20	56743
2004-05-26 00:00:00+00	2004-05-26 00:00:00+00	2004-05-26 00:00:00+00	0	204.71	\N	\N	204.71	\N	\N	\N	\N	40	20	56745
2004-05-27 00:00:00+00	2004-05-27 00:00:00+00	2004-05-27 00:00:00+00	0	204.62	\N	\N	204.62	\N	\N	\N	\N	40	20	56747
2004-05-28 00:00:00+00	2004-05-28 00:00:00+00	2004-05-28 00:00:00+00	0	204.47	\N	\N	204.47	\N	\N	\N	\N	40	20	56749
2004-05-29 00:00:00+00	2004-05-29 00:00:00+00	2004-05-29 00:00:00+00	0	204.42	\N	\N	204.42	\N	\N	\N	\N	40	20	56751
2004-05-30 00:00:00+00	2004-05-30 00:00:00+00	2004-05-30 00:00:00+00	0	204.35	\N	\N	204.35	\N	\N	\N	\N	40	20	56753
2004-05-31 00:00:00+00	2004-05-31 00:00:00+00	2004-05-31 00:00:00+00	0	204.18	\N	\N	204.18	\N	\N	\N	\N	40	20	56755
2004-06-01 00:00:00+00	2004-06-01 00:00:00+00	2004-06-01 00:00:00+00	0	204.22	\N	\N	204.22	\N	\N	\N	\N	40	20	56757
2004-06-02 00:00:00+00	2004-06-02 00:00:00+00	2004-06-02 00:00:00+00	0	204.27	\N	\N	204.27	\N	\N	\N	\N	40	20	56759
2004-06-03 00:00:00+00	2004-06-03 00:00:00+00	2004-06-03 00:00:00+00	0	204.3	\N	\N	204.3	\N	\N	\N	\N	40	20	56761
2004-06-04 00:00:00+00	2004-06-04 00:00:00+00	2004-06-04 00:00:00+00	0	204.31	\N	\N	204.31	\N	\N	\N	\N	40	20	56763
2004-06-05 00:00:00+00	2004-06-05 00:00:00+00	2004-06-05 00:00:00+00	0	204.22	\N	\N	204.22	\N	\N	\N	\N	40	20	56765
2004-06-06 00:00:00+00	2004-06-06 00:00:00+00	2004-06-06 00:00:00+00	0	204.2	\N	\N	204.2	\N	\N	\N	\N	40	20	56767
2004-06-07 00:00:00+00	2004-06-07 00:00:00+00	2004-06-07 00:00:00+00	0	204.15	\N	\N	204.15	\N	\N	\N	\N	40	20	56769
2004-06-08 00:00:00+00	2004-06-08 00:00:00+00	2004-06-08 00:00:00+00	0	204.08	\N	\N	204.08	\N	\N	\N	\N	40	20	56771
2004-06-09 00:00:00+00	2004-06-09 00:00:00+00	2004-06-09 00:00:00+00	0	204.04	\N	\N	204.04	\N	\N	\N	\N	40	20	56773
2004-06-10 00:00:00+00	2004-06-10 00:00:00+00	2004-06-10 00:00:00+00	0	204.01	\N	\N	204.01	\N	\N	\N	\N	40	20	56775
2004-06-11 00:00:00+00	2004-06-11 00:00:00+00	2004-06-11 00:00:00+00	0	204.02	\N	\N	204.02	\N	\N	\N	\N	40	20	56777
2004-06-12 00:00:00+00	2004-06-12 00:00:00+00	2004-06-12 00:00:00+00	0	204.04	\N	\N	204.04	\N	\N	\N	\N	40	20	56779
2004-06-13 00:00:00+00	2004-06-13 00:00:00+00	2004-06-13 00:00:00+00	0	204	\N	\N	204	\N	\N	\N	\N	40	20	56781
2004-06-14 00:00:00+00	2004-06-14 00:00:00+00	2004-06-14 00:00:00+00	0	203.92	\N	\N	203.92	\N	\N	\N	\N	40	20	56783
2004-06-15 00:00:00+00	2004-06-15 00:00:00+00	2004-06-15 00:00:00+00	0	203.87	\N	\N	203.87	\N	\N	\N	\N	40	20	56785
2004-06-16 00:00:00+00	2004-06-16 00:00:00+00	2004-06-16 00:00:00+00	0	203.87	\N	\N	203.87	\N	\N	\N	\N	40	20	56787
2004-06-17 00:00:00+00	2004-06-17 00:00:00+00	2004-06-17 00:00:00+00	0	203.98	\N	\N	203.98	\N	\N	\N	\N	40	20	56789
2004-06-18 00:00:00+00	2004-06-18 00:00:00+00	2004-06-18 00:00:00+00	0	204.04	\N	\N	204.04	\N	\N	\N	\N	40	20	56791
2004-06-19 00:00:00+00	2004-06-19 00:00:00+00	2004-06-19 00:00:00+00	0	203.89	\N	\N	203.89	\N	\N	\N	\N	40	20	56793
2004-06-20 00:00:00+00	2004-06-20 00:00:00+00	2004-06-20 00:00:00+00	0	203.86	\N	\N	203.86	\N	\N	\N	\N	40	20	56795
2004-06-21 00:00:00+00	2004-06-21 00:00:00+00	2004-06-21 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56797
2004-06-22 00:00:00+00	2004-06-22 00:00:00+00	2004-06-22 00:00:00+00	0	203.84	\N	\N	203.84	\N	\N	\N	\N	40	20	56799
2004-06-23 00:00:00+00	2004-06-23 00:00:00+00	2004-06-23 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56801
2004-06-24 00:00:00+00	2004-06-24 00:00:00+00	2004-06-24 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56803
2004-06-25 00:00:00+00	2004-06-25 00:00:00+00	2004-06-25 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56805
2004-06-26 00:00:00+00	2004-06-26 00:00:00+00	2004-06-26 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56807
2004-06-27 00:00:00+00	2004-06-27 00:00:00+00	2004-06-27 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56809
2004-06-28 00:00:00+00	2004-06-28 00:00:00+00	2004-06-28 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56811
2004-06-29 00:00:00+00	2004-06-29 00:00:00+00	2004-06-29 00:00:00+00	0	203.79	\N	\N	203.79	\N	\N	\N	\N	40	20	56813
2004-06-30 00:00:00+00	2004-06-30 00:00:00+00	2004-06-30 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56815
2004-07-01 00:00:00+00	2004-07-01 00:00:00+00	2004-07-01 00:00:00+00	0	203.87	\N	\N	203.87	\N	\N	\N	\N	40	20	56817
2004-07-02 00:00:00+00	2004-07-02 00:00:00+00	2004-07-02 00:00:00+00	0	203.84	\N	\N	203.84	\N	\N	\N	\N	40	20	56819
2004-07-03 00:00:00+00	2004-07-03 00:00:00+00	2004-07-03 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56821
2004-07-04 00:00:00+00	2004-07-04 00:00:00+00	2004-07-04 00:00:00+00	0	203.84	\N	\N	203.84	\N	\N	\N	\N	40	20	56823
2004-07-05 00:00:00+00	2004-07-05 00:00:00+00	2004-07-05 00:00:00+00	0	203.84	\N	\N	203.84	\N	\N	\N	\N	40	20	56825
2004-07-06 00:00:00+00	2004-07-06 00:00:00+00	2004-07-06 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56827
2004-07-07 00:00:00+00	2004-07-07 00:00:00+00	2004-07-07 00:00:00+00	0	203.75	\N	\N	203.75	\N	\N	\N	\N	40	20	56829
2004-07-08 00:00:00+00	2004-07-08 00:00:00+00	2004-07-08 00:00:00+00	0	203.74	\N	\N	203.74	\N	\N	\N	\N	40	20	56831
2004-07-09 00:00:00+00	2004-07-09 00:00:00+00	2004-07-09 00:00:00+00	0	203.74	\N	\N	203.74	\N	\N	\N	\N	40	20	56833
2004-07-10 00:00:00+00	2004-07-10 00:00:00+00	2004-07-10 00:00:00+00	0	203.73	\N	\N	203.73	\N	\N	\N	\N	40	20	56835
2004-07-11 00:00:00+00	2004-07-11 00:00:00+00	2004-07-11 00:00:00+00	0	203.77	\N	\N	203.77	\N	\N	\N	\N	40	20	56837
2004-07-12 00:00:00+00	2004-07-12 00:00:00+00	2004-07-12 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56839
2004-07-13 00:00:00+00	2004-07-13 00:00:00+00	2004-07-13 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56841
2004-07-14 00:00:00+00	2004-07-14 00:00:00+00	2004-07-14 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56843
2004-07-15 00:00:00+00	2004-07-15 00:00:00+00	2004-07-15 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56845
2004-07-16 00:00:00+00	2004-07-16 00:00:00+00	2004-07-16 00:00:00+00	0	203.83	\N	\N	203.83	\N	\N	\N	\N	40	20	56847
2004-07-17 00:00:00+00	2004-07-17 00:00:00+00	2004-07-17 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56849
2004-07-18 00:00:00+00	2004-07-18 00:00:00+00	2004-07-18 00:00:00+00	0	203.86	\N	\N	203.86	\N	\N	\N	\N	40	20	56851
2004-07-19 00:00:00+00	2004-07-19 00:00:00+00	2004-07-19 00:00:00+00	0	203.81	\N	\N	203.81	\N	\N	\N	\N	40	20	56853
2004-07-20 00:00:00+00	2004-07-20 00:00:00+00	2004-07-20 00:00:00+00	0	203.75	\N	\N	203.75	\N	\N	\N	\N	40	20	56855
2004-07-21 00:00:00+00	2004-07-21 00:00:00+00	2004-07-21 00:00:00+00	0	203.69	\N	\N	203.69	\N	\N	\N	\N	40	20	56857
2004-07-22 00:00:00+00	2004-07-22 00:00:00+00	2004-07-22 00:00:00+00	0	203.67	\N	\N	203.67	\N	\N	\N	\N	40	20	56859
2004-07-23 00:00:00+00	2004-07-23 00:00:00+00	2004-07-23 00:00:00+00	0	203.79	\N	\N	203.79	\N	\N	\N	\N	40	20	56861
2004-07-24 00:00:00+00	2004-07-24 00:00:00+00	2004-07-24 00:00:00+00	0	203.81	\N	\N	203.81	\N	\N	\N	\N	40	20	56863
2004-07-25 00:00:00+00	2004-07-25 00:00:00+00	2004-07-25 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56865
2004-07-30 00:00:00+00	2004-07-30 00:00:00+00	2004-07-30 00:00:00+00	0	203.81	\N	\N	203.81	\N	\N	\N	\N	40	20	56867
2004-07-31 00:00:00+00	2004-07-31 00:00:00+00	2004-07-31 00:00:00+00	0	203.77	\N	\N	203.77	\N	\N	\N	\N	40	20	56869
2004-08-01 00:00:00+00	2004-08-01 00:00:00+00	2004-08-01 00:00:00+00	0	203.76	\N	\N	203.76	\N	\N	\N	\N	40	20	56871
2004-08-02 00:00:00+00	2004-08-02 00:00:00+00	2004-08-02 00:00:00+00	0	203.76	\N	\N	203.76	\N	\N	\N	\N	40	20	56873
2004-08-03 00:00:00+00	2004-08-03 00:00:00+00	2004-08-03 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56875
2004-08-04 00:00:00+00	2004-08-04 00:00:00+00	2004-08-04 00:00:00+00	0	203.76	\N	\N	203.76	\N	\N	\N	\N	40	20	56877
2004-08-05 00:00:00+00	2004-08-05 00:00:00+00	2004-08-05 00:00:00+00	0	203.74	\N	\N	203.74	\N	\N	\N	\N	40	20	56879
2004-08-06 00:00:00+00	2004-08-06 00:00:00+00	2004-08-06 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56881
2004-08-07 00:00:00+00	2004-08-07 00:00:00+00	2004-08-07 00:00:00+00	0	203.83	\N	\N	203.83	\N	\N	\N	\N	40	20	56883
2004-08-08 00:00:00+00	2004-08-08 00:00:00+00	2004-08-08 00:00:00+00	0	203.74	\N	\N	203.74	\N	\N	\N	\N	40	20	56885
2004-08-09 00:00:00+00	2004-08-09 00:00:00+00	2004-08-09 00:00:00+00	0	203.73	\N	\N	203.73	\N	\N	\N	\N	40	20	56887
2004-08-10 00:00:00+00	2004-08-10 00:00:00+00	2004-08-10 00:00:00+00	0	203.76	\N	\N	203.76	\N	\N	\N	\N	40	20	56889
2004-08-11 00:00:00+00	2004-08-11 00:00:00+00	2004-08-11 00:00:00+00	0	203.78	\N	\N	203.78	\N	\N	\N	\N	40	20	56891
2004-08-12 00:00:00+00	2004-08-12 00:00:00+00	2004-08-12 00:00:00+00	0	203.83	\N	\N	203.83	\N	\N	\N	\N	40	20	56893
2004-08-13 00:00:00+00	2004-08-13 00:00:00+00	2004-08-13 00:00:00+00	0	203.8	\N	\N	203.8	\N	\N	\N	\N	40	20	56895
2004-08-14 00:00:00+00	2004-08-14 00:00:00+00	2004-08-14 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56897
2004-08-15 00:00:00+00	2004-08-15 00:00:00+00	2004-08-15 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56899
2004-08-16 00:00:00+00	2004-08-16 00:00:00+00	2004-08-16 00:00:00+00	0	203.82	\N	\N	203.82	\N	\N	\N	\N	40	20	56901
2004-08-17 00:00:00+00	2004-08-17 00:00:00+00	2004-08-17 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56903
2004-08-18 00:00:00+00	2004-08-18 00:00:00+00	2004-08-18 00:00:00+00	0	203.93	\N	\N	203.93	\N	\N	\N	\N	40	20	56905
2004-08-19 00:00:00+00	2004-08-19 00:00:00+00	2004-08-19 00:00:00+00	0	203.89	\N	\N	203.89	\N	\N	\N	\N	40	20	56907
2004-08-20 00:00:00+00	2004-08-20 00:00:00+00	2004-08-20 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56909
2004-08-21 00:00:00+00	2004-08-21 00:00:00+00	2004-08-21 00:00:00+00	0	203.87	\N	\N	203.87	\N	\N	\N	\N	40	20	56911
2004-08-22 00:00:00+00	2004-08-22 00:00:00+00	2004-08-22 00:00:00+00	0	203.91	\N	\N	203.91	\N	\N	\N	\N	40	20	56913
2004-08-23 00:00:00+00	2004-08-23 00:00:00+00	2004-08-23 00:00:00+00	0	203.89	\N	\N	203.89	\N	\N	\N	\N	40	20	56915
2004-08-24 00:00:00+00	2004-08-24 00:00:00+00	2004-08-24 00:00:00+00	0	203.87	\N	\N	203.87	\N	\N	\N	\N	40	20	56917
2004-08-25 00:00:00+00	2004-08-25 00:00:00+00	2004-08-25 00:00:00+00	0	203.85	\N	\N	203.85	\N	\N	\N	\N	40	20	56919
2004-08-26 00:00:00+00	2004-08-26 00:00:00+00	2004-08-26 00:00:00+00	0	203.9	\N	\N	203.9	\N	\N	\N	\N	40	20	56921
2005-10-26 00:00:00+00	2005-10-26 00:00:00+00	2005-10-26 00:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	41	21	67646
2005-10-27 00:00:00+00	2005-10-27 00:00:00+00	2005-10-27 00:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	41	21	67648
2005-10-28 00:00:00+00	2005-10-28 00:00:00+00	2005-10-28 00:00:00+00	0	6133	\N	\N	6133	\N	\N	\N	\N	41	21	67650
2005-10-29 00:00:00+00	2005-10-29 00:00:00+00	2005-10-29 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67652
2005-10-30 00:00:00+00	2005-10-30 00:00:00+00	2005-10-30 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67654
2005-10-31 00:00:00+00	2005-10-31 00:00:00+00	2005-10-31 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67656
2005-11-01 00:00:00+00	2005-11-01 00:00:00+00	2005-11-01 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67658
2005-11-02 00:00:00+00	2005-11-02 00:00:00+00	2005-11-02 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67660
2005-11-03 00:00:00+00	2005-11-03 00:00:00+00	2005-11-03 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67662
2005-11-04 00:00:00+00	2005-11-04 00:00:00+00	2005-11-04 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67664
2005-11-05 00:00:00+00	2005-11-05 00:00:00+00	2005-11-05 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67666
2005-11-06 00:00:00+00	2005-11-06 00:00:00+00	2005-11-06 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67668
2005-11-07 00:00:00+00	2005-11-07 00:00:00+00	2005-11-07 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67670
2005-11-08 00:00:00+00	2005-11-08 00:00:00+00	2005-11-08 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67672
2005-11-09 00:00:00+00	2005-11-09 00:00:00+00	2005-11-09 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67674
2005-11-10 00:00:00+00	2005-11-10 00:00:00+00	2005-11-10 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67676
2005-11-11 00:00:00+00	2005-11-11 00:00:00+00	2005-11-11 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67678
2005-11-12 00:00:00+00	2005-11-12 00:00:00+00	2005-11-12 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67680
2005-11-13 00:00:00+00	2005-11-13 00:00:00+00	2005-11-13 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67682
2005-11-14 00:00:00+00	2005-11-14 00:00:00+00	2005-11-14 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67684
2005-11-15 00:00:00+00	2005-11-15 00:00:00+00	2005-11-15 00:00:00+00	0	6134	\N	\N	6134	\N	\N	\N	\N	41	21	67686
2005-11-16 00:00:00+00	2005-11-16 00:00:00+00	2005-11-16 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67688
2005-11-17 00:00:00+00	2005-11-17 00:00:00+00	2005-11-17 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67690
2005-11-18 00:00:00+00	2005-11-18 00:00:00+00	2005-11-18 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67692
2005-11-19 00:00:00+00	2005-11-19 00:00:00+00	2005-11-19 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67694
2005-11-20 00:00:00+00	2005-11-20 00:00:00+00	2005-11-20 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67696
2005-11-21 00:00:00+00	2005-11-21 00:00:00+00	2005-11-21 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67698
2005-11-22 00:00:00+00	2005-11-22 00:00:00+00	2005-11-22 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67700
2005-11-23 00:00:00+00	2005-11-23 00:00:00+00	2005-11-23 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67702
2005-11-24 00:00:00+00	2005-11-24 00:00:00+00	2005-11-24 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67704
2005-11-25 00:00:00+00	2005-11-25 00:00:00+00	2005-11-25 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67706
2005-11-26 00:00:00+00	2005-11-26 00:00:00+00	2005-11-26 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67708
2005-11-27 00:00:00+00	2005-11-27 00:00:00+00	2005-11-27 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67710
2005-11-28 00:00:00+00	2005-11-28 00:00:00+00	2005-11-28 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67712
2005-11-29 00:00:00+00	2005-11-29 00:00:00+00	2005-11-29 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67714
2005-11-30 00:00:00+00	2005-11-30 00:00:00+00	2005-11-30 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67716
2005-12-01 00:00:00+00	2005-12-01 00:00:00+00	2005-12-01 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67718
2005-12-02 00:00:00+00	2005-12-02 00:00:00+00	2005-12-02 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67720
2005-12-03 00:00:00+00	2005-12-03 00:00:00+00	2005-12-03 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67722
2005-12-04 00:00:00+00	2005-12-04 00:00:00+00	2005-12-04 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67724
2005-12-05 00:00:00+00	2005-12-05 00:00:00+00	2005-12-05 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67726
2005-12-06 00:00:00+00	2005-12-06 00:00:00+00	2005-12-06 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67728
2005-12-07 00:00:00+00	2005-12-07 00:00:00+00	2005-12-07 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67730
2005-12-08 00:00:00+00	2005-12-08 00:00:00+00	2005-12-08 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67732
2005-12-09 00:00:00+00	2005-12-09 00:00:00+00	2005-12-09 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67734
2005-12-10 00:00:00+00	2005-12-10 00:00:00+00	2005-12-10 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67736
2005-12-11 00:00:00+00	2005-12-11 00:00:00+00	2005-12-11 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67738
2005-12-12 00:00:00+00	2005-12-12 00:00:00+00	2005-12-12 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67740
2005-12-13 00:00:00+00	2005-12-13 00:00:00+00	2005-12-13 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67742
2005-12-14 00:00:00+00	2005-12-14 00:00:00+00	2005-12-14 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67744
2005-12-15 00:00:00+00	2005-12-15 00:00:00+00	2005-12-15 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67746
2005-12-16 00:00:00+00	2005-12-16 00:00:00+00	2005-12-16 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67748
2005-12-17 00:00:00+00	2005-12-17 00:00:00+00	2005-12-17 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67750
2005-12-18 00:00:00+00	2005-12-18 00:00:00+00	2005-12-18 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67752
2005-12-19 00:00:00+00	2005-12-19 00:00:00+00	2005-12-19 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67754
2005-12-20 00:00:00+00	2005-12-20 00:00:00+00	2005-12-20 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67756
2005-12-21 00:00:00+00	2005-12-21 00:00:00+00	2005-12-21 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67758
2005-12-22 00:00:00+00	2005-12-22 00:00:00+00	2005-12-22 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67760
2005-12-23 00:00:00+00	2005-12-23 00:00:00+00	2005-12-23 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67762
2005-12-24 00:00:00+00	2005-12-24 00:00:00+00	2005-12-24 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67764
2005-12-25 00:00:00+00	2005-12-25 00:00:00+00	2005-12-25 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67766
2005-12-26 00:00:00+00	2005-12-26 00:00:00+00	2005-12-26 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67768
2005-12-27 00:00:00+00	2005-12-27 00:00:00+00	2005-12-27 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67770
2005-12-28 00:00:00+00	2005-12-28 00:00:00+00	2005-12-28 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67772
2005-12-29 00:00:00+00	2005-12-29 00:00:00+00	2005-12-29 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67774
2005-12-30 00:00:00+00	2005-12-30 00:00:00+00	2005-12-30 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67776
2005-12-31 00:00:00+00	2005-12-31 00:00:00+00	2005-12-31 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67778
2006-01-01 00:00:00+00	2006-01-01 00:00:00+00	2006-01-01 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67780
2006-01-02 00:00:00+00	2006-01-02 00:00:00+00	2006-01-02 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67782
2006-01-03 00:00:00+00	2006-01-03 00:00:00+00	2006-01-03 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67784
2006-01-04 00:00:00+00	2006-01-04 00:00:00+00	2006-01-04 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67786
2006-01-05 00:00:00+00	2006-01-05 00:00:00+00	2006-01-05 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67788
2006-01-06 00:00:00+00	2006-01-06 00:00:00+00	2006-01-06 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67790
2006-01-07 00:00:00+00	2006-01-07 00:00:00+00	2006-01-07 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67792
2006-01-08 00:00:00+00	2006-01-08 00:00:00+00	2006-01-08 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67794
2006-01-09 00:00:00+00	2006-01-09 00:00:00+00	2006-01-09 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67796
2006-01-10 00:00:00+00	2006-01-10 00:00:00+00	2006-01-10 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67798
2006-01-11 00:00:00+00	2006-01-11 00:00:00+00	2006-01-11 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67800
2006-01-12 00:00:00+00	2006-01-12 00:00:00+00	2006-01-12 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67802
2006-01-13 00:00:00+00	2006-01-13 00:00:00+00	2006-01-13 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67804
2006-01-14 00:00:00+00	2006-01-14 00:00:00+00	2006-01-14 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67806
2006-01-15 00:00:00+00	2006-01-15 00:00:00+00	2006-01-15 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67808
2006-01-16 00:00:00+00	2006-01-16 00:00:00+00	2006-01-16 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67810
2006-01-17 00:00:00+00	2006-01-17 00:00:00+00	2006-01-17 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67812
2006-01-18 00:00:00+00	2006-01-18 00:00:00+00	2006-01-18 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67814
2006-01-19 00:00:00+00	2006-01-19 00:00:00+00	2006-01-19 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67816
2006-01-20 00:00:00+00	2006-01-20 00:00:00+00	2006-01-20 00:00:00+00	0	6135	\N	\N	6135	\N	\N	\N	\N	41	21	67818
2006-01-21 00:00:00+00	2006-01-21 00:00:00+00	2006-01-21 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67820
2006-01-22 00:00:00+00	2006-01-22 00:00:00+00	2006-01-22 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67822
2006-01-23 00:00:00+00	2006-01-23 00:00:00+00	2006-01-23 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67824
2006-01-24 00:00:00+00	2006-01-24 00:00:00+00	2006-01-24 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67826
2006-01-25 00:00:00+00	2006-01-25 00:00:00+00	2006-01-25 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67828
2006-01-26 00:00:00+00	2006-01-26 00:00:00+00	2006-01-26 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67830
2006-01-27 00:00:00+00	2006-01-27 00:00:00+00	2006-01-27 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67832
2006-01-28 00:00:00+00	2006-01-28 00:00:00+00	2006-01-28 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67834
2006-01-29 00:00:00+00	2006-01-29 00:00:00+00	2006-01-29 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67836
2006-01-30 00:00:00+00	2006-01-30 00:00:00+00	2006-01-30 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67838
2006-01-31 00:00:00+00	2006-01-31 00:00:00+00	2006-01-31 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67840
2006-02-01 00:00:00+00	2006-02-01 00:00:00+00	2006-02-01 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67842
2006-02-02 00:00:00+00	2006-02-02 00:00:00+00	2006-02-02 00:00:00+00	0	6136	\N	\N	6136	\N	\N	\N	\N	41	21	67844
2005-10-26 00:00:00+00	2005-10-26 00:00:00+00	2005-10-26 00:00:00+00	0	256.66	\N	\N	256.66	\N	\N	\N	\N	42	21	67645
2005-10-27 00:00:00+00	2005-10-27 00:00:00+00	2005-10-27 00:00:00+00	0	256.56	\N	\N	256.56	\N	\N	\N	\N	42	21	67647
2005-10-28 00:00:00+00	2005-10-28 00:00:00+00	2005-10-28 00:00:00+00	0	256.54	\N	\N	256.54	\N	\N	\N	\N	42	21	67649
2005-10-29 00:00:00+00	2005-10-29 00:00:00+00	2005-10-29 00:00:00+00	0	256.5	\N	\N	256.5	\N	\N	\N	\N	42	21	67651
2005-10-30 00:00:00+00	2005-10-30 00:00:00+00	2005-10-30 00:00:00+00	0	256.47	\N	\N	256.47	\N	\N	\N	\N	42	21	67653
2005-10-31 00:00:00+00	2005-10-31 00:00:00+00	2005-10-31 00:00:00+00	0	256.44	\N	\N	256.44	\N	\N	\N	\N	42	21	67655
2005-11-01 00:00:00+00	2005-11-01 00:00:00+00	2005-11-01 00:00:00+00	0	256.45	\N	\N	256.45	\N	\N	\N	\N	42	21	67657
2005-11-02 00:00:00+00	2005-11-02 00:00:00+00	2005-11-02 00:00:00+00	0	256.45	\N	\N	256.45	\N	\N	\N	\N	42	21	67659
2005-11-03 00:00:00+00	2005-11-03 00:00:00+00	2005-11-03 00:00:00+00	0	256.38	\N	\N	256.38	\N	\N	\N	\N	42	21	67661
2005-11-04 00:00:00+00	2005-11-04 00:00:00+00	2005-11-04 00:00:00+00	0	256.34	\N	\N	256.34	\N	\N	\N	\N	42	21	67663
2005-11-05 00:00:00+00	2005-11-05 00:00:00+00	2005-11-05 00:00:00+00	0	256.26	\N	\N	256.26	\N	\N	\N	\N	42	21	67665
2005-11-06 00:00:00+00	2005-11-06 00:00:00+00	2005-11-06 00:00:00+00	0	256.07	\N	\N	256.07	\N	\N	\N	\N	42	21	67667
2005-11-07 00:00:00+00	2005-11-07 00:00:00+00	2005-11-07 00:00:00+00	0	256	\N	\N	256	\N	\N	\N	\N	42	21	67669
2005-11-08 00:00:00+00	2005-11-08 00:00:00+00	2005-11-08 00:00:00+00	0	255.92	\N	\N	255.92	\N	\N	\N	\N	42	21	67671
2005-11-09 00:00:00+00	2005-11-09 00:00:00+00	2005-11-09 00:00:00+00	0	255.83	\N	\N	255.83	\N	\N	\N	\N	42	21	67673
2005-11-10 00:00:00+00	2005-11-10 00:00:00+00	2005-11-10 00:00:00+00	0	255.82	\N	\N	255.82	\N	\N	\N	\N	42	21	67675
2005-11-11 00:00:00+00	2005-11-11 00:00:00+00	2005-11-11 00:00:00+00	0	255.92	\N	\N	255.92	\N	\N	\N	\N	42	21	67677
2005-11-12 00:00:00+00	2005-11-12 00:00:00+00	2005-11-12 00:00:00+00	0	255.86	\N	\N	255.86	\N	\N	\N	\N	42	21	67679
2005-11-13 00:00:00+00	2005-11-13 00:00:00+00	2005-11-13 00:00:00+00	0	255.69	\N	\N	255.69	\N	\N	\N	\N	42	21	67681
2005-11-14 00:00:00+00	2005-11-14 00:00:00+00	2005-11-14 00:00:00+00	0	255.76	\N	\N	255.76	\N	\N	\N	\N	42	21	67683
2005-11-15 00:00:00+00	2005-11-15 00:00:00+00	2005-11-15 00:00:00+00	0	255.74	\N	\N	255.74	\N	\N	\N	\N	42	21	67685
2005-11-16 00:00:00+00	2005-11-16 00:00:00+00	2005-11-16 00:00:00+00	0	255.46	\N	\N	255.46	\N	\N	\N	\N	42	21	67687
2005-11-17 00:00:00+00	2005-11-17 00:00:00+00	2005-11-17 00:00:00+00	0	255.47	\N	\N	255.47	\N	\N	\N	\N	42	21	67689
2005-11-18 00:00:00+00	2005-11-18 00:00:00+00	2005-11-18 00:00:00+00	0	255.47	\N	\N	255.47	\N	\N	\N	\N	42	21	67691
2005-11-19 00:00:00+00	2005-11-19 00:00:00+00	2005-11-19 00:00:00+00	0	255.49	\N	\N	255.49	\N	\N	\N	\N	42	21	67693
2005-11-20 00:00:00+00	2005-11-20 00:00:00+00	2005-11-20 00:00:00+00	0	255.32	\N	\N	255.32	\N	\N	\N	\N	42	21	67695
2005-11-21 00:00:00+00	2005-11-21 00:00:00+00	2005-11-21 00:00:00+00	0	255.3	\N	\N	255.3	\N	\N	\N	\N	42	21	67697
2005-11-22 00:00:00+00	2005-11-22 00:00:00+00	2005-11-22 00:00:00+00	0	255.28	\N	\N	255.28	\N	\N	\N	\N	42	21	67699
2005-11-23 00:00:00+00	2005-11-23 00:00:00+00	2005-11-23 00:00:00+00	0	255.32	\N	\N	255.32	\N	\N	\N	\N	42	21	67701
2005-11-24 00:00:00+00	2005-11-24 00:00:00+00	2005-11-24 00:00:00+00	0	255.32	\N	\N	255.32	\N	\N	\N	\N	42	21	67703
2005-11-25 00:00:00+00	2005-11-25 00:00:00+00	2005-11-25 00:00:00+00	0	255.3	\N	\N	255.3	\N	\N	\N	\N	42	21	67705
2005-11-26 00:00:00+00	2005-11-26 00:00:00+00	2005-11-26 00:00:00+00	0	255.45	\N	\N	255.45	\N	\N	\N	\N	42	21	67707
2005-11-27 00:00:00+00	2005-11-27 00:00:00+00	2005-11-27 00:00:00+00	0	255.42	\N	\N	255.42	\N	\N	\N	\N	42	21	67709
2005-11-28 00:00:00+00	2005-11-28 00:00:00+00	2005-11-28 00:00:00+00	0	255.23	\N	\N	255.23	\N	\N	\N	\N	42	21	67711
2005-11-29 00:00:00+00	2005-11-29 00:00:00+00	2005-11-29 00:00:00+00	0	255.05	\N	\N	255.05	\N	\N	\N	\N	42	21	67713
2005-11-30 00:00:00+00	2005-11-30 00:00:00+00	2005-11-30 00:00:00+00	0	255.05	\N	\N	255.05	\N	\N	\N	\N	42	21	67715
2005-12-01 00:00:00+00	2005-12-01 00:00:00+00	2005-12-01 00:00:00+00	0	254.99	\N	\N	254.99	\N	\N	\N	\N	42	21	67717
2005-12-02 00:00:00+00	2005-12-02 00:00:00+00	2005-12-02 00:00:00+00	0	255.04	\N	\N	255.04	\N	\N	\N	\N	42	21	67719
2005-12-03 00:00:00+00	2005-12-03 00:00:00+00	2005-12-03 00:00:00+00	0	255.04	\N	\N	255.04	\N	\N	\N	\N	42	21	67721
2005-12-04 00:00:00+00	2005-12-04 00:00:00+00	2005-12-04 00:00:00+00	0	254.93	\N	\N	254.93	\N	\N	\N	\N	42	21	67723
2005-12-05 00:00:00+00	2005-12-05 00:00:00+00	2005-12-05 00:00:00+00	0	254.8	\N	\N	254.8	\N	\N	\N	\N	42	21	67725
2005-12-06 00:00:00+00	2005-12-06 00:00:00+00	2005-12-06 00:00:00+00	0	254.87	\N	\N	254.87	\N	\N	\N	\N	42	21	67727
2005-12-07 00:00:00+00	2005-12-07 00:00:00+00	2005-12-07 00:00:00+00	0	254.87	\N	\N	254.87	\N	\N	\N	\N	42	21	67729
2005-12-08 00:00:00+00	2005-12-08 00:00:00+00	2005-12-08 00:00:00+00	0	254.68	\N	\N	254.68	\N	\N	\N	\N	42	21	67731
2005-12-09 00:00:00+00	2005-12-09 00:00:00+00	2005-12-09 00:00:00+00	0	254.72	\N	\N	254.72	\N	\N	\N	\N	42	21	67733
2005-12-10 00:00:00+00	2005-12-10 00:00:00+00	2005-12-10 00:00:00+00	0	254.68	\N	\N	254.68	\N	\N	\N	\N	42	21	67735
2005-12-11 00:00:00+00	2005-12-11 00:00:00+00	2005-12-11 00:00:00+00	0	254.71	\N	\N	254.71	\N	\N	\N	\N	42	21	67737
2005-12-12 00:00:00+00	2005-12-12 00:00:00+00	2005-12-12 00:00:00+00	0	254.74	\N	\N	254.74	\N	\N	\N	\N	42	21	67739
2005-12-13 00:00:00+00	2005-12-13 00:00:00+00	2005-12-13 00:00:00+00	0	254.78	\N	\N	254.78	\N	\N	\N	\N	42	21	67741
2005-12-14 00:00:00+00	2005-12-14 00:00:00+00	2005-12-14 00:00:00+00	0	254.78	\N	\N	254.78	\N	\N	\N	\N	42	21	67743
2005-12-15 00:00:00+00	2005-12-15 00:00:00+00	2005-12-15 00:00:00+00	0	254.77	\N	\N	254.77	\N	\N	\N	\N	42	21	67745
2005-12-16 00:00:00+00	2005-12-16 00:00:00+00	2005-12-16 00:00:00+00	0	254.78	\N	\N	254.78	\N	\N	\N	\N	42	21	67747
2005-12-17 00:00:00+00	2005-12-17 00:00:00+00	2005-12-17 00:00:00+00	0	254.75	\N	\N	254.75	\N	\N	\N	\N	42	21	67749
2005-12-18 00:00:00+00	2005-12-18 00:00:00+00	2005-12-18 00:00:00+00	0	254.56	\N	\N	254.56	\N	\N	\N	\N	42	21	67751
2005-12-19 00:00:00+00	2005-12-19 00:00:00+00	2005-12-19 00:00:00+00	0	254.47	\N	\N	254.47	\N	\N	\N	\N	42	21	67753
2005-12-20 00:00:00+00	2005-12-20 00:00:00+00	2005-12-20 00:00:00+00	0	254.48	\N	\N	254.48	\N	\N	\N	\N	42	21	67755
2005-12-21 00:00:00+00	2005-12-21 00:00:00+00	2005-12-21 00:00:00+00	0	254.43	\N	\N	254.43	\N	\N	\N	\N	42	21	67757
2005-12-22 00:00:00+00	2005-12-22 00:00:00+00	2005-12-22 00:00:00+00	0	254.47	\N	\N	254.47	\N	\N	\N	\N	42	21	67759
2005-12-23 00:00:00+00	2005-12-23 00:00:00+00	2005-12-23 00:00:00+00	0	254.49	\N	\N	254.49	\N	\N	\N	\N	42	21	67761
2005-12-24 00:00:00+00	2005-12-24 00:00:00+00	2005-12-24 00:00:00+00	0	254.39	\N	\N	254.39	\N	\N	\N	\N	42	21	67763
2005-12-25 00:00:00+00	2005-12-25 00:00:00+00	2005-12-25 00:00:00+00	0	254.43	\N	\N	254.43	\N	\N	\N	\N	42	21	67765
2005-12-26 00:00:00+00	2005-12-26 00:00:00+00	2005-12-26 00:00:00+00	0	254.49	\N	\N	254.49	\N	\N	\N	\N	42	21	67767
2005-12-27 00:00:00+00	2005-12-27 00:00:00+00	2005-12-27 00:00:00+00	0	254.48	\N	\N	254.48	\N	\N	\N	\N	42	21	67769
2005-12-28 00:00:00+00	2005-12-28 00:00:00+00	2005-12-28 00:00:00+00	0	254.5	\N	\N	254.5	\N	\N	\N	\N	42	21	67771
2005-12-29 00:00:00+00	2005-12-29 00:00:00+00	2005-12-29 00:00:00+00	0	254.55	\N	\N	254.55	\N	\N	\N	\N	42	21	67773
2005-12-30 00:00:00+00	2005-12-30 00:00:00+00	2005-12-30 00:00:00+00	0	254.55	\N	\N	254.55	\N	\N	\N	\N	42	21	67775
2005-12-31 00:00:00+00	2005-12-31 00:00:00+00	2005-12-31 00:00:00+00	0	254.66	\N	\N	254.66	\N	\N	\N	\N	42	21	67777
2006-01-01 00:00:00+00	2006-01-01 00:00:00+00	2006-01-01 00:00:00+00	0	254.7	\N	\N	254.7	\N	\N	\N	\N	42	21	67779
2006-01-02 00:00:00+00	2006-01-02 00:00:00+00	2006-01-02 00:00:00+00	0	254.51	\N	\N	254.51	\N	\N	\N	\N	42	21	67781
2006-01-03 00:00:00+00	2006-01-03 00:00:00+00	2006-01-03 00:00:00+00	0	254.51	\N	\N	254.51	\N	\N	\N	\N	42	21	67783
2006-01-04 00:00:00+00	2006-01-04 00:00:00+00	2006-01-04 00:00:00+00	0	254.39	\N	\N	254.39	\N	\N	\N	\N	42	21	67785
2006-01-05 00:00:00+00	2006-01-05 00:00:00+00	2006-01-05 00:00:00+00	0	254.31	\N	\N	254.31	\N	\N	\N	\N	42	21	67787
2006-01-06 00:00:00+00	2006-01-06 00:00:00+00	2006-01-06 00:00:00+00	0	254.4	\N	\N	254.4	\N	\N	\N	\N	42	21	67789
2006-01-07 00:00:00+00	2006-01-07 00:00:00+00	2006-01-07 00:00:00+00	0	254.62	\N	\N	254.62	\N	\N	\N	\N	42	21	67791
2006-01-08 00:00:00+00	2006-01-08 00:00:00+00	2006-01-08 00:00:00+00	0	254.6	\N	\N	254.6	\N	\N	\N	\N	42	21	67793
2006-01-09 00:00:00+00	2006-01-09 00:00:00+00	2006-01-09 00:00:00+00	0	254.56	\N	\N	254.56	\N	\N	\N	\N	42	21	67795
2006-01-10 00:00:00+00	2006-01-10 00:00:00+00	2006-01-10 00:00:00+00	0	254.52	\N	\N	254.52	\N	\N	\N	\N	42	21	67797
2006-01-11 00:00:00+00	2006-01-11 00:00:00+00	2006-01-11 00:00:00+00	0	254.66	\N	\N	254.66	\N	\N	\N	\N	42	21	67799
2006-01-12 00:00:00+00	2006-01-12 00:00:00+00	2006-01-12 00:00:00+00	0	254.66	\N	\N	254.66	\N	\N	\N	\N	42	21	67801
2006-01-13 00:00:00+00	2006-01-13 00:00:00+00	2006-01-13 00:00:00+00	0	254.5	\N	\N	254.5	\N	\N	\N	\N	42	21	67803
2006-01-14 00:00:00+00	2006-01-14 00:00:00+00	2006-01-14 00:00:00+00	0	254.58	\N	\N	254.58	\N	\N	\N	\N	42	21	67805
2006-01-15 00:00:00+00	2006-01-15 00:00:00+00	2006-01-15 00:00:00+00	0	254.72	\N	\N	254.72	\N	\N	\N	\N	42	21	67807
2006-01-16 00:00:00+00	2006-01-16 00:00:00+00	2006-01-16 00:00:00+00	0	254.72	\N	\N	254.72	\N	\N	\N	\N	42	21	67809
2006-01-17 00:00:00+00	2006-01-17 00:00:00+00	2006-01-17 00:00:00+00	0	254.48	\N	\N	254.48	\N	\N	\N	\N	42	21	67811
2006-01-18 00:00:00+00	2006-01-18 00:00:00+00	2006-01-18 00:00:00+00	0	254.56	\N	\N	254.56	\N	\N	\N	\N	42	21	67813
2006-01-19 00:00:00+00	2006-01-19 00:00:00+00	2006-01-19 00:00:00+00	0	254.65	\N	\N	254.65	\N	\N	\N	\N	42	21	67815
2006-01-20 00:00:00+00	2006-01-20 00:00:00+00	2006-01-20 00:00:00+00	0	254.54	\N	\N	254.54	\N	\N	\N	\N	42	21	67817
2006-01-21 00:00:00+00	2006-01-21 00:00:00+00	2006-01-21 00:00:00+00	0	254.41	\N	\N	254.41	\N	\N	\N	\N	42	21	67819
2006-01-22 00:00:00+00	2006-01-22 00:00:00+00	2006-01-22 00:00:00+00	0	254.36	\N	\N	254.36	\N	\N	\N	\N	42	21	67821
2006-01-23 00:00:00+00	2006-01-23 00:00:00+00	2006-01-23 00:00:00+00	0	254.3	\N	\N	254.3	\N	\N	\N	\N	42	21	67823
2006-01-24 00:00:00+00	2006-01-24 00:00:00+00	2006-01-24 00:00:00+00	0	254.24	\N	\N	254.24	\N	\N	\N	\N	42	21	67825
2006-01-25 00:00:00+00	2006-01-25 00:00:00+00	2006-01-25 00:00:00+00	0	254.31	\N	\N	254.31	\N	\N	\N	\N	42	21	67827
2006-01-26 00:00:00+00	2006-01-26 00:00:00+00	2006-01-26 00:00:00+00	0	254.32	\N	\N	254.32	\N	\N	\N	\N	42	21	67829
2006-01-27 00:00:00+00	2006-01-27 00:00:00+00	2006-01-27 00:00:00+00	0	254.42	\N	\N	254.42	\N	\N	\N	\N	42	21	67831
2006-01-28 00:00:00+00	2006-01-28 00:00:00+00	2006-01-28 00:00:00+00	0	254.41	\N	\N	254.41	\N	\N	\N	\N	42	21	67833
2006-01-29 00:00:00+00	2006-01-29 00:00:00+00	2006-01-29 00:00:00+00	0	254.38	\N	\N	254.38	\N	\N	\N	\N	42	21	67835
2006-01-30 00:00:00+00	2006-01-30 00:00:00+00	2006-01-30 00:00:00+00	0	254.31	\N	\N	254.31	\N	\N	\N	\N	42	21	67837
2006-01-31 00:00:00+00	2006-01-31 00:00:00+00	2006-01-31 00:00:00+00	0	254.36	\N	\N	254.36	\N	\N	\N	\N	42	21	67839
2006-02-01 00:00:00+00	2006-02-01 00:00:00+00	2006-02-01 00:00:00+00	0	254.35	\N	\N	254.35	\N	\N	\N	\N	42	21	67841
2006-02-02 00:00:00+00	2006-02-02 00:00:00+00	2006-02-02 00:00:00+00	0	254.35	\N	\N	254.35	\N	\N	\N	\N	42	21	67843
1998-02-04 00:00:00+00	1998-02-04 00:00:00+00	1998-02-04 00:00:00+00	0	188.35	\N	\N	188.35	\N	\N	\N	\N	44	22	78275
1998-02-05 00:00:00+00	1998-02-05 00:00:00+00	1998-02-05 00:00:00+00	0	188.87	\N	\N	188.87	\N	\N	\N	\N	44	22	78277
1998-02-06 00:00:00+00	1998-02-06 00:00:00+00	1998-02-06 00:00:00+00	0	189.04	\N	\N	189.04	\N	\N	\N	\N	44	22	78279
1998-02-07 00:00:00+00	1998-02-07 00:00:00+00	1998-02-07 00:00:00+00	0	189.09	\N	\N	189.09	\N	\N	\N	\N	44	22	78281
1998-02-08 00:00:00+00	1998-02-08 00:00:00+00	1998-02-08 00:00:00+00	0	189	\N	\N	189	\N	\N	\N	\N	44	22	78283
1998-02-09 00:00:00+00	1998-02-09 00:00:00+00	1998-02-09 00:00:00+00	0	188.92	\N	\N	188.92	\N	\N	\N	\N	44	22	78285
1998-02-10 00:00:00+00	1998-02-10 00:00:00+00	1998-02-10 00:00:00+00	0	188.66	\N	\N	188.66	\N	\N	\N	\N	44	22	78287
1998-02-11 00:00:00+00	1998-02-11 00:00:00+00	1998-02-11 00:00:00+00	0	188.82	\N	\N	188.82	\N	\N	\N	\N	44	22	78289
1998-02-12 00:00:00+00	1998-02-12 00:00:00+00	1998-02-12 00:00:00+00	0	188.84	\N	\N	188.84	\N	\N	\N	\N	44	22	78291
1998-02-13 00:00:00+00	1998-02-13 00:00:00+00	1998-02-13 00:00:00+00	0	188.88	\N	\N	188.88	\N	\N	\N	\N	44	22	78293
1998-02-14 00:00:00+00	1998-02-14 00:00:00+00	1998-02-14 00:00:00+00	0	189.47	\N	\N	189.47	\N	\N	\N	\N	44	22	78295
1998-02-15 00:00:00+00	1998-02-15 00:00:00+00	1998-02-15 00:00:00+00	0	189.5	\N	\N	189.5	\N	\N	\N	\N	44	22	78297
1998-02-16 00:00:00+00	1998-02-16 00:00:00+00	1998-02-16 00:00:00+00	0	189.6	\N	\N	189.6	\N	\N	\N	\N	44	22	78299
1998-02-17 00:00:00+00	1998-02-17 00:00:00+00	1998-02-17 00:00:00+00	0	189.62	\N	\N	189.62	\N	\N	\N	\N	44	22	78301
1998-02-18 00:00:00+00	1998-02-18 00:00:00+00	1998-02-18 00:00:00+00	0	189.25	\N	\N	189.25	\N	\N	\N	\N	44	22	78303
1998-02-19 00:00:00+00	1998-02-19 00:00:00+00	1998-02-19 00:00:00+00	0	189.47	\N	\N	189.47	\N	\N	\N	\N	44	22	78305
1998-02-20 00:00:00+00	1998-02-20 00:00:00+00	1998-02-20 00:00:00+00	0	189.76	\N	\N	189.76	\N	\N	\N	\N	44	22	78307
1998-02-21 00:00:00+00	1998-02-21 00:00:00+00	1998-02-21 00:00:00+00	0	189.98	\N	\N	189.98	\N	\N	\N	\N	44	22	78309
1998-02-22 00:00:00+00	1998-02-22 00:00:00+00	1998-02-22 00:00:00+00	0	190	\N	\N	190	\N	\N	\N	\N	44	22	78311
1998-02-23 00:00:00+00	1998-02-23 00:00:00+00	1998-02-23 00:00:00+00	0	189.89	\N	\N	189.89	\N	\N	\N	\N	44	22	78313
1998-02-24 00:00:00+00	1998-02-24 00:00:00+00	1998-02-24 00:00:00+00	0	189.28	\N	\N	189.28	\N	\N	\N	\N	44	22	78315
1998-02-25 00:00:00+00	1998-02-25 00:00:00+00	1998-02-25 00:00:00+00	0	188.69	\N	\N	188.69	\N	\N	\N	\N	44	22	78317
1998-02-26 00:00:00+00	1998-02-26 00:00:00+00	1998-02-26 00:00:00+00	0	188.46	\N	\N	188.46	\N	\N	\N	\N	44	22	78319
1998-02-27 00:00:00+00	1998-02-27 00:00:00+00	1998-02-27 00:00:00+00	0	188.36	\N	\N	188.36	\N	\N	\N	\N	44	22	78321
1998-02-28 00:00:00+00	1998-02-28 00:00:00+00	1998-02-28 00:00:00+00	0	188.37	\N	\N	188.37	\N	\N	\N	\N	44	22	78323
1998-03-01 00:00:00+00	1998-03-01 00:00:00+00	1998-03-01 00:00:00+00	0	188.51	\N	\N	188.51	\N	\N	\N	\N	44	22	78325
1998-03-02 00:00:00+00	1998-03-02 00:00:00+00	1998-03-02 00:00:00+00	0	188.53	\N	\N	188.53	\N	\N	\N	\N	44	22	78327
1998-03-03 00:00:00+00	1998-03-03 00:00:00+00	1998-03-03 00:00:00+00	0	188.67	\N	\N	188.67	\N	\N	\N	\N	44	22	78329
1998-03-04 00:00:00+00	1998-03-04 00:00:00+00	1998-03-04 00:00:00+00	0	188.63	\N	\N	188.63	\N	\N	\N	\N	44	22	78331
1998-03-05 00:00:00+00	1998-03-05 00:00:00+00	1998-03-05 00:00:00+00	0	188.69	\N	\N	188.69	\N	\N	\N	\N	44	22	78333
1998-03-06 00:00:00+00	1998-03-06 00:00:00+00	1998-03-06 00:00:00+00	0	188.83	\N	\N	188.83	\N	\N	\N	\N	44	22	78335
1998-03-07 00:00:00+00	1998-03-07 00:00:00+00	1998-03-07 00:00:00+00	0	188.83	\N	\N	188.83	\N	\N	\N	\N	44	22	78337
1998-03-08 00:00:00+00	1998-03-08 00:00:00+00	1998-03-08 00:00:00+00	0	188.89	\N	\N	188.89	\N	\N	\N	\N	44	22	78339
1998-03-09 00:00:00+00	1998-03-09 00:00:00+00	1998-03-09 00:00:00+00	0	188.94	\N	\N	188.94	\N	\N	\N	\N	44	22	78341
1998-03-10 00:00:00+00	1998-03-10 00:00:00+00	1998-03-10 00:00:00+00	0	189.06	\N	\N	189.06	\N	\N	\N	\N	44	22	78343
1998-03-11 00:00:00+00	1998-03-11 00:00:00+00	1998-03-11 00:00:00+00	0	189.12	\N	\N	189.12	\N	\N	\N	\N	44	22	78345
1998-03-12 00:00:00+00	1998-03-12 00:00:00+00	1998-03-12 00:00:00+00	0	189.25	\N	\N	189.25	\N	\N	\N	\N	44	22	78347
1998-03-13 00:00:00+00	1998-03-13 00:00:00+00	1998-03-13 00:00:00+00	0	189.28	\N	\N	189.28	\N	\N	\N	\N	44	22	78349
1998-03-14 00:00:00+00	1998-03-14 00:00:00+00	1998-03-14 00:00:00+00	0	189.65	\N	\N	189.65	\N	\N	\N	\N	44	22	78351
1998-03-15 00:00:00+00	1998-03-15 00:00:00+00	1998-03-15 00:00:00+00	0	190.19	\N	\N	190.19	\N	\N	\N	\N	44	22	78353
1998-03-16 00:00:00+00	1998-03-16 00:00:00+00	1998-03-16 00:00:00+00	0	190.58	\N	\N	190.58	\N	\N	\N	\N	44	22	78355
1998-03-17 00:00:00+00	1998-03-17 00:00:00+00	1998-03-17 00:00:00+00	0	190.81	\N	\N	190.81	\N	\N	\N	\N	44	22	78357
1998-03-18 00:00:00+00	1998-03-18 00:00:00+00	1998-03-18 00:00:00+00	0	190.93	\N	\N	190.93	\N	\N	\N	\N	44	22	78359
1998-03-19 00:00:00+00	1998-03-19 00:00:00+00	1998-03-19 00:00:00+00	0	190.87	\N	\N	190.87	\N	\N	\N	\N	44	22	78361
1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	0	191.03	\N	\N	191.03	\N	\N	\N	\N	44	22	78363
1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	0	190.95	\N	\N	190.95	\N	\N	\N	\N	44	22	78365
1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	0	190.77	\N	\N	190.77	\N	\N	\N	\N	44	22	78367
1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	0	190.08	\N	\N	190.08	\N	\N	\N	\N	44	22	78369
1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	0	189.52	\N	\N	189.52	\N	\N	\N	\N	44	22	78371
1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	0	189.28	\N	\N	189.28	\N	\N	\N	\N	44	22	78373
1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	0	189.22	\N	\N	189.22	\N	\N	\N	\N	44	22	78375
1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	0	189.14	\N	\N	189.14	\N	\N	\N	\N	44	22	78377
1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	0	189.22	\N	\N	189.22	\N	\N	\N	\N	44	22	78379
1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	0	189.87	\N	\N	189.87	\N	\N	\N	\N	44	22	78381
1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	0	190.46	\N	\N	190.46	\N	\N	\N	\N	44	22	78383
1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	0	192.72	\N	\N	192.72	\N	\N	\N	\N	44	22	78385
1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	0	192.75	\N	\N	192.75	\N	\N	\N	\N	44	22	78387
1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	0	192.67	\N	\N	192.67	\N	\N	\N	\N	44	22	78389
1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	0	192.7	\N	\N	192.7	\N	\N	\N	\N	44	22	78391
1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	0	192.71	\N	\N	192.71	\N	\N	\N	\N	44	22	78393
1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	0	192.73	\N	\N	192.73	\N	\N	\N	\N	44	22	78395
1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	0	192.66	\N	\N	192.66	\N	\N	\N	\N	44	22	78397
1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	0	192.88	\N	\N	192.88	\N	\N	\N	\N	44	22	78399
1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	0	192.81	\N	\N	192.81	\N	\N	\N	\N	44	22	78401
1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	0	192.93	\N	\N	192.93	\N	\N	\N	\N	44	22	78403
1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	0	192.85	\N	\N	192.85	\N	\N	\N	\N	44	22	78405
1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	0	192.75	\N	\N	192.75	\N	\N	\N	\N	44	22	78407
1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	0	192.27	\N	\N	192.27	\N	\N	\N	\N	44	22	78409
1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	0	191.79	\N	\N	191.79	\N	\N	\N	\N	44	22	78411
1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	0	192.14	\N	\N	192.14	\N	\N	\N	\N	44	22	78413
1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	0	192.66	\N	\N	192.66	\N	\N	\N	\N	44	22	78415
1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	0	192.98	\N	\N	192.98	\N	\N	\N	\N	44	22	78417
1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	0	193.3	\N	\N	193.3	\N	\N	\N	\N	44	22	78419
1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	0	193.42	\N	\N	193.42	\N	\N	\N	\N	44	22	78421
1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	0	193.54	\N	\N	193.54	\N	\N	\N	\N	44	22	78423
1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	0	193.57	\N	\N	193.57	\N	\N	\N	\N	44	22	78425
1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	0	193.58	\N	\N	193.58	\N	\N	\N	\N	44	22	78427
1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	0	193.61	\N	\N	193.61	\N	\N	\N	\N	44	22	78429
1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	0	193.73	\N	\N	193.73	\N	\N	\N	\N	44	22	78431
1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	0	193.65	\N	\N	193.65	\N	\N	\N	\N	44	22	78433
1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	0	193.76	\N	\N	193.76	\N	\N	\N	\N	44	22	78435
1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	0	193.69	\N	\N	193.69	\N	\N	\N	\N	44	22	78437
1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	0	193.82	\N	\N	193.82	\N	\N	\N	\N	44	22	78439
1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	0	193.67	\N	\N	193.67	\N	\N	\N	\N	44	22	78441
1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	0	193.79	\N	\N	193.79	\N	\N	\N	\N	44	22	78443
1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	0	193.82	\N	\N	193.82	\N	\N	\N	\N	44	22	78445
1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	0	193.76	\N	\N	193.76	\N	\N	\N	\N	44	22	78447
1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	0	193.78	\N	\N	193.78	\N	\N	\N	\N	44	22	78449
1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	0	193.8	\N	\N	193.8	\N	\N	\N	\N	44	22	78451
1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	0	193.62	\N	\N	193.62	\N	\N	\N	\N	44	22	78453
1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	0	192.97	\N	\N	192.97	\N	\N	\N	\N	44	22	78455
1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	0	193.12	\N	\N	193.12	\N	\N	\N	\N	44	22	78457
1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	0	193.53	\N	\N	193.53	\N	\N	\N	\N	44	22	78459
1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	0	193.69	\N	\N	193.69	\N	\N	\N	\N	44	22	78461
1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	0	193.78	\N	\N	193.78	\N	\N	\N	\N	44	22	78463
1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	44	22	78465
1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	44	22	78467
1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	44	22	78469
1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	44	22	78471
1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	0	193.88	\N	\N	193.88	\N	\N	\N	\N	44	22	78473
1949-06-14 12:00:00+00	1949-06-14 12:00:00+00	1949-06-14 12:00:00+00	0	41.85	\N	\N	41.85	\N	\N	\N	\N	56	28	95469
1950-12-08 12:00:00+00	1950-12-08 12:00:00+00	1950-12-08 12:00:00+00	0	44.24	\N	\N	44.24	\N	\N	\N	\N	56	28	95471
1957-11-12 12:00:00+00	1957-11-12 12:00:00+00	1957-11-12 12:00:00+00	0	43.4	\N	\N	43.4	\N	\N	\N	\N	56	28	95473
1958-02-03 12:00:00+00	1958-02-03 12:00:00+00	1958-02-03 12:00:00+00	0	51.15	\N	\N	51.15	\N	\N	\N	\N	56	28	95475
1958-05-13 12:00:00+00	1958-05-13 12:00:00+00	1958-05-13 12:00:00+00	0	45.73	\N	\N	45.73	\N	\N	\N	\N	56	28	95477
1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	0	44.6	\N	\N	44.6	\N	\N	\N	\N	56	28	95479
1958-11-19 12:00:00+00	1958-11-19 12:00:00+00	1958-11-19 12:00:00+00	0	41.82	\N	\N	41.82	\N	\N	\N	\N	56	28	95481
1959-05-04 12:00:00+00	1959-05-04 12:00:00+00	1959-05-04 12:00:00+00	0	40.34	\N	\N	40.34	\N	\N	\N	\N	56	28	95483
1959-09-03 12:00:00+00	1959-09-03 12:00:00+00	1959-09-03 12:00:00+00	0	40.26	\N	\N	40.26	\N	\N	\N	\N	56	28	95485
1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	0	39.28	\N	\N	39.28	\N	\N	\N	\N	56	28	95487
1960-02-10 12:00:00+00	1960-02-10 12:00:00+00	1960-02-10 12:00:00+00	0	40.38	\N	\N	40.38	\N	\N	\N	\N	56	28	95489
1960-05-10 12:00:00+00	1960-05-10 12:00:00+00	1960-05-10 12:00:00+00	0	39.55	\N	\N	39.55	\N	\N	\N	\N	56	28	95491
1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	0	40.17	\N	\N	40.17	\N	\N	\N	\N	56	28	95493
1960-11-14 12:00:00+00	1960-11-14 12:00:00+00	1960-11-14 12:00:00+00	0	40.07	\N	\N	40.07	\N	\N	\N	\N	56	28	95495
1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	0	39.25	\N	\N	39.25	\N	\N	\N	\N	56	28	95497
1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	0	39.13	\N	\N	39.13	\N	\N	\N	\N	56	28	95499
1961-08-07 12:00:00+00	1961-08-07 12:00:00+00	1961-08-07 12:00:00+00	0	40.09	\N	\N	40.09	\N	\N	\N	\N	56	28	95501
1962-02-14 12:00:00+00	1962-02-14 12:00:00+00	1962-02-14 12:00:00+00	0	39.32	\N	\N	39.32	\N	\N	\N	\N	56	28	95503
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	39.73	\N	\N	39.73	\N	\N	\N	\N	56	28	95505
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	39.73	\N	\N	39.73	\N	\N	\N	\N	56	28	95507
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	40	\N	\N	40	\N	\N	\N	\N	56	28	95509
1984-03-13 12:00:00+00	1984-03-13 12:00:00+00	1984-03-13 12:00:00+00	0	46.09	\N	\N	46.09	\N	\N	\N	\N	56	28	95511
1994-02-02 12:00:00+00	1994-02-02 12:00:00+00	1994-02-02 12:00:00+00	0	47.4	\N	\N	47.4	\N	\N	\N	\N	56	28	95513
1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	0	46	\N	\N	46	\N	\N	\N	\N	56	28	95515
2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	0	46.34	\N	\N	46.34	\N	\N	\N	\N	56	28	95517
2009-04-15 18:00:00+00	2009-04-15 18:00:00+00	2009-04-15 18:00:00+00	0	46.8	\N	\N	46.8	\N	\N	\N	\N	56	28	95519
2013-04-02 19:40:00+00	2013-04-02 19:40:00+00	2013-04-02 19:40:00+00	0	47.18	\N	\N	47.18	\N	\N	\N	\N	56	28	95521
2017-07-21 19:30:00+00	2017-07-21 19:30:00+00	2017-07-21 19:30:00+00	0	48.07	\N	\N	48.07	\N	\N	\N	\N	56	28	95523
2017-12-12 18:02:00+00	2017-12-12 18:02:00+00	2017-12-12 18:02:00+00	0	46.58	\N	\N	46.58	\N	\N	\N	\N	56	28	95525
2013-06-17 07:00:00+00	2013-06-17 07:00:00+00	2013-06-17 07:00:00+00	0	6511	\N	\N	6511	\N	\N	\N	\N	57	29	95528
2013-07-16 07:00:00+00	2013-07-16 07:00:00+00	2013-07-16 07:00:00+00	0	6511	\N	\N	6511	\N	\N	\N	\N	57	29	95530
2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	0	6511	\N	\N	6511	\N	\N	\N	\N	57	29	95532
2014-02-27 07:00:00+00	2014-02-27 07:00:00+00	2014-02-27 07:00:00+00	0	6511	\N	\N	6511	\N	\N	\N	\N	57	29	95534
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	6510	\N	\N	6510	\N	\N	\N	\N	57	29	95536
2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	0	6510	\N	\N	6510	\N	\N	\N	\N	57	29	95538
2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	0	6510	\N	\N	6510	\N	\N	\N	\N	57	29	95540
2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	0	6509	\N	\N	6509	\N	\N	\N	\N	57	29	95542
2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	0	6510	\N	\N	6510	\N	\N	\N	\N	57	29	95544
2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	0	6509	\N	\N	6509	\N	\N	\N	\N	57	29	95546
2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	0	6508	\N	\N	6508	\N	\N	\N	\N	57	29	95548
2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	0	6508	\N	\N	6508	\N	\N	\N	\N	57	29	95550
2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	0	6507	\N	\N	6507	\N	\N	\N	\N	57	29	95552
2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	0	6507	\N	\N	6507	\N	\N	\N	\N	57	29	95554
2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	0	6507	\N	\N	6507	\N	\N	\N	\N	57	29	95556
2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	0	6507	\N	\N	6507	\N	\N	\N	\N	57	29	95558
2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	0	6506	\N	\N	6506	\N	\N	\N	\N	57	29	95560
2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	0	6506	\N	\N	6506	\N	\N	\N	\N	57	29	95562
2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	0	6506	\N	\N	6506	\N	\N	\N	\N	57	29	95564
2020-05-29 07:00:00+00	2020-05-29 07:00:00+00	2020-05-29 07:00:00+00	0	6506	\N	\N	6506	\N	\N	\N	\N	57	29	95566
2013-06-17 07:00:00+00	2013-06-17 07:00:00+00	2013-06-17 07:00:00+00	0	121	\N	\N	121	\N	\N	\N	\N	58	29	95527
2013-07-16 07:00:00+00	2013-07-16 07:00:00+00	2013-07-16 07:00:00+00	0	120.86	\N	\N	120.86	\N	\N	\N	\N	58	29	95529
2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	0	120.93	\N	\N	120.93	\N	\N	\N	\N	58	29	95531
2014-02-27 07:00:00+00	2014-02-27 07:00:00+00	2014-02-27 07:00:00+00	0	121.43	\N	\N	121.43	\N	\N	\N	\N	58	29	95533
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	121.56	\N	\N	121.56	\N	\N	\N	\N	58	29	95535
2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	0	121.7	\N	\N	121.7	\N	\N	\N	\N	58	29	95537
2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	0	122.14	\N	\N	122.14	\N	\N	\N	\N	58	29	95539
2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	0	123.22	\N	\N	123.22	\N	\N	\N	\N	58	29	95541
2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	0	122.16	\N	\N	122.16	\N	\N	\N	\N	58	29	95543
2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	0	123.1	\N	\N	123.1	\N	\N	\N	\N	58	29	95545
2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	0	123.51	\N	\N	123.51	\N	\N	\N	\N	58	29	95547
2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	0	123.74	\N	\N	123.74	\N	\N	\N	\N	58	29	95549
2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	0	124.58	\N	\N	124.58	\N	\N	\N	\N	58	29	95551
2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	0	125.02	\N	\N	125.02	\N	\N	\N	\N	58	29	95553
2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	0	125.34	\N	\N	125.34	\N	\N	\N	\N	58	29	95555
2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	0	125.42	\N	\N	125.42	\N	\N	\N	\N	58	29	95557
2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	0	125.86	\N	\N	125.86	\N	\N	\N	\N	58	29	95559
2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	2019-05-29 07:00:00+00	0	125.7	\N	\N	125.7	\N	\N	\N	\N	58	29	95561
2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	0	125.6	\N	\N	125.6	\N	\N	\N	\N	58	29	95563
2020-05-29 07:00:00+00	2020-05-29 07:00:00+00	2020-05-29 07:00:00+00	0	126.44	\N	\N	126.44	\N	\N	\N	\N	58	29	95565
1963-08-27 12:00:00+00	1963-08-27 12:00:00+00	1963-08-27 12:00:00+00	0	67.32	\N	\N	67.32	\N	\N	\N	\N	60	30	95567
1964-03-24 12:00:00+00	1964-03-24 12:00:00+00	1964-03-24 12:00:00+00	0	67.14	\N	\N	67.14	\N	\N	\N	\N	60	30	95569
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	68.79	\N	\N	68.79	\N	\N	\N	\N	60	30	95571
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	67.49	\N	\N	67.49	\N	\N	\N	\N	60	30	95573
1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	0	68.09	\N	\N	68.09	\N	\N	\N	\N	60	30	95575
1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	0	64.9	\N	\N	64.9	\N	\N	\N	\N	60	30	95577
1966-08-22 12:00:00+00	1966-08-22 12:00:00+00	1966-08-22 12:00:00+00	0	60.43	\N	\N	60.43	\N	\N	\N	\N	60	30	95579
1967-02-20 12:00:00+00	1967-02-20 12:00:00+00	1967-02-20 12:00:00+00	0	61.03	\N	\N	61.03	\N	\N	\N	\N	60	30	95581
1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	0	51.6	\N	\N	51.6	\N	\N	\N	\N	60	30	95583
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	55.72	\N	\N	55.72	\N	\N	\N	\N	60	30	95585
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	55.89	\N	\N	55.89	\N	\N	\N	\N	60	30	95587
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	56.49	\N	\N	56.49	\N	\N	\N	\N	60	30	95589
1972-01-20 12:00:00+00	1972-01-20 12:00:00+00	1972-01-20 12:00:00+00	0	58.93	\N	\N	58.93	\N	\N	\N	\N	60	30	95591
1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	0	55.87	\N	\N	55.87	\N	\N	\N	\N	60	30	95593
1973-05-24 12:00:00+00	1973-05-24 12:00:00+00	1973-05-24 12:00:00+00	0	57.2	\N	\N	57.2	\N	\N	\N	\N	60	30	95595
1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	0	59.9	\N	\N	59.9	\N	\N	\N	\N	60	30	95597
1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	0	64.15	\N	\N	64.15	\N	\N	\N	\N	60	30	95599
1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	0	63.24	\N	\N	63.24	\N	\N	\N	\N	60	30	95601
1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	0	62.64	\N	\N	62.64	\N	\N	\N	\N	60	30	95603
1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	0	62.13	\N	\N	62.13	\N	\N	\N	\N	60	30	95605
1979-02-28 12:00:00+00	1979-02-28 12:00:00+00	1979-02-28 12:00:00+00	0	62.96	\N	\N	62.96	\N	\N	\N	\N	60	30	95607
1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	0	65.04	\N	\N	65.04	\N	\N	\N	\N	60	30	95609
1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	0	66.83	\N	\N	66.83	\N	\N	\N	\N	60	30	95611
1994-02-01 12:00:00+00	1994-02-01 12:00:00+00	1994-02-01 12:00:00+00	0	66.25	\N	\N	66.25	\N	\N	\N	\N	60	30	95613
1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	0	68.95	\N	\N	68.95	\N	\N	\N	\N	60	30	95615
2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	0	71.5	\N	\N	71.5	\N	\N	\N	\N	60	30	95617
2009-03-27 12:00:00+00	2009-03-27 12:00:00+00	2009-03-27 12:00:00+00	0	77.52	\N	\N	77.52	\N	\N	\N	\N	60	30	95619
2013-04-01 20:30:00+00	2013-04-01 20:30:00+00	2013-04-01 20:30:00+00	0	72.78	\N	\N	72.78	\N	\N	\N	\N	60	30	95621
2016-03-14 22:30:00+00	2016-03-14 22:30:00+00	2016-03-14 22:30:00+00	0	72.84	\N	\N	72.84	\N	\N	\N	\N	60	30	95623
2016-08-08 22:40:00+00	2016-08-08 22:40:00+00	2016-08-08 22:40:00+00	0	73.62	\N	\N	73.62	\N	\N	\N	\N	60	30	95625
2016-09-23 19:51:00+00	2016-09-23 19:51:00+00	2016-09-23 19:51:00+00	0	72.87	\N	\N	72.87	\N	\N	\N	\N	60	30	95627
2017-04-17 20:10:00+00	2017-04-17 20:10:00+00	2017-04-17 20:10:00+00	0	72.86	\N	\N	72.86	\N	\N	\N	\N	60	30	95629
2017-06-16 19:01:00+00	2017-06-16 19:01:00+00	2017-06-16 19:01:00+00	0	72.92	\N	\N	72.92	\N	\N	\N	\N	60	30	95631
2017-09-28 18:40:00+00	2017-09-28 18:40:00+00	2017-09-28 18:40:00+00	0	72.99	\N	\N	72.99	\N	\N	\N	\N	60	30	95633
2017-12-11 22:30:00+00	2017-12-11 22:30:00+00	2017-12-11 22:30:00+00	0	73.01	\N	\N	73.01	\N	\N	\N	\N	60	30	95635
2018-04-25 17:00:00+00	2018-04-25 17:00:00+00	2018-04-25 17:00:00+00	0	73.02	\N	\N	73.02	\N	\N	\N	\N	60	30	95637
2020-01-06 17:09:00+00	2020-01-06 17:09:00+00	2020-01-06 17:09:00+00	0	73.19	\N	\N	73.19	\N	\N	\N	\N	60	30	95639
2013-06-06 07:00:00+00	2013-06-06 07:00:00+00	2013-06-06 07:00:00+00	0	140.77	\N	\N	140.77	\N	\N	\N	\N	62	31	95641
2013-06-13 07:00:00+00	2013-06-13 07:00:00+00	2013-06-13 07:00:00+00	0	138.37	\N	\N	138.37	\N	\N	\N	\N	62	31	95643
2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	2013-09-26 07:00:00+00	0	127.5	\N	\N	127.5	\N	\N	\N	\N	62	31	95645
2014-02-18 07:00:00+00	2014-02-18 07:00:00+00	2014-02-18 07:00:00+00	0	117.27	\N	\N	117.27	\N	\N	\N	\N	62	31	95647
2014-03-12 07:00:00+00	2014-03-12 07:00:00+00	2014-03-12 07:00:00+00	0	115.45	\N	\N	115.45	\N	\N	\N	\N	62	31	95649
2014-04-01 07:00:00+00	2014-04-01 07:00:00+00	2014-04-01 07:00:00+00	0	114.98	\N	\N	114.98	\N	\N	\N	\N	62	31	95651
2014-04-28 07:00:00+00	2014-04-28 07:00:00+00	2014-04-28 07:00:00+00	0	112.93	\N	\N	112.93	\N	\N	\N	\N	62	31	95653
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	111.64	\N	\N	111.64	\N	\N	\N	\N	62	31	95655
2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	2014-06-30 07:00:00+00	0	111.81	\N	\N	111.81	\N	\N	\N	\N	62	31	95657
2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	2014-10-02 07:00:00+00	0	111.63	\N	\N	111.63	\N	\N	\N	\N	62	31	95659
2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	2014-12-01 07:00:00+00	0	109.7	\N	\N	109.7	\N	\N	\N	\N	62	31	95661
2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	2015-05-15 07:00:00+00	0	107.04	\N	\N	107.04	\N	\N	\N	\N	62	31	95663
2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	2015-11-24 07:00:00+00	0	103.53	\N	\N	103.53	\N	\N	\N	\N	62	31	95665
2015-12-02 07:00:00+00	2015-12-02 07:00:00+00	2015-12-02 07:00:00+00	0	103.34	\N	\N	103.34	\N	\N	\N	\N	62	31	95667
2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	2016-05-03 07:00:00+00	0	106.05	\N	\N	106.05	\N	\N	\N	\N	62	31	95669
2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	2016-11-16 07:00:00+00	0	106.78	\N	\N	106.78	\N	\N	\N	\N	62	31	95671
2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	2017-05-09 07:00:00+00	0	104.14	\N	\N	104.14	\N	\N	\N	\N	62	31	95673
2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	2017-11-17 07:00:00+00	0	108.4	\N	\N	108.4	\N	\N	\N	\N	62	31	95675
2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	2018-05-03 07:00:00+00	0	113.12	\N	\N	113.12	\N	\N	\N	\N	62	31	95677
2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	2018-11-27 07:00:00+00	0	120	\N	\N	120	\N	\N	\N	\N	62	31	95679
2018-12-07 07:00:00+00	2018-12-07 07:00:00+00	2018-12-07 07:00:00+00	0	119.36	\N	\N	119.36	\N	\N	\N	\N	62	31	95681
2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	2019-05-15 07:00:00+00	0	120.82	\N	\N	120.82	\N	\N	\N	\N	62	31	95683
2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	2019-11-26 07:00:00+00	0	123.73	\N	\N	123.73	\N	\N	\N	\N	62	31	95685
2020-03-10 07:00:00+00	2020-03-10 07:00:00+00	2020-03-10 07:00:00+00	0	124.82	\N	\N	124.82	\N	\N	\N	\N	62	31	95687
1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157888
1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157890
1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157892
1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157894
1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157896
1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157898
1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157900
1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157902
1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157904
1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157906
1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157908
1998-03-31 00:00:00+00	1998-03-31 00:00:00+00	1998-03-31 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157910
1998-04-01 00:00:00+00	1998-04-01 00:00:00+00	1998-04-01 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157912
1998-04-02 00:00:00+00	1998-04-02 00:00:00+00	1998-04-02 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157914
1998-04-03 00:00:00+00	1998-04-03 00:00:00+00	1998-04-03 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157916
1998-04-04 00:00:00+00	1998-04-04 00:00:00+00	1998-04-04 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157918
1998-04-05 00:00:00+00	1998-04-05 00:00:00+00	1998-04-05 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157920
1998-04-06 00:00:00+00	1998-04-06 00:00:00+00	1998-04-06 00:00:00+00	0	4914	\N	\N	4914	\N	\N	\N	\N	75	38	157922
1998-04-07 00:00:00+00	1998-04-07 00:00:00+00	1998-04-07 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157924
1998-04-08 00:00:00+00	1998-04-08 00:00:00+00	1998-04-08 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157926
1998-04-09 00:00:00+00	1998-04-09 00:00:00+00	1998-04-09 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157928
1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157930
1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157932
1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157934
1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157936
1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157938
1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157940
1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157942
1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157944
1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157946
1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157948
1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	157950
1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	157952
1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157954
1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157956
1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157958
1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157960
1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157962
1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157964
1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157966
1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157968
1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	0	4913	\N	\N	4913	\N	\N	\N	\N	75	38	157970
1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157972
1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157974
1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	157976
1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	157978
1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157980
1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157982
1998-05-07 00:00:00+00	1998-05-07 00:00:00+00	1998-05-07 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157984
1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157986
1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157988
1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157990
1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157992
1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157994
1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	157996
1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	157998
1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	158000
1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158002
1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158004
1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158006
1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158008
1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158010
1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158012
1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	0	4912	\N	\N	4912	\N	\N	\N	\N	75	38	158014
1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158016
1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158018
1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158020
1998-05-26 00:00:00+00	1998-05-26 00:00:00+00	1998-05-26 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158022
1998-05-27 00:00:00+00	1998-05-27 00:00:00+00	1998-05-27 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158024
1998-05-28 00:00:00+00	1998-05-28 00:00:00+00	1998-05-28 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158026
1998-05-29 00:00:00+00	1998-05-29 00:00:00+00	1998-05-29 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158028
1998-05-30 00:00:00+00	1998-05-30 00:00:00+00	1998-05-30 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158030
1998-05-31 00:00:00+00	1998-05-31 00:00:00+00	1998-05-31 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158032
1998-06-01 00:00:00+00	1998-06-01 00:00:00+00	1998-06-01 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158034
1998-06-02 00:00:00+00	1998-06-02 00:00:00+00	1998-06-02 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158036
1998-06-03 00:00:00+00	1998-06-03 00:00:00+00	1998-06-03 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158038
1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158040
1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158042
1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158044
1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158046
1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158048
1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158050
1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158052
1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158054
1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	0	4911	\N	\N	4911	\N	\N	\N	\N	75	38	158056
1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158058
1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158060
1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158062
1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158064
1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158066
1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158068
1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158070
1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158072
1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158074
1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	0	4910	\N	\N	4910	\N	\N	\N	\N	75	38	158076
1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158078
1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158080
1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158082
1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158084
1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	0	4909	\N	\N	4909	\N	\N	\N	\N	75	38	158086
1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	0	539.26	\N	\N	539.26	\N	\N	\N	\N	76	38	157887
1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	0	539.93	\N	\N	539.93	\N	\N	\N	\N	76	38	157889
1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	0	539.66	\N	\N	539.66	\N	\N	\N	\N	76	38	157891
1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	0	540.35	\N	\N	540.35	\N	\N	\N	\N	76	38	157893
1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	0	540.4	\N	\N	540.4	\N	\N	\N	\N	76	38	157895
1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	0	540.13	\N	\N	540.13	\N	\N	\N	\N	76	38	157897
1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	0	540.26	\N	\N	540.26	\N	\N	\N	\N	76	38	157899
1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	0	539.87	\N	\N	539.87	\N	\N	\N	\N	76	38	157901
1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	0	539.6	\N	\N	539.6	\N	\N	\N	\N	76	38	157903
1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	0	539.47	\N	\N	539.47	\N	\N	\N	\N	76	38	157905
1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	0	539.59	\N	\N	539.59	\N	\N	\N	\N	76	38	157907
1998-03-31 00:00:00+00	1998-03-31 00:00:00+00	1998-03-31 00:00:00+00	0	539.34	\N	\N	539.34	\N	\N	\N	\N	76	38	157909
1998-04-01 00:00:00+00	1998-04-01 00:00:00+00	1998-04-01 00:00:00+00	0	539.38	\N	\N	539.38	\N	\N	\N	\N	76	38	157911
1998-04-02 00:00:00+00	1998-04-02 00:00:00+00	1998-04-02 00:00:00+00	0	539.44	\N	\N	539.44	\N	\N	\N	\N	76	38	157913
1998-04-03 00:00:00+00	1998-04-03 00:00:00+00	1998-04-03 00:00:00+00	0	539.61	\N	\N	539.61	\N	\N	\N	\N	76	38	157915
1998-04-04 00:00:00+00	1998-04-04 00:00:00+00	1998-04-04 00:00:00+00	0	539.56	\N	\N	539.56	\N	\N	\N	\N	76	38	157917
1998-04-05 00:00:00+00	1998-04-05 00:00:00+00	1998-04-05 00:00:00+00	0	539.55	\N	\N	539.55	\N	\N	\N	\N	76	38	157919
1998-04-06 00:00:00+00	1998-04-06 00:00:00+00	1998-04-06 00:00:00+00	0	539.43	\N	\N	539.43	\N	\N	\N	\N	76	38	157921
1998-04-07 00:00:00+00	1998-04-07 00:00:00+00	1998-04-07 00:00:00+00	0	539.87	\N	\N	539.87	\N	\N	\N	\N	76	38	157923
1998-04-08 00:00:00+00	1998-04-08 00:00:00+00	1998-04-08 00:00:00+00	0	540.34	\N	\N	540.34	\N	\N	\N	\N	76	38	157925
1998-04-09 00:00:00+00	1998-04-09 00:00:00+00	1998-04-09 00:00:00+00	0	540.44	\N	\N	540.44	\N	\N	\N	\N	76	38	157927
1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	0	540.84	\N	\N	540.84	\N	\N	\N	\N	76	38	157929
1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	0	540.82	\N	\N	540.82	\N	\N	\N	\N	76	38	157931
1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	0	541.13	\N	\N	541.13	\N	\N	\N	\N	76	38	157933
1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	0	541.46	\N	\N	541.46	\N	\N	\N	\N	76	38	157935
1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	0	540.85	\N	\N	540.85	\N	\N	\N	\N	76	38	157937
1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	0	540.75	\N	\N	540.75	\N	\N	\N	\N	76	38	157939
1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	0	540.72	\N	\N	540.72	\N	\N	\N	\N	76	38	157941
1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	0	540.82	\N	\N	540.82	\N	\N	\N	\N	76	38	157943
1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	0	541.11	\N	\N	541.11	\N	\N	\N	\N	76	38	157945
1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	0	541.3	\N	\N	541.3	\N	\N	\N	\N	76	38	157947
1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	0	541.56	\N	\N	541.56	\N	\N	\N	\N	76	38	157949
1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	0	541.51	\N	\N	541.51	\N	\N	\N	\N	76	38	157951
1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	0	541.34	\N	\N	541.34	\N	\N	\N	\N	76	38	157953
1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	0	541.19	\N	\N	541.19	\N	\N	\N	\N	76	38	157955
1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	0	540.96	\N	\N	540.96	\N	\N	\N	\N	76	38	157957
1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	0	540.77	\N	\N	540.77	\N	\N	\N	\N	76	38	157959
1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	0	540.61	\N	\N	540.61	\N	\N	\N	\N	76	38	157961
1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	0	540.47	\N	\N	540.47	\N	\N	\N	\N	76	38	157963
1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	0	540.58	\N	\N	540.58	\N	\N	\N	\N	76	38	157965
1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	0	540.49	\N	\N	540.49	\N	\N	\N	\N	76	38	157967
1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	0	540.5	\N	\N	540.5	\N	\N	\N	\N	76	38	157969
1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	0	540.55	\N	\N	540.55	\N	\N	\N	\N	76	38	157971
1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	0	541.28	\N	\N	541.28	\N	\N	\N	\N	76	38	157973
1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	0	541.69	\N	\N	541.69	\N	\N	\N	\N	76	38	157975
1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	0	541.81	\N	\N	541.81	\N	\N	\N	\N	76	38	157977
1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	0	541.43	\N	\N	541.43	\N	\N	\N	\N	76	38	157979
1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	0	541.37	\N	\N	541.37	\N	\N	\N	\N	76	38	157981
1998-05-07 00:00:00+00	1998-05-07 00:00:00+00	1998-05-07 00:00:00+00	0	541.34	\N	\N	541.34	\N	\N	\N	\N	76	38	157983
1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	0	541.3	\N	\N	541.3	\N	\N	\N	\N	76	38	157985
1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	0	541.22	\N	\N	541.22	\N	\N	\N	\N	76	38	157987
1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	0	541.33	\N	\N	541.33	\N	\N	\N	\N	76	38	157989
1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	0	541.4	\N	\N	541.4	\N	\N	\N	\N	76	38	157991
1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	0	541.38	\N	\N	541.38	\N	\N	\N	\N	76	38	157993
1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	0	541.2	\N	\N	541.2	\N	\N	\N	\N	76	38	157995
1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	0	541.57	\N	\N	541.57	\N	\N	\N	\N	76	38	157997
1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	0	541.45	\N	\N	541.45	\N	\N	\N	\N	76	38	157999
1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	0	541.75	\N	\N	541.75	\N	\N	\N	\N	76	38	158001
1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	0	541.83	\N	\N	541.83	\N	\N	\N	\N	76	38	158003
1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	0	541.81	\N	\N	541.81	\N	\N	\N	\N	76	38	158005
1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	0	542.21	\N	\N	542.21	\N	\N	\N	\N	76	38	158007
1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	0	542.27	\N	\N	542.27	\N	\N	\N	\N	76	38	158009
1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	0	541.79	\N	\N	541.79	\N	\N	\N	\N	76	38	158011
1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	0	541.27	\N	\N	541.27	\N	\N	\N	\N	76	38	158013
1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	0	541.98	\N	\N	541.98	\N	\N	\N	\N	76	38	158015
1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	0	541.91	\N	\N	541.91	\N	\N	\N	\N	76	38	158017
1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	0	541.94	\N	\N	541.94	\N	\N	\N	\N	76	38	158019
1998-05-26 00:00:00+00	1998-05-26 00:00:00+00	1998-05-26 00:00:00+00	0	542.12	\N	\N	542.12	\N	\N	\N	\N	76	38	158021
1998-05-27 00:00:00+00	1998-05-27 00:00:00+00	1998-05-27 00:00:00+00	0	542.32	\N	\N	542.32	\N	\N	\N	\N	76	38	158023
1998-05-28 00:00:00+00	1998-05-28 00:00:00+00	1998-05-28 00:00:00+00	0	542.3	\N	\N	542.3	\N	\N	\N	\N	76	38	158025
1998-05-29 00:00:00+00	1998-05-29 00:00:00+00	1998-05-29 00:00:00+00	0	542.48	\N	\N	542.48	\N	\N	\N	\N	76	38	158027
1998-05-30 00:00:00+00	1998-05-30 00:00:00+00	1998-05-30 00:00:00+00	0	542.45	\N	\N	542.45	\N	\N	\N	\N	76	38	158029
1998-05-31 00:00:00+00	1998-05-31 00:00:00+00	1998-05-31 00:00:00+00	0	542.88	\N	\N	542.88	\N	\N	\N	\N	76	38	158031
1998-06-01 00:00:00+00	1998-06-01 00:00:00+00	1998-06-01 00:00:00+00	0	542.88	\N	\N	542.88	\N	\N	\N	\N	76	38	158033
1998-06-02 00:00:00+00	1998-06-02 00:00:00+00	1998-06-02 00:00:00+00	0	542.75	\N	\N	542.75	\N	\N	\N	\N	76	38	158035
1998-06-03 00:00:00+00	1998-06-03 00:00:00+00	1998-06-03 00:00:00+00	0	542.73	\N	\N	542.73	\N	\N	\N	\N	76	38	158037
1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	0	542.71	\N	\N	542.71	\N	\N	\N	\N	76	38	158039
1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	0	542.66	\N	\N	542.66	\N	\N	\N	\N	76	38	158041
1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	0	543.22	\N	\N	543.22	\N	\N	\N	\N	76	38	158043
1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	0	543.21	\N	\N	543.21	\N	\N	\N	\N	76	38	158045
1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	0	542.99	\N	\N	542.99	\N	\N	\N	\N	76	38	158047
1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	0	542.83	\N	\N	542.83	\N	\N	\N	\N	76	38	158049
1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	0	542.69	\N	\N	542.69	\N	\N	\N	\N	76	38	158051
1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	0	542.47	\N	\N	542.47	\N	\N	\N	\N	76	38	158053
1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	0	542.21	\N	\N	542.21	\N	\N	\N	\N	76	38	158055
1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	0	543.16	\N	\N	543.16	\N	\N	\N	\N	76	38	158057
1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	0	543.36	\N	\N	543.36	\N	\N	\N	\N	76	38	158059
1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	0	543.31	\N	\N	543.31	\N	\N	\N	\N	76	38	158061
1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	0	542.96	\N	\N	542.96	\N	\N	\N	\N	76	38	158063
1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	0	542.91	\N	\N	542.91	\N	\N	\N	\N	76	38	158065
1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	0	543.12	\N	\N	543.12	\N	\N	\N	\N	76	38	158067
1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	0	543.13	\N	\N	543.13	\N	\N	\N	\N	76	38	158069
1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	0	543.35	\N	\N	543.35	\N	\N	\N	\N	76	38	158071
1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	0	543.72	\N	\N	543.72	\N	\N	\N	\N	76	38	158073
1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	0	543.4	\N	\N	543.4	\N	\N	\N	\N	76	38	158075
1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	0	543.52	\N	\N	543.52	\N	\N	\N	\N	76	38	158077
1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	0	543.51	\N	\N	543.51	\N	\N	\N	\N	76	38	158079
1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	0	543.55	\N	\N	543.55	\N	\N	\N	\N	76	38	158081
1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	0	543.71	\N	\N	543.71	\N	\N	\N	\N	76	38	158083
1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	0	544.17	\N	\N	544.17	\N	\N	\N	\N	76	38	158085
1974-06-25 12:00:00+00	1974-06-25 12:00:00+00	1974-06-25 12:00:00+00	0	416.3	\N	\N	416.3	\N	\N	\N	\N	82	41	172789
1983-03-02 12:00:00+00	1983-03-02 12:00:00+00	1983-03-02 12:00:00+00	0	288.58	\N	\N	288.58	\N	\N	\N	\N	82	41	172791
1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	0	409.17	\N	\N	409.17	\N	\N	\N	\N	82	41	172793
1986-03-24 12:00:00+00	1986-03-24 12:00:00+00	1986-03-24 12:00:00+00	0	409.9	\N	\N	409.9	\N	\N	\N	\N	82	41	172795
1987-02-11 12:00:00+00	1987-02-11 12:00:00+00	1987-02-11 12:00:00+00	0	408.41	\N	\N	408.41	\N	\N	\N	\N	82	41	172797
1988-02-10 12:00:00+00	1988-02-10 12:00:00+00	1988-02-10 12:00:00+00	0	409.1	\N	\N	409.1	\N	\N	\N	\N	82	41	172799
1989-02-27 12:00:00+00	1989-02-27 12:00:00+00	1989-02-27 12:00:00+00	0	408.85	\N	\N	408.85	\N	\N	\N	\N	82	41	172801
1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	0	409.05	\N	\N	409.05	\N	\N	\N	\N	82	41	172803
1991-02-15 12:00:00+00	1991-02-15 12:00:00+00	1991-02-15 12:00:00+00	0	409.24	\N	\N	409.24	\N	\N	\N	\N	82	41	172805
1992-02-03 12:00:00+00	1992-02-03 12:00:00+00	1992-02-03 12:00:00+00	0	409	\N	\N	409	\N	\N	\N	\N	82	41	172807
1993-02-11 12:00:00+00	1993-02-11 12:00:00+00	1993-02-11 12:00:00+00	0	409.23	\N	\N	409.23	\N	\N	\N	\N	82	41	172809
1994-02-07 12:00:00+00	1994-02-07 12:00:00+00	1994-02-07 12:00:00+00	0	409.19	\N	\N	409.19	\N	\N	\N	\N	82	41	172811
1995-02-07 12:00:00+00	1995-02-07 12:00:00+00	1995-02-07 12:00:00+00	0	409.18	\N	\N	409.18	\N	\N	\N	\N	82	41	172813
1996-02-05 12:00:00+00	1996-02-05 12:00:00+00	1996-02-05 12:00:00+00	0	409.48	\N	\N	409.48	\N	\N	\N	\N	82	41	172815
1997-02-17 12:00:00+00	1997-02-17 12:00:00+00	1997-02-17 12:00:00+00	0	409.35	\N	\N	409.35	\N	\N	\N	\N	82	41	172817
1998-02-11 12:00:00+00	1998-02-11 12:00:00+00	1998-02-11 12:00:00+00	0	409.49	\N	\N	409.49	\N	\N	\N	\N	82	41	172819
1999-01-27 18:15:00+00	1999-01-27 18:15:00+00	1999-01-27 18:15:00+00	0	409.14	\N	\N	409.14	\N	\N	\N	\N	82	41	172821
2000-02-14 17:30:00+00	2000-02-14 17:30:00+00	2000-02-14 17:30:00+00	0	409.2	\N	\N	409.2	\N	\N	\N	\N	82	41	172823
2001-02-20 12:00:00+00	2001-02-20 12:00:00+00	2001-02-20 12:00:00+00	0	408.99	\N	\N	408.99	\N	\N	\N	\N	82	41	172825
2002-02-11 12:00:00+00	2002-02-11 12:00:00+00	2002-02-11 12:00:00+00	0	409.8	\N	\N	409.8	\N	\N	\N	\N	82	41	172827
2003-02-12 12:00:00+00	2003-02-12 12:00:00+00	2003-02-12 12:00:00+00	0	409.31	\N	\N	409.31	\N	\N	\N	\N	82	41	172829
2004-02-16 12:00:00+00	2004-02-16 12:00:00+00	2004-02-16 12:00:00+00	0	409.56	\N	\N	409.56	\N	\N	\N	\N	82	41	172831
2005-03-24 21:25:00+00	2005-03-24 21:25:00+00	2005-03-24 21:25:00+00	0	409.06	\N	\N	409.06	\N	\N	\N	\N	82	41	172833
2006-03-28 19:34:00+00	2006-03-28 19:34:00+00	2006-03-28 19:34:00+00	0	409.29	\N	\N	409.29	\N	\N	\N	\N	82	41	172835
2007-03-20 20:56:00+00	2007-03-20 20:56:00+00	2007-03-20 20:56:00+00	0	409.21	\N	\N	409.21	\N	\N	\N	\N	82	41	172837
2009-02-25 20:36:00+00	2009-02-25 20:36:00+00	2009-02-25 20:36:00+00	0	409.47	\N	\N	409.47	\N	\N	\N	\N	82	41	172839
2010-02-05 00:00:00+00	2010-02-05 00:00:00+00	2010-02-05 00:00:00+00	0	409.12	\N	\N	409.12	\N	\N	\N	\N	82	41	172841
2011-03-16 18:04:00+00	2011-03-16 18:04:00+00	2011-03-16 18:04:00+00	0	409.31	\N	\N	409.31	\N	\N	\N	\N	82	41	172843
2012-03-21 19:32:00+00	2012-03-21 19:32:00+00	2012-03-21 19:32:00+00	0	408.97	\N	\N	408.97	\N	\N	\N	\N	82	41	172845
2013-01-22 20:03:00+00	2013-01-22 20:03:00+00	2013-01-22 20:03:00+00	0	410.24	\N	\N	410.24	\N	\N	\N	\N	82	41	172847
2015-03-03 23:37:00+00	2015-03-03 23:37:00+00	2015-03-03 23:37:00+00	0	409.1	\N	\N	409.1	\N	\N	\N	\N	82	41	172849
2019-02-01 18:40:00+00	2019-02-01 18:40:00+00	2019-02-01 18:40:00+00	0	410.2	\N	\N	410.2	\N	\N	\N	\N	82	41	172851
1982-01-22 12:00:00+00	1982-01-22 12:00:00+00	1982-01-22 12:00:00+00	0	4276	\N	\N	4276	\N	\N	\N	\N	83	42	172854
1984-01-23 12:00:00+00	1984-01-23 12:00:00+00	1984-01-23 12:00:00+00	0	4288	\N	\N	4288	\N	\N	\N	\N	83	42	172856
1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	0	4246	\N	\N	4246	\N	\N	\N	\N	83	42	172858
1986-03-20 12:00:00+00	1986-03-20 12:00:00+00	1986-03-20 12:00:00+00	0	4243	\N	\N	4243	\N	\N	\N	\N	83	42	172860
1987-02-09 12:00:00+00	1987-02-09 12:00:00+00	1987-02-09 12:00:00+00	0	4248	\N	\N	4248	\N	\N	\N	\N	83	42	172862
1988-02-08 12:00:00+00	1988-02-08 12:00:00+00	1988-02-08 12:00:00+00	0	4248	\N	\N	4248	\N	\N	\N	\N	83	42	172864
1989-02-13 12:00:00+00	1989-02-13 12:00:00+00	1989-02-13 12:00:00+00	0	4243	\N	\N	4243	\N	\N	\N	\N	83	42	172866
1991-02-14 12:00:00+00	1991-02-14 12:00:00+00	1991-02-14 12:00:00+00	0	4256	\N	\N	4256	\N	\N	\N	\N	83	42	172868
1992-01-23 12:00:00+00	1992-01-23 12:00:00+00	1992-01-23 12:00:00+00	0	4258	\N	\N	4258	\N	\N	\N	\N	83	42	172870
1993-02-08 12:00:00+00	1993-02-08 12:00:00+00	1993-02-08 12:00:00+00	0	4262	\N	\N	4262	\N	\N	\N	\N	83	42	172872
1994-02-15 12:00:00+00	1994-02-15 12:00:00+00	1994-02-15 12:00:00+00	0	4265	\N	\N	4265	\N	\N	\N	\N	83	42	172874
1995-02-10 12:00:00+00	1995-02-10 12:00:00+00	1995-02-10 12:00:00+00	0	4267	\N	\N	4267	\N	\N	\N	\N	83	42	172876
1996-02-12 12:00:00+00	1996-02-12 12:00:00+00	1996-02-12 12:00:00+00	0	4269	\N	\N	4269	\N	\N	\N	\N	83	42	172878
1997-02-12 12:00:00+00	1997-02-12 12:00:00+00	1997-02-12 12:00:00+00	0	4272	\N	\N	4272	\N	\N	\N	\N	83	42	172880
1998-03-17 12:00:00+00	1998-03-17 12:00:00+00	1998-03-17 12:00:00+00	0	4274	\N	\N	4274	\N	\N	\N	\N	83	42	172882
1999-01-26 12:00:00+00	1999-01-26 12:00:00+00	1999-01-26 12:00:00+00	0	4275	\N	\N	4275	\N	\N	\N	\N	83	42	172884
2000-03-07 22:20:00+00	2000-03-07 22:20:00+00	2000-03-07 22:20:00+00	0	4278	\N	\N	4278	\N	\N	\N	\N	83	42	172886
2001-03-06 18:45:00+00	2001-03-06 18:45:00+00	2001-03-06 18:45:00+00	0	4279	\N	\N	4279	\N	\N	\N	\N	83	42	172888
2002-02-27 16:30:00+00	2002-02-27 16:30:00+00	2002-02-27 16:30:00+00	0	4280	\N	\N	4280	\N	\N	\N	\N	83	42	172890
2003-03-06 16:40:00+00	2003-03-06 16:40:00+00	2003-03-06 16:40:00+00	0	4277	\N	\N	4277	\N	\N	\N	\N	83	42	172892
2004-03-02 20:15:00+00	2004-03-02 20:15:00+00	2004-03-02 20:15:00+00	0	4272	\N	\N	4272	\N	\N	\N	\N	83	42	172894
2005-03-01 21:30:00+00	2005-03-01 21:30:00+00	2005-03-01 21:30:00+00	0	4270	\N	\N	4270	\N	\N	\N	\N	83	42	172896
2006-03-17 21:58:00+00	2006-03-17 21:58:00+00	2006-03-17 21:58:00+00	0	4267	\N	\N	4267	\N	\N	\N	\N	83	42	172898
2007-03-16 17:42:00+00	2007-03-16 17:42:00+00	2007-03-16 17:42:00+00	0	4270	\N	\N	4270	\N	\N	\N	\N	83	42	172900
2008-03-07 19:28:00+00	2008-03-07 19:28:00+00	2008-03-07 19:28:00+00	0	4273	\N	\N	4273	\N	\N	\N	\N	83	42	172902
2009-02-23 23:44:00+00	2009-02-23 23:44:00+00	2009-02-23 23:44:00+00	0	4273	\N	\N	4273	\N	\N	\N	\N	83	42	172904
2010-03-08 21:25:00+00	2010-03-08 21:25:00+00	2010-03-08 21:25:00+00	0	4275	\N	\N	4275	\N	\N	\N	\N	83	42	172906
2011-03-03 21:42:00+00	2011-03-03 21:42:00+00	2011-03-03 21:42:00+00	0	4277	\N	\N	4277	\N	\N	\N	\N	83	42	172908
2012-03-16 18:13:00+00	2012-03-16 18:13:00+00	2012-03-16 18:13:00+00	0	4278	\N	\N	4278	\N	\N	\N	\N	83	42	172910
2013-01-22 00:02:00+00	2013-01-22 00:02:00+00	2013-01-22 00:02:00+00	0	4279	\N	\N	4279	\N	\N	\N	\N	83	42	172912
2014-01-14 20:50:00+00	2014-01-14 20:50:00+00	2014-01-14 20:50:00+00	0	4305	\N	\N	4305	\N	\N	\N	\N	83	42	172914
2015-02-25 23:20:00+00	2015-02-25 23:20:00+00	2015-02-25 23:20:00+00	0	4281	\N	\N	4281	\N	\N	\N	\N	83	42	172916
2016-03-17 18:01:00+00	2016-03-17 18:01:00+00	2016-03-17 18:01:00+00	0	4283	\N	\N	4283	\N	\N	\N	\N	83	42	172918
2016-12-20 20:00:00+00	2016-12-20 20:00:00+00	2016-12-20 20:00:00+00	0	4284	\N	\N	4284	\N	\N	\N	\N	83	42	172920
2017-03-09 21:30:00+00	2017-03-09 21:30:00+00	2017-03-09 21:30:00+00	0	4284	\N	\N	4284	\N	\N	\N	\N	83	42	172922
2018-02-16 22:40:00+00	2018-02-16 22:40:00+00	2018-02-16 22:40:00+00	0	4284	\N	\N	4284	\N	\N	\N	\N	83	42	172924
2018-08-22 16:19:00+00	2018-08-22 16:19:00+00	2018-08-22 16:19:00+00	0	4284	\N	\N	4284	\N	\N	\N	\N	83	42	172926
2019-02-05 22:28:00+00	2019-02-05 22:28:00+00	2019-02-05 22:28:00+00	0	4285	\N	\N	4285	\N	\N	\N	\N	83	42	172928
1955-07-07 12:00:00+00	1955-07-07 12:00:00+00	1955-07-07 12:00:00+00	0	3798	\N	\N	3798	\N	\N	\N	\N	85	43	172930
1982-01-13 12:00:00+00	1982-01-13 12:00:00+00	1982-01-13 12:00:00+00	0	3799	\N	\N	3799	\N	\N	\N	\N	85	43	172932
1984-02-29 12:00:00+00	1984-02-29 12:00:00+00	1984-02-29 12:00:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172934
1985-02-15 12:00:00+00	1985-02-15 12:00:00+00	1985-02-15 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172936
1989-02-16 12:00:00+00	1989-02-16 12:00:00+00	1989-02-16 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172938
1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172940
1991-02-22 12:00:00+00	1991-02-22 12:00:00+00	1991-02-22 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172942
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172944
1993-02-22 12:00:00+00	1993-02-22 12:00:00+00	1993-02-22 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172946
1994-02-10 12:00:00+00	1994-02-10 12:00:00+00	1994-02-10 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172948
1995-02-08 12:00:00+00	1995-02-08 12:00:00+00	1995-02-08 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172950
1996-02-07 12:00:00+00	1996-02-07 12:00:00+00	1996-02-07 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172952
1997-02-13 12:00:00+00	1997-02-13 12:00:00+00	1997-02-13 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172954
1998-02-20 12:00:00+00	1998-02-20 12:00:00+00	1998-02-20 12:00:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172956
1999-01-26 18:20:00+00	1999-01-26 18:20:00+00	1999-01-26 18:20:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172958
2000-02-24 21:30:00+00	2000-02-24 21:30:00+00	2000-02-24 21:30:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172960
2001-02-26 21:30:00+00	2001-02-26 21:30:00+00	2001-02-26 21:30:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172962
2002-02-21 19:40:00+00	2002-02-21 19:40:00+00	2002-02-21 19:40:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172964
2003-02-06 20:45:00+00	2003-02-06 20:45:00+00	2003-02-06 20:45:00+00	0	3797	\N	\N	3797	\N	\N	\N	\N	85	43	172966
2004-02-10 20:20:00+00	2004-02-10 20:20:00+00	2004-02-10 20:20:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172968
2005-02-04 21:25:00+00	2005-02-04 21:25:00+00	2005-02-04 21:25:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172970
2006-03-03 18:32:00+00	2006-03-03 18:32:00+00	2006-03-03 18:32:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172972
2007-03-06 22:38:00+00	2007-03-06 22:38:00+00	2007-03-06 22:38:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172974
2008-03-20 22:00:00+00	2008-03-20 22:00:00+00	2008-03-20 22:00:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172976
2009-01-27 18:10:00+00	2009-01-27 18:10:00+00	2009-01-27 18:10:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172978
2010-03-11 22:46:00+00	2010-03-11 22:46:00+00	2010-03-11 22:46:00+00	0	3796	\N	\N	3796	\N	\N	\N	\N	85	43	172980
2011-02-25 00:36:00+00	2011-02-25 00:36:00+00	2011-02-25 00:36:00+00	0	3795	\N	\N	3795	\N	\N	\N	\N	85	43	172982
2011-03-17 20:14:00+00	2011-03-17 20:14:00+00	2011-03-17 20:14:00+00	0	3795	\N	\N	3795	\N	\N	\N	\N	85	43	172984
2011-05-04 18:06:00+00	2011-05-04 18:06:00+00	2011-05-04 18:06:00+00	0	3795	\N	\N	3795	\N	\N	\N	\N	85	43	172986
2011-06-01 17:50:00+00	2011-06-01 17:50:00+00	2011-06-01 17:50:00+00	0	3795	\N	\N	3795	\N	\N	\N	\N	85	43	172988
2011-07-06 17:44:00+00	2011-07-06 17:44:00+00	2011-07-06 17:44:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	172990
2011-08-16 16:46:00+00	2011-08-16 16:46:00+00	2011-08-16 16:46:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	172992
2011-10-18 18:40:00+00	2011-10-18 18:40:00+00	2011-10-18 18:40:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	172994
2012-01-27 18:10:00+00	2012-01-27 18:10:00+00	2012-01-27 18:10:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	172996
2012-06-25 20:35:00+00	2012-06-25 20:35:00+00	2012-06-25 20:35:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	172998
2013-01-15 16:44:00+00	2013-01-15 16:44:00+00	2013-01-15 16:44:00+00	0	3794	\N	\N	3794	\N	\N	\N	\N	85	43	173000
2014-01-27 21:04:00+00	2014-01-27 21:04:00+00	2014-01-27 21:04:00+00	0	3793	\N	\N	3793	\N	\N	\N	\N	85	43	173002
2015-03-04 19:05:00+00	2015-03-04 19:05:00+00	2015-03-04 19:05:00+00	0	3793	\N	\N	3793	\N	\N	\N	\N	85	43	173004
2016-02-17 20:07:00+00	2016-02-17 20:07:00+00	2016-02-17 20:07:00+00	0	3792	\N	\N	3792	\N	\N	\N	\N	85	43	173006
2016-12-20 23:30:00+00	2016-12-20 23:30:00+00	2016-12-20 23:30:00+00	0	3793	\N	\N	3793	\N	\N	\N	\N	85	43	173008
2017-03-04 22:30:00+00	2017-03-04 22:30:00+00	2017-03-04 22:30:00+00	0	3793	\N	\N	3793	\N	\N	\N	\N	85	43	173010
2018-02-01 19:05:00+00	2018-02-01 19:05:00+00	2018-02-01 19:05:00+00	0	3792	\N	\N	3792	\N	\N	\N	\N	85	43	173012
2018-08-24 15:47:00+00	2018-08-24 15:47:00+00	2018-08-24 15:47:00+00	0	3792	\N	\N	3792	\N	\N	\N	\N	85	43	173014
2019-01-29 22:25:00+00	2019-01-29 22:25:00+00	2019-01-29 22:25:00+00	0	3791	\N	\N	3791	\N	\N	\N	\N	85	43	173016
1985-03-06 00:00:00+00	1985-03-06 00:00:00+00	1985-03-06 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173018
1985-03-07 00:00:00+00	1985-03-07 00:00:00+00	1985-03-07 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173020
1985-03-08 00:00:00+00	1985-03-08 00:00:00+00	1985-03-08 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173022
1985-03-09 00:00:00+00	1985-03-09 00:00:00+00	1985-03-09 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173024
1985-03-10 00:00:00+00	1985-03-10 00:00:00+00	1985-03-10 00:00:00+00	0	3866.2	\N	\N	3866.2	\N	\N	\N	\N	87	44	173026
1985-03-11 00:00:00+00	1985-03-11 00:00:00+00	1985-03-11 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173028
1985-03-12 00:00:00+00	1985-03-12 00:00:00+00	1985-03-12 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173030
1985-03-13 00:00:00+00	1985-03-13 00:00:00+00	1985-03-13 00:00:00+00	0	3867.2	\N	\N	3867.2	\N	\N	\N	\N	87	44	173032
1985-03-14 00:00:00+00	1985-03-14 00:00:00+00	1985-03-14 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173034
1985-03-15 00:00:00+00	1985-03-15 00:00:00+00	1985-03-15 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173036
1985-03-16 00:00:00+00	1985-03-16 00:00:00+00	1985-03-16 00:00:00+00	0	3867.6	\N	\N	3867.6	\N	\N	\N	\N	87	44	173038
1985-03-17 00:00:00+00	1985-03-17 00:00:00+00	1985-03-17 00:00:00+00	0	3867.6	\N	\N	3867.6	\N	\N	\N	\N	87	44	173040
1985-03-18 00:00:00+00	1985-03-18 00:00:00+00	1985-03-18 00:00:00+00	0	3867.6	\N	\N	3867.6	\N	\N	\N	\N	87	44	173042
1985-03-19 00:00:00+00	1985-03-19 00:00:00+00	1985-03-19 00:00:00+00	0	3867.7	\N	\N	3867.7	\N	\N	\N	\N	87	44	173044
1985-03-20 00:00:00+00	1985-03-20 00:00:00+00	1985-03-20 00:00:00+00	0	3867.7	\N	\N	3867.7	\N	\N	\N	\N	87	44	173046
1985-03-21 00:00:00+00	1985-03-21 00:00:00+00	1985-03-21 00:00:00+00	0	3867.7	\N	\N	3867.7	\N	\N	\N	\N	87	44	173048
1985-03-22 00:00:00+00	1985-03-22 00:00:00+00	1985-03-22 00:00:00+00	0	3867.6	\N	\N	3867.6	\N	\N	\N	\N	87	44	173050
1985-03-23 00:00:00+00	1985-03-23 00:00:00+00	1985-03-23 00:00:00+00	0	3867.6	\N	\N	3867.6	\N	\N	\N	\N	87	44	173052
1985-03-24 00:00:00+00	1985-03-24 00:00:00+00	1985-03-24 00:00:00+00	0	3866.2	\N	\N	3866.2	\N	\N	\N	\N	87	44	173054
1985-03-25 00:00:00+00	1985-03-25 00:00:00+00	1985-03-25 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173056
1985-03-26 00:00:00+00	1985-03-26 00:00:00+00	1985-03-26 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173058
1985-03-27 00:00:00+00	1985-03-27 00:00:00+00	1985-03-27 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173060
1985-03-28 00:00:00+00	1985-03-28 00:00:00+00	1985-03-28 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173062
1985-03-29 00:00:00+00	1985-03-29 00:00:00+00	1985-03-29 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173064
1985-03-30 00:00:00+00	1985-03-30 00:00:00+00	1985-03-30 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173066
1985-03-31 00:00:00+00	1985-03-31 00:00:00+00	1985-03-31 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173068
1985-04-01 00:00:00+00	1985-04-01 00:00:00+00	1985-04-01 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173070
1985-04-02 00:00:00+00	1985-04-02 00:00:00+00	1985-04-02 00:00:00+00	0	3867.2	\N	\N	3867.2	\N	\N	\N	\N	87	44	173072
1985-04-03 00:00:00+00	1985-04-03 00:00:00+00	1985-04-03 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173074
1985-04-04 00:00:00+00	1985-04-04 00:00:00+00	1985-04-04 00:00:00+00	0	3865.5	\N	\N	3865.5	\N	\N	\N	\N	87	44	173076
1985-04-05 00:00:00+00	1985-04-05 00:00:00+00	1985-04-05 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173078
1985-04-06 00:00:00+00	1985-04-06 00:00:00+00	1985-04-06 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173080
1985-04-07 00:00:00+00	1985-04-07 00:00:00+00	1985-04-07 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173082
1985-04-08 00:00:00+00	1985-04-08 00:00:00+00	1985-04-08 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173084
1985-04-09 00:00:00+00	1985-04-09 00:00:00+00	1985-04-09 00:00:00+00	0	3867.1	\N	\N	3867.1	\N	\N	\N	\N	87	44	173086
1985-04-10 00:00:00+00	1985-04-10 00:00:00+00	1985-04-10 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173088
1985-04-11 00:00:00+00	1985-04-11 00:00:00+00	1985-04-11 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173090
1985-04-12 00:00:00+00	1985-04-12 00:00:00+00	1985-04-12 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173092
1985-04-13 00:00:00+00	1985-04-13 00:00:00+00	1985-04-13 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173094
1985-04-14 00:00:00+00	1985-04-14 00:00:00+00	1985-04-14 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173096
1985-04-15 00:00:00+00	1985-04-15 00:00:00+00	1985-04-15 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173098
1985-04-16 00:00:00+00	1985-04-16 00:00:00+00	1985-04-16 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173100
1985-04-17 00:00:00+00	1985-04-17 00:00:00+00	1985-04-17 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173102
1985-04-18 00:00:00+00	1985-04-18 00:00:00+00	1985-04-18 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173104
1985-04-19 00:00:00+00	1985-04-19 00:00:00+00	1985-04-19 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173106
1985-04-20 00:00:00+00	1985-04-20 00:00:00+00	1985-04-20 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173108
1985-04-21 00:00:00+00	1985-04-21 00:00:00+00	1985-04-21 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173110
1985-04-22 00:00:00+00	1985-04-22 00:00:00+00	1985-04-22 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173112
1985-04-23 00:00:00+00	1985-04-23 00:00:00+00	1985-04-23 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173114
1985-04-24 00:00:00+00	1985-04-24 00:00:00+00	1985-04-24 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173116
1985-04-25 00:00:00+00	1985-04-25 00:00:00+00	1985-04-25 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173118
1985-04-26 00:00:00+00	1985-04-26 00:00:00+00	1985-04-26 00:00:00+00	0	3866.7	\N	\N	3866.7	\N	\N	\N	\N	87	44	173120
1985-04-27 00:00:00+00	1985-04-27 00:00:00+00	1985-04-27 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173122
1985-04-28 00:00:00+00	1985-04-28 00:00:00+00	1985-04-28 00:00:00+00	0	3865.7	\N	\N	3865.7	\N	\N	\N	\N	87	44	173124
1985-04-29 00:00:00+00	1985-04-29 00:00:00+00	1985-04-29 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173126
1985-04-30 00:00:00+00	1985-04-30 00:00:00+00	1985-04-30 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173128
1985-05-01 00:00:00+00	1985-05-01 00:00:00+00	1985-05-01 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173130
1985-05-02 00:00:00+00	1985-05-02 00:00:00+00	1985-05-02 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173132
1985-05-03 00:00:00+00	1985-05-03 00:00:00+00	1985-05-03 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173134
1985-05-04 00:00:00+00	1985-05-04 00:00:00+00	1985-05-04 00:00:00+00	0	3867.5	\N	\N	3867.5	\N	\N	\N	\N	87	44	173136
1985-05-05 00:00:00+00	1985-05-05 00:00:00+00	1985-05-05 00:00:00+00	0	3867.4	\N	\N	3867.4	\N	\N	\N	\N	87	44	173138
1985-05-06 00:00:00+00	1985-05-06 00:00:00+00	1985-05-06 00:00:00+00	0	3867.3	\N	\N	3867.3	\N	\N	\N	\N	87	44	173140
1985-05-07 00:00:00+00	1985-05-07 00:00:00+00	1985-05-07 00:00:00+00	0	3867.1	\N	\N	3867.1	\N	\N	\N	\N	87	44	173142
1985-05-08 00:00:00+00	1985-05-08 00:00:00+00	1985-05-08 00:00:00+00	0	3867.1	\N	\N	3867.1	\N	\N	\N	\N	87	44	173144
1985-05-09 00:00:00+00	1985-05-09 00:00:00+00	1985-05-09 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173146
1985-05-10 00:00:00+00	1985-05-10 00:00:00+00	1985-05-10 00:00:00+00	0	3867	\N	\N	3867	\N	\N	\N	\N	87	44	173148
1985-05-11 00:00:00+00	1985-05-11 00:00:00+00	1985-05-11 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173150
1985-05-12 00:00:00+00	1985-05-12 00:00:00+00	1985-05-12 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173152
1985-05-13 00:00:00+00	1985-05-13 00:00:00+00	1985-05-13 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173154
1985-05-14 00:00:00+00	1985-05-14 00:00:00+00	1985-05-14 00:00:00+00	0	3866.9	\N	\N	3866.9	\N	\N	\N	\N	87	44	173156
1985-05-15 00:00:00+00	1985-05-15 00:00:00+00	1985-05-15 00:00:00+00	0	3865.4	\N	\N	3865.4	\N	\N	\N	\N	87	44	173158
1985-05-16 00:00:00+00	1985-05-16 00:00:00+00	1985-05-16 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173160
1985-05-17 00:00:00+00	1985-05-17 00:00:00+00	1985-05-17 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173162
1985-05-18 00:00:00+00	1985-05-18 00:00:00+00	1985-05-18 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173164
1985-05-19 00:00:00+00	1985-05-19 00:00:00+00	1985-05-19 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173166
1985-05-20 00:00:00+00	1985-05-20 00:00:00+00	1985-05-20 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173168
1985-05-21 00:00:00+00	1985-05-21 00:00:00+00	1985-05-21 00:00:00+00	0	3866.8	\N	\N	3866.8	\N	\N	\N	\N	87	44	173170
1985-05-22 00:00:00+00	1985-05-22 00:00:00+00	1985-05-22 00:00:00+00	0	3866.7	\N	\N	3866.7	\N	\N	\N	\N	87	44	173172
1985-05-23 00:00:00+00	1985-05-23 00:00:00+00	1985-05-23 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173174
1985-05-24 00:00:00+00	1985-05-24 00:00:00+00	1985-05-24 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173176
1985-05-25 00:00:00+00	1985-05-25 00:00:00+00	1985-05-25 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173178
1985-05-26 00:00:00+00	1985-05-26 00:00:00+00	1985-05-26 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173180
1985-05-27 00:00:00+00	1985-05-27 00:00:00+00	1985-05-27 00:00:00+00	0	3866.7	\N	\N	3866.7	\N	\N	\N	\N	87	44	173182
1985-05-28 00:00:00+00	1985-05-28 00:00:00+00	1985-05-28 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173184
1985-05-29 00:00:00+00	1985-05-29 00:00:00+00	1985-05-29 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173186
1985-05-30 00:00:00+00	1985-05-30 00:00:00+00	1985-05-30 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173188
1985-05-31 00:00:00+00	1985-05-31 00:00:00+00	1985-05-31 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173190
1985-06-01 00:00:00+00	1985-06-01 00:00:00+00	1985-06-01 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173192
1985-06-02 00:00:00+00	1985-06-02 00:00:00+00	1985-06-02 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173194
1985-06-03 00:00:00+00	1985-06-03 00:00:00+00	1985-06-03 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173196
1985-06-04 00:00:00+00	1985-06-04 00:00:00+00	1985-06-04 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173198
1985-06-05 00:00:00+00	1985-06-05 00:00:00+00	1985-06-05 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173200
1985-06-06 00:00:00+00	1985-06-06 00:00:00+00	1985-06-06 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173202
1985-06-07 00:00:00+00	1985-06-07 00:00:00+00	1985-06-07 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173204
1985-06-08 00:00:00+00	1985-06-08 00:00:00+00	1985-06-08 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173206
1985-06-09 00:00:00+00	1985-06-09 00:00:00+00	1985-06-09 00:00:00+00	0	3865.2	\N	\N	3865.2	\N	\N	\N	\N	87	44	173208
1985-06-10 00:00:00+00	1985-06-10 00:00:00+00	1985-06-10 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173210
1985-06-11 00:00:00+00	1985-06-11 00:00:00+00	1985-06-11 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173212
1985-06-12 00:00:00+00	1985-06-12 00:00:00+00	1985-06-12 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173214
1985-06-13 00:00:00+00	1985-06-13 00:00:00+00	1985-06-13 00:00:00+00	0	3866.6	\N	\N	3866.6	\N	\N	\N	\N	87	44	173216
2003-12-31 00:00:00+00	2003-12-31 00:00:00+00	2003-12-31 00:00:00+00	0	5785	\N	\N	5785	\N	\N	\N	\N	35	18	44362
2004-01-01 00:00:00+00	2004-01-01 00:00:00+00	2004-01-01 00:00:00+00	0	5785	\N	\N	5785	\N	\N	\N	\N	35	18	44364
2004-01-02 00:00:00+00	2004-01-02 00:00:00+00	2004-01-02 00:00:00+00	0	5785	\N	\N	5785	\N	\N	\N	\N	35	18	44366
2004-01-03 00:00:00+00	2004-01-03 00:00:00+00	2004-01-03 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44368
2004-01-04 00:00:00+00	2004-01-04 00:00:00+00	2004-01-04 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44370
2004-01-05 00:00:00+00	2004-01-05 00:00:00+00	2004-01-05 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44372
2004-01-06 00:00:00+00	2004-01-06 00:00:00+00	2004-01-06 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44374
2004-01-07 00:00:00+00	2004-01-07 00:00:00+00	2004-01-07 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44376
2004-01-08 00:00:00+00	2004-01-08 00:00:00+00	2004-01-08 00:00:00+00	0	5784	\N	\N	5784	\N	\N	\N	\N	35	18	44378
2004-01-09 00:00:00+00	2004-01-09 00:00:00+00	2004-01-09 00:00:00+00	0	5783	\N	\N	5783	\N	\N	\N	\N	35	18	44380
2004-01-10 00:00:00+00	2004-01-10 00:00:00+00	2004-01-10 00:00:00+00	0	5783	\N	\N	5783	\N	\N	\N	\N	35	18	44382
2004-01-11 00:00:00+00	2004-01-11 00:00:00+00	2004-01-11 00:00:00+00	0	5783	\N	\N	5783	\N	\N	\N	\N	35	18	44384
2004-01-12 00:00:00+00	2004-01-12 00:00:00+00	2004-01-12 00:00:00+00	0	5783	\N	\N	5783	\N	\N	\N	\N	35	18	44386
2004-01-13 00:00:00+00	2004-01-13 00:00:00+00	2004-01-13 00:00:00+00	0	5783	\N	\N	5783	\N	\N	\N	\N	35	18	44388
2004-01-14 00:00:00+00	2004-01-14 00:00:00+00	2004-01-14 00:00:00+00	0	5782	\N	\N	5782	\N	\N	\N	\N	35	18	44390
2004-01-15 00:00:00+00	2004-01-15 00:00:00+00	2004-01-15 00:00:00+00	0	5782	\N	\N	5782	\N	\N	\N	\N	35	18	44392
2004-01-16 00:00:00+00	2004-01-16 00:00:00+00	2004-01-16 00:00:00+00	0	5782	\N	\N	5782	\N	\N	\N	\N	35	18	44394
2004-01-17 00:00:00+00	2004-01-17 00:00:00+00	2004-01-17 00:00:00+00	0	5781	\N	\N	5781	\N	\N	\N	\N	35	18	44396
2004-01-18 00:00:00+00	2004-01-18 00:00:00+00	2004-01-18 00:00:00+00	0	5781	\N	\N	5781	\N	\N	\N	\N	35	18	44398
2004-01-19 00:00:00+00	2004-01-19 00:00:00+00	2004-01-19 00:00:00+00	0	5781	\N	\N	5781	\N	\N	\N	\N	35	18	44400
2004-01-20 00:00:00+00	2004-01-20 00:00:00+00	2004-01-20 00:00:00+00	0	5780	\N	\N	5780	\N	\N	\N	\N	35	18	44402
2004-01-21 00:00:00+00	2004-01-21 00:00:00+00	2004-01-21 00:00:00+00	0	5780	\N	\N	5780	\N	\N	\N	\N	35	18	44404
2004-01-22 00:00:00+00	2004-01-22 00:00:00+00	2004-01-22 00:00:00+00	0	5779	\N	\N	5779	\N	\N	\N	\N	35	18	44406
2004-01-23 00:00:00+00	2004-01-23 00:00:00+00	2004-01-23 00:00:00+00	0	5779	\N	\N	5779	\N	\N	\N	\N	35	18	44408
2004-01-24 00:00:00+00	2004-01-24 00:00:00+00	2004-01-24 00:00:00+00	0	5779	\N	\N	5779	\N	\N	\N	\N	35	18	44410
2004-01-25 00:00:00+00	2004-01-25 00:00:00+00	2004-01-25 00:00:00+00	0	5779	\N	\N	5779	\N	\N	\N	\N	35	18	44412
2004-01-26 00:00:00+00	2004-01-26 00:00:00+00	2004-01-26 00:00:00+00	0	5778	\N	\N	5778	\N	\N	\N	\N	35	18	44414
2004-01-27 00:00:00+00	2004-01-27 00:00:00+00	2004-01-27 00:00:00+00	0	5778	\N	\N	5778	\N	\N	\N	\N	35	18	44416
2004-01-28 00:00:00+00	2004-01-28 00:00:00+00	2004-01-28 00:00:00+00	0	5778	\N	\N	5778	\N	\N	\N	\N	35	18	44418
2004-01-29 00:00:00+00	2004-01-29 00:00:00+00	2004-01-29 00:00:00+00	0	5778	\N	\N	5778	\N	\N	\N	\N	35	18	44420
2004-01-30 00:00:00+00	2004-01-30 00:00:00+00	2004-01-30 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44422
2004-01-31 00:00:00+00	2004-01-31 00:00:00+00	2004-01-31 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44424
2004-02-01 00:00:00+00	2004-02-01 00:00:00+00	2004-02-01 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44426
2004-02-02 00:00:00+00	2004-02-02 00:00:00+00	2004-02-02 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44428
2004-02-03 00:00:00+00	2004-02-03 00:00:00+00	2004-02-03 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44430
2004-02-04 00:00:00+00	2004-02-04 00:00:00+00	2004-02-04 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44432
2004-02-05 00:00:00+00	2004-02-05 00:00:00+00	2004-02-05 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44434
2004-02-06 00:00:00+00	2004-02-06 00:00:00+00	2004-02-06 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44436
2004-02-07 00:00:00+00	2004-02-07 00:00:00+00	2004-02-07 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44438
2004-02-08 00:00:00+00	2004-02-08 00:00:00+00	2004-02-08 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44440
2004-02-09 00:00:00+00	2004-02-09 00:00:00+00	2004-02-09 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44442
2004-02-10 00:00:00+00	2004-02-10 00:00:00+00	2004-02-10 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44444
2004-02-11 00:00:00+00	2004-02-11 00:00:00+00	2004-02-11 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44446
2004-02-12 00:00:00+00	2004-02-12 00:00:00+00	2004-02-12 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44448
2004-02-13 00:00:00+00	2004-02-13 00:00:00+00	2004-02-13 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44450
2004-02-14 00:00:00+00	2004-02-14 00:00:00+00	2004-02-14 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44452
2004-02-15 00:00:00+00	2004-02-15 00:00:00+00	2004-02-15 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44454
2004-02-16 00:00:00+00	2004-02-16 00:00:00+00	2004-02-16 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44456
2004-02-17 00:00:00+00	2004-02-17 00:00:00+00	2004-02-17 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44458
2004-02-18 00:00:00+00	2004-02-18 00:00:00+00	2004-02-18 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44460
2004-02-19 00:00:00+00	2004-02-19 00:00:00+00	2004-02-19 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44462
2004-02-20 00:00:00+00	2004-02-20 00:00:00+00	2004-02-20 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44464
2004-02-21 00:00:00+00	2004-02-21 00:00:00+00	2004-02-21 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44466
2004-02-22 00:00:00+00	2004-02-22 00:00:00+00	2004-02-22 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44468
2004-02-23 00:00:00+00	2004-02-23 00:00:00+00	2004-02-23 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44470
2004-02-24 00:00:00+00	2004-02-24 00:00:00+00	2004-02-24 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44472
2004-02-25 00:00:00+00	2004-02-25 00:00:00+00	2004-02-25 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44474
2004-02-26 00:00:00+00	2004-02-26 00:00:00+00	2004-02-26 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44476
2004-02-27 00:00:00+00	2004-02-27 00:00:00+00	2004-02-27 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44478
2004-02-28 00:00:00+00	2004-02-28 00:00:00+00	2004-02-28 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44480
2004-02-29 00:00:00+00	2004-02-29 00:00:00+00	2004-02-29 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44482
2004-03-01 00:00:00+00	2004-03-01 00:00:00+00	2004-03-01 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44484
2004-03-02 00:00:00+00	2004-03-02 00:00:00+00	2004-03-02 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44486
2004-03-03 00:00:00+00	2004-03-03 00:00:00+00	2004-03-03 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44488
2004-03-04 00:00:00+00	2004-03-04 00:00:00+00	2004-03-04 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44490
2004-03-05 00:00:00+00	2004-03-05 00:00:00+00	2004-03-05 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44492
2004-03-06 00:00:00+00	2004-03-06 00:00:00+00	2004-03-06 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44494
2004-03-07 00:00:00+00	2004-03-07 00:00:00+00	2004-03-07 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44496
2004-03-08 00:00:00+00	2004-03-08 00:00:00+00	2004-03-08 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44498
2004-03-09 00:00:00+00	2004-03-09 00:00:00+00	2004-03-09 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44500
2004-03-10 00:00:00+00	2004-03-10 00:00:00+00	2004-03-10 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44502
2004-03-11 00:00:00+00	2004-03-11 00:00:00+00	2004-03-11 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44504
2004-03-12 00:00:00+00	2004-03-12 00:00:00+00	2004-03-12 00:00:00+00	0	5777	\N	\N	5777	\N	\N	\N	\N	35	18	44506
2004-03-13 00:00:00+00	2004-03-13 00:00:00+00	2004-03-13 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44508
2004-03-14 00:00:00+00	2004-03-14 00:00:00+00	2004-03-14 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44510
2004-03-15 00:00:00+00	2004-03-15 00:00:00+00	2004-03-15 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44512
2004-03-16 00:00:00+00	2004-03-16 00:00:00+00	2004-03-16 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44514
2004-03-17 00:00:00+00	2004-03-17 00:00:00+00	2004-03-17 00:00:00+00	0	5776	\N	\N	5776	\N	\N	\N	\N	35	18	44516
2004-03-18 00:00:00+00	2004-03-18 00:00:00+00	2004-03-18 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44518
2004-03-19 00:00:00+00	2004-03-19 00:00:00+00	2004-03-19 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44520
2004-03-20 00:00:00+00	2004-03-20 00:00:00+00	2004-03-20 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44522
2004-03-21 00:00:00+00	2004-03-21 00:00:00+00	2004-03-21 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44524
2004-03-22 00:00:00+00	2004-03-22 00:00:00+00	2004-03-22 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44526
2004-03-23 00:00:00+00	2004-03-23 00:00:00+00	2004-03-23 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44528
2004-03-24 00:00:00+00	2004-03-24 00:00:00+00	2004-03-24 00:00:00+00	0	5775	\N	\N	5775	\N	\N	\N	\N	35	18	44530
2004-03-25 00:00:00+00	2004-03-25 00:00:00+00	2004-03-25 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44532
2004-03-26 00:00:00+00	2004-03-26 00:00:00+00	2004-03-26 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44534
2004-03-27 00:00:00+00	2004-03-27 00:00:00+00	2004-03-27 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44536
2004-03-28 00:00:00+00	2004-03-28 00:00:00+00	2004-03-28 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44538
2004-03-29 00:00:00+00	2004-03-29 00:00:00+00	2004-03-29 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44540
2004-03-30 00:00:00+00	2004-03-30 00:00:00+00	2004-03-30 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44542
2004-03-31 00:00:00+00	2004-03-31 00:00:00+00	2004-03-31 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44544
2004-04-01 00:00:00+00	2004-04-01 00:00:00+00	2004-04-01 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44546
2004-04-02 00:00:00+00	2004-04-02 00:00:00+00	2004-04-02 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44548
2004-04-03 00:00:00+00	2004-04-03 00:00:00+00	2004-04-03 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44550
2004-04-04 00:00:00+00	2004-04-04 00:00:00+00	2004-04-04 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44552
2004-04-05 00:00:00+00	2004-04-05 00:00:00+00	2004-04-05 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44554
2004-04-06 00:00:00+00	2004-04-06 00:00:00+00	2004-04-06 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44556
2004-04-07 00:00:00+00	2004-04-07 00:00:00+00	2004-04-07 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44558
2004-04-08 00:00:00+00	2004-04-08 00:00:00+00	2004-04-08 00:00:00+00	0	5774	\N	\N	5774	\N	\N	\N	\N	35	18	44560
1998-02-04 00:00:00+00	1998-02-04 00:00:00+00	1998-02-04 00:00:00+00	0	6692	\N	\N	6692	\N	\N	\N	\N	43	22	78276
1998-02-05 00:00:00+00	1998-02-05 00:00:00+00	1998-02-05 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78278
1998-02-06 00:00:00+00	1998-02-06 00:00:00+00	1998-02-06 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78280
1998-02-07 00:00:00+00	1998-02-07 00:00:00+00	1998-02-07 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78282
1998-02-08 00:00:00+00	1998-02-08 00:00:00+00	1998-02-08 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78284
1998-02-09 00:00:00+00	1998-02-09 00:00:00+00	1998-02-09 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78286
1998-02-10 00:00:00+00	1998-02-10 00:00:00+00	1998-02-10 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78288
1998-02-11 00:00:00+00	1998-02-11 00:00:00+00	1998-02-11 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78290
1998-02-12 00:00:00+00	1998-02-12 00:00:00+00	1998-02-12 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78292
1998-02-13 00:00:00+00	1998-02-13 00:00:00+00	1998-02-13 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78294
1998-02-14 00:00:00+00	1998-02-14 00:00:00+00	1998-02-14 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78296
1998-02-15 00:00:00+00	1998-02-15 00:00:00+00	1998-02-15 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78298
1998-02-16 00:00:00+00	1998-02-16 00:00:00+00	1998-02-16 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78300
1998-02-17 00:00:00+00	1998-02-17 00:00:00+00	1998-02-17 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78302
1998-02-18 00:00:00+00	1998-02-18 00:00:00+00	1998-02-18 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78304
1998-02-19 00:00:00+00	1998-02-19 00:00:00+00	1998-02-19 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78306
1998-02-20 00:00:00+00	1998-02-20 00:00:00+00	1998-02-20 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78308
1998-02-21 00:00:00+00	1998-02-21 00:00:00+00	1998-02-21 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78310
1998-02-22 00:00:00+00	1998-02-22 00:00:00+00	1998-02-22 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78312
1998-02-23 00:00:00+00	1998-02-23 00:00:00+00	1998-02-23 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78314
1998-02-24 00:00:00+00	1998-02-24 00:00:00+00	1998-02-24 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78316
1998-02-25 00:00:00+00	1998-02-25 00:00:00+00	1998-02-25 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78318
1998-02-26 00:00:00+00	1998-02-26 00:00:00+00	1998-02-26 00:00:00+00	0	6692	\N	\N	6692	\N	\N	\N	\N	43	22	78320
1998-02-27 00:00:00+00	1998-02-27 00:00:00+00	1998-02-27 00:00:00+00	0	6692	\N	\N	6692	\N	\N	\N	\N	43	22	78322
1998-02-28 00:00:00+00	1998-02-28 00:00:00+00	1998-02-28 00:00:00+00	0	6692	\N	\N	6692	\N	\N	\N	\N	43	22	78324
1998-03-01 00:00:00+00	1998-03-01 00:00:00+00	1998-03-01 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78326
1998-03-02 00:00:00+00	1998-03-02 00:00:00+00	1998-03-02 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78328
1998-03-03 00:00:00+00	1998-03-03 00:00:00+00	1998-03-03 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78330
1998-03-04 00:00:00+00	1998-03-04 00:00:00+00	1998-03-04 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78332
1998-03-05 00:00:00+00	1998-03-05 00:00:00+00	1998-03-05 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78334
1998-03-06 00:00:00+00	1998-03-06 00:00:00+00	1998-03-06 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78336
1998-03-07 00:00:00+00	1998-03-07 00:00:00+00	1998-03-07 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78338
1998-03-08 00:00:00+00	1998-03-08 00:00:00+00	1998-03-08 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78340
1998-03-09 00:00:00+00	1998-03-09 00:00:00+00	1998-03-09 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78342
1998-03-10 00:00:00+00	1998-03-10 00:00:00+00	1998-03-10 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78344
1998-03-11 00:00:00+00	1998-03-11 00:00:00+00	1998-03-11 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78346
1998-03-12 00:00:00+00	1998-03-12 00:00:00+00	1998-03-12 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78348
1998-03-13 00:00:00+00	1998-03-13 00:00:00+00	1998-03-13 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78350
1998-03-14 00:00:00+00	1998-03-14 00:00:00+00	1998-03-14 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78352
1998-03-15 00:00:00+00	1998-03-15 00:00:00+00	1998-03-15 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78354
1998-03-16 00:00:00+00	1998-03-16 00:00:00+00	1998-03-16 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78356
1998-03-17 00:00:00+00	1998-03-17 00:00:00+00	1998-03-17 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78358
1998-03-18 00:00:00+00	1998-03-18 00:00:00+00	1998-03-18 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78360
1998-03-19 00:00:00+00	1998-03-19 00:00:00+00	1998-03-19 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78362
1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	1998-03-20 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78364
1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	1998-03-21 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78366
1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	1998-03-22 00:00:00+00	0	6689	\N	\N	6689	\N	\N	\N	\N	43	22	78368
1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	1998-03-23 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78370
1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	1998-03-24 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78372
1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	1998-03-25 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78374
1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	1998-03-26 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78376
1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	1998-03-27 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78378
1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	1998-03-28 00:00:00+00	0	6691	\N	\N	6691	\N	\N	\N	\N	43	22	78380
1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	1998-03-29 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78382
1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	1998-03-30 00:00:00+00	0	6690	\N	\N	6690	\N	\N	\N	\N	43	22	78384
1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	1998-04-10 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78386
1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	1998-04-11 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78388
1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	1998-04-12 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78390
1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	1998-04-13 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78392
1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	1998-04-14 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78394
1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	1998-04-15 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78396
1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	1998-04-16 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78398
1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	1998-04-17 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78400
1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	1998-04-18 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78402
1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	1998-04-19 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78404
1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	1998-04-20 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78406
1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	1998-04-21 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78408
1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	1998-04-22 00:00:00+00	0	6688	\N	\N	6688	\N	\N	\N	\N	43	22	78410
1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	1998-04-23 00:00:00+00	0	6688	\N	\N	6688	\N	\N	\N	\N	43	22	78412
1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	1998-04-24 00:00:00+00	0	6688	\N	\N	6688	\N	\N	\N	\N	43	22	78414
1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	1998-04-25 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78416
1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	1998-04-26 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78418
1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	1998-04-27 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78420
1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	1998-04-28 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78422
1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	1998-04-29 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78424
1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	1998-04-30 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78426
1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	1998-05-01 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78428
1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	1998-05-02 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78430
1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	1998-05-03 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78432
1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	1998-05-04 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78434
1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	1998-05-05 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78436
1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	1998-05-06 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78438
1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	1998-05-08 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78440
1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	1998-05-09 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78442
1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	1998-05-10 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78444
1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	1998-05-11 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78446
1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	1998-05-12 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78448
1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	1998-05-13 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78450
1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	1998-05-14 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78452
1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	1998-05-15 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78454
1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	1998-05-16 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78456
1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	1998-05-17 00:00:00+00	0	6687	\N	\N	6687	\N	\N	\N	\N	43	22	78458
1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	1998-05-18 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78460
1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	1998-05-19 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78462
1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	1998-05-20 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78464
1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	1998-05-21 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78466
1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	1998-05-22 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78468
1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	1998-05-23 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78470
1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	1998-05-24 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78472
1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	1998-05-25 00:00:00+00	0	6686	\N	\N	6686	\N	\N	\N	\N	43	22	78474
1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	1980-06-25 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94652
1991-02-25 07:00:00+00	1991-02-25 07:00:00+00	1991-02-25 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94654
1992-02-19 07:00:00+00	1992-02-19 07:00:00+00	1992-02-19 07:00:00+00	0	7002	\N	\N	7002	\N	\N	\N	\N	45	23	94656
1993-02-23 07:00:00+00	1993-02-23 07:00:00+00	1993-02-23 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94658
1994-02-28 07:00:00+00	1994-02-28 07:00:00+00	1994-02-28 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94660
1995-02-21 07:00:00+00	1995-02-21 07:00:00+00	1995-02-21 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94662
1996-02-07 07:00:00+00	1996-02-07 07:00:00+00	1996-02-07 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94664
1997-02-19 07:00:00+00	1997-02-19 07:00:00+00	1997-02-19 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94666
2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94668
2008-05-13 07:00:00+00	2008-05-13 07:00:00+00	2008-05-13 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94670
2008-09-24 07:00:00+00	2008-09-24 07:00:00+00	2008-09-24 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94672
2009-02-09 07:00:00+00	2009-02-09 07:00:00+00	2009-02-09 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94674
2009-12-09 07:00:00+00	2009-12-09 07:00:00+00	2009-12-09 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94676
2010-03-24 07:00:00+00	2010-03-24 07:00:00+00	2010-03-24 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94678
2010-05-11 07:00:00+00	2010-05-11 07:00:00+00	2010-05-11 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94680
2010-07-14 07:00:00+00	2010-07-14 07:00:00+00	2010-07-14 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94682
2010-09-20 07:00:00+00	2010-09-20 07:00:00+00	2010-09-20 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94684
2010-11-10 07:00:00+00	2010-11-10 07:00:00+00	2010-11-10 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94686
2011-01-12 07:00:00+00	2011-01-12 07:00:00+00	2011-01-12 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94688
2011-05-17 07:00:00+00	2011-05-17 07:00:00+00	2011-05-17 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94690
2011-07-14 07:00:00+00	2011-07-14 07:00:00+00	2011-07-14 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94692
2011-11-11 07:00:00+00	2011-11-11 07:00:00+00	2011-11-11 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94694
2012-02-27 07:00:00+00	2012-02-27 07:00:00+00	2012-02-27 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94696
2013-02-27 07:00:00+00	2013-02-27 07:00:00+00	2013-02-27 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94698
2015-02-25 07:00:00+00	2015-02-25 07:00:00+00	2015-02-25 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94700
2016-02-18 07:00:00+00	2016-02-18 07:00:00+00	2016-02-18 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94702
2017-02-20 07:00:00+00	2017-02-20 07:00:00+00	2017-02-20 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94704
2018-06-06 07:00:00+00	2018-06-06 07:00:00+00	2018-06-06 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94706
2018-11-13 07:00:00+00	2018-11-13 07:00:00+00	2018-11-13 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94708
2019-02-20 07:00:00+00	2019-02-20 07:00:00+00	2019-02-20 07:00:00+00	0	7008	\N	\N	7008	\N	\N	\N	\N	45	23	94710
2020-03-12 07:00:00+00	2020-03-12 07:00:00+00	2020-03-12 07:00:00+00	0	7007	\N	\N	7007	\N	\N	\N	\N	45	23	94712
1977-12-15 07:00:00+00	1977-12-15 07:00:00+00	1977-12-15 07:00:00+00	0	283.6	\N	\N	283.6	\N	\N	\N	\N	50	25	95083
1991-02-11 07:00:00+00	1991-02-11 07:00:00+00	1991-02-11 07:00:00+00	0	252.45	\N	\N	252.45	\N	\N	\N	\N	50	25	95085
1996-02-08 07:00:00+00	1996-02-08 07:00:00+00	1996-02-08 07:00:00+00	0	249.3	\N	\N	249.3	\N	\N	\N	\N	50	25	95087
2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	2001-02-06 07:00:00+00	0	251.03	\N	\N	251.03	\N	\N	\N	\N	50	25	95089
2008-05-08 07:00:00+00	2008-05-08 07:00:00+00	2008-05-08 07:00:00+00	0	250.26	\N	\N	250.26	\N	\N	\N	\N	50	25	95091
2008-09-17 07:00:00+00	2008-09-17 07:00:00+00	2008-09-17 07:00:00+00	0	267.14	\N	\N	267.14	\N	\N	\N	\N	50	25	95093
2009-02-23 07:00:00+00	2009-02-23 07:00:00+00	2009-02-23 07:00:00+00	0	268.5	\N	\N	268.5	\N	\N	\N	\N	50	25	95095
2010-02-10 07:00:00+00	2010-02-10 07:00:00+00	2010-02-10 07:00:00+00	0	250.71	\N	\N	250.71	\N	\N	\N	\N	50	25	95097
2011-03-22 07:00:00+00	2011-03-22 07:00:00+00	2011-03-22 07:00:00+00	0	250.85	\N	\N	250.85	\N	\N	\N	\N	50	25	95099
2012-03-07 07:00:00+00	2012-03-07 07:00:00+00	2012-03-07 07:00:00+00	0	250.06	\N	\N	250.06	\N	\N	\N	\N	50	25	95101
2013-03-15 07:00:00+00	2013-03-15 07:00:00+00	2013-03-15 07:00:00+00	0	254.96	\N	\N	254.96	\N	\N	\N	\N	50	25	95103
2015-03-11 07:00:00+00	2015-03-11 07:00:00+00	2015-03-11 07:00:00+00	0	250.73	\N	\N	250.73	\N	\N	\N	\N	50	25	95105
2016-02-19 07:00:00+00	2016-02-19 07:00:00+00	2016-02-19 07:00:00+00	0	251.56	\N	\N	251.56	\N	\N	\N	\N	50	25	95107
2017-02-23 07:00:00+00	2017-02-23 07:00:00+00	2017-02-23 07:00:00+00	0	253.21	\N	\N	253.21	\N	\N	\N	\N	50	25	95109
2018-02-19 07:00:00+00	2018-02-19 07:00:00+00	2018-02-19 07:00:00+00	0	251.11	\N	\N	251.11	\N	\N	\N	\N	50	25	95111
2019-02-19 07:00:00+00	2019-02-19 07:00:00+00	2019-02-19 07:00:00+00	0	253.19	\N	\N	253.19	\N	\N	\N	\N	50	25	95113
2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	2020-03-11 07:00:00+00	0	251.28	\N	\N	251.28	\N	\N	\N	\N	50	25	95115
1949-06-14 12:00:00+00	1949-06-14 12:00:00+00	1949-06-14 12:00:00+00	0	6391	\N	\N	6391	\N	\N	\N	\N	55	28	95470
1950-12-08 12:00:00+00	1950-12-08 12:00:00+00	1950-12-08 12:00:00+00	0	6389	\N	\N	6389	\N	\N	\N	\N	55	28	95472
1957-11-12 12:00:00+00	1957-11-12 12:00:00+00	1957-11-12 12:00:00+00	0	6390	\N	\N	6390	\N	\N	\N	\N	55	28	95474
1958-02-03 12:00:00+00	1958-02-03 12:00:00+00	1958-02-03 12:00:00+00	0	6382	\N	\N	6382	\N	\N	\N	\N	55	28	95476
1958-05-13 12:00:00+00	1958-05-13 12:00:00+00	1958-05-13 12:00:00+00	0	6387	\N	\N	6387	\N	\N	\N	\N	55	28	95478
1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	0	6388	\N	\N	6388	\N	\N	\N	\N	55	28	95480
1958-11-19 12:00:00+00	1958-11-19 12:00:00+00	1958-11-19 12:00:00+00	0	6391	\N	\N	6391	\N	\N	\N	\N	55	28	95482
1959-05-04 12:00:00+00	1959-05-04 12:00:00+00	1959-05-04 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95484
1959-09-03 12:00:00+00	1959-09-03 12:00:00+00	1959-09-03 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95486
1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	0	6394	\N	\N	6394	\N	\N	\N	\N	55	28	95488
1960-02-10 12:00:00+00	1960-02-10 12:00:00+00	1960-02-10 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95490
1960-05-10 12:00:00+00	1960-05-10 12:00:00+00	1960-05-10 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95492
1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95494
1960-11-14 12:00:00+00	1960-11-14 12:00:00+00	1960-11-14 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95496
1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	1961-02-16 12:00:00+00	0	6394	\N	\N	6394	\N	\N	\N	\N	55	28	95498
1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	1961-05-11 12:00:00+00	0	6394	\N	\N	6394	\N	\N	\N	\N	55	28	95500
1961-08-07 12:00:00+00	1961-08-07 12:00:00+00	1961-08-07 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95502
1962-02-14 12:00:00+00	1962-02-14 12:00:00+00	1962-02-14 12:00:00+00	0	6394	\N	\N	6394	\N	\N	\N	\N	55	28	95504
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95506
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95508
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	6393	\N	\N	6393	\N	\N	\N	\N	55	28	95510
1984-03-13 12:00:00+00	1984-03-13 12:00:00+00	1984-03-13 12:00:00+00	0	6387	\N	\N	6387	\N	\N	\N	\N	55	28	95512
1994-02-02 12:00:00+00	1994-02-02 12:00:00+00	1994-02-02 12:00:00+00	0	6386	\N	\N	6386	\N	\N	\N	\N	55	28	95514
1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	0	6387	\N	\N	6387	\N	\N	\N	\N	55	28	95516
2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	0	6387	\N	\N	6387	\N	\N	\N	\N	55	28	95518
2009-04-15 18:00:00+00	2009-04-15 18:00:00+00	2009-04-15 18:00:00+00	0	6386	\N	\N	6386	\N	\N	\N	\N	55	28	95520
2013-04-02 19:40:00+00	2013-04-02 19:40:00+00	2013-04-02 19:40:00+00	0	6386	\N	\N	6386	\N	\N	\N	\N	55	28	95522
2017-07-21 19:30:00+00	2017-07-21 19:30:00+00	2017-07-21 19:30:00+00	0	6385	\N	\N	6385	\N	\N	\N	\N	55	28	95524
2017-12-12 18:02:00+00	2017-12-12 18:02:00+00	2017-12-12 18:02:00+00	0	6386	\N	\N	6386	\N	\N	\N	\N	55	28	95526
1954-09-10 12:00:00+00	1954-09-10 12:00:00+00	1954-09-10 12:00:00+00	0	6341	\N	\N	6341	\N	\N	\N	\N	1	1	2
1985-08-01 12:00:00+00	1985-08-01 12:00:00+00	1985-08-01 12:00:00+00	0	6270	\N	\N	6270	\N	\N	\N	\N	1	1	4
2002-05-24 12:00:00+00	2002-05-24 12:00:00+00	2002-05-24 12:00:00+00	0	6278	\N	\N	6278	\N	\N	\N	\N	1	1	6
2003-03-12 12:00:00+00	2003-03-12 12:00:00+00	2003-03-12 12:00:00+00	0	6312	\N	\N	6312	\N	\N	\N	\N	1	1	8
2004-03-03 15:18:00+00	2004-03-03 15:18:00+00	2004-03-03 15:18:00+00	0	6316	\N	\N	6316	\N	\N	\N	\N	1	1	10
2006-02-16 14:28:00+00	2006-02-16 14:28:00+00	2006-02-16 14:28:00+00	0	6274	\N	\N	6274	\N	\N	\N	\N	1	1	12
2007-02-07 21:55:00+00	2007-02-07 21:55:00+00	2007-02-07 21:55:00+00	0	6284	\N	\N	6284	\N	\N	\N	\N	1	1	14
2008-03-05 23:00:00+00	2008-03-05 23:00:00+00	2008-03-05 23:00:00+00	0	6283	\N	\N	6283	\N	\N	\N	\N	1	1	16
2009-03-25 20:50:00+00	2009-03-25 20:50:00+00	2009-03-25 20:50:00+00	0	6294	\N	\N	6294	\N	\N	\N	\N	1	1	18
2011-03-10 22:15:00+00	2011-03-10 22:15:00+00	2011-03-10 22:15:00+00	0	6308	\N	\N	6308	\N	\N	\N	\N	1	1	20
2012-03-15 17:45:00+00	2012-03-15 17:45:00+00	2012-03-15 17:45:00+00	0	6310	\N	\N	6310	\N	\N	\N	\N	1	1	22
2013-04-04 18:00:00+00	2013-04-04 18:00:00+00	2013-04-04 18:00:00+00	0	6267	\N	\N	6267	\N	\N	\N	\N	1	1	24
2014-03-19 00:00:00+00	2014-03-19 00:00:00+00	2014-03-19 00:00:00+00	0	6275	\N	\N	6275	\N	\N	\N	\N	1	1	26
2016-02-24 19:30:00+00	2016-02-24 19:30:00+00	2016-02-24 19:30:00+00	0	6276	\N	\N	6276	\N	\N	\N	\N	1	1	28
2016-08-11 17:00:00+00	2016-08-11 17:00:00+00	2016-08-11 17:00:00+00	0	6296	\N	\N	6296	\N	\N	\N	\N	1	1	30
2017-08-01 20:30:00+00	2017-08-01 20:30:00+00	2017-08-01 20:30:00+00	0	6294	\N	\N	6294	\N	\N	\N	\N	1	1	32
2019-12-13 21:26:00+00	2019-12-13 21:26:00+00	2019-12-13 21:26:00+00	0	6266	\N	\N	6266	\N	\N	\N	\N	1	1	34
2011-04-21 07:00:00+00	2011-04-21 07:00:00+00	2011-04-21 07:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	5	3	80
2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	82
2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	84
2011-12-16 07:00:00+00	2011-12-16 07:00:00+00	2011-12-16 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	86
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	88
2012-06-06 07:00:00+00	2012-06-06 07:00:00+00	2012-06-06 07:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	5	3	90
2012-09-22 07:00:00+00	2012-09-22 07:00:00+00	2012-09-22 07:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	5	3	92
2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	94
2013-03-12 07:00:00+00	2013-03-12 07:00:00+00	2013-03-12 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	96
2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	98
2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	100
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	102
2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	104
2014-06-05 07:00:00+00	2014-06-05 07:00:00+00	2014-06-05 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	106
2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	5	3	108
2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	110
2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	112
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	114
2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	116
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	118
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	6443	\N	\N	6443	\N	\N	\N	\N	5	3	120
2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	0	6444	\N	\N	6444	\N	\N	\N	\N	5	3	122
2012-11-07 07:00:00+00	2012-11-07 07:00:00+00	2012-11-07 07:00:00+00	0	7270	\N	\N	7270	\N	\N	\N	\N	7	4	124
2013-02-25 07:00:00+00	2013-02-25 07:00:00+00	2013-02-25 07:00:00+00	0	7269	\N	\N	7269	\N	\N	\N	\N	7	4	126
2013-06-11 07:00:00+00	2013-06-11 07:00:00+00	2013-06-11 07:00:00+00	0	7279	\N	\N	7279	\N	\N	\N	\N	7	4	128
2013-08-30 07:00:00+00	2013-08-30 07:00:00+00	2013-08-30 07:00:00+00	0	7271	\N	\N	7271	\N	\N	\N	\N	7	4	130
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	7271	\N	\N	7271	\N	\N	\N	\N	7	4	132
2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	0	7269	\N	\N	7269	\N	\N	\N	\N	7	4	134
2014-06-24 07:00:00+00	2014-06-24 07:00:00+00	2014-06-24 07:00:00+00	0	7277	\N	\N	7277	\N	\N	\N	\N	7	4	136
2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	0	7271	\N	\N	7271	\N	\N	\N	\N	7	4	138
2014-12-11 07:00:00+00	2014-12-11 07:00:00+00	2014-12-11 07:00:00+00	0	7269	\N	\N	7269	\N	\N	\N	\N	7	4	140
2015-03-18 07:00:00+00	2015-03-18 07:00:00+00	2015-03-18 07:00:00+00	0	7269	\N	\N	7269	\N	\N	\N	\N	7	4	142
2015-06-02 07:00:00+00	2015-06-02 07:00:00+00	2015-06-02 07:00:00+00	0	7273	\N	\N	7273	\N	\N	\N	\N	7	4	144
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	7271	\N	\N	7271	\N	\N	\N	\N	7	4	146
2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	0	7273	\N	\N	7273	\N	\N	\N	\N	7	4	148
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	7270	\N	\N	7270	\N	\N	\N	\N	7	4	150
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	7269	\N	\N	7269	\N	\N	\N	\N	7	4	152
2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	0	7270	\N	\N	7270	\N	\N	\N	\N	7	4	154
1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	1982-08-04 12:00:00+00	0	76.21	\N	\N	76.21	\N	\N	\N	\N	12	6	191
1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	1983-03-28 12:00:00+00	0	82.45	\N	\N	82.45	\N	\N	\N	\N	12	6	193
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	87.48	\N	\N	87.48	\N	\N	\N	\N	12	6	195
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	94.87	\N	\N	94.87	\N	\N	\N	\N	12	6	197
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	98.89	\N	\N	98.89	\N	\N	\N	\N	12	6	199
1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	1985-06-28 12:00:00+00	0	101.4	\N	\N	101.4	\N	\N	\N	\N	12	6	201
1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	1985-08-15 12:00:00+00	0	102.36	\N	\N	102.36	\N	\N	\N	\N	12	6	203
1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	1986-02-21 12:00:00+00	0	106.31	\N	\N	106.31	\N	\N	\N	\N	12	6	205
1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	1986-10-08 12:00:00+00	0	110.01	\N	\N	110.01	\N	\N	\N	\N	12	6	207
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	111.63	\N	\N	111.63	\N	\N	\N	\N	12	6	209
1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	1987-10-06 12:00:00+00	0	114.87	\N	\N	114.87	\N	\N	\N	\N	12	6	211
1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	1988-02-24 12:00:00+00	0	116.59	\N	\N	116.59	\N	\N	\N	\N	12	6	213
1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	1988-10-26 12:00:00+00	0	119.11	\N	\N	119.11	\N	\N	\N	\N	12	6	215
1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	1989-04-26 12:00:00+00	0	116.69	\N	\N	116.69	\N	\N	\N	\N	12	6	217
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	122.18	\N	\N	122.18	\N	\N	\N	\N	12	6	219
1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	1990-05-23 12:00:00+00	0	123.6	\N	\N	123.6	\N	\N	\N	\N	12	6	221
1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	1992-02-26 12:00:00+00	0	125.42	\N	\N	125.42	\N	\N	\N	\N	12	6	223
1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	1993-03-18 12:00:00+00	0	125.72	\N	\N	125.72	\N	\N	\N	\N	12	6	225
1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	1993-08-02 12:00:00+00	0	126.11	\N	\N	126.11	\N	\N	\N	\N	12	6	227
1994-03-19 12:00:00+00	1994-03-19 12:00:00+00	1994-03-19 12:00:00+00	0	126.25	\N	\N	126.25	\N	\N	\N	\N	12	6	229
1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	1994-07-11 12:00:00+00	0	126.35	\N	\N	126.35	\N	\N	\N	\N	12	6	231
1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	1995-02-02 12:00:00+00	0	126.35	\N	\N	126.35	\N	\N	\N	\N	12	6	233
1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	1995-07-26 12:00:00+00	0	126.26	\N	\N	126.26	\N	\N	\N	\N	12	6	235
1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	1996-02-23 12:00:00+00	0	125.97	\N	\N	125.97	\N	\N	\N	\N	12	6	237
1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	1996-07-31 12:00:00+00	0	125.94	\N	\N	125.94	\N	\N	\N	\N	12	6	239
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	125.48	\N	\N	125.48	\N	\N	\N	\N	12	6	241
1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	1997-08-12 12:00:00+00	0	125.51	\N	\N	125.51	\N	\N	\N	\N	12	6	243
1998-02-23 12:00:00+00	1998-02-23 12:00:00+00	1998-02-23 12:00:00+00	0	125.04	\N	\N	125.04	\N	\N	\N	\N	12	6	245
1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	1998-03-23 12:00:00+00	0	125.04	\N	\N	125.04	\N	\N	\N	\N	12	6	247
1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	1998-07-21 12:00:00+00	0	125.02	\N	\N	125.02	\N	\N	\N	\N	12	6	249
1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	1999-02-09 12:00:00+00	0	124.68	\N	\N	124.68	\N	\N	\N	\N	12	6	251
1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	1999-08-27 12:00:00+00	0	124.5	\N	\N	124.5	\N	\N	\N	\N	12	6	253
2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	2000-02-29 12:00:00+00	0	124.2	\N	\N	124.2	\N	\N	\N	\N	12	6	255
2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	2000-07-19 12:00:00+00	0	124.25	\N	\N	124.25	\N	\N	\N	\N	12	6	257
2001-02-07 22:25:00+00	2001-02-07 22:25:00+00	2001-02-07 22:25:00+00	0	123.61	\N	\N	123.61	\N	\N	\N	\N	12	6	259
2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	2001-07-03 12:00:00+00	0	124.03	\N	\N	124.03	\N	\N	\N	\N	12	6	261
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	124.02	\N	\N	124.02	\N	\N	\N	\N	12	6	263
2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	2002-09-04 12:00:00+00	0	123.93	\N	\N	123.93	\N	\N	\N	\N	12	6	265
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	123.73	\N	\N	123.73	\N	\N	\N	\N	12	6	267
2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	2003-08-13 12:00:00+00	0	123.82	\N	\N	123.82	\N	\N	\N	\N	12	6	269
2004-03-03 20:47:00+00	2004-03-03 20:47:00+00	2004-03-03 20:47:00+00	0	123.59	\N	\N	123.59	\N	\N	\N	\N	12	6	271
2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	2004-09-01 12:00:00+00	0	123.9	\N	\N	123.9	\N	\N	\N	\N	12	6	273
2005-03-09 12:00:00+00	2005-03-09 12:00:00+00	2005-03-09 12:00:00+00	0	123.98	\N	\N	123.98	\N	\N	\N	\N	12	6	275
2005-09-21 17:25:00+00	2005-09-21 17:25:00+00	2005-09-21 17:25:00+00	0	123.99	\N	\N	123.99	\N	\N	\N	\N	12	6	277
2006-02-15 17:31:00+00	2006-02-15 17:31:00+00	2006-02-15 17:31:00+00	0	123.68	\N	\N	123.68	\N	\N	\N	\N	12	6	279
2007-02-13 19:18:00+00	2007-02-13 19:18:00+00	2007-02-13 19:18:00+00	0	123.81	\N	\N	123.81	\N	\N	\N	\N	12	6	281
2007-08-09 19:30:00+00	2007-08-09 19:30:00+00	2007-08-09 19:30:00+00	0	123.47	\N	\N	123.47	\N	\N	\N	\N	12	6	283
2008-03-06 23:45:00+00	2008-03-06 23:45:00+00	2008-03-06 23:45:00+00	0	123.63	\N	\N	123.63	\N	\N	\N	\N	12	6	285
2008-08-11 22:55:00+00	2008-08-11 22:55:00+00	2008-08-11 22:55:00+00	0	123.9	\N	\N	123.9	\N	\N	\N	\N	12	6	287
2009-03-25 15:20:00+00	2009-03-25 15:20:00+00	2009-03-25 15:20:00+00	0	123.76	\N	\N	123.76	\N	\N	\N	\N	12	6	289
2009-08-04 21:00:00+00	2009-08-04 21:00:00+00	2009-08-04 21:00:00+00	0	123.15	\N	\N	123.15	\N	\N	\N	\N	12	6	291
2010-03-18 19:15:00+00	2010-03-18 19:15:00+00	2010-03-18 19:15:00+00	0	124.57	\N	\N	124.57	\N	\N	\N	\N	12	6	293
2010-09-01 22:40:00+00	2010-09-01 22:40:00+00	2010-09-01 22:40:00+00	0	124.87	\N	\N	124.87	\N	\N	\N	\N	12	6	295
2011-03-10 01:00:00+00	2011-03-10 01:00:00+00	2011-03-10 01:00:00+00	0	125.17	\N	\N	125.17	\N	\N	\N	\N	12	6	297
2011-08-02 19:53:00+00	2011-08-02 19:53:00+00	2011-08-02 19:53:00+00	0	125.24	\N	\N	125.24	\N	\N	\N	\N	12	6	299
2012-03-13 23:00:00+00	2012-03-13 23:00:00+00	2012-03-13 23:00:00+00	0	129.09	\N	\N	129.09	\N	\N	\N	\N	12	6	301
2012-07-19 21:15:00+00	2012-07-19 21:15:00+00	2012-07-19 21:15:00+00	0	125.16	\N	\N	125.16	\N	\N	\N	\N	12	6	303
2013-04-04 19:30:00+00	2013-04-04 19:30:00+00	2013-04-04 19:30:00+00	0	124.84	\N	\N	124.84	\N	\N	\N	\N	12	6	305
2013-08-15 21:40:00+00	2013-08-15 21:40:00+00	2013-08-15 21:40:00+00	0	124.81	\N	\N	124.81	\N	\N	\N	\N	12	6	307
2014-03-20 18:10:00+00	2014-03-20 18:10:00+00	2014-03-20 18:10:00+00	0	124.68	\N	\N	124.68	\N	\N	\N	\N	12	6	309
2014-08-08 21:10:00+00	2014-08-08 21:10:00+00	2014-08-08 21:10:00+00	0	121.3	\N	\N	121.3	\N	\N	\N	\N	12	6	311
2015-02-27 21:45:00+00	2015-02-27 21:45:00+00	2015-02-27 21:45:00+00	0	124.98	\N	\N	124.98	\N	\N	\N	\N	12	6	313
2015-07-23 17:15:00+00	2015-07-23 17:15:00+00	2015-07-23 17:15:00+00	0	124.09	\N	\N	124.09	\N	\N	\N	\N	12	6	315
2016-02-24 21:30:00+00	2016-02-24 21:30:00+00	2016-02-24 21:30:00+00	0	123.89	\N	\N	123.89	\N	\N	\N	\N	12	6	317
2016-07-27 18:15:00+00	2016-07-27 18:15:00+00	2016-07-27 18:15:00+00	0	123.12	\N	\N	123.12	\N	\N	\N	\N	12	6	319
2016-08-11 01:42:00+00	2016-08-11 01:42:00+00	2016-08-11 01:42:00+00	0	128.98	\N	\N	128.98	\N	\N	\N	\N	12	6	321
2017-03-31 21:04:00+00	2017-03-31 21:04:00+00	2017-03-31 21:04:00+00	0	122.96	\N	\N	122.96	\N	\N	\N	\N	12	6	323
2017-08-02 19:32:00+00	2017-08-02 19:32:00+00	2017-08-02 19:32:00+00	0	123.11	\N	\N	123.11	\N	\N	\N	\N	12	6	325
2018-02-07 22:47:00+00	2018-02-07 22:47:00+00	2018-02-07 22:47:00+00	0	122.82	\N	\N	122.82	\N	\N	\N	\N	12	6	327
2019-03-25 23:57:00+00	2019-03-25 23:57:00+00	2019-03-25 23:57:00+00	0	122	\N	\N	122	\N	\N	\N	\N	12	6	329
2020-01-09 17:53:00+00	2020-01-09 17:53:00+00	2020-01-09 17:53:00+00	0	121.64	\N	\N	121.64	\N	\N	\N	\N	12	6	331
2011-05-25 15:39:00+00	2011-05-25 15:39:00+00	2011-05-25 15:39:00+00	0	174.31	\N	\N	174.31	\N	\N	\N	\N	16	8	467
2011-06-22 19:10:00+00	2011-06-22 19:10:00+00	2011-06-22 19:10:00+00	0	174.34	\N	\N	174.34	\N	\N	\N	\N	16	8	469
2011-07-26 21:00:00+00	2011-07-26 21:00:00+00	2011-07-26 21:00:00+00	0	174.17	\N	\N	174.17	\N	\N	\N	\N	16	8	471
2011-09-01 18:10:00+00	2011-09-01 18:10:00+00	2011-09-01 18:10:00+00	0	174.15	\N	\N	174.15	\N	\N	\N	\N	16	8	473
2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	0	174.82	\N	\N	174.82	\N	\N	\N	\N	16	8	475
2011-11-08 21:45:00+00	2011-11-08 21:45:00+00	2011-11-08 21:45:00+00	0	174.73	\N	\N	174.73	\N	\N	\N	\N	16	8	477
2011-12-08 16:30:00+00	2011-12-08 16:30:00+00	2011-12-08 16:30:00+00	0	174.77	\N	\N	174.77	\N	\N	\N	\N	16	8	479
2012-01-10 16:40:00+00	2012-01-10 16:40:00+00	2012-01-10 16:40:00+00	0	174.57	\N	\N	174.57	\N	\N	\N	\N	16	8	481
2012-02-07 23:30:00+00	2012-02-07 23:30:00+00	2012-02-07 23:30:00+00	0	174.52	\N	\N	174.52	\N	\N	\N	\N	16	8	483
2012-03-06 22:40:00+00	2012-03-06 22:40:00+00	2012-03-06 22:40:00+00	0	174.29	\N	\N	174.29	\N	\N	\N	\N	16	8	485
2012-04-12 22:20:00+00	2012-04-12 22:20:00+00	2012-04-12 22:20:00+00	0	175.19	\N	\N	175.19	\N	\N	\N	\N	16	8	487
2012-05-08 22:30:00+00	2012-05-08 22:30:00+00	2012-05-08 22:30:00+00	0	173.6	\N	\N	173.6	\N	\N	\N	\N	16	8	489
2012-08-14 23:00:00+00	2012-08-14 23:00:00+00	2012-08-14 23:00:00+00	0	173.32	\N	\N	173.32	\N	\N	\N	\N	16	8	491
2012-10-09 17:20:00+00	2012-10-09 17:20:00+00	2012-10-09 17:20:00+00	0	173.11	\N	\N	173.11	\N	\N	\N	\N	16	8	493
2013-02-27 00:10:00+00	2013-02-27 00:10:00+00	2013-02-27 00:10:00+00	0	172.62	\N	\N	172.62	\N	\N	\N	\N	16	8	495
2013-04-03 16:50:00+00	2013-04-03 16:50:00+00	2013-04-03 16:50:00+00	0	172.55	\N	\N	172.55	\N	\N	\N	\N	16	8	497
2013-07-10 23:30:00+00	2013-07-10 23:30:00+00	2013-07-10 23:30:00+00	0	172.34	\N	\N	172.34	\N	\N	\N	\N	16	8	499
2013-12-11 21:35:00+00	2013-12-11 21:35:00+00	2013-12-11 21:35:00+00	0	171.79	\N	\N	171.79	\N	\N	\N	\N	16	8	501
2016-08-12 22:20:00+00	2016-08-12 22:20:00+00	2016-08-12 22:20:00+00	0	168.13	\N	\N	168.13	\N	\N	\N	\N	16	8	503
2018-02-06 17:55:00+00	2018-02-06 17:55:00+00	2018-02-06 17:55:00+00	0	166.51	\N	\N	166.51	\N	\N	\N	\N	16	8	505
2018-12-18 23:06:00+00	2018-12-18 23:06:00+00	2018-12-18 23:06:00+00	0	166.7	\N	\N	166.7	\N	\N	\N	\N	16	8	507
2019-12-13 17:10:00+00	2019-12-13 17:10:00+00	2019-12-13 17:10:00+00	0	166.46	\N	\N	166.46	\N	\N	\N	\N	16	8	509
1993-09-21 12:00:00+00	1993-09-21 12:00:00+00	1993-09-21 12:00:00+00	0	5420.4	\N	\N	5420.4	\N	\N	\N	\N	25	13	772
1994-05-22 12:00:00+00	1994-05-22 12:00:00+00	1994-05-22 12:00:00+00	0	5420.8	\N	\N	5420.8	\N	\N	\N	\N	25	13	774
1994-09-18 12:00:00+00	1994-09-18 12:00:00+00	1994-09-18 12:00:00+00	0	5420.4	\N	\N	5420.4	\N	\N	\N	\N	25	13	776
1995-05-22 12:00:00+00	1995-05-22 12:00:00+00	1995-05-22 12:00:00+00	0	5420.3	\N	\N	5420.3	\N	\N	\N	\N	25	13	778
1995-09-11 12:00:00+00	1995-09-11 12:00:00+00	1995-09-11 12:00:00+00	0	5420.2	\N	\N	5420.2	\N	\N	\N	\N	25	13	780
1996-05-28 12:00:00+00	1996-05-28 12:00:00+00	1996-05-28 12:00:00+00	0	5420	\N	\N	5420	\N	\N	\N	\N	25	13	782
1996-09-03 12:00:00+00	1996-09-03 12:00:00+00	1996-09-03 12:00:00+00	0	5419.8	\N	\N	5419.8	\N	\N	\N	\N	25	13	784
1997-03-11 12:00:00+00	1997-03-11 12:00:00+00	1997-03-11 12:00:00+00	0	5419.7	\N	\N	5419.7	\N	\N	\N	\N	25	13	786
1997-05-20 12:00:00+00	1997-05-20 12:00:00+00	1997-05-20 12:00:00+00	0	5419.6	\N	\N	5419.6	\N	\N	\N	\N	25	13	788
1997-09-08 12:00:00+00	1997-09-08 12:00:00+00	1997-09-08 12:00:00+00	0	5420.7	\N	\N	5420.7	\N	\N	\N	\N	25	13	790
1998-05-19 12:00:00+00	1998-05-19 12:00:00+00	1998-05-19 12:00:00+00	0	5421.2	\N	\N	5421.2	\N	\N	\N	\N	25	13	792
1998-08-31 12:00:00+00	1998-08-31 12:00:00+00	1998-08-31 12:00:00+00	0	5420.9	\N	\N	5420.9	\N	\N	\N	\N	25	13	794
1999-06-07 12:00:00+00	1999-06-07 12:00:00+00	1999-06-07 12:00:00+00	0	5422	\N	\N	5422	\N	\N	\N	\N	25	13	796
1999-11-17 12:00:00+00	1999-11-17 12:00:00+00	1999-11-17 12:00:00+00	0	5422.3	\N	\N	5422.3	\N	\N	\N	\N	25	13	798
2000-05-31 12:00:00+00	2000-05-31 12:00:00+00	2000-05-31 12:00:00+00	0	5422	\N	\N	5422	\N	\N	\N	\N	25	13	800
2000-11-14 12:00:00+00	2000-11-14 12:00:00+00	2000-11-14 12:00:00+00	0	5421.4	\N	\N	5421.4	\N	\N	\N	\N	25	13	802
2001-05-21 12:00:00+00	2001-05-21 12:00:00+00	2001-05-21 12:00:00+00	0	5421.4	\N	\N	5421.4	\N	\N	\N	\N	25	13	804
2001-11-06 12:00:00+00	2001-11-06 12:00:00+00	2001-11-06 12:00:00+00	0	5421	\N	\N	5421	\N	\N	\N	\N	25	13	806
2002-05-14 12:00:00+00	2002-05-14 12:00:00+00	2002-05-14 12:00:00+00	0	5420.9	\N	\N	5420.9	\N	\N	\N	\N	25	13	808
2006-07-18 22:50:00+00	2006-07-18 22:50:00+00	2006-07-18 22:50:00+00	0	5421.8	\N	\N	5421.8	\N	\N	\N	\N	25	13	810
2007-03-05 20:48:00+00	2007-03-05 20:48:00+00	2007-03-05 20:48:00+00	0	5421.8	\N	\N	5421.8	\N	\N	\N	\N	25	13	812
2007-08-07 20:00:00+00	2007-08-07 20:00:00+00	2007-08-07 20:00:00+00	0	5421.8	\N	\N	5421.8	\N	\N	\N	\N	25	13	814
2008-03-26 00:40:00+00	2008-03-26 00:40:00+00	2008-03-26 00:40:00+00	0	5422.9	\N	\N	5422.9	\N	\N	\N	\N	25	13	816
2008-08-11 19:00:00+00	2008-08-11 19:00:00+00	2008-08-11 19:00:00+00	0	5422.6	\N	\N	5422.6	\N	\N	\N	\N	25	13	818
2009-03-24 14:03:00+00	2009-03-24 14:03:00+00	2009-03-24 14:03:00+00	0	5422.5	\N	\N	5422.5	\N	\N	\N	\N	25	13	820
2009-08-03 19:30:00+00	2009-08-03 19:30:00+00	2009-08-03 19:30:00+00	0	5422.1	\N	\N	5422.1	\N	\N	\N	\N	25	13	822
2010-03-16 17:10:00+00	2010-03-16 17:10:00+00	2010-03-16 17:10:00+00	0	5421.9	\N	\N	5421.9	\N	\N	\N	\N	25	13	824
2010-09-01 18:30:00+00	2010-09-01 18:30:00+00	2010-09-01 18:30:00+00	0	5421.7	\N	\N	5421.7	\N	\N	\N	\N	25	13	826
2011-01-25 15:15:00+00	2011-01-25 15:15:00+00	2011-01-25 15:15:00+00	0	5421.8	\N	\N	5421.8	\N	\N	\N	\N	25	13	828
2011-06-21 19:30:00+00	2011-06-21 19:30:00+00	2011-06-21 19:30:00+00	0	5422	\N	\N	5422	\N	\N	\N	\N	25	13	830
2012-03-15 22:00:00+00	2012-03-15 22:00:00+00	2012-03-15 22:00:00+00	0	5421.6	\N	\N	5421.6	\N	\N	\N	\N	25	13	832
2013-04-08 18:30:00+00	2013-04-08 18:30:00+00	2013-04-08 18:30:00+00	0	5421.8	\N	\N	5421.8	\N	\N	\N	\N	25	13	834
2014-08-08 17:00:00+00	2014-08-08 17:00:00+00	2014-08-08 17:00:00+00	0	5423.4	\N	\N	5423.4	\N	\N	\N	\N	25	13	836
2015-02-24 21:15:00+00	2015-02-24 21:15:00+00	2015-02-24 21:15:00+00	0	5424.2	\N	\N	5424.2	\N	\N	\N	\N	25	13	838
2016-02-22 16:30:00+00	2016-02-22 16:30:00+00	2016-02-22 16:30:00+00	0	5427.6	\N	\N	5427.6	\N	\N	\N	\N	25	13	840
2016-07-26 20:00:00+00	2016-07-26 20:00:00+00	2016-07-26 20:00:00+00	0	5426.3	\N	\N	5426.3	\N	\N	\N	\N	25	13	842
2017-03-29 21:50:00+00	2017-03-29 21:50:00+00	2017-03-29 21:50:00+00	0	5425.7	\N	\N	5425.7	\N	\N	\N	\N	25	13	844
2018-02-06 15:13:00+00	2018-02-06 15:13:00+00	2018-02-06 15:13:00+00	0	5425.1	\N	\N	5425.1	\N	\N	\N	\N	25	13	846
2018-12-19 20:37:00+00	2018-12-19 20:37:00+00	2018-12-19 20:37:00+00	0	5424.4	\N	\N	5424.4	\N	\N	\N	\N	25	13	848
2019-12-12 15:35:00+00	2019-12-12 15:35:00+00	2019-12-12 15:35:00+00	0	5423.8	\N	\N	5423.8	\N	\N	\N	\N	25	13	850
1999-09-21 00:00:00+00	1999-09-21 00:00:00+00	1999-09-21 00:00:00+00	0	32.01	\N	\N	32.01	\N	\N	\N	\N	32	16	15675
1999-09-22 00:00:00+00	1999-09-22 00:00:00+00	1999-09-22 00:00:00+00	0	31.94	\N	\N	31.94	\N	\N	\N	\N	32	16	15677
1999-09-23 00:00:00+00	1999-09-23 00:00:00+00	1999-09-23 00:00:00+00	0	31.86	\N	\N	31.86	\N	\N	\N	\N	32	16	15679
1999-09-24 00:00:00+00	1999-09-24 00:00:00+00	1999-09-24 00:00:00+00	0	31.82	\N	\N	31.82	\N	\N	\N	\N	32	16	15681
1999-09-25 00:00:00+00	1999-09-25 00:00:00+00	1999-09-25 00:00:00+00	0	31.77	\N	\N	31.77	\N	\N	\N	\N	32	16	15683
1999-09-26 00:00:00+00	1999-09-26 00:00:00+00	1999-09-26 00:00:00+00	0	31.7	\N	\N	31.7	\N	\N	\N	\N	32	16	15685
1999-09-27 00:00:00+00	1999-09-27 00:00:00+00	1999-09-27 00:00:00+00	0	31.66	\N	\N	31.66	\N	\N	\N	\N	32	16	15687
1999-09-28 00:00:00+00	1999-09-28 00:00:00+00	1999-09-28 00:00:00+00	0	31.68	\N	\N	31.68	\N	\N	\N	\N	32	16	15689
1999-09-29 00:00:00+00	1999-09-29 00:00:00+00	1999-09-29 00:00:00+00	0	31.71	\N	\N	31.71	\N	\N	\N	\N	32	16	15691
1999-09-30 00:00:00+00	1999-09-30 00:00:00+00	1999-09-30 00:00:00+00	0	31.95	\N	\N	31.95	\N	\N	\N	\N	32	16	15693
1999-10-01 00:00:00+00	1999-10-01 00:00:00+00	1999-10-01 00:00:00+00	0	31.49	\N	\N	31.49	\N	\N	\N	\N	32	16	15695
1999-10-02 00:00:00+00	1999-10-02 00:00:00+00	1999-10-02 00:00:00+00	0	31.47	\N	\N	31.47	\N	\N	\N	\N	32	16	15697
1999-10-03 00:00:00+00	1999-10-03 00:00:00+00	1999-10-03 00:00:00+00	0	31.45	\N	\N	31.45	\N	\N	\N	\N	32	16	15699
1999-10-04 00:00:00+00	1999-10-04 00:00:00+00	1999-10-04 00:00:00+00	0	31.47	\N	\N	31.47	\N	\N	\N	\N	32	16	15701
1999-10-05 00:00:00+00	1999-10-05 00:00:00+00	1999-10-05 00:00:00+00	0	31.41	\N	\N	31.41	\N	\N	\N	\N	32	16	15703
1999-10-06 00:00:00+00	1999-10-06 00:00:00+00	1999-10-06 00:00:00+00	0	31.33	\N	\N	31.33	\N	\N	\N	\N	32	16	15705
1999-10-07 00:00:00+00	1999-10-07 00:00:00+00	1999-10-07 00:00:00+00	0	31.23	\N	\N	31.23	\N	\N	\N	\N	32	16	15707
1999-10-08 00:00:00+00	1999-10-08 00:00:00+00	1999-10-08 00:00:00+00	0	31.25	\N	\N	31.25	\N	\N	\N	\N	32	16	15709
1999-10-09 00:00:00+00	1999-10-09 00:00:00+00	1999-10-09 00:00:00+00	0	31.24	\N	\N	31.24	\N	\N	\N	\N	32	16	15711
1999-10-10 00:00:00+00	1999-10-10 00:00:00+00	1999-10-10 00:00:00+00	0	31.2	\N	\N	31.2	\N	\N	\N	\N	32	16	15713
1999-10-11 00:00:00+00	1999-10-11 00:00:00+00	1999-10-11 00:00:00+00	0	31.16	\N	\N	31.16	\N	\N	\N	\N	32	16	15715
1999-10-12 00:00:00+00	1999-10-12 00:00:00+00	1999-10-12 00:00:00+00	0	31.11	\N	\N	31.11	\N	\N	\N	\N	32	16	15717
1999-10-13 00:00:00+00	1999-10-13 00:00:00+00	1999-10-13 00:00:00+00	0	31.03	\N	\N	31.03	\N	\N	\N	\N	32	16	15719
1999-10-14 00:00:00+00	1999-10-14 00:00:00+00	1999-10-14 00:00:00+00	0	30.97	\N	\N	30.97	\N	\N	\N	\N	32	16	15721
1999-10-15 00:00:00+00	1999-10-15 00:00:00+00	1999-10-15 00:00:00+00	0	30.87	\N	\N	30.87	\N	\N	\N	\N	32	16	15723
1999-10-16 00:00:00+00	1999-10-16 00:00:00+00	1999-10-16 00:00:00+00	0	30.86	\N	\N	30.86	\N	\N	\N	\N	32	16	15725
1999-10-17 00:00:00+00	1999-10-17 00:00:00+00	1999-10-17 00:00:00+00	0	30.85	\N	\N	30.85	\N	\N	\N	\N	32	16	15727
1999-10-18 00:00:00+00	1999-10-18 00:00:00+00	1999-10-18 00:00:00+00	0	30.78	\N	\N	30.78	\N	\N	\N	\N	32	16	15729
1999-10-19 00:00:00+00	1999-10-19 00:00:00+00	1999-10-19 00:00:00+00	0	30.73	\N	\N	30.73	\N	\N	\N	\N	32	16	15731
1999-10-20 00:00:00+00	1999-10-20 00:00:00+00	1999-10-20 00:00:00+00	0	30.71	\N	\N	30.71	\N	\N	\N	\N	32	16	15733
1999-10-21 00:00:00+00	1999-10-21 00:00:00+00	1999-10-21 00:00:00+00	0	30.65	\N	\N	30.65	\N	\N	\N	\N	32	16	15735
1999-10-22 00:00:00+00	1999-10-22 00:00:00+00	1999-10-22 00:00:00+00	0	30.59	\N	\N	30.59	\N	\N	\N	\N	32	16	15737
1999-10-23 00:00:00+00	1999-10-23 00:00:00+00	1999-10-23 00:00:00+00	0	30.59	\N	\N	30.59	\N	\N	\N	\N	32	16	15739
1999-10-24 00:00:00+00	1999-10-24 00:00:00+00	1999-10-24 00:00:00+00	0	30.57	\N	\N	30.57	\N	\N	\N	\N	32	16	15741
1999-10-25 00:00:00+00	1999-10-25 00:00:00+00	1999-10-25 00:00:00+00	0	30.57	\N	\N	30.57	\N	\N	\N	\N	32	16	15743
1999-10-26 00:00:00+00	1999-10-26 00:00:00+00	1999-10-26 00:00:00+00	0	30.57	\N	\N	30.57	\N	\N	\N	\N	32	16	15745
1999-10-27 00:00:00+00	1999-10-27 00:00:00+00	1999-10-27 00:00:00+00	0	30.53	\N	\N	30.53	\N	\N	\N	\N	32	16	15747
1999-10-28 00:00:00+00	1999-10-28 00:00:00+00	1999-10-28 00:00:00+00	0	30.54	\N	\N	30.54	\N	\N	\N	\N	32	16	15749
1999-10-29 00:00:00+00	1999-10-29 00:00:00+00	1999-10-29 00:00:00+00	0	30.51	\N	\N	30.51	\N	\N	\N	\N	32	16	15751
1999-10-30 00:00:00+00	1999-10-30 00:00:00+00	1999-10-30 00:00:00+00	0	30.57	\N	\N	30.57	\N	\N	\N	\N	32	16	15753
1999-10-31 00:00:00+00	1999-10-31 00:00:00+00	1999-10-31 00:00:00+00	0	30.57	\N	\N	30.57	\N	\N	\N	\N	32	16	15755
1999-11-01 00:00:00+00	1999-11-01 00:00:00+00	1999-11-01 00:00:00+00	0	30.55	\N	\N	30.55	\N	\N	\N	\N	32	16	15757
1999-11-02 00:00:00+00	1999-11-02 00:00:00+00	1999-11-02 00:00:00+00	0	30.62	\N	\N	30.62	\N	\N	\N	\N	32	16	15759
1999-11-03 00:00:00+00	1999-11-03 00:00:00+00	1999-11-03 00:00:00+00	0	30.56	\N	\N	30.56	\N	\N	\N	\N	32	16	15761
1999-11-04 00:00:00+00	1999-11-04 00:00:00+00	1999-11-04 00:00:00+00	0	30.55	\N	\N	30.55	\N	\N	\N	\N	32	16	15763
1999-11-05 00:00:00+00	1999-11-05 00:00:00+00	1999-11-05 00:00:00+00	0	30.6	\N	\N	30.6	\N	\N	\N	\N	32	16	15765
1999-11-06 00:00:00+00	1999-11-06 00:00:00+00	1999-11-06 00:00:00+00	0	30.62	\N	\N	30.62	\N	\N	\N	\N	32	16	15767
1999-11-07 00:00:00+00	1999-11-07 00:00:00+00	1999-11-07 00:00:00+00	0	30.62	\N	\N	30.62	\N	\N	\N	\N	32	16	15769
1999-11-08 00:00:00+00	1999-11-08 00:00:00+00	1999-11-08 00:00:00+00	0	30.58	\N	\N	30.58	\N	\N	\N	\N	32	16	15771
1999-11-09 00:00:00+00	1999-11-09 00:00:00+00	1999-11-09 00:00:00+00	0	30.58	\N	\N	30.58	\N	\N	\N	\N	32	16	15773
1999-11-10 00:00:00+00	1999-11-10 00:00:00+00	1999-11-10 00:00:00+00	0	30.61	\N	\N	30.61	\N	\N	\N	\N	32	16	15775
1999-11-11 00:00:00+00	1999-11-11 00:00:00+00	1999-11-11 00:00:00+00	0	30.64	\N	\N	30.64	\N	\N	\N	\N	32	16	15777
1999-11-12 00:00:00+00	1999-11-12 00:00:00+00	1999-11-12 00:00:00+00	0	30.65	\N	\N	30.65	\N	\N	\N	\N	32	16	15779
1999-11-13 00:00:00+00	1999-11-13 00:00:00+00	1999-11-13 00:00:00+00	0	30.65	\N	\N	30.65	\N	\N	\N	\N	32	16	15781
1999-11-14 00:00:00+00	1999-11-14 00:00:00+00	1999-11-14 00:00:00+00	0	30.67	\N	\N	30.67	\N	\N	\N	\N	32	16	15783
1999-11-15 00:00:00+00	1999-11-15 00:00:00+00	1999-11-15 00:00:00+00	0	30.67	\N	\N	30.67	\N	\N	\N	\N	32	16	15785
1999-11-16 00:00:00+00	1999-11-16 00:00:00+00	1999-11-16 00:00:00+00	0	30.65	\N	\N	30.65	\N	\N	\N	\N	32	16	15787
1999-11-17 00:00:00+00	1999-11-17 00:00:00+00	1999-11-17 00:00:00+00	0	30.64	\N	\N	30.64	\N	\N	\N	\N	32	16	15789
1999-11-18 00:00:00+00	1999-11-18 00:00:00+00	1999-11-18 00:00:00+00	0	30.67	\N	\N	30.67	\N	\N	\N	\N	32	16	15791
1999-11-19 00:00:00+00	1999-11-19 00:00:00+00	1999-11-19 00:00:00+00	0	30.71	\N	\N	30.71	\N	\N	\N	\N	32	16	15793
1999-11-20 00:00:00+00	1999-11-20 00:00:00+00	1999-11-20 00:00:00+00	0	30.69	\N	\N	30.69	\N	\N	\N	\N	32	16	15795
1999-11-21 00:00:00+00	1999-11-21 00:00:00+00	1999-11-21 00:00:00+00	0	30.61	\N	\N	30.61	\N	\N	\N	\N	32	16	15797
1999-11-22 00:00:00+00	1999-11-22 00:00:00+00	1999-11-22 00:00:00+00	0	30.69	\N	\N	30.69	\N	\N	\N	\N	32	16	15799
1999-11-23 00:00:00+00	1999-11-23 00:00:00+00	1999-11-23 00:00:00+00	0	30.71	\N	\N	30.71	\N	\N	\N	\N	32	16	15801
1999-11-24 00:00:00+00	1999-11-24 00:00:00+00	1999-11-24 00:00:00+00	0	30.73	\N	\N	30.73	\N	\N	\N	\N	32	16	15803
1999-11-25 00:00:00+00	1999-11-25 00:00:00+00	1999-11-25 00:00:00+00	0	30.74	\N	\N	30.74	\N	\N	\N	\N	32	16	15805
1999-11-26 00:00:00+00	1999-11-26 00:00:00+00	1999-11-26 00:00:00+00	0	30.7	\N	\N	30.7	\N	\N	\N	\N	32	16	15807
1999-11-27 00:00:00+00	1999-11-27 00:00:00+00	1999-11-27 00:00:00+00	0	30.71	\N	\N	30.71	\N	\N	\N	\N	32	16	15809
1999-11-28 00:00:00+00	1999-11-28 00:00:00+00	1999-11-28 00:00:00+00	0	30.77	\N	\N	30.77	\N	\N	\N	\N	32	16	15811
1999-11-29 00:00:00+00	1999-11-29 00:00:00+00	1999-11-29 00:00:00+00	0	30.81	\N	\N	30.81	\N	\N	\N	\N	32	16	15813
1999-11-30 00:00:00+00	1999-11-30 00:00:00+00	1999-11-30 00:00:00+00	0	30.81	\N	\N	30.81	\N	\N	\N	\N	32	16	15815
1999-12-01 00:00:00+00	1999-12-01 00:00:00+00	1999-12-01 00:00:00+00	0	30.71	\N	\N	30.71	\N	\N	\N	\N	32	16	15817
1999-12-02 00:00:00+00	1999-12-02 00:00:00+00	1999-12-02 00:00:00+00	0	30.64	\N	\N	30.64	\N	\N	\N	\N	32	16	15819
1999-12-03 00:00:00+00	1999-12-03 00:00:00+00	1999-12-03 00:00:00+00	0	30.65	\N	\N	30.65	\N	\N	\N	\N	32	16	15821
1999-12-04 00:00:00+00	1999-12-04 00:00:00+00	1999-12-04 00:00:00+00	0	30.73	\N	\N	30.73	\N	\N	\N	\N	32	16	15823
1999-12-05 00:00:00+00	1999-12-05 00:00:00+00	1999-12-05 00:00:00+00	0	30.76	\N	\N	30.76	\N	\N	\N	\N	32	16	15825
1999-12-06 00:00:00+00	1999-12-06 00:00:00+00	1999-12-06 00:00:00+00	0	30.72	\N	\N	30.72	\N	\N	\N	\N	32	16	15827
1999-12-07 00:00:00+00	1999-12-07 00:00:00+00	1999-12-07 00:00:00+00	0	30.67	\N	\N	30.67	\N	\N	\N	\N	32	16	15829
1999-12-08 00:00:00+00	1999-12-08 00:00:00+00	1999-12-08 00:00:00+00	0	30.73	\N	\N	30.73	\N	\N	\N	\N	32	16	15831
1999-12-09 00:00:00+00	1999-12-09 00:00:00+00	1999-12-09 00:00:00+00	0	30.73	\N	\N	30.73	\N	\N	\N	\N	32	16	15833
1999-12-10 00:00:00+00	1999-12-10 00:00:00+00	1999-12-10 00:00:00+00	0	30.72	\N	\N	30.72	\N	\N	\N	\N	32	16	15835
1999-12-11 00:00:00+00	1999-12-11 00:00:00+00	1999-12-11 00:00:00+00	0	30.67	\N	\N	30.67	\N	\N	\N	\N	32	16	15837
1999-12-12 00:00:00+00	1999-12-12 00:00:00+00	1999-12-12 00:00:00+00	0	30.72	\N	\N	30.72	\N	\N	\N	\N	32	16	15839
1999-12-13 00:00:00+00	1999-12-13 00:00:00+00	1999-12-13 00:00:00+00	0	30.72	\N	\N	30.72	\N	\N	\N	\N	32	16	15841
1999-12-14 00:00:00+00	1999-12-14 00:00:00+00	1999-12-14 00:00:00+00	0	30.75	\N	\N	30.75	\N	\N	\N	\N	32	16	15843
1999-12-15 00:00:00+00	1999-12-15 00:00:00+00	1999-12-15 00:00:00+00	0	30.78	\N	\N	30.78	\N	\N	\N	\N	32	16	15845
1999-12-16 00:00:00+00	1999-12-16 00:00:00+00	1999-12-16 00:00:00+00	0	30.75	\N	\N	30.75	\N	\N	\N	\N	32	16	15847
1999-12-17 00:00:00+00	1999-12-17 00:00:00+00	1999-12-17 00:00:00+00	0	30.76	\N	\N	30.76	\N	\N	\N	\N	32	16	15849
1999-12-18 00:00:00+00	1999-12-18 00:00:00+00	1999-12-18 00:00:00+00	0	30.75	\N	\N	30.75	\N	\N	\N	\N	32	16	15851
1999-12-19 00:00:00+00	1999-12-19 00:00:00+00	1999-12-19 00:00:00+00	0	30.74	\N	\N	30.74	\N	\N	\N	\N	32	16	15853
1999-12-20 00:00:00+00	1999-12-20 00:00:00+00	1999-12-20 00:00:00+00	0	30.74	\N	\N	30.74	\N	\N	\N	\N	32	16	15855
1999-12-21 00:00:00+00	1999-12-21 00:00:00+00	1999-12-21 00:00:00+00	0	30.76	\N	\N	30.76	\N	\N	\N	\N	32	16	15857
1999-12-22 00:00:00+00	1999-12-22 00:00:00+00	1999-12-22 00:00:00+00	0	30.82	\N	\N	30.82	\N	\N	\N	\N	32	16	15859
1999-12-23 00:00:00+00	1999-12-23 00:00:00+00	1999-12-23 00:00:00+00	0	30.85	\N	\N	30.85	\N	\N	\N	\N	32	16	15861
1999-12-24 00:00:00+00	1999-12-24 00:00:00+00	1999-12-24 00:00:00+00	0	30.85	\N	\N	30.85	\N	\N	\N	\N	32	16	15863
1999-12-25 00:00:00+00	1999-12-25 00:00:00+00	1999-12-25 00:00:00+00	0	30.81	\N	\N	30.81	\N	\N	\N	\N	32	16	15865
1999-12-26 00:00:00+00	1999-12-26 00:00:00+00	1999-12-26 00:00:00+00	0	30.81	\N	\N	30.81	\N	\N	\N	\N	32	16	15867
1999-12-27 00:00:00+00	1999-12-27 00:00:00+00	1999-12-27 00:00:00+00	0	30.78	\N	\N	30.78	\N	\N	\N	\N	32	16	15869
1999-12-28 00:00:00+00	1999-12-28 00:00:00+00	1999-12-28 00:00:00+00	0	30.78	\N	\N	30.78	\N	\N	\N	\N	32	16	15871
1999-12-29 00:00:00+00	1999-12-29 00:00:00+00	1999-12-29 00:00:00+00	0	30.72	\N	\N	30.72	\N	\N	\N	\N	32	16	15873
1975-07-08 12:00:00+00	1975-07-08 12:00:00+00	1975-07-08 12:00:00+00	0	137	\N	\N	137	\N	\N	\N	\N	64	32	95689
1982-12-16 12:00:00+00	1982-12-16 12:00:00+00	1982-12-16 12:00:00+00	0	137.2	\N	\N	137.2	\N	\N	\N	\N	64	32	95691
1983-01-27 12:00:00+00	1983-01-27 12:00:00+00	1983-01-27 12:00:00+00	0	136.79	\N	\N	136.79	\N	\N	\N	\N	64	32	95693
1983-02-24 12:00:00+00	1983-02-24 12:00:00+00	1983-02-24 12:00:00+00	0	136.75	\N	\N	136.75	\N	\N	\N	\N	64	32	95695
1983-03-30 12:00:00+00	1983-03-30 12:00:00+00	1983-03-30 12:00:00+00	0	137.04	\N	\N	137.04	\N	\N	\N	\N	64	32	95697
1983-04-26 12:00:00+00	1983-04-26 12:00:00+00	1983-04-26 12:00:00+00	0	136.72	\N	\N	136.72	\N	\N	\N	\N	64	32	95699
1983-05-31 12:00:00+00	1983-05-31 12:00:00+00	1983-05-31 12:00:00+00	0	136.64	\N	\N	136.64	\N	\N	\N	\N	64	32	95701
1983-07-11 12:00:00+00	1983-07-11 12:00:00+00	1983-07-11 12:00:00+00	0	137.01	\N	\N	137.01	\N	\N	\N	\N	64	32	95703
1983-08-01 12:00:00+00	1983-08-01 12:00:00+00	1983-08-01 12:00:00+00	0	137.08	\N	\N	137.08	\N	\N	\N	\N	64	32	95705
1983-10-07 12:00:00+00	1983-10-07 12:00:00+00	1983-10-07 12:00:00+00	0	137.1	\N	\N	137.1	\N	\N	\N	\N	64	32	95707
1983-12-02 12:00:00+00	1983-12-02 12:00:00+00	1983-12-02 12:00:00+00	0	136.86	\N	\N	136.86	\N	\N	\N	\N	64	32	95709
1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	0	136.55	\N	\N	136.55	\N	\N	\N	\N	64	32	95711
1984-03-01 12:00:00+00	1984-03-01 12:00:00+00	1984-03-01 12:00:00+00	0	136.69	\N	\N	136.69	\N	\N	\N	\N	64	32	95713
1984-04-30 12:00:00+00	1984-04-30 12:00:00+00	1984-04-30 12:00:00+00	0	137.05	\N	\N	137.05	\N	\N	\N	\N	64	32	95715
1984-06-10 12:00:00+00	1984-06-10 12:00:00+00	1984-06-10 12:00:00+00	0	136.94	\N	\N	136.94	\N	\N	\N	\N	64	32	95717
1984-07-30 12:00:00+00	1984-07-30 12:00:00+00	1984-07-30 12:00:00+00	0	139.24	\N	\N	139.24	\N	\N	\N	\N	64	32	95719
1985-02-28 12:00:00+00	1985-02-28 12:00:00+00	1985-02-28 12:00:00+00	0	136.88	\N	\N	136.88	\N	\N	\N	\N	64	32	95721
1985-04-23 12:00:00+00	1985-04-23 12:00:00+00	1985-04-23 12:00:00+00	0	136.52	\N	\N	136.52	\N	\N	\N	\N	64	32	95723
1985-09-05 12:00:00+00	1985-09-05 12:00:00+00	1985-09-05 12:00:00+00	0	136.97	\N	\N	136.97	\N	\N	\N	\N	64	32	95725
1986-01-29 12:00:00+00	1986-01-29 12:00:00+00	1986-01-29 12:00:00+00	0	136.73	\N	\N	136.73	\N	\N	\N	\N	64	32	95727
1986-05-30 12:00:00+00	1986-05-30 12:00:00+00	1986-05-30 12:00:00+00	0	136.9	\N	\N	136.9	\N	\N	\N	\N	64	32	95729
1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	1986-08-01 12:00:00+00	0	136.21	\N	\N	136.21	\N	\N	\N	\N	64	32	95731
1987-01-21 12:00:00+00	1987-01-21 12:00:00+00	1987-01-21 12:00:00+00	0	136.85	\N	\N	136.85	\N	\N	\N	\N	64	32	95733
1987-06-30 12:00:00+00	1987-06-30 12:00:00+00	1987-06-30 12:00:00+00	0	136.75	\N	\N	136.75	\N	\N	\N	\N	64	32	95735
1987-07-30 12:00:00+00	1987-07-30 12:00:00+00	1987-07-30 12:00:00+00	0	138.84	\N	\N	138.84	\N	\N	\N	\N	64	32	95737
1987-12-30 12:00:00+00	1987-12-30 12:00:00+00	1987-12-30 12:00:00+00	0	136.75	\N	\N	136.75	\N	\N	\N	\N	64	32	95739
1988-07-26 12:00:00+00	1988-07-26 12:00:00+00	1988-07-26 12:00:00+00	0	139.78	\N	\N	139.78	\N	\N	\N	\N	64	32	95741
1989-01-30 12:00:00+00	1989-01-30 12:00:00+00	1989-01-30 12:00:00+00	0	137.08	\N	\N	137.08	\N	\N	\N	\N	64	32	95743
1989-07-07 12:00:00+00	1989-07-07 12:00:00+00	1989-07-07 12:00:00+00	0	137.32	\N	\N	137.32	\N	\N	\N	\N	64	32	95745
1990-02-09 12:00:00+00	1990-02-09 12:00:00+00	1990-02-09 12:00:00+00	0	137.17	\N	\N	137.17	\N	\N	\N	\N	64	32	95747
1990-07-06 12:00:00+00	1990-07-06 12:00:00+00	1990-07-06 12:00:00+00	0	137.19	\N	\N	137.19	\N	\N	\N	\N	64	32	95749
1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	0	137.2	\N	\N	137.2	\N	\N	\N	\N	64	32	95751
1991-07-02 12:00:00+00	1991-07-02 12:00:00+00	1991-07-02 12:00:00+00	0	139.36	\N	\N	139.36	\N	\N	\N	\N	64	32	95753
1991-07-20 12:00:00+00	1991-07-20 12:00:00+00	1991-07-20 12:00:00+00	0	139.36	\N	\N	139.36	\N	\N	\N	\N	64	32	95755
1991-10-02 12:00:00+00	1991-10-02 12:00:00+00	1991-10-02 12:00:00+00	0	136.72	\N	\N	136.72	\N	\N	\N	\N	64	32	95757
1992-01-09 12:00:00+00	1992-01-09 12:00:00+00	1992-01-09 12:00:00+00	0	136.92	\N	\N	136.92	\N	\N	\N	\N	64	32	95759
1992-07-14 12:00:00+00	1992-07-14 12:00:00+00	1992-07-14 12:00:00+00	0	136.79	\N	\N	136.79	\N	\N	\N	\N	64	32	95761
1993-01-12 12:00:00+00	1993-01-12 12:00:00+00	1993-01-12 12:00:00+00	0	136.7	\N	\N	136.7	\N	\N	\N	\N	64	32	95763
1993-06-30 12:00:00+00	1993-06-30 12:00:00+00	1993-06-30 12:00:00+00	0	136.6	\N	\N	136.6	\N	\N	\N	\N	64	32	95765
1993-12-30 12:00:00+00	1993-12-30 12:00:00+00	1993-12-30 12:00:00+00	0	136.9	\N	\N	136.9	\N	\N	\N	\N	64	32	95767
1994-06-30 12:00:00+00	1994-06-30 12:00:00+00	1994-06-30 12:00:00+00	0	136.71	\N	\N	136.71	\N	\N	\N	\N	64	32	95769
1995-01-20 12:00:00+00	1995-01-20 12:00:00+00	1995-01-20 12:00:00+00	0	136.71	\N	\N	136.71	\N	\N	\N	\N	64	32	95771
1995-06-29 12:00:00+00	1995-06-29 12:00:00+00	1995-06-29 12:00:00+00	0	136.83	\N	\N	136.83	\N	\N	\N	\N	64	32	95773
1995-10-31 12:00:00+00	1995-10-31 12:00:00+00	1995-10-31 12:00:00+00	0	136.64	\N	\N	136.64	\N	\N	\N	\N	64	32	95775
1996-01-25 12:00:00+00	1996-01-25 12:00:00+00	1996-01-25 12:00:00+00	0	136.48	\N	\N	136.48	\N	\N	\N	\N	64	32	95777
1996-09-24 12:00:00+00	1996-09-24 12:00:00+00	1996-09-24 12:00:00+00	0	137.16	\N	\N	137.16	\N	\N	\N	\N	64	32	95779
1997-04-29 12:00:00+00	1997-04-29 12:00:00+00	1997-04-29 12:00:00+00	0	136.83	\N	\N	136.83	\N	\N	\N	\N	64	32	95781
1998-02-12 12:00:00+00	1998-02-12 12:00:00+00	1998-02-12 12:00:00+00	0	136.69	\N	\N	136.69	\N	\N	\N	\N	64	32	95783
1998-07-29 12:00:00+00	1998-07-29 12:00:00+00	1998-07-29 12:00:00+00	0	137.34	\N	\N	137.34	\N	\N	\N	\N	64	32	95785
1999-07-20 12:00:00+00	1999-07-20 12:00:00+00	1999-07-20 12:00:00+00	0	137.47	\N	\N	137.47	\N	\N	\N	\N	64	32	95787
2000-02-10 12:00:00+00	2000-02-10 12:00:00+00	2000-02-10 12:00:00+00	0	137.52	\N	\N	137.52	\N	\N	\N	\N	64	32	95789
2000-08-23 12:00:00+00	2000-08-23 12:00:00+00	2000-08-23 12:00:00+00	0	137.01	\N	\N	137.01	\N	\N	\N	\N	64	32	95791
2000-12-11 12:00:00+00	2000-12-11 12:00:00+00	2000-12-11 12:00:00+00	0	136.8	\N	\N	136.8	\N	\N	\N	\N	64	32	95793
2001-06-11 12:00:00+00	2001-06-11 12:00:00+00	2001-06-11 12:00:00+00	0	136.88	\N	\N	136.88	\N	\N	\N	\N	64	32	95795
2001-12-19 12:00:00+00	2001-12-19 12:00:00+00	2001-12-19 12:00:00+00	0	137.32	\N	\N	137.32	\N	\N	\N	\N	64	32	95797
2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	0	137.22	\N	\N	137.22	\N	\N	\N	\N	64	32	95799
2003-09-29 12:00:00+00	2003-09-29 12:00:00+00	2003-09-29 12:00:00+00	0	137.72	\N	\N	137.72	\N	\N	\N	\N	64	32	95801
2004-03-08 12:00:00+00	2004-03-08 12:00:00+00	2004-03-08 12:00:00+00	0	137.74	\N	\N	137.74	\N	\N	\N	\N	64	32	95803
2004-09-16 12:00:00+00	2004-09-16 12:00:00+00	2004-09-16 12:00:00+00	0	137.92	\N	\N	137.92	\N	\N	\N	\N	64	32	95805
2005-03-18 12:00:00+00	2005-03-18 12:00:00+00	2005-03-18 12:00:00+00	0	137.17	\N	\N	137.17	\N	\N	\N	\N	64	32	95807
2005-09-08 12:00:00+00	2005-09-08 12:00:00+00	2005-09-08 12:00:00+00	0	138.46	\N	\N	138.46	\N	\N	\N	\N	64	32	95809
2006-02-23 12:00:00+00	2006-02-23 12:00:00+00	2006-02-23 12:00:00+00	0	137.7	\N	\N	137.7	\N	\N	\N	\N	64	32	95811
2006-09-11 12:00:00+00	2006-09-11 12:00:00+00	2006-09-11 12:00:00+00	0	137.92	\N	\N	137.92	\N	\N	\N	\N	64	32	95813
2007-03-05 12:00:00+00	2007-03-05 12:00:00+00	2007-03-05 12:00:00+00	0	137.79	\N	\N	137.79	\N	\N	\N	\N	64	32	95815
2007-08-26 12:00:00+00	2007-08-26 12:00:00+00	2007-08-26 12:00:00+00	0	137.8	\N	\N	137.8	\N	\N	\N	\N	64	32	95817
2008-03-28 12:00:00+00	2008-03-28 12:00:00+00	2008-03-28 12:00:00+00	0	137.5	\N	\N	137.5	\N	\N	\N	\N	64	32	95819
2008-08-28 12:00:00+00	2008-08-28 12:00:00+00	2008-08-28 12:00:00+00	0	137.72	\N	\N	137.72	\N	\N	\N	\N	64	32	95821
2009-02-23 12:00:00+00	2009-02-23 12:00:00+00	2009-02-23 12:00:00+00	0	137.62	\N	\N	137.62	\N	\N	\N	\N	64	32	95823
2009-08-24 12:00:00+00	2009-08-24 12:00:00+00	2009-08-24 12:00:00+00	0	137.78	\N	\N	137.78	\N	\N	\N	\N	64	32	95825
2010-02-23 12:00:00+00	2010-02-23 12:00:00+00	2010-02-23 12:00:00+00	0	137.59	\N	\N	137.59	\N	\N	\N	\N	64	32	95827
2010-08-30 12:00:00+00	2010-08-30 12:00:00+00	2010-08-30 12:00:00+00	0	137.51	\N	\N	137.51	\N	\N	\N	\N	64	32	95829
2011-02-16 17:02:00+00	2011-02-16 17:02:00+00	2011-02-16 17:02:00+00	0	137.25	\N	\N	137.25	\N	\N	\N	\N	64	32	95831
2011-09-09 15:57:00+00	2011-09-09 15:57:00+00	2011-09-09 15:57:00+00	0	137.82	\N	\N	137.82	\N	\N	\N	\N	64	32	95833
2012-03-02 16:03:00+00	2012-03-02 16:03:00+00	2012-03-02 16:03:00+00	0	137.45	\N	\N	137.45	\N	\N	\N	\N	64	32	95835
2012-08-24 16:13:00+00	2012-08-24 16:13:00+00	2012-08-24 16:13:00+00	0	137.87	\N	\N	137.87	\N	\N	\N	\N	64	32	95837
2013-02-26 16:34:00+00	2013-02-26 16:34:00+00	2013-02-26 16:34:00+00	0	137.48	\N	\N	137.48	\N	\N	\N	\N	64	32	95839
2013-09-03 15:40:00+00	2013-09-03 15:40:00+00	2013-09-03 15:40:00+00	0	138.1	\N	\N	138.1	\N	\N	\N	\N	64	32	95841
2014-02-25 16:27:00+00	2014-02-25 16:27:00+00	2014-02-25 16:27:00+00	0	137.57	\N	\N	137.57	\N	\N	\N	\N	64	32	95843
2014-08-25 15:17:00+00	2014-08-25 15:17:00+00	2014-08-25 15:17:00+00	0	137.87	\N	\N	137.87	\N	\N	\N	\N	64	32	95845
2015-03-03 16:16:00+00	2015-03-03 16:16:00+00	2015-03-03 16:16:00+00	0	137.4	\N	\N	137.4	\N	\N	\N	\N	64	32	95847
2015-08-27 16:40:00+00	2015-08-27 16:40:00+00	2015-08-27 16:40:00+00	0	137.95	\N	\N	137.95	\N	\N	\N	\N	64	32	95849
2016-02-29 17:17:00+00	2016-02-29 17:17:00+00	2016-02-29 17:17:00+00	0	137.51	\N	\N	137.51	\N	\N	\N	\N	64	32	95851
2016-08-23 14:31:00+00	2016-08-23 14:31:00+00	2016-08-23 14:31:00+00	0	137.9	\N	\N	137.9	\N	\N	\N	\N	64	32	95853
2017-02-27 16:03:00+00	2017-02-27 16:03:00+00	2017-02-27 16:03:00+00	0	137.54	\N	\N	137.54	\N	\N	\N	\N	64	32	95855
2017-08-21 16:04:00+00	2017-08-21 16:04:00+00	2017-08-21 16:04:00+00	0	137.94	\N	\N	137.94	\N	\N	\N	\N	64	32	95857
2018-03-05 16:42:00+00	2018-03-05 16:42:00+00	2018-03-05 16:42:00+00	0	137.78	\N	\N	137.78	\N	\N	\N	\N	64	32	95859
2018-08-27 14:54:00+00	2018-08-27 14:54:00+00	2018-08-27 14:54:00+00	0	137.91	\N	\N	137.91	\N	\N	\N	\N	64	32	95861
2019-03-04 16:05:00+00	2019-03-04 16:05:00+00	2019-03-04 16:05:00+00	0	138.07	\N	\N	138.07	\N	\N	\N	\N	64	32	95863
2019-08-21 14:26:00+00	2019-08-21 14:26:00+00	2019-08-21 14:26:00+00	0	137.89	\N	\N	137.89	\N	\N	\N	\N	64	32	95865
2020-02-27 16:40:00+00	2020-02-27 16:40:00+00	2020-02-27 16:40:00+00	0	137.79	\N	\N	137.79	\N	\N	\N	\N	64	32	95867
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111370
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111372
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111374
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111376
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111378
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111380
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111382
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111384
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111386
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111388
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111390
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111392
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111394
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111396
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111398
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111400
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111402
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111404
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111406
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111408
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111410
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111412
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111414
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111416
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111418
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111420
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111422
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111424
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111426
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111428
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111430
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111432
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111434
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111436
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111438
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111440
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111442
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111444
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111446
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111448
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111450
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111452
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111454
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111456
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111458
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111460
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111462
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111464
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111466
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111468
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111470
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111472
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111474
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111476
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111478
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111480
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111482
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111484
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111486
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111488
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111490
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111492
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111494
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111496
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111498
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111500
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111502
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111504
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111506
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111508
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111510
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111512
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111514
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111516
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111518
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111520
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111522
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111524
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111526
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111528
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111530
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111532
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111534
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111536
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111538
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111540
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111542
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111544
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111546
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111548
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111550
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111552
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111554
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111556
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111558
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111560
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111562
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111564
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111566
1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	0	4830	\N	\N	4830	\N	\N	\N	\N	69	35	111568
1982-01-22 12:00:00+00	1982-01-22 12:00:00+00	1982-01-22 12:00:00+00	0	187.4	\N	\N	187.4	\N	\N	\N	\N	84	42	172853
1984-01-23 12:00:00+00	1984-01-23 12:00:00+00	1984-01-23 12:00:00+00	0	175.1	\N	\N	175.1	\N	\N	\N	\N	84	42	172855
1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	1985-02-27 12:00:00+00	0	217.34	\N	\N	217.34	\N	\N	\N	\N	84	42	172857
1986-03-20 12:00:00+00	1986-03-20 12:00:00+00	1986-03-20 12:00:00+00	0	219.83	\N	\N	219.83	\N	\N	\N	\N	84	42	172859
1987-02-09 12:00:00+00	1987-02-09 12:00:00+00	1987-02-09 12:00:00+00	0	215.2	\N	\N	215.2	\N	\N	\N	\N	84	42	172861
1988-02-08 12:00:00+00	1988-02-08 12:00:00+00	1988-02-08 12:00:00+00	0	214.9	\N	\N	214.9	\N	\N	\N	\N	84	42	172863
1989-02-13 12:00:00+00	1989-02-13 12:00:00+00	1989-02-13 12:00:00+00	0	219.72	\N	\N	219.72	\N	\N	\N	\N	84	42	172865
1991-02-14 12:00:00+00	1991-02-14 12:00:00+00	1991-02-14 12:00:00+00	0	206.57	\N	\N	206.57	\N	\N	\N	\N	84	42	172867
1992-01-23 12:00:00+00	1992-01-23 12:00:00+00	1992-01-23 12:00:00+00	0	205.17	\N	\N	205.17	\N	\N	\N	\N	84	42	172869
1993-02-08 12:00:00+00	1993-02-08 12:00:00+00	1993-02-08 12:00:00+00	0	200.54	\N	\N	200.54	\N	\N	\N	\N	84	42	172871
1994-02-15 12:00:00+00	1994-02-15 12:00:00+00	1994-02-15 12:00:00+00	0	198.3	\N	\N	198.3	\N	\N	\N	\N	84	42	172873
1995-02-10 12:00:00+00	1995-02-10 12:00:00+00	1995-02-10 12:00:00+00	0	195.6	\N	\N	195.6	\N	\N	\N	\N	84	42	172875
1996-02-12 12:00:00+00	1996-02-12 12:00:00+00	1996-02-12 12:00:00+00	0	193.83	\N	\N	193.83	\N	\N	\N	\N	84	42	172877
1997-02-12 12:00:00+00	1997-02-12 12:00:00+00	1997-02-12 12:00:00+00	0	191.2	\N	\N	191.2	\N	\N	\N	\N	84	42	172879
1998-03-17 12:00:00+00	1998-03-17 12:00:00+00	1998-03-17 12:00:00+00	0	189.13	\N	\N	189.13	\N	\N	\N	\N	84	42	172881
1999-01-26 12:00:00+00	1999-01-26 12:00:00+00	1999-01-26 12:00:00+00	0	187.65	\N	\N	187.65	\N	\N	\N	\N	84	42	172883
2000-03-07 22:20:00+00	2000-03-07 22:20:00+00	2000-03-07 22:20:00+00	0	184.81	\N	\N	184.81	\N	\N	\N	\N	84	42	172885
2001-03-06 18:45:00+00	2001-03-06 18:45:00+00	2001-03-06 18:45:00+00	0	183.65	\N	\N	183.65	\N	\N	\N	\N	84	42	172887
2002-02-27 16:30:00+00	2002-02-27 16:30:00+00	2002-02-27 16:30:00+00	0	183	\N	\N	183	\N	\N	\N	\N	84	42	172889
2003-03-06 16:40:00+00	2003-03-06 16:40:00+00	2003-03-06 16:40:00+00	0	186.48	\N	\N	186.48	\N	\N	\N	\N	84	42	172891
2004-03-02 20:15:00+00	2004-03-02 20:15:00+00	2004-03-02 20:15:00+00	0	190.75	\N	\N	190.75	\N	\N	\N	\N	84	42	172893
2005-03-01 21:30:00+00	2005-03-01 21:30:00+00	2005-03-01 21:30:00+00	0	193.21	\N	\N	193.21	\N	\N	\N	\N	84	42	172895
2006-03-17 21:58:00+00	2006-03-17 21:58:00+00	2006-03-17 21:58:00+00	0	196.25	\N	\N	196.25	\N	\N	\N	\N	84	42	172897
2007-03-16 17:42:00+00	2007-03-16 17:42:00+00	2007-03-16 17:42:00+00	0	193.02	\N	\N	193.02	\N	\N	\N	\N	84	42	172899
2008-03-07 19:28:00+00	2008-03-07 19:28:00+00	2008-03-07 19:28:00+00	0	190.11	\N	\N	190.11	\N	\N	\N	\N	84	42	172901
2009-02-23 23:44:00+00	2009-02-23 23:44:00+00	2009-02-23 23:44:00+00	0	189.59	\N	\N	189.59	\N	\N	\N	\N	84	42	172903
2010-03-08 21:25:00+00	2010-03-08 21:25:00+00	2010-03-08 21:25:00+00	0	187.94	\N	\N	187.94	\N	\N	\N	\N	84	42	172905
2011-03-03 21:42:00+00	2011-03-03 21:42:00+00	2011-03-03 21:42:00+00	0	186.22	\N	\N	186.22	\N	\N	\N	\N	84	42	172907
2012-03-16 18:13:00+00	2012-03-16 18:13:00+00	2012-03-16 18:13:00+00	0	184.93	\N	\N	184.93	\N	\N	\N	\N	84	42	172909
2013-01-22 00:02:00+00	2013-01-22 00:02:00+00	2013-01-22 00:02:00+00	0	184.01	\N	\N	184.01	\N	\N	\N	\N	84	42	172911
2014-01-14 20:50:00+00	2014-01-14 20:50:00+00	2014-01-14 20:50:00+00	0	157.87	\N	\N	157.87	\N	\N	\N	\N	84	42	172913
2015-02-25 23:20:00+00	2015-02-25 23:20:00+00	2015-02-25 23:20:00+00	0	182.04	\N	\N	182.04	\N	\N	\N	\N	84	42	172915
2016-03-17 18:01:00+00	2016-03-17 18:01:00+00	2016-03-17 18:01:00+00	0	179.6	\N	\N	179.6	\N	\N	\N	\N	84	42	172917
2016-12-20 20:00:00+00	2016-12-20 20:00:00+00	2016-12-20 20:00:00+00	0	179.34	\N	\N	179.34	\N	\N	\N	\N	84	42	172919
2017-03-09 21:30:00+00	2017-03-09 21:30:00+00	2017-03-09 21:30:00+00	0	179.11	\N	\N	179.11	\N	\N	\N	\N	84	42	172921
2018-02-16 22:40:00+00	2018-02-16 22:40:00+00	2018-02-16 22:40:00+00	0	178.65	\N	\N	178.65	\N	\N	\N	\N	84	42	172923
2018-08-22 16:19:00+00	2018-08-22 16:19:00+00	2018-08-22 16:19:00+00	0	178.51	\N	\N	178.51	\N	\N	\N	\N	84	42	172925
2019-02-05 22:28:00+00	2019-02-05 22:28:00+00	2019-02-05 22:28:00+00	0	178.41	\N	\N	178.41	\N	\N	\N	\N	84	42	172927
1955-07-07 12:00:00+00	1955-07-07 12:00:00+00	1955-07-07 12:00:00+00	0	322.54	\N	\N	322.54	\N	\N	\N	\N	86	43	172929
1982-01-13 12:00:00+00	1982-01-13 12:00:00+00	1982-01-13 12:00:00+00	0	321.53	\N	\N	321.53	\N	\N	\N	\N	86	43	172931
1984-02-29 12:00:00+00	1984-02-29 12:00:00+00	1984-02-29 12:00:00+00	0	324.52	\N	\N	324.52	\N	\N	\N	\N	86	43	172933
1985-02-15 12:00:00+00	1985-02-15 12:00:00+00	1985-02-15 12:00:00+00	0	323.96	\N	\N	323.96	\N	\N	\N	\N	86	43	172935
1989-02-16 12:00:00+00	1989-02-16 12:00:00+00	1989-02-16 12:00:00+00	0	324.12	\N	\N	324.12	\N	\N	\N	\N	86	43	172937
1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	1990-02-13 12:00:00+00	0	324.09	\N	\N	324.09	\N	\N	\N	\N	86	43	172939
1991-02-22 12:00:00+00	1991-02-22 12:00:00+00	1991-02-22 12:00:00+00	0	323.99	\N	\N	323.99	\N	\N	\N	\N	86	43	172941
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	324.16	\N	\N	324.16	\N	\N	\N	\N	86	43	172943
1993-02-22 12:00:00+00	1993-02-22 12:00:00+00	1993-02-22 12:00:00+00	0	324.1	\N	\N	324.1	\N	\N	\N	\N	86	43	172945
1994-02-10 12:00:00+00	1994-02-10 12:00:00+00	1994-02-10 12:00:00+00	0	324.28	\N	\N	324.28	\N	\N	\N	\N	86	43	172947
1995-02-08 12:00:00+00	1995-02-08 12:00:00+00	1995-02-08 12:00:00+00	0	324.35	\N	\N	324.35	\N	\N	\N	\N	86	43	172949
1996-02-07 12:00:00+00	1996-02-07 12:00:00+00	1996-02-07 12:00:00+00	0	324.4	\N	\N	324.4	\N	\N	\N	\N	86	43	172951
1997-02-13 12:00:00+00	1997-02-13 12:00:00+00	1997-02-13 12:00:00+00	0	324.38	\N	\N	324.38	\N	\N	\N	\N	86	43	172953
1998-02-20 12:00:00+00	1998-02-20 12:00:00+00	1998-02-20 12:00:00+00	0	324.33	\N	\N	324.33	\N	\N	\N	\N	86	43	172955
1999-01-26 18:20:00+00	1999-01-26 18:20:00+00	1999-01-26 18:20:00+00	0	324.43	\N	\N	324.43	\N	\N	\N	\N	86	43	172957
2000-02-24 21:30:00+00	2000-02-24 21:30:00+00	2000-02-24 21:30:00+00	0	324.39	\N	\N	324.39	\N	\N	\N	\N	86	43	172959
2001-02-26 21:30:00+00	2001-02-26 21:30:00+00	2001-02-26 21:30:00+00	0	324.45	\N	\N	324.45	\N	\N	\N	\N	86	43	172961
2002-02-21 19:40:00+00	2002-02-21 19:40:00+00	2002-02-21 19:40:00+00	0	324.55	\N	\N	324.55	\N	\N	\N	\N	86	43	172963
2003-02-06 20:45:00+00	2003-02-06 20:45:00+00	2003-02-06 20:45:00+00	0	324.48	\N	\N	324.48	\N	\N	\N	\N	86	43	172965
2004-02-10 20:20:00+00	2004-02-10 20:20:00+00	2004-02-10 20:20:00+00	0	324.58	\N	\N	324.58	\N	\N	\N	\N	86	43	172967
2005-02-04 21:25:00+00	2005-02-04 21:25:00+00	2005-02-04 21:25:00+00	0	324.73	\N	\N	324.73	\N	\N	\N	\N	86	43	172969
2006-03-03 18:32:00+00	2006-03-03 18:32:00+00	2006-03-03 18:32:00+00	0	324.69	\N	\N	324.69	\N	\N	\N	\N	86	43	172971
2007-03-06 22:38:00+00	2007-03-06 22:38:00+00	2007-03-06 22:38:00+00	0	324.86	\N	\N	324.86	\N	\N	\N	\N	86	43	172973
2008-03-20 22:00:00+00	2008-03-20 22:00:00+00	2008-03-20 22:00:00+00	0	324.87	\N	\N	324.87	\N	\N	\N	\N	86	43	172975
2009-01-27 18:10:00+00	2009-01-27 18:10:00+00	2009-01-27 18:10:00+00	0	324.86	\N	\N	324.86	\N	\N	\N	\N	86	43	172977
2010-03-11 22:46:00+00	2010-03-11 22:46:00+00	2010-03-11 22:46:00+00	0	324.89	\N	\N	324.89	\N	\N	\N	\N	86	43	172979
2011-02-25 00:36:00+00	2011-02-25 00:36:00+00	2011-02-25 00:36:00+00	0	325.98	\N	\N	325.98	\N	\N	\N	\N	86	43	172981
2011-03-17 20:14:00+00	2011-03-17 20:14:00+00	2011-03-17 20:14:00+00	0	326.07	\N	\N	326.07	\N	\N	\N	\N	86	43	172983
2011-05-04 18:06:00+00	2011-05-04 18:06:00+00	2011-05-04 18:06:00+00	0	326.34	\N	\N	326.34	\N	\N	\N	\N	86	43	172985
2011-06-01 17:50:00+00	2011-06-01 17:50:00+00	2011-06-01 17:50:00+00	0	326.4	\N	\N	326.4	\N	\N	\N	\N	86	43	172987
2011-07-06 17:44:00+00	2011-07-06 17:44:00+00	2011-07-06 17:44:00+00	0	326.54	\N	\N	326.54	\N	\N	\N	\N	86	43	172989
2011-08-16 16:46:00+00	2011-08-16 16:46:00+00	2011-08-16 16:46:00+00	0	326.69	\N	\N	326.69	\N	\N	\N	\N	86	43	172991
2011-10-18 18:40:00+00	2011-10-18 18:40:00+00	2011-10-18 18:40:00+00	0	326.82	\N	\N	326.82	\N	\N	\N	\N	86	43	172993
2012-01-27 18:10:00+00	2012-01-27 18:10:00+00	2012-01-27 18:10:00+00	0	326.87	\N	\N	326.87	\N	\N	\N	\N	86	43	172995
2012-06-25 20:35:00+00	2012-06-25 20:35:00+00	2012-06-25 20:35:00+00	0	327.26	\N	\N	327.26	\N	\N	\N	\N	86	43	172997
2013-01-15 16:44:00+00	2013-01-15 16:44:00+00	2013-01-15 16:44:00+00	0	327.25	\N	\N	327.25	\N	\N	\N	\N	86	43	172999
2014-01-27 21:04:00+00	2014-01-27 21:04:00+00	2014-01-27 21:04:00+00	0	327.61	\N	\N	327.61	\N	\N	\N	\N	86	43	173001
2015-03-04 19:05:00+00	2015-03-04 19:05:00+00	2015-03-04 19:05:00+00	0	327.61	\N	\N	327.61	\N	\N	\N	\N	86	43	173003
2016-02-17 20:07:00+00	2016-02-17 20:07:00+00	2016-02-17 20:07:00+00	0	328.66	\N	\N	328.66	\N	\N	\N	\N	86	43	173005
2016-12-20 23:30:00+00	2016-12-20 23:30:00+00	2016-12-20 23:30:00+00	0	328.44	\N	\N	328.44	\N	\N	\N	\N	86	43	173007
2017-03-04 22:30:00+00	2017-03-04 22:30:00+00	2017-03-04 22:30:00+00	0	328.25	\N	\N	328.25	\N	\N	\N	\N	86	43	173009
2018-02-01 19:05:00+00	2018-02-01 19:05:00+00	2018-02-01 19:05:00+00	0	328.92	\N	\N	328.92	\N	\N	\N	\N	86	43	173011
2018-08-24 15:47:00+00	2018-08-24 15:47:00+00	2018-08-24 15:47:00+00	0	329.17	\N	\N	329.17	\N	\N	\N	\N	86	43	173013
2019-01-29 22:25:00+00	2019-01-29 22:25:00+00	2019-01-29 22:25:00+00	0	329.54	\N	\N	329.54	\N	\N	\N	\N	86	43	173015
2021-02-09 15:55:01+00	2021-02-09 15:55:01+00	2021-02-09 15:55:01+00	0	200	\N	\N	200	\N	\N	\N	\N	119	45	184352
2021-02-09 15:54:01+00	2021-02-09 15:54:01+00	2021-02-09 15:54:01+00	0	200	\N	\N	200	\N	\N	\N	\N	119	45	184351
2021-02-09 15:53:01+00	2021-02-09 15:53:01+00	2021-02-09 15:53:01+00	0	200	\N	\N	200	\N	\N	\N	\N	119	45	184350
2021-02-09 15:35:01+00	2021-02-09 15:35:01+00	2021-02-09 15:35:01+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184349
2021-02-09 15:34:02+00	2021-02-09 15:34:02+00	2021-02-09 15:34:02+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184348
2021-02-09 15:33:01+00	2021-02-09 15:33:01+00	2021-02-09 15:33:01+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184347
2021-02-09 15:32:01+00	2021-02-09 15:32:01+00	2021-02-09 15:32:01+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184346
2021-02-09 15:31:01+00	2021-02-09 15:31:01+00	2021-02-09 15:31:01+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184345
2021-02-09 15:30:01+00	2021-02-09 15:30:01+00	2021-02-09 15:30:01+00	0	100	\N	\N	100	\N	\N	\N	\N	119	45	184344
2021-02-09 14:53:01+00	2021-02-09 14:53:01+00	2021-02-09 14:53:01+00	0	0.9864	\N	\N	0.9864	\N	\N	\N	\N	119	45	184343
2021-02-09 14:52:01+00	2021-02-09 14:52:01+00	2021-02-09 14:52:01+00	0	0.8905	\N	\N	0.8905	\N	\N	\N	\N	119	45	184342
2021-02-09 14:50:02+00	2021-02-09 14:50:02+00	2021-02-09 14:50:02+00	0	0.3313	\N	\N	0.3313	\N	\N	\N	\N	119	45	184341
2021-02-09 14:49:01+00	2021-02-09 14:49:01+00	2021-02-09 14:49:01+00	0	0.6766	\N	\N	0.6766	\N	\N	\N	\N	119	45	184340
2021-02-09 14:48:01+00	2021-02-09 14:48:01+00	2021-02-09 14:48:01+00	0	0.6703	\N	\N	0.6703	\N	\N	\N	\N	119	45	184339
2021-02-09 14:47:01+00	2021-02-09 14:47:01+00	2021-02-09 14:47:01+00	0	0.1653	\N	\N	0.1653	\N	\N	\N	\N	119	45	184338
2021-02-09 14:46:01+00	2021-02-09 14:46:01+00	2021-02-09 14:46:01+00	0	0.8394	\N	\N	0.8394	\N	\N	\N	\N	119	45	184337
2021-02-09 14:45:02+00	2021-02-09 14:45:02+00	2021-02-09 14:45:02+00	0	0.2164	\N	\N	0.2164	\N	\N	\N	\N	119	45	184336
2021-02-09 14:44:02+00	2021-02-09 14:44:02+00	2021-02-09 14:44:02+00	0	0.1618	\N	\N	0.1618	\N	\N	\N	\N	119	45	184335
2021-02-09 14:43:01+00	2021-02-09 14:43:01+00	2021-02-09 14:43:01+00	0	0.8993	\N	\N	0.8993	\N	\N	\N	\N	119	45	184334
2021-02-09 14:42:01+00	2021-02-09 14:42:01+00	2021-02-09 14:42:01+00	0	0.1902	\N	\N	0.1902	\N	\N	\N	\N	119	45	184333
2021-02-09 14:41:01+00	2021-02-09 14:41:01+00	2021-02-09 14:41:01+00	0	0.4908	\N	\N	0.4908	\N	\N	\N	\N	119	45	184332
2021-02-09 14:40:01+00	2021-02-09 14:40:01+00	2021-02-09 14:40:01+00	0	0.462	\N	\N	0.462	\N	\N	\N	\N	119	45	184331
2021-02-09 14:39:02+00	2021-02-09 14:39:02+00	2021-02-09 14:39:02+00	0	0.1352	\N	\N	0.1352	\N	\N	\N	\N	119	45	184330
2021-02-09 14:38:01+00	2021-02-09 14:38:01+00	2021-02-09 14:38:01+00	0	0.5163	\N	\N	0.5163	\N	\N	\N	\N	119	45	184329
2021-02-09 14:37:01+00	2021-02-09 14:37:01+00	2021-02-09 14:37:01+00	0	0.9096	\N	\N	0.9096	\N	\N	\N	\N	119	45	184328
2021-02-09 14:36:01+00	2021-02-09 14:36:01+00	2021-02-09 14:36:01+00	0	0.0176	\N	\N	0.0176	\N	\N	\N	\N	119	45	184327
2021-02-09 14:35:02+00	2021-02-09 14:35:02+00	2021-02-09 14:35:02+00	0	0.1749	\N	\N	0.1749	\N	\N	\N	\N	119	45	184326
2021-02-09 14:34:02+00	2021-02-09 14:34:02+00	2021-02-09 14:34:02+00	0	0.3277	\N	\N	0.3277	\N	\N	\N	\N	119	45	184325
2021-02-09 14:33:01+00	2021-02-09 14:33:01+00	2021-02-09 14:33:01+00	0	0.3046	\N	\N	0.3046	\N	\N	\N	\N	119	45	184324
2021-02-09 14:32:01+00	2021-02-09 14:32:01+00	2021-02-09 14:32:01+00	0	0.9666	\N	\N	0.9666	\N	\N	\N	\N	119	45	184323
2021-02-09 14:31:01+00	2021-02-09 14:31:01+00	2021-02-09 14:31:01+00	0	0.5523	\N	\N	0.5523	\N	\N	\N	\N	119	45	184322
2021-02-09 14:30:01+00	2021-02-09 14:30:01+00	2021-02-09 14:30:01+00	0	0.1196	\N	\N	0.1196	\N	\N	\N	\N	119	45	184321
2021-02-09 14:29:01+00	2021-02-09 14:29:01+00	2021-02-09 14:29:01+00	0	0.4748	\N	\N	0.4748	\N	\N	\N	\N	119	45	184320
2021-02-09 14:28:01+00	2021-02-09 14:28:01+00	2021-02-09 14:28:01+00	0	0.668	\N	\N	0.668	\N	\N	\N	\N	119	45	184319
2021-02-09 14:27:01+00	2021-02-09 14:27:01+00	2021-02-09 14:27:01+00	0	0.2167	\N	\N	0.2167	\N	\N	\N	\N	119	45	184318
2021-02-09 14:26:01+00	2021-02-09 14:26:01+00	2021-02-09 14:26:01+00	0	0.1761	\N	\N	0.1761	\N	\N	\N	\N	119	45	184317
2021-02-09 14:25:01+00	2021-02-09 14:25:01+00	2021-02-09 14:25:01+00	0	0.0091	\N	\N	0.0091	\N	\N	\N	\N	119	45	184316
2021-02-09 14:24:01+00	2021-02-09 14:24:01+00	2021-02-09 14:24:01+00	0	0.6468	\N	\N	0.6468	\N	\N	\N	\N	119	45	184315
2021-02-09 14:23:01+00	2021-02-09 14:23:01+00	2021-02-09 14:23:01+00	0	0.8578	\N	\N	0.8578	\N	\N	\N	\N	119	45	184314
2021-02-09 14:22:01+00	2021-02-09 14:22:01+00	2021-02-09 14:22:01+00	0	0.2306	\N	\N	0.2306	\N	\N	\N	\N	119	45	184313
2021-02-09 14:21:01+00	2021-02-09 14:21:01+00	2021-02-09 14:21:01+00	0	0.8679	\N	\N	0.8679	\N	\N	\N	\N	119	45	184312
2021-02-09 14:20:01+00	2021-02-09 14:20:01+00	2021-02-09 14:20:01+00	0	0.2112	\N	\N	0.2112	\N	\N	\N	\N	119	45	184311
2021-02-09 03:54:01+00	2021-02-09 03:54:01+00	2021-02-09 03:54:01+00	0	0.3003	\N	\N	0.3003	\N	\N	\N	\N	119	45	184310
2021-02-09 03:53:01+00	2021-02-09 03:53:01+00	2021-02-09 03:53:01+00	0	0.0771	\N	\N	0.0771	\N	\N	\N	\N	119	45	184309
2021-02-09 03:52:01+00	2021-02-09 03:52:01+00	2021-02-09 03:52:01+00	0	0.1776	\N	\N	0.1776	\N	\N	\N	\N	119	45	184308
2021-02-09 02:35:22+00	2021-02-09 02:35:22+00	2021-02-09 02:35:22+00	0	0.2417	\N	\N	0.2417	\N	\N	\N	\N	119	45	184307
2021-02-09 02:32:21+00	2021-02-09 02:32:21+00	2021-02-09 02:32:21+00	0	0.5329	\N	\N	0.5329	\N	\N	\N	\N	119	45	184306
2021-02-09 02:32:13+00	2021-02-09 02:32:13+00	2021-02-09 02:32:13+00	0	0.6756	\N	\N	0.6756	\N	\N	\N	\N	119	45	184305
2021-02-09 02:32:06+00	2021-02-09 02:32:06+00	2021-02-09 02:32:06+00	0	0.4037	\N	\N	0.4037	\N	\N	\N	\N	119	45	184304
2021-02-09 02:20:47+00	2021-02-09 02:20:47+00	2021-02-09 02:20:47+00	0	0.1762	\N	\N	0.1762	\N	\N	\N	\N	119	45	184303
2021-02-09 02:01:16+00	2021-02-09 02:01:16+00	2021-02-09 02:01:16+00	0	0.3791	\N	\N	0.3791	\N	\N	\N	\N	119	45	184302
2021-02-08 22:42:00+00	2021-02-08 22:42:00+00	2021-02-08 22:42:00+00	0	0.3199	\N	\N	0.3199	\N	\N	\N	\N	119	45	184301
2021-02-01 18:55:01+00	2021-02-01 18:55:01+00	2021-02-01 18:55:01+00	0	0.5487	\N	\N	0.5487	\N	\N	\N	\N	119	45	184300
2021-02-01 03:10:01+00	2021-02-01 03:10:01+00	2021-02-01 03:10:01+00	0	0.7022	\N	\N	0.7022	\N	\N	\N	\N	119	45	184299
2021-02-01 03:09:01+00	2021-02-01 03:09:01+00	2021-02-01 03:09:01+00	0	0.1637	\N	\N	0.1637	\N	\N	\N	\N	119	45	184298
2021-01-31 23:47:01+00	2021-01-31 23:47:01+00	2021-01-31 23:47:01+00	0	0.3094	\N	\N	0.3094	\N	\N	\N	\N	119	45	184297
2021-01-31 23:46:01+00	2021-01-31 23:46:01+00	2021-01-31 23:46:01+00	0	0.6721	\N	\N	0.6721	\N	\N	\N	\N	119	45	184296
2021-01-31 23:45:02+00	2021-01-31 23:45:02+00	2021-01-31 23:45:02+00	0	0.5836	\N	\N	0.5836	\N	\N	\N	\N	119	45	184295
2021-01-31 23:44:02+00	2021-01-31 23:44:02+00	2021-01-31 23:44:02+00	0	0.8632	\N	\N	0.8632	\N	\N	\N	\N	119	45	184294
2021-01-31 23:43:01+00	2021-01-31 23:43:01+00	2021-01-31 23:43:01+00	0	0.4392	\N	\N	0.4392	\N	\N	\N	\N	119	45	184293
2021-01-31 23:42:01+00	2021-01-31 23:42:01+00	2021-01-31 23:42:01+00	0	0.6881	\N	\N	0.6881	\N	\N	\N	\N	119	45	184292
2021-01-31 23:41:01+00	2021-01-31 23:41:01+00	2021-01-31 23:41:01+00	0	0.094	\N	\N	0.094	\N	\N	\N	\N	119	45	184291
2021-01-31 23:40:02+00	2021-01-31 23:40:02+00	2021-01-31 23:40:02+00	0	0.21	\N	\N	0.21	\N	\N	\N	\N	119	45	184290
2021-01-31 23:39:01+00	2021-01-31 23:39:01+00	2021-01-31 23:39:01+00	0	0.5868	\N	\N	0.5868	\N	\N	\N	\N	119	45	184289
2021-01-31 23:38:01+00	2021-01-31 23:38:01+00	2021-01-31 23:38:01+00	0	0.733	\N	\N	0.733	\N	\N	\N	\N	119	45	184288
2021-01-31 23:28:01+00	2021-01-31 23:28:01+00	2021-01-31 23:28:01+00	0	0.5565	\N	\N	0.5565	\N	\N	\N	\N	119	45	184287
2021-01-31 23:27:01+00	2021-01-31 23:27:01+00	2021-01-31 23:27:01+00	0	0.3747	\N	\N	0.3747	\N	\N	\N	\N	119	45	184286
2021-01-31 23:23:01+00	2021-01-31 23:23:01+00	2021-01-31 23:23:01+00	0	0.1053	\N	\N	0.1053	\N	\N	\N	\N	119	45	184285
2021-01-31 23:22:01+00	2021-01-31 23:22:01+00	2021-01-31 23:22:01+00	0	0.2163	\N	\N	0.2163	\N	\N	\N	\N	119	45	184284
2021-01-31 23:21:01+00	2021-01-31 23:21:01+00	2021-01-31 23:21:01+00	0	0.0172	\N	\N	0.0172	\N	\N	\N	\N	119	45	184283
2021-01-31 23:20:01+00	2021-01-31 23:20:01+00	2021-01-31 23:20:01+00	0	0.2838	\N	\N	0.2838	\N	\N	\N	\N	119	45	184282
2021-01-31 23:07:02+00	2021-01-31 23:07:02+00	2021-01-31 23:07:02+00	0	0.8618	\N	\N	0.8618	\N	\N	\N	\N	119	45	184281
2021-01-31 23:06:01+00	2021-01-31 23:06:01+00	2021-01-31 23:06:01+00	0	0.8937	\N	\N	0.8937	\N	\N	\N	\N	119	45	184280
2021-01-31 21:27:01+00	2021-01-31 21:27:01+00	2021-01-31 21:27:01+00	0	0.8915	\N	\N	0.8915	\N	\N	\N	\N	119	45	184279
2021-01-31 21:26:01+00	2021-01-31 21:26:01+00	2021-01-31 21:26:01+00	0	0.8388	\N	\N	0.8388	\N	\N	\N	\N	119	45	184278
2021-01-31 21:25:01+00	2021-01-31 21:25:01+00	2021-01-31 21:25:01+00	0	0.4344	\N	\N	0.4344	\N	\N	\N	\N	119	45	184277
2021-01-31 21:24:02+00	2021-01-31 21:24:02+00	2021-01-31 21:24:02+00	0	0.4852	\N	\N	0.4852	\N	\N	\N	\N	119	45	184276
2021-01-31 21:23:01+00	2021-01-31 21:23:01+00	2021-01-31 21:23:01+00	0	0.3479	\N	\N	0.3479	\N	\N	\N	\N	119	45	184275
2021-01-31 21:22:01+00	2021-01-31 21:22:01+00	2021-01-31 21:22:01+00	0	0.6186	\N	\N	0.6186	\N	\N	\N	\N	119	45	184274
2021-01-31 21:21:01+00	2021-01-31 21:21:01+00	2021-01-31 21:21:01+00	0	0.0702	\N	\N	0.0702	\N	\N	\N	\N	119	45	184273
2021-01-31 21:20:02+00	2021-01-31 21:20:02+00	2021-01-31 21:20:02+00	0	0.6541	\N	\N	0.6541	\N	\N	\N	\N	119	45	184272
2021-01-31 21:19:01+00	2021-01-31 21:19:01+00	2021-01-31 21:19:01+00	0	0.9403	\N	\N	0.9403	\N	\N	\N	\N	119	45	184271
2021-01-31 21:18:01+00	2021-01-31 21:18:01+00	2021-01-31 21:18:01+00	0	0.4052	\N	\N	0.4052	\N	\N	\N	\N	119	45	184270
2021-01-31 21:17:01+00	2021-01-31 21:17:01+00	2021-01-31 21:17:01+00	0	0.5262	\N	\N	0.5262	\N	\N	\N	\N	119	45	184269
2021-01-31 20:57:06+00	2021-01-31 20:57:06+00	2021-01-31 20:57:06+00	0	0.9724	\N	\N	0.9724	\N	\N	\N	\N	119	45	184268
2021-01-31 20:40:01+00	2021-01-31 20:40:01+00	2021-01-31 20:40:01+00	0	0.3427	\N	\N	0.3427	\N	\N	\N	\N	119	45	184267
2021-01-31 20:39:02+00	2021-01-31 20:39:02+00	2021-01-31 20:39:02+00	0	0.0876	\N	\N	0.0876	\N	\N	\N	\N	119	45	184266
2021-01-31 20:38:01+00	2021-01-31 20:38:01+00	2021-01-31 20:38:01+00	0	0.1175	\N	\N	0.1175	\N	\N	\N	\N	119	45	184265
2021-01-31 19:40:30+00	2021-01-31 19:40:30+00	2021-01-31 19:40:30+00	0	0.7237	\N	\N	0.7237	\N	\N	\N	\N	119	45	184264
2021-01-31 17:14:00+00	2021-01-31 17:14:00+00	2021-01-31 17:14:00+00	0	0.7425	\N	\N	0.7425	\N	\N	\N	\N	119	45	184263
2021-01-31 17:13:00+00	2021-01-31 17:13:00+00	2021-01-31 17:13:00+00	0	0.9921	\N	\N	0.9921	\N	\N	\N	\N	119	45	184262
2021-01-31 17:12:00+00	2021-01-31 17:12:00+00	2021-01-31 17:12:00+00	0	0.5757	\N	\N	0.5757	\N	\N	\N	\N	119	45	184261
2021-01-31 17:11:00+00	2021-01-31 17:11:00+00	2021-01-31 17:11:00+00	0	0.9106	\N	\N	0.9106	\N	\N	\N	\N	119	45	184260
2021-01-31 17:10:00+00	2021-01-31 17:10:00+00	2021-01-31 17:10:00+00	0	0.7437	\N	\N	0.7437	\N	\N	\N	\N	119	45	184259
2021-01-31 17:09:00+00	2021-01-31 17:09:00+00	2021-01-31 17:09:00+00	0	0.3167	\N	\N	0.3167	\N	\N	\N	\N	119	45	184258
2021-01-31 17:08:00+00	2021-01-31 17:08:00+00	2021-01-31 17:08:00+00	0	0.4073	\N	\N	0.4073	\N	\N	\N	\N	119	45	184257
2021-01-31 17:07:01+00	2021-01-31 17:07:01+00	2021-01-31 17:07:01+00	0	0.6003	\N	\N	0.6003	\N	\N	\N	\N	119	45	184256
2021-01-31 16:05:26+00	2021-01-31 16:05:26+00	2021-01-31 16:05:26+00	0	0.623	\N	\N	0.623	\N	\N	\N	\N	119	45	184255
2021-01-31 14:57:12+00	2021-01-31 14:57:12+00	2021-01-31 14:57:12+00	0	0.6952	\N	\N	0.6952	\N	\N	\N	\N	119	45	184254
2021-01-31 14:57:00+00	2021-01-31 14:57:00+00	2021-01-31 14:57:00+00	0	0.1696	\N	\N	0.1696	\N	\N	\N	\N	119	45	184253
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	4830.86	\N	\N	4830.86	\N	\N	\N	\N	71	36	127382
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	4830.94	\N	\N	4830.94	\N	\N	\N	\N	71	36	127384
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	4830.94	\N	\N	4830.94	\N	\N	\N	\N	71	36	127386
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	4831.03	\N	\N	4831.03	\N	\N	\N	\N	71	36	127388
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	4830.83	\N	\N	4830.83	\N	\N	\N	\N	71	36	127390
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	4830.64	\N	\N	4830.64	\N	\N	\N	\N	71	36	127392
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	4830.67	\N	\N	4830.67	\N	\N	\N	\N	71	36	127394
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	4830.77	\N	\N	4830.77	\N	\N	\N	\N	71	36	127396
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	4830.89	\N	\N	4830.89	\N	\N	\N	\N	71	36	127398
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	4830.74	\N	\N	4830.74	\N	\N	\N	\N	71	36	127400
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	4830.64	\N	\N	4830.64	\N	\N	\N	\N	71	36	127402
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	4830.7	\N	\N	4830.7	\N	\N	\N	\N	71	36	127404
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	4830.88	\N	\N	4830.88	\N	\N	\N	\N	71	36	127406
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	4831.05	\N	\N	4831.05	\N	\N	\N	\N	71	36	127408
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	4830.97	\N	\N	4830.97	\N	\N	\N	\N	71	36	127410
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	4830.79	\N	\N	4830.79	\N	\N	\N	\N	71	36	127412
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	4830.73	\N	\N	4830.73	\N	\N	\N	\N	71	36	127414
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	4830.73	\N	\N	4830.73	\N	\N	\N	\N	71	36	127416
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	4830.68	\N	\N	4830.68	\N	\N	\N	\N	71	36	127418
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	4830.58	\N	\N	4830.58	\N	\N	\N	\N	71	36	127420
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	4830.56	\N	\N	4830.56	\N	\N	\N	\N	71	36	127422
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	4830.64	\N	\N	4830.64	\N	\N	\N	\N	71	36	127424
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	4830.76	\N	\N	4830.76	\N	\N	\N	\N	71	36	127426
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	4830.87	\N	\N	4830.87	\N	\N	\N	\N	71	36	127428
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	4830.97	\N	\N	4830.97	\N	\N	\N	\N	71	36	127430
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	4830.93	\N	\N	4830.93	\N	\N	\N	\N	71	36	127432
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	4830.94	\N	\N	4830.94	\N	\N	\N	\N	71	36	127434
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	4830.98	\N	\N	4830.98	\N	\N	\N	\N	71	36	127436
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	4831.1	\N	\N	4831.1	\N	\N	\N	\N	71	36	127438
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	4831.01	\N	\N	4831.01	\N	\N	\N	\N	71	36	127440
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	4831.01	\N	\N	4831.01	\N	\N	\N	\N	71	36	127442
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	4831.06	\N	\N	4831.06	\N	\N	\N	\N	71	36	127444
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	4831.03	\N	\N	4831.03	\N	\N	\N	\N	71	36	127446
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	4830.98	\N	\N	4830.98	\N	\N	\N	\N	71	36	127448
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	4830.98	\N	\N	4830.98	\N	\N	\N	\N	71	36	127450
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	4831.07	\N	\N	4831.07	\N	\N	\N	\N	71	36	127452
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	4830.95	\N	\N	4830.95	\N	\N	\N	\N	71	36	127454
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	4830.95	\N	\N	4830.95	\N	\N	\N	\N	71	36	127456
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	4831.08	\N	\N	4831.08	\N	\N	\N	\N	71	36	127458
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	4830.87	\N	\N	4830.87	\N	\N	\N	\N	71	36	127460
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	4830.85	\N	\N	4830.85	\N	\N	\N	\N	71	36	127462
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	4830.83	\N	\N	4830.83	\N	\N	\N	\N	71	36	127464
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	4830.81	\N	\N	4830.81	\N	\N	\N	\N	71	36	127466
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	4830.86	\N	\N	4830.86	\N	\N	\N	\N	71	36	127468
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	4830.87	\N	\N	4830.87	\N	\N	\N	\N	71	36	127470
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	4830.93	\N	\N	4830.93	\N	\N	\N	\N	71	36	127472
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	4830.95	\N	\N	4830.95	\N	\N	\N	\N	71	36	127474
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	4830.99	\N	\N	4830.99	\N	\N	\N	\N	71	36	127476
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	4830.88	\N	\N	4830.88	\N	\N	\N	\N	71	36	127478
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	4830.82	\N	\N	4830.82	\N	\N	\N	\N	71	36	127480
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	4830.82	\N	\N	4830.82	\N	\N	\N	\N	71	36	127482
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	4830.89	\N	\N	4830.89	\N	\N	\N	\N	71	36	127484
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	4830.79	\N	\N	4830.79	\N	\N	\N	\N	71	36	127486
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	4830.86	\N	\N	4830.86	\N	\N	\N	\N	71	36	127488
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	4830.84	\N	\N	4830.84	\N	\N	\N	\N	71	36	127490
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	4830.83	\N	\N	4830.83	\N	\N	\N	\N	71	36	127492
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	4830.88	\N	\N	4830.88	\N	\N	\N	\N	71	36	127494
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	4831.01	\N	\N	4831.01	\N	\N	\N	\N	71	36	127496
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	4831.01	\N	\N	4831.01	\N	\N	\N	\N	71	36	127498
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	4830.84	\N	\N	4830.84	\N	\N	\N	\N	71	36	127500
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	4830.84	\N	\N	4830.84	\N	\N	\N	\N	71	36	127502
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	4830.98	\N	\N	4830.98	\N	\N	\N	\N	71	36	127504
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	4831.14	\N	\N	4831.14	\N	\N	\N	\N	71	36	127506
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	4831.12	\N	\N	4831.12	\N	\N	\N	\N	71	36	127508
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	4831.17	\N	\N	4831.17	\N	\N	\N	\N	71	36	127510
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	4831.19	\N	\N	4831.19	\N	\N	\N	\N	71	36	127512
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	4830.88	\N	\N	4830.88	\N	\N	\N	\N	71	36	127514
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	4830.86	\N	\N	4830.86	\N	\N	\N	\N	71	36	127516
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	4830.92	\N	\N	4830.92	\N	\N	\N	\N	71	36	127518
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	4830.74	\N	\N	4830.74	\N	\N	\N	\N	71	36	127520
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	4830.75	\N	\N	4830.75	\N	\N	\N	\N	71	36	127522
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	4830.79	\N	\N	4830.79	\N	\N	\N	\N	71	36	127524
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	4830.71	\N	\N	4830.71	\N	\N	\N	\N	71	36	127526
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	4830.78	\N	\N	4830.78	\N	\N	\N	\N	71	36	127528
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	4830.84	\N	\N	4830.84	\N	\N	\N	\N	71	36	127530
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	4830.81	\N	\N	4830.81	\N	\N	\N	\N	71	36	127532
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	4830.82	\N	\N	4830.82	\N	\N	\N	\N	71	36	127534
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	4831.19	\N	\N	4831.19	\N	\N	\N	\N	71	36	127536
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	4831.19	\N	\N	4831.19	\N	\N	\N	\N	71	36	127538
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	4831.24	\N	\N	4831.24	\N	\N	\N	\N	71	36	127540
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	4830.96	\N	\N	4830.96	\N	\N	\N	\N	71	36	127542
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	4830.95	\N	\N	4830.95	\N	\N	\N	\N	71	36	127544
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	4831	\N	\N	4831	\N	\N	\N	\N	71	36	127546
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	4830.85	\N	\N	4830.85	\N	\N	\N	\N	71	36	127548
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	4830.83	\N	\N	4830.83	\N	\N	\N	\N	71	36	127550
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	4830.9	\N	\N	4830.9	\N	\N	\N	\N	71	36	127552
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	4830.96	\N	\N	4830.96	\N	\N	\N	\N	71	36	127554
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	4830.95	\N	\N	4830.95	\N	\N	\N	\N	71	36	127556
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	4830.92	\N	\N	4830.92	\N	\N	\N	\N	71	36	127558
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	4831.02	\N	\N	4831.02	\N	\N	\N	\N	71	36	127560
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	4831.02	\N	\N	4831.02	\N	\N	\N	\N	71	36	127562
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	4831.1	\N	\N	4831.1	\N	\N	\N	\N	71	36	127564
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	4831.06	\N	\N	4831.06	\N	\N	\N	\N	71	36	127566
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	4830.92	\N	\N	4830.92	\N	\N	\N	\N	71	36	127568
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	4830.82	\N	\N	4830.82	\N	\N	\N	\N	71	36	127570
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	4830.85	\N	\N	4830.85	\N	\N	\N	\N	71	36	127572
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	4830.9	\N	\N	4830.9	\N	\N	\N	\N	71	36	127574
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	4830.96	\N	\N	4830.96	\N	\N	\N	\N	71	36	127576
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	4830.94	\N	\N	4830.94	\N	\N	\N	\N	71	36	127578
1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	0	4830.86	\N	\N	4830.86	\N	\N	\N	\N	71	36	127580
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	193.31	\N	\N	193.31	\N	\N	\N	\N	72	36	127381
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	193.23	\N	\N	193.23	\N	\N	\N	\N	72	36	127383
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	193.23	\N	\N	193.23	\N	\N	\N	\N	72	36	127385
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	193.14	\N	\N	193.14	\N	\N	\N	\N	72	36	127387
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	193.34	\N	\N	193.34	\N	\N	\N	\N	72	36	127389
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	193.53	\N	\N	193.53	\N	\N	\N	\N	72	36	127391
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	193.5	\N	\N	193.5	\N	\N	\N	\N	72	36	127393
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	193.4	\N	\N	193.4	\N	\N	\N	\N	72	36	127395
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	193.28	\N	\N	193.28	\N	\N	\N	\N	72	36	127397
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	193.43	\N	\N	193.43	\N	\N	\N	\N	72	36	127399
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	193.53	\N	\N	193.53	\N	\N	\N	\N	72	36	127401
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	193.47	\N	\N	193.47	\N	\N	\N	\N	72	36	127403
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	193.29	\N	\N	193.29	\N	\N	\N	\N	72	36	127405
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	193.12	\N	\N	193.12	\N	\N	\N	\N	72	36	127407
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	193.2	\N	\N	193.2	\N	\N	\N	\N	72	36	127409
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	193.38	\N	\N	193.38	\N	\N	\N	\N	72	36	127411
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	193.44	\N	\N	193.44	\N	\N	\N	\N	72	36	127413
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	193.44	\N	\N	193.44	\N	\N	\N	\N	72	36	127415
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	193.49	\N	\N	193.49	\N	\N	\N	\N	72	36	127417
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	193.59	\N	\N	193.59	\N	\N	\N	\N	72	36	127419
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	193.61	\N	\N	193.61	\N	\N	\N	\N	72	36	127421
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	193.53	\N	\N	193.53	\N	\N	\N	\N	72	36	127423
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	193.41	\N	\N	193.41	\N	\N	\N	\N	72	36	127425
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	193.3	\N	\N	193.3	\N	\N	\N	\N	72	36	127427
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	193.2	\N	\N	193.2	\N	\N	\N	\N	72	36	127429
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	193.24	\N	\N	193.24	\N	\N	\N	\N	72	36	127431
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	193.23	\N	\N	193.23	\N	\N	\N	\N	72	36	127433
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	193.19	\N	\N	193.19	\N	\N	\N	\N	72	36	127435
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	193.07	\N	\N	193.07	\N	\N	\N	\N	72	36	127437
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	193.16	\N	\N	193.16	\N	\N	\N	\N	72	36	127439
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	193.16	\N	\N	193.16	\N	\N	\N	\N	72	36	127441
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	193.11	\N	\N	193.11	\N	\N	\N	\N	72	36	127443
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	193.14	\N	\N	193.14	\N	\N	\N	\N	72	36	127445
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	193.19	\N	\N	193.19	\N	\N	\N	\N	72	36	127447
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	193.19	\N	\N	193.19	\N	\N	\N	\N	72	36	127449
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	193.1	\N	\N	193.1	\N	\N	\N	\N	72	36	127451
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	193.22	\N	\N	193.22	\N	\N	\N	\N	72	36	127453
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	193.22	\N	\N	193.22	\N	\N	\N	\N	72	36	127455
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	193.09	\N	\N	193.09	\N	\N	\N	\N	72	36	127457
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	193.3	\N	\N	193.3	\N	\N	\N	\N	72	36	127459
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	193.32	\N	\N	193.32	\N	\N	\N	\N	72	36	127461
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	193.34	\N	\N	193.34	\N	\N	\N	\N	72	36	127463
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	193.36	\N	\N	193.36	\N	\N	\N	\N	72	36	127465
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	193.31	\N	\N	193.31	\N	\N	\N	\N	72	36	127467
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	193.3	\N	\N	193.3	\N	\N	\N	\N	72	36	127469
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	193.24	\N	\N	193.24	\N	\N	\N	\N	72	36	127471
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	193.22	\N	\N	193.22	\N	\N	\N	\N	72	36	127473
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	193.18	\N	\N	193.18	\N	\N	\N	\N	72	36	127475
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	193.29	\N	\N	193.29	\N	\N	\N	\N	72	36	127477
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	193.35	\N	\N	193.35	\N	\N	\N	\N	72	36	127479
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	193.35	\N	\N	193.35	\N	\N	\N	\N	72	36	127481
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	193.28	\N	\N	193.28	\N	\N	\N	\N	72	36	127483
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	193.38	\N	\N	193.38	\N	\N	\N	\N	72	36	127485
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	193.31	\N	\N	193.31	\N	\N	\N	\N	72	36	127487
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	193.33	\N	\N	193.33	\N	\N	\N	\N	72	36	127489
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	193.34	\N	\N	193.34	\N	\N	\N	\N	72	36	127491
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	193.29	\N	\N	193.29	\N	\N	\N	\N	72	36	127493
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	193.16	\N	\N	193.16	\N	\N	\N	\N	72	36	127495
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	193.16	\N	\N	193.16	\N	\N	\N	\N	72	36	127497
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	193.33	\N	\N	193.33	\N	\N	\N	\N	72	36	127499
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	193.33	\N	\N	193.33	\N	\N	\N	\N	72	36	127501
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	193.19	\N	\N	193.19	\N	\N	\N	\N	72	36	127503
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	193.03	\N	\N	193.03	\N	\N	\N	\N	72	36	127505
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	193.05	\N	\N	193.05	\N	\N	\N	\N	72	36	127507
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	193	\N	\N	193	\N	\N	\N	\N	72	36	127509
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	192.98	\N	\N	192.98	\N	\N	\N	\N	72	36	127511
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	193.29	\N	\N	193.29	\N	\N	\N	\N	72	36	127513
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	193.31	\N	\N	193.31	\N	\N	\N	\N	72	36	127515
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	193.25	\N	\N	193.25	\N	\N	\N	\N	72	36	127517
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	193.43	\N	\N	193.43	\N	\N	\N	\N	72	36	127519
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	193.42	\N	\N	193.42	\N	\N	\N	\N	72	36	127521
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	193.38	\N	\N	193.38	\N	\N	\N	\N	72	36	127523
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	193.46	\N	\N	193.46	\N	\N	\N	\N	72	36	127525
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	193.39	\N	\N	193.39	\N	\N	\N	\N	72	36	127527
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	193.33	\N	\N	193.33	\N	\N	\N	\N	72	36	127529
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	193.36	\N	\N	193.36	\N	\N	\N	\N	72	36	127531
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	193.35	\N	\N	193.35	\N	\N	\N	\N	72	36	127533
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	192.98	\N	\N	192.98	\N	\N	\N	\N	72	36	127535
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	192.98	\N	\N	192.98	\N	\N	\N	\N	72	36	127537
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	192.93	\N	\N	192.93	\N	\N	\N	\N	72	36	127539
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	193.21	\N	\N	193.21	\N	\N	\N	\N	72	36	127541
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	193.22	\N	\N	193.22	\N	\N	\N	\N	72	36	127543
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	193.17	\N	\N	193.17	\N	\N	\N	\N	72	36	127545
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	193.32	\N	\N	193.32	\N	\N	\N	\N	72	36	127547
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	193.34	\N	\N	193.34	\N	\N	\N	\N	72	36	127549
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	193.27	\N	\N	193.27	\N	\N	\N	\N	72	36	127551
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	193.21	\N	\N	193.21	\N	\N	\N	\N	72	36	127553
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	193.22	\N	\N	193.22	\N	\N	\N	\N	72	36	127555
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	193.25	\N	\N	193.25	\N	\N	\N	\N	72	36	127557
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	193.15	\N	\N	193.15	\N	\N	\N	\N	72	36	127559
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	193.15	\N	\N	193.15	\N	\N	\N	\N	72	36	127561
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	193.07	\N	\N	193.07	\N	\N	\N	\N	72	36	127563
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	193.11	\N	\N	193.11	\N	\N	\N	\N	72	36	127565
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	193.25	\N	\N	193.25	\N	\N	\N	\N	72	36	127567
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	193.35	\N	\N	193.35	\N	\N	\N	\N	72	36	127569
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	193.32	\N	\N	193.32	\N	\N	\N	\N	72	36	127571
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	193.27	\N	\N	193.27	\N	\N	\N	\N	72	36	127573
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	193.21	\N	\N	193.21	\N	\N	\N	\N	72	36	127575
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	193.23	\N	\N	193.23	\N	\N	\N	\N	72	36	127577
1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	0	193.31	\N	\N	193.31	\N	\N	\N	\N	72	36	127579
1980-01-09 12:00:00+00	1980-01-09 12:00:00+00	1980-01-09 12:00:00+00	0	307.48	\N	\N	307.48	\N	\N	\N	\N	80	40	172607
1981-01-09 12:00:00+00	1981-01-09 12:00:00+00	1981-01-09 12:00:00+00	0	309.92	\N	\N	309.92	\N	\N	\N	\N	80	40	172609
1982-01-08 12:00:00+00	1982-01-08 12:00:00+00	1982-01-08 12:00:00+00	0	305.21	\N	\N	305.21	\N	\N	\N	\N	80	40	172611
1983-01-07 12:00:00+00	1983-01-07 12:00:00+00	1983-01-07 12:00:00+00	0	304.04	\N	\N	304.04	\N	\N	\N	\N	80	40	172613
1984-01-16 12:00:00+00	1984-01-16 12:00:00+00	1984-01-16 12:00:00+00	0	303.18	\N	\N	303.18	\N	\N	\N	\N	80	40	172615
1985-01-10 12:00:00+00	1985-01-10 12:00:00+00	1985-01-10 12:00:00+00	0	302.75	\N	\N	302.75	\N	\N	\N	\N	80	40	172617
1986-01-10 12:00:00+00	1986-01-10 12:00:00+00	1986-01-10 12:00:00+00	0	301.9	\N	\N	301.9	\N	\N	\N	\N	80	40	172619
1987-01-13 12:00:00+00	1987-01-13 12:00:00+00	1987-01-13 12:00:00+00	0	301.13	\N	\N	301.13	\N	\N	\N	\N	80	40	172621
1988-01-11 12:00:00+00	1988-01-11 12:00:00+00	1988-01-11 12:00:00+00	0	300.57	\N	\N	300.57	\N	\N	\N	\N	80	40	172623
1988-09-16 12:00:00+00	1988-09-16 12:00:00+00	1988-09-16 12:00:00+00	0	300.48	\N	\N	300.48	\N	\N	\N	\N	80	40	172625
1988-12-15 12:00:00+00	1988-12-15 12:00:00+00	1988-12-15 12:00:00+00	0	300.59	\N	\N	300.59	\N	\N	\N	\N	80	40	172627
1989-01-07 12:00:00+00	1989-01-07 12:00:00+00	1989-01-07 12:00:00+00	0	300.32	\N	\N	300.32	\N	\N	\N	\N	80	40	172629
1989-03-16 12:00:00+00	1989-03-16 12:00:00+00	1989-03-16 12:00:00+00	0	300.21	\N	\N	300.21	\N	\N	\N	\N	80	40	172631
1989-05-16 12:00:00+00	1989-05-16 12:00:00+00	1989-05-16 12:00:00+00	0	300.1	\N	\N	300.1	\N	\N	\N	\N	80	40	172633
1990-01-04 12:00:00+00	1990-01-04 12:00:00+00	1990-01-04 12:00:00+00	0	299.97	\N	\N	299.97	\N	\N	\N	\N	80	40	172635
1990-01-12 12:00:00+00	1990-01-12 12:00:00+00	1990-01-12 12:00:00+00	0	300.23	\N	\N	300.23	\N	\N	\N	\N	80	40	172637
1990-12-14 12:00:00+00	1990-12-14 12:00:00+00	1990-12-14 12:00:00+00	0	299.41	\N	\N	299.41	\N	\N	\N	\N	80	40	172639
1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	0	299.69	\N	\N	299.69	\N	\N	\N	\N	80	40	172641
1991-01-16 12:00:00+00	1991-01-16 12:00:00+00	1991-01-16 12:00:00+00	0	299.61	\N	\N	299.61	\N	\N	\N	\N	80	40	172643
1991-06-14 12:00:00+00	1991-06-14 12:00:00+00	1991-06-14 12:00:00+00	0	299.25	\N	\N	299.25	\N	\N	\N	\N	80	40	172645
1991-07-31 12:00:00+00	1991-07-31 12:00:00+00	1991-07-31 12:00:00+00	0	299.36	\N	\N	299.36	\N	\N	\N	\N	80	40	172647
1991-12-17 12:00:00+00	1991-12-17 12:00:00+00	1991-12-17 12:00:00+00	0	299.3	\N	\N	299.3	\N	\N	\N	\N	80	40	172649
1992-01-03 12:00:00+00	1992-01-03 12:00:00+00	1992-01-03 12:00:00+00	0	299.14	\N	\N	299.14	\N	\N	\N	\N	80	40	172651
1992-03-17 12:00:00+00	1992-03-17 12:00:00+00	1992-03-17 12:00:00+00	0	298.72	\N	\N	298.72	\N	\N	\N	\N	80	40	172653
1992-08-21 12:00:00+00	1992-08-21 12:00:00+00	1992-08-21 12:00:00+00	0	298.68	\N	\N	298.68	\N	\N	\N	\N	80	40	172655
1992-12-15 12:00:00+00	1992-12-15 12:00:00+00	1992-12-15 12:00:00+00	0	298.4	\N	\N	298.4	\N	\N	\N	\N	80	40	172657
1993-01-05 12:00:00+00	1993-01-05 12:00:00+00	1993-01-05 12:00:00+00	0	298.66	\N	\N	298.66	\N	\N	\N	\N	80	40	172659
1993-01-15 12:00:00+00	1993-01-15 12:00:00+00	1993-01-15 12:00:00+00	0	298.66	\N	\N	298.66	\N	\N	\N	\N	80	40	172661
1993-03-12 12:00:00+00	1993-03-12 12:00:00+00	1993-03-12 12:00:00+00	0	298.85	\N	\N	298.85	\N	\N	\N	\N	80	40	172663
1994-01-04 12:00:00+00	1994-01-04 12:00:00+00	1994-01-04 12:00:00+00	0	298.48	\N	\N	298.48	\N	\N	\N	\N	80	40	172665
1994-08-22 12:00:00+00	1994-08-22 12:00:00+00	1994-08-22 12:00:00+00	0	297.9	\N	\N	297.9	\N	\N	\N	\N	80	40	172667
1995-01-06 12:00:00+00	1995-01-06 12:00:00+00	1995-01-06 12:00:00+00	0	297.65	\N	\N	297.65	\N	\N	\N	\N	80	40	172669
1996-01-11 12:00:00+00	1996-01-11 12:00:00+00	1996-01-11 12:00:00+00	0	297.79	\N	\N	297.79	\N	\N	\N	\N	80	40	172671
1996-03-14 12:00:00+00	1996-03-14 12:00:00+00	1996-03-14 12:00:00+00	0	297.43	\N	\N	297.43	\N	\N	\N	\N	80	40	172673
1996-08-09 12:00:00+00	1996-08-09 12:00:00+00	1996-08-09 12:00:00+00	0	297.67	\N	\N	297.67	\N	\N	\N	\N	80	40	172675
1996-09-29 12:00:00+00	1996-09-29 12:00:00+00	1996-09-29 12:00:00+00	0	298.71	\N	\N	298.71	\N	\N	\N	\N	80	40	172677
1996-10-03 12:00:00+00	1996-10-03 12:00:00+00	1996-10-03 12:00:00+00	0	297.64	\N	\N	297.64	\N	\N	\N	\N	80	40	172679
1996-12-17 12:00:00+00	1996-12-17 12:00:00+00	1996-12-17 12:00:00+00	0	297.54	\N	\N	297.54	\N	\N	\N	\N	80	40	172681
1997-03-13 12:00:00+00	1997-03-13 12:00:00+00	1997-03-13 12:00:00+00	0	297	\N	\N	297	\N	\N	\N	\N	80	40	172683
1997-05-22 12:00:00+00	1997-05-22 12:00:00+00	1997-05-22 12:00:00+00	0	296.7	\N	\N	296.7	\N	\N	\N	\N	80	40	172685
1997-06-12 12:00:00+00	1997-06-12 12:00:00+00	1997-06-12 12:00:00+00	0	297.05	\N	\N	297.05	\N	\N	\N	\N	80	40	172687
1997-09-17 12:00:00+00	1997-09-17 12:00:00+00	1997-09-17 12:00:00+00	0	297.05	\N	\N	297.05	\N	\N	\N	\N	80	40	172689
1997-10-03 12:00:00+00	1997-10-03 12:00:00+00	1997-10-03 12:00:00+00	0	296.91	\N	\N	296.91	\N	\N	\N	\N	80	40	172691
1997-12-16 12:00:00+00	1997-12-16 12:00:00+00	1997-12-16 12:00:00+00	0	297.08	\N	\N	297.08	\N	\N	\N	\N	80	40	172693
1998-03-20 12:00:00+00	1998-03-20 12:00:00+00	1998-03-20 12:00:00+00	0	297.2	\N	\N	297.2	\N	\N	\N	\N	80	40	172695
1998-03-31 12:00:00+00	1998-03-31 12:00:00+00	1998-03-31 12:00:00+00	0	296.88	\N	\N	296.88	\N	\N	\N	\N	80	40	172697
1998-10-02 12:00:00+00	1998-10-02 12:00:00+00	1998-10-02 12:00:00+00	0	296.55	\N	\N	296.55	\N	\N	\N	\N	80	40	172699
1998-12-04 21:14:00+00	1998-12-04 21:14:00+00	1998-12-04 21:14:00+00	0	296.46	\N	\N	296.46	\N	\N	\N	\N	80	40	172701
1999-03-05 12:00:00+00	1999-03-05 12:00:00+00	1999-03-05 12:00:00+00	0	296.6	\N	\N	296.6	\N	\N	\N	\N	80	40	172703
1999-03-25 18:00:00+00	1999-03-25 18:00:00+00	1999-03-25 18:00:00+00	0	296.79	\N	\N	296.79	\N	\N	\N	\N	80	40	172705
1999-05-04 16:15:00+00	1999-05-04 16:15:00+00	1999-05-04 16:15:00+00	0	296.24	\N	\N	296.24	\N	\N	\N	\N	80	40	172707
1999-07-06 12:00:00+00	1999-07-06 12:00:00+00	1999-07-06 12:00:00+00	0	296.66	\N	\N	296.66	\N	\N	\N	\N	80	40	172709
1999-10-13 16:00:00+00	1999-10-13 16:00:00+00	1999-10-13 16:00:00+00	0	296.39	\N	\N	296.39	\N	\N	\N	\N	80	40	172711
1999-10-15 17:45:00+00	1999-10-15 17:45:00+00	1999-10-15 17:45:00+00	0	296.12	\N	\N	296.12	\N	\N	\N	\N	80	40	172713
2000-02-07 22:45:00+00	2000-02-07 22:45:00+00	2000-02-07 22:45:00+00	0	296.38	\N	\N	296.38	\N	\N	\N	\N	80	40	172715
2000-05-02 14:15:00+00	2000-05-02 14:15:00+00	2000-05-02 14:15:00+00	0	296.22	\N	\N	296.22	\N	\N	\N	\N	80	40	172717
2000-07-31 19:30:00+00	2000-07-31 19:30:00+00	2000-07-31 19:30:00+00	0	296.15	\N	\N	296.15	\N	\N	\N	\N	80	40	172719
2000-10-10 19:10:00+00	2000-10-10 19:10:00+00	2000-10-10 19:10:00+00	0	295.81	\N	\N	295.81	\N	\N	\N	\N	80	40	172721
2000-10-27 20:17:00+00	2000-10-27 20:17:00+00	2000-10-27 20:17:00+00	0	296.02	\N	\N	296.02	\N	\N	\N	\N	80	40	172723
2001-01-09 21:00:00+00	2001-01-09 21:00:00+00	2001-01-09 21:00:00+00	0	295.94	\N	\N	295.94	\N	\N	\N	\N	80	40	172725
2001-03-28 23:30:00+00	2001-03-28 23:30:00+00	2001-03-28 23:30:00+00	0	295.65	\N	\N	295.65	\N	\N	\N	\N	80	40	172727
2001-04-26 21:00:00+00	2001-04-26 21:00:00+00	2001-04-26 21:00:00+00	0	295.86	\N	\N	295.86	\N	\N	\N	\N	80	40	172729
2001-05-29 18:00:00+00	2001-05-29 18:00:00+00	2001-05-29 18:00:00+00	0	295.8	\N	\N	295.8	\N	\N	\N	\N	80	40	172731
2001-06-26 20:20:00+00	2001-06-26 20:20:00+00	2001-06-26 20:20:00+00	0	295.86	\N	\N	295.86	\N	\N	\N	\N	80	40	172733
2001-07-27 20:03:00+00	2001-07-27 20:03:00+00	2001-07-27 20:03:00+00	0	295.9	\N	\N	295.9	\N	\N	\N	\N	80	40	172735
2001-10-02 20:07:00+00	2001-10-02 20:07:00+00	2001-10-02 20:07:00+00	0	295.55	\N	\N	295.55	\N	\N	\N	\N	80	40	172737
2001-11-19 21:50:00+00	2001-11-19 21:50:00+00	2001-11-19 21:50:00+00	0	296.01	\N	\N	296.01	\N	\N	\N	\N	80	40	172739
2002-08-14 12:00:00+00	2002-08-14 12:00:00+00	2002-08-14 12:00:00+00	0	295.62	\N	\N	295.62	\N	\N	\N	\N	80	40	172741
2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	0	295.49	\N	\N	295.49	\N	\N	\N	\N	80	40	172743
2003-07-08 12:00:00+00	2003-07-08 12:00:00+00	2003-07-08 12:00:00+00	0	295.35	\N	\N	295.35	\N	\N	\N	\N	80	40	172745
2004-02-24 16:30:00+00	2004-02-24 16:30:00+00	2004-02-24 16:30:00+00	0	295.09	\N	\N	295.09	\N	\N	\N	\N	80	40	172747
2004-08-21 12:00:00+00	2004-08-21 12:00:00+00	2004-08-21 12:00:00+00	0	295.08	\N	\N	295.08	\N	\N	\N	\N	80	40	172749
2006-02-23 19:45:00+00	2006-02-23 19:45:00+00	2006-02-23 19:45:00+00	0	294.89	\N	\N	294.89	\N	\N	\N	\N	80	40	172751
2006-09-13 20:30:00+00	2006-09-13 20:30:00+00	2006-09-13 20:30:00+00	0	294.41	\N	\N	294.41	\N	\N	\N	\N	80	40	172753
2007-05-22 19:20:00+00	2007-05-22 19:20:00+00	2007-05-22 19:20:00+00	0	294.37	\N	\N	294.37	\N	\N	\N	\N	80	40	172755
2007-09-20 19:45:00+00	2007-09-20 19:45:00+00	2007-09-20 19:45:00+00	0	294.37	\N	\N	294.37	\N	\N	\N	\N	80	40	172757
2008-03-12 23:10:00+00	2008-03-12 23:10:00+00	2008-03-12 23:10:00+00	0	294.05	\N	\N	294.05	\N	\N	\N	\N	80	40	172759
2008-09-25 18:39:00+00	2008-09-25 18:39:00+00	2008-09-25 18:39:00+00	0	294.3	\N	\N	294.3	\N	\N	\N	\N	80	40	172761
2009-10-26 16:25:00+00	2009-10-26 16:25:00+00	2009-10-26 16:25:00+00	0	294.51	\N	\N	294.51	\N	\N	\N	\N	80	40	172763
2010-02-21 19:23:00+00	2010-02-21 19:23:00+00	2010-02-21 19:23:00+00	0	294.31	\N	\N	294.31	\N	\N	\N	\N	80	40	172765
2010-08-28 17:30:00+00	2010-08-28 17:30:00+00	2010-08-28 17:30:00+00	0	294.03	\N	\N	294.03	\N	\N	\N	\N	80	40	172767
2012-01-24 19:30:00+00	2012-01-24 19:30:00+00	2012-01-24 19:30:00+00	0	293.9	\N	\N	293.9	\N	\N	\N	\N	80	40	172769
2012-04-16 19:42:00+00	2012-04-16 19:42:00+00	2012-04-16 19:42:00+00	0	294.66	\N	\N	294.66	\N	\N	\N	\N	80	40	172771
2013-01-29 20:15:00+00	2013-01-29 20:15:00+00	2013-01-29 20:15:00+00	0	293.53	\N	\N	293.53	\N	\N	\N	\N	80	40	172773
2015-01-26 22:10:00+00	2015-01-26 22:10:00+00	2015-01-26 22:10:00+00	0	293.8	\N	\N	293.8	\N	\N	\N	\N	80	40	172775
2016-01-28 16:50:00+00	2016-01-28 16:50:00+00	2016-01-28 16:50:00+00	0	294.37	\N	\N	294.37	\N	\N	\N	\N	80	40	172777
2016-08-18 18:00:00+00	2016-08-18 18:00:00+00	2016-08-18 18:00:00+00	0	293.13	\N	\N	293.13	\N	\N	\N	\N	80	40	172779
2017-02-16 21:30:00+00	2017-02-16 21:30:00+00	2017-02-16 21:30:00+00	0	292.96	\N	\N	292.96	\N	\N	\N	\N	80	40	172781
2017-07-25 23:10:00+00	2017-07-25 23:10:00+00	2017-07-25 23:10:00+00	0	293.15	\N	\N	293.15	\N	\N	\N	\N	80	40	172783
2018-12-05 20:07:00+00	2018-12-05 20:07:00+00	2018-12-05 20:07:00+00	0	294.35	\N	\N	294.35	\N	\N	\N	\N	80	40	172785
2020-01-14 21:05:00+00	2020-01-14 21:05:00+00	2020-01-14 21:05:00+00	0	294.4	\N	\N	294.4	\N	\N	\N	\N	80	40	172787
1985-03-06 00:00:00+00	1985-03-06 00:00:00+00	1985-03-06 00:00:00+00	0	22.3	\N	\N	22.3	\N	\N	\N	\N	88	44	173017
1985-03-07 00:00:00+00	1985-03-07 00:00:00+00	1985-03-07 00:00:00+00	0	22.33	\N	\N	22.33	\N	\N	\N	\N	88	44	173019
1985-03-08 00:00:00+00	1985-03-08 00:00:00+00	1985-03-08 00:00:00+00	0	22.34	\N	\N	22.34	\N	\N	\N	\N	88	44	173021
1985-03-09 00:00:00+00	1985-03-09 00:00:00+00	1985-03-09 00:00:00+00	0	22.38	\N	\N	22.38	\N	\N	\N	\N	88	44	173023
1985-03-10 00:00:00+00	1985-03-10 00:00:00+00	1985-03-10 00:00:00+00	0	23.51	\N	\N	23.51	\N	\N	\N	\N	88	44	173025
1985-03-11 00:00:00+00	1985-03-11 00:00:00+00	1985-03-11 00:00:00+00	0	22.39	\N	\N	22.39	\N	\N	\N	\N	88	44	173027
1985-03-12 00:00:00+00	1985-03-12 00:00:00+00	1985-03-12 00:00:00+00	0	22.4	\N	\N	22.4	\N	\N	\N	\N	88	44	173029
1985-03-13 00:00:00+00	1985-03-13 00:00:00+00	1985-03-13 00:00:00+00	0	22.46	\N	\N	22.46	\N	\N	\N	\N	88	44	173031
1985-03-14 00:00:00+00	1985-03-14 00:00:00+00	1985-03-14 00:00:00+00	0	22.44	\N	\N	22.44	\N	\N	\N	\N	88	44	173033
1985-03-15 00:00:00+00	1985-03-15 00:00:00+00	1985-03-15 00:00:00+00	0	22.25	\N	\N	22.25	\N	\N	\N	\N	88	44	173035
1985-03-16 00:00:00+00	1985-03-16 00:00:00+00	1985-03-16 00:00:00+00	0	22.15	\N	\N	22.15	\N	\N	\N	\N	88	44	173037
1985-03-17 00:00:00+00	1985-03-17 00:00:00+00	1985-03-17 00:00:00+00	0	22.14	\N	\N	22.14	\N	\N	\N	\N	88	44	173039
1985-03-18 00:00:00+00	1985-03-18 00:00:00+00	1985-03-18 00:00:00+00	0	22.08	\N	\N	22.08	\N	\N	\N	\N	88	44	173041
1985-03-19 00:00:00+00	1985-03-19 00:00:00+00	1985-03-19 00:00:00+00	0	22.02	\N	\N	22.02	\N	\N	\N	\N	88	44	173043
1985-03-20 00:00:00+00	1985-03-20 00:00:00+00	1985-03-20 00:00:00+00	0	22.04	\N	\N	22.04	\N	\N	\N	\N	88	44	173045
1985-03-21 00:00:00+00	1985-03-21 00:00:00+00	1985-03-21 00:00:00+00	0	22.04	\N	\N	22.04	\N	\N	\N	\N	88	44	173047
1985-03-22 00:00:00+00	1985-03-22 00:00:00+00	1985-03-22 00:00:00+00	0	22.1	\N	\N	22.1	\N	\N	\N	\N	88	44	173049
1985-03-23 00:00:00+00	1985-03-23 00:00:00+00	1985-03-23 00:00:00+00	0	22.14	\N	\N	22.14	\N	\N	\N	\N	88	44	173051
1985-03-24 00:00:00+00	1985-03-24 00:00:00+00	1985-03-24 00:00:00+00	0	23.46	\N	\N	23.46	\N	\N	\N	\N	88	44	173053
1985-03-25 00:00:00+00	1985-03-25 00:00:00+00	1985-03-25 00:00:00+00	0	22.35	\N	\N	22.35	\N	\N	\N	\N	88	44	173055
1985-03-26 00:00:00+00	1985-03-26 00:00:00+00	1985-03-26 00:00:00+00	0	22.35	\N	\N	22.35	\N	\N	\N	\N	88	44	173057
1985-03-27 00:00:00+00	1985-03-27 00:00:00+00	1985-03-27 00:00:00+00	0	22.29	\N	\N	22.29	\N	\N	\N	\N	88	44	173059
1985-03-28 00:00:00+00	1985-03-28 00:00:00+00	1985-03-28 00:00:00+00	0	22.22	\N	\N	22.22	\N	\N	\N	\N	88	44	173061
1985-03-29 00:00:00+00	1985-03-29 00:00:00+00	1985-03-29 00:00:00+00	0	22.2	\N	\N	22.2	\N	\N	\N	\N	88	44	173063
1985-03-30 00:00:00+00	1985-03-30 00:00:00+00	1985-03-30 00:00:00+00	0	22.21	\N	\N	22.21	\N	\N	\N	\N	88	44	173065
1985-03-31 00:00:00+00	1985-03-31 00:00:00+00	1985-03-31 00:00:00+00	0	22.24	\N	\N	22.24	\N	\N	\N	\N	88	44	173067
1985-04-01 00:00:00+00	1985-04-01 00:00:00+00	1985-04-01 00:00:00+00	0	22.38	\N	\N	22.38	\N	\N	\N	\N	88	44	173069
1985-04-02 00:00:00+00	1985-04-02 00:00:00+00	1985-04-02 00:00:00+00	0	22.51	\N	\N	22.51	\N	\N	\N	\N	88	44	173071
1985-04-03 00:00:00+00	1985-04-03 00:00:00+00	1985-04-03 00:00:00+00	0	22.75	\N	\N	22.75	\N	\N	\N	\N	88	44	173073
1985-04-04 00:00:00+00	1985-04-04 00:00:00+00	1985-04-04 00:00:00+00	0	24.16	\N	\N	24.16	\N	\N	\N	\N	88	44	173075
1985-04-05 00:00:00+00	1985-04-05 00:00:00+00	1985-04-05 00:00:00+00	0	23.13	\N	\N	23.13	\N	\N	\N	\N	88	44	173077
1985-04-06 00:00:00+00	1985-04-06 00:00:00+00	1985-04-06 00:00:00+00	0	22.8	\N	\N	22.8	\N	\N	\N	\N	88	44	173079
1985-04-07 00:00:00+00	1985-04-07 00:00:00+00	1985-04-07 00:00:00+00	0	22.81	\N	\N	22.81	\N	\N	\N	\N	88	44	173081
1985-04-08 00:00:00+00	1985-04-08 00:00:00+00	1985-04-08 00:00:00+00	0	22.82	\N	\N	22.82	\N	\N	\N	\N	88	44	173083
1985-04-09 00:00:00+00	1985-04-09 00:00:00+00	1985-04-09 00:00:00+00	0	22.62	\N	\N	22.62	\N	\N	\N	\N	88	44	173085
1985-04-10 00:00:00+00	1985-04-10 00:00:00+00	1985-04-10 00:00:00+00	0	22.73	\N	\N	22.73	\N	\N	\N	\N	88	44	173087
1985-04-11 00:00:00+00	1985-04-11 00:00:00+00	1985-04-11 00:00:00+00	0	22.78	\N	\N	22.78	\N	\N	\N	\N	88	44	173089
1985-04-12 00:00:00+00	1985-04-12 00:00:00+00	1985-04-12 00:00:00+00	0	22.81	\N	\N	22.81	\N	\N	\N	\N	88	44	173091
1985-04-13 00:00:00+00	1985-04-13 00:00:00+00	1985-04-13 00:00:00+00	0	22.85	\N	\N	22.85	\N	\N	\N	\N	88	44	173093
1985-04-14 00:00:00+00	1985-04-14 00:00:00+00	1985-04-14 00:00:00+00	0	22.86	\N	\N	22.86	\N	\N	\N	\N	88	44	173095
1985-04-15 00:00:00+00	1985-04-15 00:00:00+00	1985-04-15 00:00:00+00	0	22.85	\N	\N	22.85	\N	\N	\N	\N	88	44	173097
1985-04-16 00:00:00+00	1985-04-16 00:00:00+00	1985-04-16 00:00:00+00	0	22.93	\N	\N	22.93	\N	\N	\N	\N	88	44	173099
1985-04-17 00:00:00+00	1985-04-17 00:00:00+00	1985-04-17 00:00:00+00	0	22.94	\N	\N	22.94	\N	\N	\N	\N	88	44	173101
1985-04-18 00:00:00+00	1985-04-18 00:00:00+00	1985-04-18 00:00:00+00	0	22.93	\N	\N	22.93	\N	\N	\N	\N	88	44	173103
1985-04-19 00:00:00+00	1985-04-19 00:00:00+00	1985-04-19 00:00:00+00	0	22.93	\N	\N	22.93	\N	\N	\N	\N	88	44	173105
1985-04-20 00:00:00+00	1985-04-20 00:00:00+00	1985-04-20 00:00:00+00	0	22.85	\N	\N	22.85	\N	\N	\N	\N	88	44	173107
1985-04-21 00:00:00+00	1985-04-21 00:00:00+00	1985-04-21 00:00:00+00	0	22.7	\N	\N	22.7	\N	\N	\N	\N	88	44	173109
1985-04-22 00:00:00+00	1985-04-22 00:00:00+00	1985-04-22 00:00:00+00	0	22.71	\N	\N	22.71	\N	\N	\N	\N	88	44	173111
1985-04-23 00:00:00+00	1985-04-23 00:00:00+00	1985-04-23 00:00:00+00	0	22.76	\N	\N	22.76	\N	\N	\N	\N	88	44	173113
1985-04-24 00:00:00+00	1985-04-24 00:00:00+00	1985-04-24 00:00:00+00	0	22.87	\N	\N	22.87	\N	\N	\N	\N	88	44	173115
1985-04-25 00:00:00+00	1985-04-25 00:00:00+00	1985-04-25 00:00:00+00	0	22.92	\N	\N	22.92	\N	\N	\N	\N	88	44	173117
1985-04-26 00:00:00+00	1985-04-26 00:00:00+00	1985-04-26 00:00:00+00	0	23.05	\N	\N	23.05	\N	\N	\N	\N	88	44	173119
1985-04-27 00:00:00+00	1985-04-27 00:00:00+00	1985-04-27 00:00:00+00	0	22.93	\N	\N	22.93	\N	\N	\N	\N	88	44	173121
1985-04-28 00:00:00+00	1985-04-28 00:00:00+00	1985-04-28 00:00:00+00	0	23.96	\N	\N	23.96	\N	\N	\N	\N	88	44	173123
1985-04-29 00:00:00+00	1985-04-29 00:00:00+00	1985-04-29 00:00:00+00	0	22.72	\N	\N	22.72	\N	\N	\N	\N	88	44	173125
1985-04-30 00:00:00+00	1985-04-30 00:00:00+00	1985-04-30 00:00:00+00	0	22.4	\N	\N	22.4	\N	\N	\N	\N	88	44	173127
1985-05-01 00:00:00+00	1985-05-01 00:00:00+00	1985-05-01 00:00:00+00	0	22.32	\N	\N	22.32	\N	\N	\N	\N	88	44	173129
1985-05-02 00:00:00+00	1985-05-02 00:00:00+00	1985-05-02 00:00:00+00	0	22.29	\N	\N	22.29	\N	\N	\N	\N	88	44	173131
1985-05-03 00:00:00+00	1985-05-03 00:00:00+00	1985-05-03 00:00:00+00	0	22.26	\N	\N	22.26	\N	\N	\N	\N	88	44	173133
1985-05-04 00:00:00+00	1985-05-04 00:00:00+00	1985-05-04 00:00:00+00	0	22.24	\N	\N	22.24	\N	\N	\N	\N	88	44	173135
1985-05-05 00:00:00+00	1985-05-05 00:00:00+00	1985-05-05 00:00:00+00	0	22.3	\N	\N	22.3	\N	\N	\N	\N	88	44	173137
1985-05-06 00:00:00+00	1985-05-06 00:00:00+00	1985-05-06 00:00:00+00	0	22.45	\N	\N	22.45	\N	\N	\N	\N	88	44	173139
1985-05-07 00:00:00+00	1985-05-07 00:00:00+00	1985-05-07 00:00:00+00	0	22.56	\N	\N	22.56	\N	\N	\N	\N	88	44	173141
1985-05-08 00:00:00+00	1985-05-08 00:00:00+00	1985-05-08 00:00:00+00	0	22.64	\N	\N	22.64	\N	\N	\N	\N	88	44	173143
1985-05-09 00:00:00+00	1985-05-09 00:00:00+00	1985-05-09 00:00:00+00	0	22.68	\N	\N	22.68	\N	\N	\N	\N	88	44	173145
1985-05-10 00:00:00+00	1985-05-10 00:00:00+00	1985-05-10 00:00:00+00	0	22.73	\N	\N	22.73	\N	\N	\N	\N	88	44	173147
1985-05-11 00:00:00+00	1985-05-11 00:00:00+00	1985-05-11 00:00:00+00	0	22.8	\N	\N	22.8	\N	\N	\N	\N	88	44	173149
1985-05-12 00:00:00+00	1985-05-12 00:00:00+00	1985-05-12 00:00:00+00	0	22.81	\N	\N	22.81	\N	\N	\N	\N	88	44	173151
1985-05-13 00:00:00+00	1985-05-13 00:00:00+00	1985-05-13 00:00:00+00	0	22.8	\N	\N	22.8	\N	\N	\N	\N	88	44	173153
1985-05-14 00:00:00+00	1985-05-14 00:00:00+00	1985-05-14 00:00:00+00	0	22.82	\N	\N	22.82	\N	\N	\N	\N	88	44	173155
1985-05-15 00:00:00+00	1985-05-15 00:00:00+00	1985-05-15 00:00:00+00	0	24.29	\N	\N	24.29	\N	\N	\N	\N	88	44	173157
1985-05-16 00:00:00+00	1985-05-16 00:00:00+00	1985-05-16 00:00:00+00	0	23.13	\N	\N	23.13	\N	\N	\N	\N	88	44	173159
1985-05-17 00:00:00+00	1985-05-17 00:00:00+00	1985-05-17 00:00:00+00	0	22.93	\N	\N	22.93	\N	\N	\N	\N	88	44	173161
1985-05-18 00:00:00+00	1985-05-18 00:00:00+00	1985-05-18 00:00:00+00	0	22.94	\N	\N	22.94	\N	\N	\N	\N	88	44	173163
1985-05-19 00:00:00+00	1985-05-19 00:00:00+00	1985-05-19 00:00:00+00	0	22.94	\N	\N	22.94	\N	\N	\N	\N	88	44	173165
1985-05-20 00:00:00+00	1985-05-20 00:00:00+00	1985-05-20 00:00:00+00	0	22.94	\N	\N	22.94	\N	\N	\N	\N	88	44	173167
1985-05-21 00:00:00+00	1985-05-21 00:00:00+00	1985-05-21 00:00:00+00	0	22.94	\N	\N	22.94	\N	\N	\N	\N	88	44	173169
1985-05-22 00:00:00+00	1985-05-22 00:00:00+00	1985-05-22 00:00:00+00	0	23.05	\N	\N	23.05	\N	\N	\N	\N	88	44	173171
1985-05-23 00:00:00+00	1985-05-23 00:00:00+00	1985-05-23 00:00:00+00	0	23.12	\N	\N	23.12	\N	\N	\N	\N	88	44	173173
1985-05-24 00:00:00+00	1985-05-24 00:00:00+00	1985-05-24 00:00:00+00	0	23.11	\N	\N	23.11	\N	\N	\N	\N	88	44	173175
1985-05-25 00:00:00+00	1985-05-25 00:00:00+00	1985-05-25 00:00:00+00	0	23.09	\N	\N	23.09	\N	\N	\N	\N	88	44	173177
1985-05-26 00:00:00+00	1985-05-26 00:00:00+00	1985-05-26 00:00:00+00	0	23.07	\N	\N	23.07	\N	\N	\N	\N	88	44	173179
1985-05-27 00:00:00+00	1985-05-27 00:00:00+00	1985-05-27 00:00:00+00	0	23.05	\N	\N	23.05	\N	\N	\N	\N	88	44	173181
1985-05-28 00:00:00+00	1985-05-28 00:00:00+00	1985-05-28 00:00:00+00	0	23.06	\N	\N	23.06	\N	\N	\N	\N	88	44	173183
1985-05-29 00:00:00+00	1985-05-29 00:00:00+00	1985-05-29 00:00:00+00	0	23.08	\N	\N	23.08	\N	\N	\N	\N	88	44	173185
1985-05-30 00:00:00+00	1985-05-30 00:00:00+00	1985-05-30 00:00:00+00	0	23.13	\N	\N	23.13	\N	\N	\N	\N	88	44	173187
1985-05-31 00:00:00+00	1985-05-31 00:00:00+00	1985-05-31 00:00:00+00	0	23.14	\N	\N	23.14	\N	\N	\N	\N	88	44	173189
1985-06-01 00:00:00+00	1985-06-01 00:00:00+00	1985-06-01 00:00:00+00	0	23.12	\N	\N	23.12	\N	\N	\N	\N	88	44	173191
1985-06-02 00:00:00+00	1985-06-02 00:00:00+00	1985-06-02 00:00:00+00	0	23.1	\N	\N	23.1	\N	\N	\N	\N	88	44	173193
1985-06-03 00:00:00+00	1985-06-03 00:00:00+00	1985-06-03 00:00:00+00	0	23.07	\N	\N	23.07	\N	\N	\N	\N	88	44	173195
1985-06-04 00:00:00+00	1985-06-04 00:00:00+00	1985-06-04 00:00:00+00	0	23.07	\N	\N	23.07	\N	\N	\N	\N	88	44	173197
1985-06-05 00:00:00+00	1985-06-05 00:00:00+00	1985-06-05 00:00:00+00	0	23.07	\N	\N	23.07	\N	\N	\N	\N	88	44	173199
1985-06-06 00:00:00+00	1985-06-06 00:00:00+00	1985-06-06 00:00:00+00	0	23.06	\N	\N	23.06	\N	\N	\N	\N	88	44	173201
1985-06-07 00:00:00+00	1985-06-07 00:00:00+00	1985-06-07 00:00:00+00	0	23.06	\N	\N	23.06	\N	\N	\N	\N	88	44	173203
1985-06-08 00:00:00+00	1985-06-08 00:00:00+00	1985-06-08 00:00:00+00	0	23.06	\N	\N	23.06	\N	\N	\N	\N	88	44	173205
1985-06-09 00:00:00+00	1985-06-09 00:00:00+00	1985-06-09 00:00:00+00	0	24.53	\N	\N	24.53	\N	\N	\N	\N	88	44	173207
1985-06-10 00:00:00+00	1985-06-10 00:00:00+00	1985-06-10 00:00:00+00	0	23.11	\N	\N	23.11	\N	\N	\N	\N	88	44	173209
1985-06-11 00:00:00+00	1985-06-11 00:00:00+00	1985-06-11 00:00:00+00	0	23.09	\N	\N	23.09	\N	\N	\N	\N	88	44	173211
1985-06-12 00:00:00+00	1985-06-12 00:00:00+00	1985-06-12 00:00:00+00	0	23.1	\N	\N	23.1	\N	\N	\N	\N	88	44	173213
1985-06-13 00:00:00+00	1985-06-13 00:00:00+00	1985-06-13 00:00:00+00	0	23.1	\N	\N	23.1	\N	\N	\N	\N	88	44	173215
2011-01-25 20:50:00+00	2011-01-25 20:50:00+00	2011-01-25 20:50:00+00	0	5242.3	\N	\N	5242.3	\N	\N	\N	\N	17	9	512
2011-05-25 15:13:00+00	2011-05-25 15:13:00+00	2011-05-25 15:13:00+00	0	5241.73	\N	\N	5241.73	\N	\N	\N	\N	17	9	514
2011-06-22 19:40:00+00	2011-06-22 19:40:00+00	2011-06-22 19:40:00+00	0	5241.61	\N	\N	5241.61	\N	\N	\N	\N	17	9	516
2011-07-26 18:30:00+00	2011-07-26 18:30:00+00	2011-07-26 18:30:00+00	0	5241.66	\N	\N	5241.66	\N	\N	\N	\N	17	9	518
2011-09-01 19:00:00+00	2011-09-01 19:00:00+00	2011-09-01 19:00:00+00	0	5241.62	\N	\N	5241.62	\N	\N	\N	\N	17	9	520
2011-11-08 23:15:00+00	2011-11-08 23:15:00+00	2011-11-08 23:15:00+00	0	5241.66	\N	\N	5241.66	\N	\N	\N	\N	17	9	522
2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	0	5241.46	\N	\N	5241.46	\N	\N	\N	\N	17	9	524
2012-01-10 18:06:00+00	2012-01-10 18:06:00+00	2012-01-10 18:06:00+00	0	5241.24	\N	\N	5241.24	\N	\N	\N	\N	17	9	526
2012-02-08 00:30:00+00	2012-02-08 00:30:00+00	2012-02-08 00:30:00+00	0	5241.09	\N	\N	5241.09	\N	\N	\N	\N	17	9	528
2012-03-06 23:30:00+00	2012-03-06 23:30:00+00	2012-03-06 23:30:00+00	0	5241.12	\N	\N	5241.12	\N	\N	\N	\N	17	9	530
2012-04-12 19:00:00+00	2012-04-12 19:00:00+00	2012-04-12 19:00:00+00	0	5240.86	\N	\N	5240.86	\N	\N	\N	\N	17	9	532
2012-05-09 00:00:00+00	2012-05-09 00:00:00+00	2012-05-09 00:00:00+00	0	5240.74	\N	\N	5240.74	\N	\N	\N	\N	17	9	534
2012-08-14 22:00:00+00	2012-08-14 22:00:00+00	2012-08-14 22:00:00+00	0	5242.21	\N	\N	5242.21	\N	\N	\N	\N	17	9	536
2012-10-09 16:50:00+00	2012-10-09 16:50:00+00	2012-10-09 16:50:00+00	0	5242.26	\N	\N	5242.26	\N	\N	\N	\N	17	9	538
2013-02-27 18:30:00+00	2013-02-27 18:30:00+00	2013-02-27 18:30:00+00	0	5242.15	\N	\N	5242.15	\N	\N	\N	\N	17	9	540
2013-04-03 14:05:00+00	2013-04-03 14:05:00+00	2013-04-03 14:05:00+00	0	5241.83	\N	\N	5241.83	\N	\N	\N	\N	17	9	542
2013-07-09 22:40:00+00	2013-07-09 22:40:00+00	2013-07-09 22:40:00+00	0	5241.46	\N	\N	5241.46	\N	\N	\N	\N	17	9	544
2013-12-10 21:55:00+00	2013-12-10 21:55:00+00	2013-12-10 21:55:00+00	0	5244.16	\N	\N	5244.16	\N	\N	\N	\N	17	9	546
2016-08-12 18:00:00+00	2016-08-12 18:00:00+00	2016-08-12 18:00:00+00	0	5247.37	\N	\N	5247.37	\N	\N	\N	\N	17	9	548
2018-02-06 18:29:00+00	2018-02-06 18:29:00+00	2018-02-06 18:29:00+00	0	5244.36	\N	\N	5244.36	\N	\N	\N	\N	17	9	550
2019-12-12 22:23:00+00	2019-12-12 22:23:00+00	2019-12-12 22:23:00+00	0	5242.88	\N	\N	5242.88	\N	\N	\N	\N	17	9	552
1973-06-05 12:00:00+00	1973-06-05 12:00:00+00	1973-06-05 12:00:00+00	0	5281	\N	\N	5281	\N	\N	\N	\N	19	10	554
1986-11-20 12:00:00+00	1986-11-20 12:00:00+00	1986-11-20 12:00:00+00	0	5289.99	\N	\N	5289.99	\N	\N	\N	\N	19	10	556
2007-08-09 02:00:00+00	2007-08-09 02:00:00+00	2007-08-09 02:00:00+00	0	5205.93	\N	\N	5205.93	\N	\N	\N	\N	19	10	558
2008-03-25 20:30:00+00	2008-03-25 20:30:00+00	2008-03-25 20:30:00+00	0	5214.46	\N	\N	5214.46	\N	\N	\N	\N	19	10	560
2009-03-24 18:45:00+00	2009-03-24 18:45:00+00	2009-03-24 18:45:00+00	0	5202.39	\N	\N	5202.39	\N	\N	\N	\N	19	10	562
2010-03-16 19:30:00+00	2010-03-16 19:30:00+00	2010-03-16 19:30:00+00	0	5199.82	\N	\N	5199.82	\N	\N	\N	\N	19	10	564
2011-01-26 15:40:00+00	2011-01-26 15:40:00+00	2011-01-26 15:40:00+00	0	5192.42	\N	\N	5192.42	\N	\N	\N	\N	19	10	566
2011-05-25 14:26:00+00	2011-05-25 14:26:00+00	2011-05-25 14:26:00+00	0	5192.43	\N	\N	5192.43	\N	\N	\N	\N	19	10	568
2011-06-22 18:30:00+00	2011-06-22 18:30:00+00	2011-06-22 18:30:00+00	0	5192.3	\N	\N	5192.3	\N	\N	\N	\N	19	10	570
2011-07-26 20:00:00+00	2011-07-26 20:00:00+00	2011-07-26 20:00:00+00	0	5192.66	\N	\N	5192.66	\N	\N	\N	\N	19	10	572
2011-09-01 17:30:00+00	2011-09-01 17:30:00+00	2011-09-01 17:30:00+00	0	5192.72	\N	\N	5192.72	\N	\N	\N	\N	19	10	574
2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	0	5192.71	\N	\N	5192.71	\N	\N	\N	\N	19	10	576
2011-11-08 21:00:00+00	2011-11-08 21:00:00+00	2011-11-08 21:00:00+00	0	5192.86	\N	\N	5192.86	\N	\N	\N	\N	19	10	578
2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	0	5193.05	\N	\N	5193.05	\N	\N	\N	\N	19	10	580
2012-01-10 16:00:00+00	2012-01-10 16:00:00+00	2012-01-10 16:00:00+00	0	5193.23	\N	\N	5193.23	\N	\N	\N	\N	19	10	582
2012-02-07 23:00:00+00	2012-02-07 23:00:00+00	2012-02-07 23:00:00+00	0	5189.99	\N	\N	5189.99	\N	\N	\N	\N	19	10	584
2012-03-06 21:50:00+00	2012-03-06 21:50:00+00	2012-03-06 21:50:00+00	0	5191.2	\N	\N	5191.2	\N	\N	\N	\N	19	10	586
2012-04-12 21:30:00+00	2012-04-12 21:30:00+00	2012-04-12 21:30:00+00	0	5189.53	\N	\N	5189.53	\N	\N	\N	\N	19	10	588
2012-05-09 00:35:00+00	2012-05-09 00:35:00+00	2012-05-09 00:35:00+00	0	5190.02	\N	\N	5190.02	\N	\N	\N	\N	19	10	590
2012-08-15 00:00:00+00	2012-08-15 00:00:00+00	2012-08-15 00:00:00+00	0	5188.11	\N	\N	5188.11	\N	\N	\N	\N	19	10	592
2012-10-09 22:50:00+00	2012-10-09 22:50:00+00	2012-10-09 22:50:00+00	0	5188.83	\N	\N	5188.83	\N	\N	\N	\N	19	10	594
2013-02-27 00:50:00+00	2013-02-27 00:50:00+00	2013-02-27 00:50:00+00	0	5188.55	\N	\N	5188.55	\N	\N	\N	\N	19	10	596
2013-04-03 18:00:00+00	2013-04-03 18:00:00+00	2013-04-03 18:00:00+00	0	5187.57	\N	\N	5187.57	\N	\N	\N	\N	19	10	598
2013-07-09 23:00:00+00	2013-07-09 23:00:00+00	2013-07-09 23:00:00+00	0	5186.83	\N	\N	5186.83	\N	\N	\N	\N	19	10	600
2013-12-10 22:30:00+00	2013-12-10 22:30:00+00	2013-12-10 22:30:00+00	0	5187.53	\N	\N	5187.53	\N	\N	\N	\N	19	10	602
2016-02-22 15:00:00+00	2016-02-22 15:00:00+00	2016-02-22 15:00:00+00	0	5152.72	\N	\N	5152.72	\N	\N	\N	\N	19	10	604
2016-08-12 21:00:00+00	2016-08-12 21:00:00+00	2016-08-12 21:00:00+00	0	5147.16	\N	\N	5147.16	\N	\N	\N	\N	19	10	606
2019-12-12 21:05:00+00	2019-12-12 21:05:00+00	2019-12-12 21:05:00+00	0	5139.31	\N	\N	5139.31	\N	\N	\N	\N	19	10	608
1973-06-05 12:00:00+00	1973-06-05 12:00:00+00	1973-06-05 12:00:00+00	0	65	\N	\N	65	\N	\N	\N	\N	20	10	553
1986-11-20 12:00:00+00	1986-11-20 12:00:00+00	1986-11-20 12:00:00+00	0	55.57	\N	\N	55.57	\N	\N	\N	\N	20	10	555
2007-08-09 02:00:00+00	2007-08-09 02:00:00+00	2007-08-09 02:00:00+00	0	139.63	\N	\N	139.63	\N	\N	\N	\N	20	10	557
2008-03-25 20:30:00+00	2008-03-25 20:30:00+00	2008-03-25 20:30:00+00	0	131.1	\N	\N	131.1	\N	\N	\N	\N	20	10	559
2009-03-24 18:45:00+00	2009-03-24 18:45:00+00	2009-03-24 18:45:00+00	0	143.17	\N	\N	143.17	\N	\N	\N	\N	20	10	561
2010-03-16 19:30:00+00	2010-03-16 19:30:00+00	2010-03-16 19:30:00+00	0	145.74	\N	\N	145.74	\N	\N	\N	\N	20	10	563
2011-01-26 15:40:00+00	2011-01-26 15:40:00+00	2011-01-26 15:40:00+00	0	153.14	\N	\N	153.14	\N	\N	\N	\N	20	10	565
2011-05-25 14:26:00+00	2011-05-25 14:26:00+00	2011-05-25 14:26:00+00	0	153.13	\N	\N	153.13	\N	\N	\N	\N	20	10	567
2011-06-22 18:30:00+00	2011-06-22 18:30:00+00	2011-06-22 18:30:00+00	0	153.26	\N	\N	153.26	\N	\N	\N	\N	20	10	569
2011-07-26 20:00:00+00	2011-07-26 20:00:00+00	2011-07-26 20:00:00+00	0	152.9	\N	\N	152.9	\N	\N	\N	\N	20	10	571
2011-09-01 17:30:00+00	2011-09-01 17:30:00+00	2011-09-01 17:30:00+00	0	152.84	\N	\N	152.84	\N	\N	\N	\N	20	10	573
2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	2011-10-04 18:00:00+00	0	152.85	\N	\N	152.85	\N	\N	\N	\N	20	10	575
2011-11-08 21:00:00+00	2011-11-08 21:00:00+00	2011-11-08 21:00:00+00	0	152.7	\N	\N	152.7	\N	\N	\N	\N	20	10	577
2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	0	152.51	\N	\N	152.51	\N	\N	\N	\N	20	10	579
2012-01-10 16:00:00+00	2012-01-10 16:00:00+00	2012-01-10 16:00:00+00	0	152.33	\N	\N	152.33	\N	\N	\N	\N	20	10	581
2012-02-07 23:00:00+00	2012-02-07 23:00:00+00	2012-02-07 23:00:00+00	0	155.57	\N	\N	155.57	\N	\N	\N	\N	20	10	583
2012-03-06 21:50:00+00	2012-03-06 21:50:00+00	2012-03-06 21:50:00+00	0	154.36	\N	\N	154.36	\N	\N	\N	\N	20	10	585
2012-04-12 21:30:00+00	2012-04-12 21:30:00+00	2012-04-12 21:30:00+00	0	156.03	\N	\N	156.03	\N	\N	\N	\N	20	10	587
2012-05-09 00:35:00+00	2012-05-09 00:35:00+00	2012-05-09 00:35:00+00	0	155.54	\N	\N	155.54	\N	\N	\N	\N	20	10	589
2012-08-15 00:00:00+00	2012-08-15 00:00:00+00	2012-08-15 00:00:00+00	0	157.45	\N	\N	157.45	\N	\N	\N	\N	20	10	591
2012-10-09 22:50:00+00	2012-10-09 22:50:00+00	2012-10-09 22:50:00+00	0	156.73	\N	\N	156.73	\N	\N	\N	\N	20	10	593
2013-02-27 00:50:00+00	2013-02-27 00:50:00+00	2013-02-27 00:50:00+00	0	157.01	\N	\N	157.01	\N	\N	\N	\N	20	10	595
2013-04-03 18:00:00+00	2013-04-03 18:00:00+00	2013-04-03 18:00:00+00	0	157.99	\N	\N	157.99	\N	\N	\N	\N	20	10	597
2013-07-09 23:00:00+00	2013-07-09 23:00:00+00	2013-07-09 23:00:00+00	0	158.73	\N	\N	158.73	\N	\N	\N	\N	20	10	599
2013-12-10 22:30:00+00	2013-12-10 22:30:00+00	2013-12-10 22:30:00+00	0	158.03	\N	\N	158.03	\N	\N	\N	\N	20	10	601
2016-02-22 15:00:00+00	2016-02-22 15:00:00+00	2016-02-22 15:00:00+00	0	192.84	\N	\N	192.84	\N	\N	\N	\N	20	10	603
2016-08-12 21:00:00+00	2016-08-12 21:00:00+00	2016-08-12 21:00:00+00	0	198.4	\N	\N	198.4	\N	\N	\N	\N	20	10	605
2019-12-12 21:05:00+00	2019-12-12 21:05:00+00	2019-12-12 21:05:00+00	0	206.25	\N	\N	206.25	\N	\N	\N	\N	20	10	607
1981-09-21 12:00:00+00	1981-09-21 12:00:00+00	1981-09-21 12:00:00+00	0	6507	\N	\N	6507	\N	\N	\N	\N	21	11	610
1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	0	6499	\N	\N	6499	\N	\N	\N	\N	21	11	612
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	6495	\N	\N	6495	\N	\N	\N	\N	21	11	614
1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	0	6491	\N	\N	6491	\N	\N	\N	\N	21	11	616
1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	0	6490	\N	\N	6490	\N	\N	\N	\N	21	11	618
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	6490	\N	\N	6490	\N	\N	\N	\N	21	11	620
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	6488	\N	\N	6488	\N	\N	\N	\N	21	11	622
1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	0	6487	\N	\N	6487	\N	\N	\N	\N	21	11	624
1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	0	6485	\N	\N	6485	\N	\N	\N	\N	21	11	626
1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	21	11	628
1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	0	6484	\N	\N	6484	\N	\N	\N	\N	21	11	630
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	6483	\N	\N	6483	\N	\N	\N	\N	21	11	632
1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	0	6480	\N	\N	6480	\N	\N	\N	\N	21	11	634
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	6479	\N	\N	6479	\N	\N	\N	\N	21	11	636
1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	0	6477	\N	\N	6477	\N	\N	\N	\N	21	11	638
1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	0	6475	\N	\N	6475	\N	\N	\N	\N	21	11	640
1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	0	6472	\N	\N	6472	\N	\N	\N	\N	21	11	642
1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	0	6471	\N	\N	6471	\N	\N	\N	\N	21	11	644
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	6470	\N	\N	6470	\N	\N	\N	\N	21	11	646
1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	0	6468	\N	\N	6468	\N	\N	\N	\N	21	11	648
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	21	11	650
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	652
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	654
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	6456	\N	\N	6456	\N	\N	\N	\N	21	11	656
2004-03-03 22:19:00+00	2004-03-03 22:19:00+00	2004-03-03 22:19:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	658
2005-03-07 23:05:00+00	2005-03-07 23:05:00+00	2005-03-07 23:05:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	660
2006-02-14 16:13:00+00	2006-02-14 16:13:00+00	2006-02-14 16:13:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	662
2007-02-13 21:26:00+00	2007-02-13 21:26:00+00	2007-02-13 21:26:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	664
2008-03-04 22:35:00+00	2008-03-04 22:35:00+00	2008-03-04 22:35:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	666
2009-03-26 14:40:00+00	2009-03-26 14:40:00+00	2009-03-26 14:40:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	668
2010-03-17 22:30:00+00	2010-03-17 22:30:00+00	2010-03-17 22:30:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	670
2011-03-09 22:25:00+00	2011-03-09 22:25:00+00	2011-03-09 22:25:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	672
2012-03-13 20:35:00+00	2012-03-13 20:35:00+00	2012-03-13 20:35:00+00	0	6454	\N	\N	6454	\N	\N	\N	\N	21	11	674
2013-04-04 23:30:00+00	2013-04-04 23:30:00+00	2013-04-04 23:30:00+00	0	6455	\N	\N	6455	\N	\N	\N	\N	21	11	676
2014-03-20 21:45:00+00	2014-03-20 21:45:00+00	2014-03-20 21:45:00+00	0	6458	\N	\N	6458	\N	\N	\N	\N	21	11	678
2015-02-28 20:45:00+00	2015-02-28 20:45:00+00	2015-02-28 20:45:00+00	0	6459	\N	\N	6459	\N	\N	\N	\N	21	11	680
2016-02-25 00:15:00+00	2016-02-25 00:15:00+00	2016-02-25 00:15:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	21	11	682
2016-08-10 22:00:00+00	2016-08-10 22:00:00+00	2016-08-10 22:00:00+00	0	6461	\N	\N	6461	\N	\N	\N	\N	21	11	684
2017-08-03 01:02:00+00	2017-08-03 01:02:00+00	2017-08-03 01:02:00+00	0	6460	\N	\N	6460	\N	\N	\N	\N	21	11	686
2018-02-08 20:09:00+00	2018-02-08 20:09:00+00	2018-02-08 20:09:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	21	11	688
2019-03-07 20:26:00+00	2019-03-07 20:26:00+00	2019-03-07 20:26:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	21	11	690
2020-01-08 18:01:00+00	2020-01-08 18:01:00+00	2020-01-08 18:01:00+00	0	6462	\N	\N	6462	\N	\N	\N	\N	21	11	692
1944-10-14 12:00:00+00	1944-10-14 12:00:00+00	1944-10-14 12:00:00+00	0	65.46	\N	\N	65.46	\N	\N	\N	\N	48	24	94713
1946-02-26 12:00:00+00	1946-02-26 12:00:00+00	1946-02-26 12:00:00+00	0	69.23	\N	\N	69.23	\N	\N	\N	\N	48	24	94715
1946-07-12 12:00:00+00	1946-07-12 12:00:00+00	1946-07-12 12:00:00+00	0	69	\N	\N	69	\N	\N	\N	\N	48	24	94717
1946-09-04 12:00:00+00	1946-09-04 12:00:00+00	1946-09-04 12:00:00+00	0	78.19	\N	\N	78.19	\N	\N	\N	\N	48	24	94719
1946-10-01 12:00:00+00	1946-10-01 12:00:00+00	1946-10-01 12:00:00+00	0	75.15	\N	\N	75.15	\N	\N	\N	\N	48	24	94721
1946-11-06 12:00:00+00	1946-11-06 12:00:00+00	1946-11-06 12:00:00+00	0	74.2	\N	\N	74.2	\N	\N	\N	\N	48	24	94723
1946-12-03 12:00:00+00	1946-12-03 12:00:00+00	1946-12-03 12:00:00+00	0	74.05	\N	\N	74.05	\N	\N	\N	\N	48	24	94725
1947-01-04 12:00:00+00	1947-01-04 12:00:00+00	1947-01-04 12:00:00+00	0	73.87	\N	\N	73.87	\N	\N	\N	\N	48	24	94727
1947-02-03 12:00:00+00	1947-02-03 12:00:00+00	1947-02-03 12:00:00+00	0	73.76	\N	\N	73.76	\N	\N	\N	\N	48	24	94729
1947-03-11 12:00:00+00	1947-03-11 12:00:00+00	1947-03-11 12:00:00+00	0	73.65	\N	\N	73.65	\N	\N	\N	\N	48	24	94731
1947-04-07 12:00:00+00	1947-04-07 12:00:00+00	1947-04-07 12:00:00+00	0	73.97	\N	\N	73.97	\N	\N	\N	\N	48	24	94733
1947-09-02 12:00:00+00	1947-09-02 12:00:00+00	1947-09-02 12:00:00+00	0	78.04	\N	\N	78.04	\N	\N	\N	\N	48	24	94735
1947-10-02 12:00:00+00	1947-10-02 12:00:00+00	1947-10-02 12:00:00+00	0	77.39	\N	\N	77.39	\N	\N	\N	\N	48	24	94737
1947-12-10 12:00:00+00	1947-12-10 12:00:00+00	1947-12-10 12:00:00+00	0	76.73	\N	\N	76.73	\N	\N	\N	\N	48	24	94739
1948-02-02 12:00:00+00	1948-02-02 12:00:00+00	1948-02-02 12:00:00+00	0	76.64	\N	\N	76.64	\N	\N	\N	\N	48	24	94741
1948-04-05 12:00:00+00	1948-04-05 12:00:00+00	1948-04-05 12:00:00+00	0	76.65	\N	\N	76.65	\N	\N	\N	\N	48	24	94743
1948-10-05 12:00:00+00	1948-10-05 12:00:00+00	1948-10-05 12:00:00+00	0	78.68	\N	\N	78.68	\N	\N	\N	\N	48	24	94745
1948-12-09 12:00:00+00	1948-12-09 12:00:00+00	1948-12-09 12:00:00+00	0	77.87	\N	\N	77.87	\N	\N	\N	\N	48	24	94747
1949-02-10 12:00:00+00	1949-02-10 12:00:00+00	1949-02-10 12:00:00+00	0	77.55	\N	\N	77.55	\N	\N	\N	\N	48	24	94749
1949-04-11 12:00:00+00	1949-04-11 12:00:00+00	1949-04-11 12:00:00+00	0	77.44	\N	\N	77.44	\N	\N	\N	\N	48	24	94751
1949-06-09 12:00:00+00	1949-06-09 12:00:00+00	1949-06-09 12:00:00+00	0	100.72	\N	\N	100.72	\N	\N	\N	\N	48	24	94753
1949-08-18 12:00:00+00	1949-08-18 12:00:00+00	1949-08-18 12:00:00+00	0	101.19	\N	\N	101.19	\N	\N	\N	\N	48	24	94755
1949-10-12 12:00:00+00	1949-10-12 12:00:00+00	1949-10-12 12:00:00+00	0	77.42	\N	\N	77.42	\N	\N	\N	\N	48	24	94757
1949-12-14 12:00:00+00	1949-12-14 12:00:00+00	1949-12-14 12:00:00+00	0	77.33	\N	\N	77.33	\N	\N	\N	\N	48	24	94759
1950-02-08 12:00:00+00	1950-02-08 12:00:00+00	1950-02-08 12:00:00+00	0	76.72	\N	\N	76.72	\N	\N	\N	\N	48	24	94761
1950-04-18 12:00:00+00	1950-04-18 12:00:00+00	1950-04-18 12:00:00+00	0	80.45	\N	\N	80.45	\N	\N	\N	\N	48	24	94763
1950-06-27 12:00:00+00	1950-06-27 12:00:00+00	1950-06-27 12:00:00+00	0	98.14	\N	\N	98.14	\N	\N	\N	\N	48	24	94765
1950-08-24 12:00:00+00	1950-08-24 12:00:00+00	1950-08-24 12:00:00+00	0	98.12	\N	\N	98.12	\N	\N	\N	\N	48	24	94767
1950-10-16 12:00:00+00	1950-10-16 12:00:00+00	1950-10-16 12:00:00+00	0	85.93	\N	\N	85.93	\N	\N	\N	\N	48	24	94769
1950-12-12 12:00:00+00	1950-12-12 12:00:00+00	1950-12-12 12:00:00+00	0	83.98	\N	\N	83.98	\N	\N	\N	\N	48	24	94771
1951-02-15 12:00:00+00	1951-02-15 12:00:00+00	1951-02-15 12:00:00+00	0	82.75	\N	\N	82.75	\N	\N	\N	\N	48	24	94773
1951-04-18 12:00:00+00	1951-04-18 12:00:00+00	1951-04-18 12:00:00+00	0	84.69	\N	\N	84.69	\N	\N	\N	\N	48	24	94775
1951-06-21 12:00:00+00	1951-06-21 12:00:00+00	1951-06-21 12:00:00+00	0	98.25	\N	\N	98.25	\N	\N	\N	\N	48	24	94777
1951-08-15 12:00:00+00	1951-08-15 12:00:00+00	1951-08-15 12:00:00+00	0	98.33	\N	\N	98.33	\N	\N	\N	\N	48	24	94779
1951-10-31 12:00:00+00	1951-10-31 12:00:00+00	1951-10-31 12:00:00+00	0	98.3	\N	\N	98.3	\N	\N	\N	\N	48	24	94781
1951-12-24 12:00:00+00	1951-12-24 12:00:00+00	1951-12-24 12:00:00+00	0	87.69	\N	\N	87.69	\N	\N	\N	\N	48	24	94783
1952-02-26 12:00:00+00	1952-02-26 12:00:00+00	1952-02-26 12:00:00+00	0	97.97	\N	\N	97.97	\N	\N	\N	\N	48	24	94785
1952-04-24 12:00:00+00	1952-04-24 12:00:00+00	1952-04-24 12:00:00+00	0	98.39	\N	\N	98.39	\N	\N	\N	\N	48	24	94787
1952-06-25 12:00:00+00	1952-06-25 12:00:00+00	1952-06-25 12:00:00+00	0	98.22	\N	\N	98.22	\N	\N	\N	\N	48	24	94789
1952-12-16 12:00:00+00	1952-12-16 12:00:00+00	1952-12-16 12:00:00+00	0	87.11	\N	\N	87.11	\N	\N	\N	\N	48	24	94791
1953-02-17 12:00:00+00	1953-02-17 12:00:00+00	1953-02-17 12:00:00+00	0	86.16	\N	\N	86.16	\N	\N	\N	\N	48	24	94793
1953-04-15 12:00:00+00	1953-04-15 12:00:00+00	1953-04-15 12:00:00+00	0	98.5	\N	\N	98.5	\N	\N	\N	\N	48	24	94795
1953-06-10 12:00:00+00	1953-06-10 12:00:00+00	1953-06-10 12:00:00+00	0	98.68	\N	\N	98.68	\N	\N	\N	\N	48	24	94797
1953-08-11 12:00:00+00	1953-08-11 12:00:00+00	1953-08-11 12:00:00+00	0	98.68	\N	\N	98.68	\N	\N	\N	\N	48	24	94799
1953-10-08 12:00:00+00	1953-10-08 12:00:00+00	1953-10-08 12:00:00+00	0	96.02	\N	\N	96.02	\N	\N	\N	\N	48	24	94801
1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	1953-12-17 12:00:00+00	0	91.58	\N	\N	91.58	\N	\N	\N	\N	48	24	94803
1954-02-11 12:00:00+00	1954-02-11 12:00:00+00	1954-02-11 12:00:00+00	0	90.17	\N	\N	90.17	\N	\N	\N	\N	48	24	94805
1954-04-07 12:00:00+00	1954-04-07 12:00:00+00	1954-04-07 12:00:00+00	0	98.71	\N	\N	98.71	\N	\N	\N	\N	48	24	94807
1954-06-11 12:00:00+00	1954-06-11 12:00:00+00	1954-06-11 12:00:00+00	0	98.76	\N	\N	98.76	\N	\N	\N	\N	48	24	94809
1954-08-27 12:00:00+00	1954-08-27 12:00:00+00	1954-08-27 12:00:00+00	0	98.77	\N	\N	98.77	\N	\N	\N	\N	48	24	94811
1954-10-13 12:00:00+00	1954-10-13 12:00:00+00	1954-10-13 12:00:00+00	0	94.17	\N	\N	94.17	\N	\N	\N	\N	48	24	94813
1954-12-01 12:00:00+00	1954-12-01 12:00:00+00	1954-12-01 12:00:00+00	0	92.45	\N	\N	92.45	\N	\N	\N	\N	48	24	94815
1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	1955-02-10 12:00:00+00	0	91.33	\N	\N	91.33	\N	\N	\N	\N	48	24	94817
1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	1955-04-15 12:00:00+00	0	98.74	\N	\N	98.74	\N	\N	\N	\N	48	24	94819
1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	1955-06-15 12:00:00+00	0	98.94	\N	\N	98.94	\N	\N	\N	\N	48	24	94821
1955-08-10 12:00:00+00	1955-08-10 12:00:00+00	1955-08-10 12:00:00+00	0	98.86	\N	\N	98.86	\N	\N	\N	\N	48	24	94823
1955-10-10 12:00:00+00	1955-10-10 12:00:00+00	1955-10-10 12:00:00+00	0	97.99	\N	\N	97.99	\N	\N	\N	\N	48	24	94825
1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	1955-12-07 12:00:00+00	0	95.49	\N	\N	95.49	\N	\N	\N	\N	48	24	94827
1956-02-07 12:00:00+00	1956-02-07 12:00:00+00	1956-02-07 12:00:00+00	0	93.67	\N	\N	93.67	\N	\N	\N	\N	48	24	94829
1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	1956-04-17 12:00:00+00	0	95.19	\N	\N	95.19	\N	\N	\N	\N	48	24	94831
1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	1956-06-05 12:00:00+00	0	98.84	\N	\N	98.84	\N	\N	\N	\N	48	24	94833
1956-08-01 12:00:00+00	1956-08-01 12:00:00+00	1956-08-01 12:00:00+00	0	98.65	\N	\N	98.65	\N	\N	\N	\N	48	24	94835
1956-10-02 12:00:00+00	1956-10-02 12:00:00+00	1956-10-02 12:00:00+00	0	98.69	\N	\N	98.69	\N	\N	\N	\N	48	24	94837
1956-12-12 12:00:00+00	1956-12-12 12:00:00+00	1956-12-12 12:00:00+00	0	98.73	\N	\N	98.73	\N	\N	\N	\N	48	24	94839
1957-02-13 12:00:00+00	1957-02-13 12:00:00+00	1957-02-13 12:00:00+00	0	98.7	\N	\N	98.7	\N	\N	\N	\N	48	24	94841
1957-05-07 12:00:00+00	1957-05-07 12:00:00+00	1957-05-07 12:00:00+00	0	98.77	\N	\N	98.77	\N	\N	\N	\N	48	24	94843
1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	1957-08-01 12:00:00+00	0	98.7	\N	\N	98.7	\N	\N	\N	\N	48	24	94845
1957-11-14 12:00:00+00	1957-11-14 12:00:00+00	1957-11-14 12:00:00+00	0	98.75	\N	\N	98.75	\N	\N	\N	\N	48	24	94847
1958-02-04 12:00:00+00	1958-02-04 12:00:00+00	1958-02-04 12:00:00+00	0	98.77	\N	\N	98.77	\N	\N	\N	\N	48	24	94849
1958-05-14 12:00:00+00	1958-05-14 12:00:00+00	1958-05-14 12:00:00+00	0	98.8	\N	\N	98.8	\N	\N	\N	\N	48	24	94851
1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	1958-08-19 12:00:00+00	0	98.72	\N	\N	98.72	\N	\N	\N	\N	48	24	94853
1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	1958-11-20 12:00:00+00	0	98.8	\N	\N	98.8	\N	\N	\N	\N	48	24	94855
1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	1959-05-05 12:00:00+00	0	98.79	\N	\N	98.79	\N	\N	\N	\N	48	24	94857
1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	1959-09-02 12:00:00+00	0	98.65	\N	\N	98.65	\N	\N	\N	\N	48	24	94859
1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	1959-11-03 12:00:00+00	0	100.74	\N	\N	100.74	\N	\N	\N	\N	48	24	94861
1960-02-09 12:00:00+00	1960-02-09 12:00:00+00	1960-02-09 12:00:00+00	0	98.78	\N	\N	98.78	\N	\N	\N	\N	48	24	94863
1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	1960-05-11 12:00:00+00	0	98.82	\N	\N	98.82	\N	\N	\N	\N	48	24	94865
1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	1960-08-25 12:00:00+00	0	102.1	\N	\N	102.1	\N	\N	\N	\N	48	24	94867
1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	1960-11-15 12:00:00+00	0	98.85	\N	\N	98.85	\N	\N	\N	\N	48	24	94869
1961-02-15 12:00:00+00	1961-02-15 12:00:00+00	1961-02-15 12:00:00+00	0	98.85	\N	\N	98.85	\N	\N	\N	\N	48	24	94871
1961-05-10 12:00:00+00	1961-05-10 12:00:00+00	1961-05-10 12:00:00+00	0	99.04	\N	\N	99.04	\N	\N	\N	\N	48	24	94873
1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	1961-08-08 12:00:00+00	0	98.95	\N	\N	98.95	\N	\N	\N	\N	48	24	94875
1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	1961-11-30 12:00:00+00	0	99.1	\N	\N	99.1	\N	\N	\N	\N	48	24	94877
1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	1962-02-13 12:00:00+00	0	98.93	\N	\N	98.93	\N	\N	\N	\N	48	24	94879
1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	1962-05-15 12:00:00+00	0	98.93	\N	\N	98.93	\N	\N	\N	\N	48	24	94881
1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	1962-08-15 12:00:00+00	0	98.87	\N	\N	98.87	\N	\N	\N	\N	48	24	94883
1962-11-27 12:00:00+00	1962-11-27 12:00:00+00	1962-11-27 12:00:00+00	0	100.07	\N	\N	100.07	\N	\N	\N	\N	48	24	94885
1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	1963-02-04 12:00:00+00	0	98.84	\N	\N	98.84	\N	\N	\N	\N	48	24	94887
1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	1963-08-19 12:00:00+00	0	98.81	\N	\N	98.81	\N	\N	\N	\N	48	24	94889
1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	1964-03-09 12:00:00+00	0	100.03	\N	\N	100.03	\N	\N	\N	\N	48	24	94891
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	99.95	\N	\N	99.95	\N	\N	\N	\N	48	24	94893
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	96.27	\N	\N	96.27	\N	\N	\N	\N	48	24	94895
1965-08-06 12:00:00+00	1965-08-06 12:00:00+00	1965-08-06 12:00:00+00	0	96.77	\N	\N	96.77	\N	\N	\N	\N	48	24	94897
1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	1966-08-23 12:00:00+00	0	100.6	\N	\N	100.6	\N	\N	\N	\N	48	24	94899
1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	1967-02-21 12:00:00+00	0	93.8	\N	\N	93.8	\N	\N	\N	\N	48	24	94901
1968-04-03 12:00:00+00	1968-04-03 12:00:00+00	1968-04-03 12:00:00+00	0	94.56	\N	\N	94.56	\N	\N	\N	\N	48	24	94903
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	96.99	\N	\N	96.99	\N	\N	\N	\N	48	24	94905
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	95.95	\N	\N	95.95	\N	\N	\N	\N	48	24	94907
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	98.93	\N	\N	98.93	\N	\N	\N	\N	48	24	94909
1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	1972-01-19 12:00:00+00	0	99.02	\N	\N	99.02	\N	\N	\N	\N	48	24	94911
1999-02-05 00:00:00+00	1999-02-05 00:00:00+00	1999-02-05 00:00:00+00	0	131.38	\N	\N	131.38	\N	\N	\N	\N	66	33	95869
1999-02-06 00:00:00+00	1999-02-06 00:00:00+00	1999-02-06 00:00:00+00	0	131.41	\N	\N	131.41	\N	\N	\N	\N	66	33	95871
1999-02-07 00:00:00+00	1999-02-07 00:00:00+00	1999-02-07 00:00:00+00	0	131.41	\N	\N	131.41	\N	\N	\N	\N	66	33	95873
1999-02-08 00:00:00+00	1999-02-08 00:00:00+00	1999-02-08 00:00:00+00	0	131.37	\N	\N	131.37	\N	\N	\N	\N	66	33	95875
1999-02-09 00:00:00+00	1999-02-09 00:00:00+00	1999-02-09 00:00:00+00	0	131.39	\N	\N	131.39	\N	\N	\N	\N	66	33	95877
1999-02-10 00:00:00+00	1999-02-10 00:00:00+00	1999-02-10 00:00:00+00	0	131.35	\N	\N	131.35	\N	\N	\N	\N	66	33	95879
1999-02-11 00:00:00+00	1999-02-11 00:00:00+00	1999-02-11 00:00:00+00	0	131.49	\N	\N	131.49	\N	\N	\N	\N	66	33	95881
1999-02-12 00:00:00+00	1999-02-12 00:00:00+00	1999-02-12 00:00:00+00	0	131.49	\N	\N	131.49	\N	\N	\N	\N	66	33	95883
1999-02-13 00:00:00+00	1999-02-13 00:00:00+00	1999-02-13 00:00:00+00	0	131.45	\N	\N	131.45	\N	\N	\N	\N	66	33	95885
1999-02-14 00:00:00+00	1999-02-14 00:00:00+00	1999-02-14 00:00:00+00	0	131.38	\N	\N	131.38	\N	\N	\N	\N	66	33	95887
1999-02-15 00:00:00+00	1999-02-15 00:00:00+00	1999-02-15 00:00:00+00	0	131.31	\N	\N	131.31	\N	\N	\N	\N	66	33	95889
1999-02-16 00:00:00+00	1999-02-16 00:00:00+00	1999-02-16 00:00:00+00	0	131.31	\N	\N	131.31	\N	\N	\N	\N	66	33	95891
1999-02-17 00:00:00+00	1999-02-17 00:00:00+00	1999-02-17 00:00:00+00	0	131.31	\N	\N	131.31	\N	\N	\N	\N	66	33	95893
1999-02-18 00:00:00+00	1999-02-18 00:00:00+00	1999-02-18 00:00:00+00	0	131.3	\N	\N	131.3	\N	\N	\N	\N	66	33	95895
1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	1999-02-19 00:00:00+00	0	131.32	\N	\N	131.32	\N	\N	\N	\N	66	33	95897
1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	1999-02-20 00:00:00+00	0	131.45	\N	\N	131.45	\N	\N	\N	\N	66	33	95899
1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	1999-02-21 00:00:00+00	0	131.48	\N	\N	131.48	\N	\N	\N	\N	66	33	95901
1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	1999-02-22 00:00:00+00	0	131.5	\N	\N	131.5	\N	\N	\N	\N	66	33	95903
1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	1999-02-23 00:00:00+00	0	131.52	\N	\N	131.52	\N	\N	\N	\N	66	33	95905
1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	1999-02-24 00:00:00+00	0	131.53	\N	\N	131.53	\N	\N	\N	\N	66	33	95907
1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	1999-02-25 00:00:00+00	0	131.52	\N	\N	131.52	\N	\N	\N	\N	66	33	95909
1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	1999-02-26 00:00:00+00	0	131.47	\N	\N	131.47	\N	\N	\N	\N	66	33	95911
1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	1999-02-27 00:00:00+00	0	131.49	\N	\N	131.49	\N	\N	\N	\N	66	33	95913
1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	1999-02-28 00:00:00+00	0	131.49	\N	\N	131.49	\N	\N	\N	\N	66	33	95915
1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	1999-03-01 00:00:00+00	0	131.47	\N	\N	131.47	\N	\N	\N	\N	66	33	95917
1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	1999-03-02 00:00:00+00	0	131.45	\N	\N	131.45	\N	\N	\N	\N	66	33	95919
1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	1999-03-03 00:00:00+00	0	131.47	\N	\N	131.47	\N	\N	\N	\N	66	33	95921
1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	1999-03-04 00:00:00+00	0	131.44	\N	\N	131.44	\N	\N	\N	\N	66	33	95923
1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	1999-03-05 00:00:00+00	0	131.54	\N	\N	131.54	\N	\N	\N	\N	66	33	95925
1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	1999-03-06 00:00:00+00	0	131.61	\N	\N	131.61	\N	\N	\N	\N	66	33	95927
1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	1999-03-07 00:00:00+00	0	131.56	\N	\N	131.56	\N	\N	\N	\N	66	33	95929
1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	1999-03-08 00:00:00+00	0	131.55	\N	\N	131.55	\N	\N	\N	\N	66	33	95931
1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	1999-03-09 00:00:00+00	0	131.56	\N	\N	131.56	\N	\N	\N	\N	66	33	95933
1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	1999-03-10 00:00:00+00	0	131.59	\N	\N	131.59	\N	\N	\N	\N	66	33	95935
1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	1999-03-11 00:00:00+00	0	131.58	\N	\N	131.58	\N	\N	\N	\N	66	33	95937
1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	1999-03-12 00:00:00+00	0	131.56	\N	\N	131.56	\N	\N	\N	\N	66	33	95939
1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	1999-03-13 00:00:00+00	0	131.54	\N	\N	131.54	\N	\N	\N	\N	66	33	95941
1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	1999-03-14 00:00:00+00	0	131.53	\N	\N	131.53	\N	\N	\N	\N	66	33	95943
1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	1999-03-15 00:00:00+00	0	131.48	\N	\N	131.48	\N	\N	\N	\N	66	33	95945
1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	1999-03-16 00:00:00+00	0	131.43	\N	\N	131.43	\N	\N	\N	\N	66	33	95947
1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	1999-03-17 00:00:00+00	0	131.45	\N	\N	131.45	\N	\N	\N	\N	66	33	95949
1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	1999-03-18 00:00:00+00	0	131.46	\N	\N	131.46	\N	\N	\N	\N	66	33	95951
1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	1999-03-19 00:00:00+00	0	131.44	\N	\N	131.44	\N	\N	\N	\N	66	33	95953
1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	1999-03-20 00:00:00+00	0	131.44	\N	\N	131.44	\N	\N	\N	\N	66	33	95955
1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	1999-03-21 00:00:00+00	0	131.41	\N	\N	131.41	\N	\N	\N	\N	66	33	95957
1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	1999-03-22 00:00:00+00	0	131.33	\N	\N	131.33	\N	\N	\N	\N	66	33	95959
1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	1999-03-23 00:00:00+00	0	131.39	\N	\N	131.39	\N	\N	\N	\N	66	33	95961
1999-03-24 00:00:00+00	1999-03-24 00:00:00+00	1999-03-24 00:00:00+00	0	131.44	\N	\N	131.44	\N	\N	\N	\N	66	33	95963
1999-04-20 00:00:00+00	1999-04-20 00:00:00+00	1999-04-20 00:00:00+00	0	131.76	\N	\N	131.76	\N	\N	\N	\N	66	33	95965
1999-04-21 00:00:00+00	1999-04-21 00:00:00+00	1999-04-21 00:00:00+00	0	131.71	\N	\N	131.71	\N	\N	\N	\N	66	33	95967
1999-04-22 00:00:00+00	1999-04-22 00:00:00+00	1999-04-22 00:00:00+00	0	131.67	\N	\N	131.67	\N	\N	\N	\N	66	33	95969
1999-04-23 00:00:00+00	1999-04-23 00:00:00+00	1999-04-23 00:00:00+00	0	131.72	\N	\N	131.72	\N	\N	\N	\N	66	33	95971
1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	1999-04-24 00:00:00+00	0	131.76	\N	\N	131.76	\N	\N	\N	\N	66	33	95973
1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	1999-04-25 00:00:00+00	0	131.77	\N	\N	131.77	\N	\N	\N	\N	66	33	95975
1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	1999-04-26 00:00:00+00	0	131.77	\N	\N	131.77	\N	\N	\N	\N	66	33	95977
1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	1999-04-27 00:00:00+00	0	131.73	\N	\N	131.73	\N	\N	\N	\N	66	33	95979
1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	1999-04-28 00:00:00+00	0	131.71	\N	\N	131.71	\N	\N	\N	\N	66	33	95981
1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	1999-04-29 00:00:00+00	0	131.69	\N	\N	131.69	\N	\N	\N	\N	66	33	95983
1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	1999-04-30 00:00:00+00	0	131.68	\N	\N	131.68	\N	\N	\N	\N	66	33	95985
1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	1999-05-01 00:00:00+00	0	131.78	\N	\N	131.78	\N	\N	\N	\N	66	33	95987
1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	1999-05-02 00:00:00+00	0	131.78	\N	\N	131.78	\N	\N	\N	\N	66	33	95989
1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	1999-05-03 00:00:00+00	0	131.84	\N	\N	131.84	\N	\N	\N	\N	66	33	95991
1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	1999-05-04 00:00:00+00	0	131.91	\N	\N	131.91	\N	\N	\N	\N	66	33	95993
1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	1999-05-05 00:00:00+00	0	131.9	\N	\N	131.9	\N	\N	\N	\N	66	33	95995
1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	1999-05-06 00:00:00+00	0	131.89	\N	\N	131.89	\N	\N	\N	\N	66	33	95997
1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	1999-05-07 00:00:00+00	0	131.87	\N	\N	131.87	\N	\N	\N	\N	66	33	95999
1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	1999-05-08 00:00:00+00	0	131.87	\N	\N	131.87	\N	\N	\N	\N	66	33	96001
1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	1999-05-09 00:00:00+00	0	131.85	\N	\N	131.85	\N	\N	\N	\N	66	33	96003
1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	1999-05-10 00:00:00+00	0	131.87	\N	\N	131.87	\N	\N	\N	\N	66	33	96005
1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	1999-05-11 00:00:00+00	0	131.95	\N	\N	131.95	\N	\N	\N	\N	66	33	96007
1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	1999-05-12 00:00:00+00	0	132	\N	\N	132	\N	\N	\N	\N	66	33	96009
1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	1999-05-13 00:00:00+00	0	131.99	\N	\N	131.99	\N	\N	\N	\N	66	33	96011
1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	1999-05-14 00:00:00+00	0	131.98	\N	\N	131.98	\N	\N	\N	\N	66	33	96013
1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	1999-05-15 00:00:00+00	0	131.98	\N	\N	131.98	\N	\N	\N	\N	66	33	96015
1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	1999-05-16 00:00:00+00	0	132.04	\N	\N	132.04	\N	\N	\N	\N	66	33	96017
1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	1999-05-17 00:00:00+00	0	132.14	\N	\N	132.14	\N	\N	\N	\N	66	33	96019
1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	1999-05-18 00:00:00+00	0	132.16	\N	\N	132.16	\N	\N	\N	\N	66	33	96021
1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	1999-05-19 00:00:00+00	0	132.09	\N	\N	132.09	\N	\N	\N	\N	66	33	96023
1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	1999-05-20 00:00:00+00	0	132.11	\N	\N	132.11	\N	\N	\N	\N	66	33	96025
1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	1999-05-21 00:00:00+00	0	132.15	\N	\N	132.15	\N	\N	\N	\N	66	33	96027
1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	1999-05-22 00:00:00+00	0	132.16	\N	\N	132.16	\N	\N	\N	\N	66	33	96029
1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	1999-05-23 00:00:00+00	0	132.18	\N	\N	132.18	\N	\N	\N	\N	66	33	96031
1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	1999-05-24 00:00:00+00	0	132.12	\N	\N	132.12	\N	\N	\N	\N	66	33	96033
1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	1999-05-25 00:00:00+00	0	132.02	\N	\N	132.02	\N	\N	\N	\N	66	33	96035
1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	1999-05-26 00:00:00+00	0	131.91	\N	\N	131.91	\N	\N	\N	\N	66	33	96037
1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	1999-05-27 00:00:00+00	0	131.88	\N	\N	131.88	\N	\N	\N	\N	66	33	96039
1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	1999-05-28 00:00:00+00	0	131.86	\N	\N	131.86	\N	\N	\N	\N	66	33	96041
1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	1999-05-29 00:00:00+00	0	131.79	\N	\N	131.79	\N	\N	\N	\N	66	33	96043
1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	1999-05-30 00:00:00+00	0	131.82	\N	\N	131.82	\N	\N	\N	\N	66	33	96045
1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	1999-05-31 00:00:00+00	0	131.81	\N	\N	131.81	\N	\N	\N	\N	66	33	96047
1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	1999-06-01 00:00:00+00	0	131.89	\N	\N	131.89	\N	\N	\N	\N	66	33	96049
1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	1999-06-02 00:00:00+00	0	131.95	\N	\N	131.95	\N	\N	\N	\N	66	33	96051
1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	1999-06-03 00:00:00+00	0	132	\N	\N	132	\N	\N	\N	\N	66	33	96053
1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	1999-06-04 00:00:00+00	0	132.01	\N	\N	132.01	\N	\N	\N	\N	66	33	96055
1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	1999-06-05 00:00:00+00	0	132.08	\N	\N	132.08	\N	\N	\N	\N	66	33	96057
1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	1999-06-06 00:00:00+00	0	132.14	\N	\N	132.14	\N	\N	\N	\N	66	33	96059
1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	1999-06-07 00:00:00+00	0	132.17	\N	\N	132.17	\N	\N	\N	\N	66	33	96061
1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	1999-06-08 00:00:00+00	0	132.18	\N	\N	132.18	\N	\N	\N	\N	66	33	96063
1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	1999-06-09 00:00:00+00	0	132.22	\N	\N	132.22	\N	\N	\N	\N	66	33	96065
1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	1999-06-10 00:00:00+00	0	132.24	\N	\N	132.24	\N	\N	\N	\N	66	33	96067
1963-08-27 12:00:00+00	1963-08-27 12:00:00+00	1963-08-27 12:00:00+00	0	5880	\N	\N	5880	\N	\N	\N	\N	59	30	95568
1964-03-24 12:00:00+00	1964-03-24 12:00:00+00	1964-03-24 12:00:00+00	0	5880	\N	\N	5880	\N	\N	\N	\N	59	30	95570
1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	1964-08-12 12:00:00+00	0	5878	\N	\N	5878	\N	\N	\N	\N	59	30	95572
1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	1965-02-09 12:00:00+00	0	5880	\N	\N	5880	\N	\N	\N	\N	59	30	95574
1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	1965-08-05 12:00:00+00	0	5879	\N	\N	5879	\N	\N	\N	\N	59	30	95576
1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	1966-02-09 12:00:00+00	0	5882	\N	\N	5882	\N	\N	\N	\N	59	30	95578
1966-08-22 12:00:00+00	1966-08-22 12:00:00+00	1966-08-22 12:00:00+00	0	5887	\N	\N	5887	\N	\N	\N	\N	59	30	95580
1967-02-20 12:00:00+00	1967-02-20 12:00:00+00	1967-02-20 12:00:00+00	0	5886	\N	\N	5886	\N	\N	\N	\N	59	30	95582
1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	1968-04-02 12:00:00+00	0	5895	\N	\N	5895	\N	\N	\N	\N	59	30	95584
1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	1969-02-12 12:00:00+00	0	5891	\N	\N	5891	\N	\N	\N	\N	59	30	95586
1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	1970-02-16 12:00:00+00	0	5891	\N	\N	5891	\N	\N	\N	\N	59	30	95588
1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	1971-01-11 12:00:00+00	0	5891	\N	\N	5891	\N	\N	\N	\N	59	30	95590
1972-01-20 12:00:00+00	1972-01-20 12:00:00+00	1972-01-20 12:00:00+00	0	5888	\N	\N	5888	\N	\N	\N	\N	59	30	95592
1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	1973-01-24 12:00:00+00	0	5891	\N	\N	5891	\N	\N	\N	\N	59	30	95594
1973-05-24 12:00:00+00	1973-05-24 12:00:00+00	1973-05-24 12:00:00+00	0	5890	\N	\N	5890	\N	\N	\N	\N	59	30	95596
1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	1974-01-14 12:00:00+00	0	5887	\N	\N	5887	\N	\N	\N	\N	59	30	95598
1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	1975-01-16 12:00:00+00	0	5883	\N	\N	5883	\N	\N	\N	\N	59	30	95600
1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	1976-02-11 12:00:00+00	0	5884	\N	\N	5884	\N	\N	\N	\N	59	30	95602
1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	1977-01-17 12:00:00+00	0	5884	\N	\N	5884	\N	\N	\N	\N	59	30	95604
1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	1978-02-02 12:00:00+00	0	5885	\N	\N	5885	\N	\N	\N	\N	59	30	95606
1979-02-28 12:00:00+00	1979-02-28 12:00:00+00	1979-02-28 12:00:00+00	0	5884	\N	\N	5884	\N	\N	\N	\N	59	30	95608
1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	1981-01-22 12:00:00+00	0	5882	\N	\N	5882	\N	\N	\N	\N	59	30	95610
1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	1984-01-31 12:00:00+00	0	5880	\N	\N	5880	\N	\N	\N	\N	59	30	95612
1994-02-01 12:00:00+00	1994-02-01 12:00:00+00	1994-02-01 12:00:00+00	0	5881	\N	\N	5881	\N	\N	\N	\N	59	30	95614
1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	1999-02-22 12:00:00+00	0	5878	\N	\N	5878	\N	\N	\N	\N	59	30	95616
2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	2004-02-18 12:00:00+00	0	5876	\N	\N	5876	\N	\N	\N	\N	59	30	95618
2009-03-27 12:00:00+00	2009-03-27 12:00:00+00	2009-03-27 12:00:00+00	0	5869	\N	\N	5869	\N	\N	\N	\N	59	30	95620
2013-04-01 20:30:00+00	2013-04-01 20:30:00+00	2013-04-01 20:30:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95622
2016-03-14 22:30:00+00	2016-03-14 22:30:00+00	2016-03-14 22:30:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95624
2016-08-08 22:40:00+00	2016-08-08 22:40:00+00	2016-08-08 22:40:00+00	0	5873	\N	\N	5873	\N	\N	\N	\N	59	30	95626
2016-09-23 19:51:00+00	2016-09-23 19:51:00+00	2016-09-23 19:51:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95628
2017-04-17 20:10:00+00	2017-04-17 20:10:00+00	2017-04-17 20:10:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95630
2017-06-16 19:01:00+00	2017-06-16 19:01:00+00	2017-06-16 19:01:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95632
2017-09-28 18:40:00+00	2017-09-28 18:40:00+00	2017-09-28 18:40:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95634
2017-12-11 22:30:00+00	2017-12-11 22:30:00+00	2017-12-11 22:30:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95636
2018-04-25 17:00:00+00	2018-04-25 17:00:00+00	2018-04-25 17:00:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95638
2020-01-06 17:09:00+00	2020-01-06 17:09:00+00	2020-01-06 17:09:00+00	0	5874	\N	\N	5874	\N	\N	\N	\N	59	30	95640
2001-06-07 12:00:00+00	2001-06-07 12:00:00+00	2001-06-07 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111228
2001-07-25 12:00:00+00	2001-07-25 12:00:00+00	2001-07-25 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111230
2001-09-27 12:00:00+00	2001-09-27 12:00:00+00	2001-09-27 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111232
2002-01-22 12:00:00+00	2002-01-22 12:00:00+00	2002-01-22 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111234
2002-09-26 12:00:00+00	2002-09-26 12:00:00+00	2002-09-26 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111236
2002-10-30 12:00:00+00	2002-10-30 12:00:00+00	2002-10-30 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111238
2003-01-16 12:00:00+00	2003-01-16 12:00:00+00	2003-01-16 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111240
2003-03-11 12:00:00+00	2003-03-11 12:00:00+00	2003-03-11 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111242
2003-04-30 12:00:00+00	2003-04-30 12:00:00+00	2003-04-30 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111244
2003-07-24 12:00:00+00	2003-07-24 12:00:00+00	2003-07-24 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111246
2003-09-11 12:00:00+00	2003-09-11 12:00:00+00	2003-09-11 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111248
2003-11-19 12:00:00+00	2003-11-19 12:00:00+00	2003-11-19 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111250
2004-02-23 12:00:00+00	2004-02-23 12:00:00+00	2004-02-23 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111252
2004-05-19 12:00:00+00	2004-05-19 12:00:00+00	2004-05-19 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111254
2004-09-22 12:00:00+00	2004-09-22 12:00:00+00	2004-09-22 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111256
2005-01-13 12:00:00+00	2005-01-13 12:00:00+00	2005-01-13 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111258
2005-03-31 12:00:00+00	2005-03-31 12:00:00+00	2005-03-31 12:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	67	34	111260
2005-05-19 12:00:00+00	2005-05-19 12:00:00+00	2005-05-19 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111262
2005-07-26 12:00:00+00	2005-07-26 12:00:00+00	2005-07-26 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111264
2006-01-11 12:00:00+00	2006-01-11 12:00:00+00	2006-01-11 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111266
2006-05-09 12:00:00+00	2006-05-09 12:00:00+00	2006-05-09 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111268
2006-09-12 12:00:00+00	2006-09-12 12:00:00+00	2006-09-12 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111270
2007-01-18 12:00:00+00	2007-01-18 12:00:00+00	2007-01-18 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111272
2007-03-06 12:00:00+00	2007-03-06 12:00:00+00	2007-03-06 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111274
2007-06-06 12:00:00+00	2007-06-06 12:00:00+00	2007-06-06 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111276
2007-08-30 12:00:00+00	2007-08-30 12:00:00+00	2007-08-30 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111278
2008-01-09 12:00:00+00	2008-01-09 12:00:00+00	2008-01-09 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111280
2008-02-27 12:00:00+00	2008-02-27 12:00:00+00	2008-02-27 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111282
2008-06-09 12:00:00+00	2008-06-09 12:00:00+00	2008-06-09 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111284
2008-08-27 12:00:00+00	2008-08-27 12:00:00+00	2008-08-27 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111286
2009-05-29 12:00:00+00	2009-05-29 12:00:00+00	2009-05-29 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111288
2009-07-30 12:00:00+00	2009-07-30 12:00:00+00	2009-07-30 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111290
2009-12-18 12:00:00+00	2009-12-18 12:00:00+00	2009-12-18 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111292
2010-02-19 12:00:00+00	2010-02-19 12:00:00+00	2010-02-19 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111294
2010-05-21 12:00:00+00	2010-05-21 12:00:00+00	2010-05-21 12:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111296
2010-09-14 12:00:00+00	2010-09-14 12:00:00+00	2010-09-14 12:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111298
2011-02-22 18:06:00+00	2011-02-22 18:06:00+00	2011-02-22 18:06:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111300
2011-06-10 15:42:00+00	2011-06-10 15:42:00+00	2011-06-10 15:42:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111302
2011-09-14 15:35:00+00	2011-09-14 15:35:00+00	2011-09-14 15:35:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111304
2011-12-28 16:39:00+00	2011-12-28 16:39:00+00	2011-12-28 16:39:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111306
2012-02-10 15:40:00+00	2012-02-10 15:40:00+00	2012-02-10 15:40:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111308
2012-05-25 19:13:00+00	2012-05-25 19:13:00+00	2012-05-25 19:13:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111310
2012-08-31 16:51:00+00	2012-08-31 16:51:00+00	2012-08-31 16:51:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111312
2012-12-21 17:17:00+00	2012-12-21 17:17:00+00	2012-12-21 17:17:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111314
2013-02-12 15:48:00+00	2013-02-12 15:48:00+00	2013-02-12 15:48:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111316
2013-05-23 15:41:00+00	2013-05-23 15:41:00+00	2013-05-23 15:41:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111318
2013-09-16 15:31:00+00	2013-09-16 15:31:00+00	2013-09-16 15:31:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111320
2013-12-17 15:58:00+00	2013-12-17 15:58:00+00	2013-12-17 15:58:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111322
2014-01-22 17:30:00+00	2014-01-22 17:30:00+00	2014-01-22 17:30:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111324
2014-06-12 15:43:00+00	2014-06-12 15:43:00+00	2014-06-12 15:43:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111326
2014-08-26 15:06:00+00	2014-08-26 15:06:00+00	2014-08-26 15:06:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111328
2014-12-10 16:40:00+00	2014-12-10 16:40:00+00	2014-12-10 16:40:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111330
2015-03-06 16:41:00+00	2015-03-06 16:41:00+00	2015-03-06 16:41:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111332
2015-09-09 15:32:00+00	2015-09-09 15:32:00+00	2015-09-09 15:32:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111334
2015-12-15 16:23:00+00	2015-12-15 16:23:00+00	2015-12-15 16:23:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	67	34	111336
2016-03-03 17:51:00+00	2016-03-03 17:51:00+00	2016-03-03 17:51:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111338
2016-05-16 15:18:00+00	2016-05-16 15:18:00+00	2016-05-16 15:18:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111340
2016-08-24 17:22:00+00	2016-08-24 17:22:00+00	2016-08-24 17:22:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111342
2017-01-30 17:23:00+00	2017-01-30 17:23:00+00	2017-01-30 17:23:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111344
2017-05-16 15:36:00+00	2017-05-16 15:36:00+00	2017-05-16 15:36:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111346
2017-07-24 16:25:00+00	2017-07-24 16:25:00+00	2017-07-24 16:25:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111348
2017-11-28 16:59:00+00	2017-11-28 16:59:00+00	2017-11-28 16:59:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111350
2018-03-07 16:37:00+00	2018-03-07 16:37:00+00	2018-03-07 16:37:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111352
2018-06-12 14:11:00+00	2018-06-12 14:11:00+00	2018-06-12 14:11:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111354
2018-08-29 16:11:00+00	2018-08-29 16:11:00+00	2018-08-29 16:11:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111356
2018-12-03 16:44:00+00	2018-12-03 16:44:00+00	2018-12-03 16:44:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111358
2019-03-14 17:22:00+00	2019-03-14 17:22:00+00	2019-03-14 17:22:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111360
2019-06-24 15:05:00+00	2019-06-24 15:05:00+00	2019-06-24 15:05:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111362
2019-08-23 14:49:00+00	2019-08-23 14:49:00+00	2019-08-23 14:49:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111364
2019-12-30 16:40:00+00	2019-12-30 16:40:00+00	2019-12-30 16:40:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111366
2020-02-26 17:08:00+00	2020-02-26 17:08:00+00	2020-02-26 17:08:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	67	34	111368
2001-06-07 12:00:00+00	2001-06-07 12:00:00+00	2001-06-07 12:00:00+00	0	899.9	\N	\N	899.9	\N	\N	\N	\N	68	34	111227
2001-07-25 12:00:00+00	2001-07-25 12:00:00+00	2001-07-25 12:00:00+00	0	899.98	\N	\N	899.98	\N	\N	\N	\N	68	34	111229
2001-09-27 12:00:00+00	2001-09-27 12:00:00+00	2001-09-27 12:00:00+00	0	899.35	\N	\N	899.35	\N	\N	\N	\N	68	34	111231
2002-01-22 12:00:00+00	2002-01-22 12:00:00+00	2002-01-22 12:00:00+00	0	899.25	\N	\N	899.25	\N	\N	\N	\N	68	34	111233
2002-09-26 12:00:00+00	2002-09-26 12:00:00+00	2002-09-26 12:00:00+00	0	899.35	\N	\N	899.35	\N	\N	\N	\N	68	34	111235
2002-10-30 12:00:00+00	2002-10-30 12:00:00+00	2002-10-30 12:00:00+00	0	899.45	\N	\N	899.45	\N	\N	\N	\N	68	34	111237
2003-01-16 12:00:00+00	2003-01-16 12:00:00+00	2003-01-16 12:00:00+00	0	899.6	\N	\N	899.6	\N	\N	\N	\N	68	34	111239
2003-03-11 12:00:00+00	2003-03-11 12:00:00+00	2003-03-11 12:00:00+00	0	899.3	\N	\N	899.3	\N	\N	\N	\N	68	34	111241
2003-04-30 12:00:00+00	2003-04-30 12:00:00+00	2003-04-30 12:00:00+00	0	899.45	\N	\N	899.45	\N	\N	\N	\N	68	34	111243
2003-07-24 12:00:00+00	2003-07-24 12:00:00+00	2003-07-24 12:00:00+00	0	899.55	\N	\N	899.55	\N	\N	\N	\N	68	34	111245
2003-09-11 12:00:00+00	2003-09-11 12:00:00+00	2003-09-11 12:00:00+00	0	899.73	\N	\N	899.73	\N	\N	\N	\N	68	34	111247
2003-11-19 12:00:00+00	2003-11-19 12:00:00+00	2003-11-19 12:00:00+00	0	899.73	\N	\N	899.73	\N	\N	\N	\N	68	34	111249
2004-02-23 12:00:00+00	2004-02-23 12:00:00+00	2004-02-23 12:00:00+00	0	899.56	\N	\N	899.56	\N	\N	\N	\N	68	34	111251
2004-05-19 12:00:00+00	2004-05-19 12:00:00+00	2004-05-19 12:00:00+00	0	899.5	\N	\N	899.5	\N	\N	\N	\N	68	34	111253
2004-09-22 12:00:00+00	2004-09-22 12:00:00+00	2004-09-22 12:00:00+00	0	900.1	\N	\N	900.1	\N	\N	\N	\N	68	34	111255
2005-01-13 12:00:00+00	2005-01-13 12:00:00+00	2005-01-13 12:00:00+00	0	899.68	\N	\N	899.68	\N	\N	\N	\N	68	34	111257
2005-03-31 12:00:00+00	2005-03-31 12:00:00+00	2005-03-31 12:00:00+00	0	899.5	\N	\N	899.5	\N	\N	\N	\N	68	34	111259
2005-05-19 12:00:00+00	2005-05-19 12:00:00+00	2005-05-19 12:00:00+00	0	899.7	\N	\N	899.7	\N	\N	\N	\N	68	34	111261
2005-07-26 12:00:00+00	2005-07-26 12:00:00+00	2005-07-26 12:00:00+00	0	900	\N	\N	900	\N	\N	\N	\N	68	34	111263
2006-01-11 12:00:00+00	2006-01-11 12:00:00+00	2006-01-11 12:00:00+00	0	900	\N	\N	900	\N	\N	\N	\N	68	34	111265
2006-05-09 12:00:00+00	2006-05-09 12:00:00+00	2006-05-09 12:00:00+00	0	900.05	\N	\N	900.05	\N	\N	\N	\N	68	34	111267
2006-09-12 12:00:00+00	2006-09-12 12:00:00+00	2006-09-12 12:00:00+00	0	900.29	\N	\N	900.29	\N	\N	\N	\N	68	34	111269
2007-01-18 12:00:00+00	2007-01-18 12:00:00+00	2007-01-18 12:00:00+00	0	900.4	\N	\N	900.4	\N	\N	\N	\N	68	34	111271
2007-03-06 12:00:00+00	2007-03-06 12:00:00+00	2007-03-06 12:00:00+00	0	900.35	\N	\N	900.35	\N	\N	\N	\N	68	34	111273
2007-06-06 12:00:00+00	2007-06-06 12:00:00+00	2007-06-06 12:00:00+00	0	900.19	\N	\N	900.19	\N	\N	\N	\N	68	34	111275
2007-08-30 12:00:00+00	2007-08-30 12:00:00+00	2007-08-30 12:00:00+00	0	900.72	\N	\N	900.72	\N	\N	\N	\N	68	34	111277
2008-01-09 12:00:00+00	2008-01-09 12:00:00+00	2008-01-09 12:00:00+00	0	900.55	\N	\N	900.55	\N	\N	\N	\N	68	34	111279
2008-02-27 12:00:00+00	2008-02-27 12:00:00+00	2008-02-27 12:00:00+00	0	900.51	\N	\N	900.51	\N	\N	\N	\N	68	34	111281
2008-06-09 12:00:00+00	2008-06-09 12:00:00+00	2008-06-09 12:00:00+00	0	900.52	\N	\N	900.52	\N	\N	\N	\N	68	34	111283
2008-08-27 12:00:00+00	2008-08-27 12:00:00+00	2008-08-27 12:00:00+00	0	900.73	\N	\N	900.73	\N	\N	\N	\N	68	34	111285
2009-05-29 12:00:00+00	2009-05-29 12:00:00+00	2009-05-29 12:00:00+00	0	900.72	\N	\N	900.72	\N	\N	\N	\N	68	34	111287
2009-07-30 12:00:00+00	2009-07-30 12:00:00+00	2009-07-30 12:00:00+00	0	899.9	\N	\N	899.9	\N	\N	\N	\N	68	34	111289
2009-12-18 12:00:00+00	2009-12-18 12:00:00+00	2009-12-18 12:00:00+00	0	900.98	\N	\N	900.98	\N	\N	\N	\N	68	34	111291
2010-02-19 12:00:00+00	2010-02-19 12:00:00+00	2010-02-19 12:00:00+00	0	900.64	\N	\N	900.64	\N	\N	\N	\N	68	34	111293
2010-05-21 12:00:00+00	2010-05-21 12:00:00+00	2010-05-21 12:00:00+00	0	900.5	\N	\N	900.5	\N	\N	\N	\N	68	34	111295
2010-09-14 12:00:00+00	2010-09-14 12:00:00+00	2010-09-14 12:00:00+00	0	900.8	\N	\N	900.8	\N	\N	\N	\N	68	34	111297
2011-02-22 18:06:00+00	2011-02-22 18:06:00+00	2011-02-22 18:06:00+00	0	900.7	\N	\N	900.7	\N	\N	\N	\N	68	34	111299
2011-06-10 15:42:00+00	2011-06-10 15:42:00+00	2011-06-10 15:42:00+00	0	900.55	\N	\N	900.55	\N	\N	\N	\N	68	34	111301
2011-09-14 15:35:00+00	2011-09-14 15:35:00+00	2011-09-14 15:35:00+00	0	900.56	\N	\N	900.56	\N	\N	\N	\N	68	34	111303
2011-12-28 16:39:00+00	2011-12-28 16:39:00+00	2011-12-28 16:39:00+00	0	900.88	\N	\N	900.88	\N	\N	\N	\N	68	34	111305
2012-02-10 15:40:00+00	2012-02-10 15:40:00+00	2012-02-10 15:40:00+00	0	900.85	\N	\N	900.85	\N	\N	\N	\N	68	34	111307
2012-05-25 19:13:00+00	2012-05-25 19:13:00+00	2012-05-25 19:13:00+00	0	900.85	\N	\N	900.85	\N	\N	\N	\N	68	34	111309
2012-08-31 16:51:00+00	2012-08-31 16:51:00+00	2012-08-31 16:51:00+00	0	901.3	\N	\N	901.3	\N	\N	\N	\N	68	34	111311
2012-12-21 17:17:00+00	2012-12-21 17:17:00+00	2012-12-21 17:17:00+00	0	901.2	\N	\N	901.2	\N	\N	\N	\N	68	34	111313
2013-02-12 15:48:00+00	2013-02-12 15:48:00+00	2013-02-12 15:48:00+00	0	900.84	\N	\N	900.84	\N	\N	\N	\N	68	34	111315
2013-05-23 15:41:00+00	2013-05-23 15:41:00+00	2013-05-23 15:41:00+00	0	900.61	\N	\N	900.61	\N	\N	\N	\N	68	34	111317
2013-09-16 15:31:00+00	2013-09-16 15:31:00+00	2013-09-16 15:31:00+00	0	900.7	\N	\N	900.7	\N	\N	\N	\N	68	34	111319
2013-12-17 15:58:00+00	2013-12-17 15:58:00+00	2013-12-17 15:58:00+00	0	900.37	\N	\N	900.37	\N	\N	\N	\N	68	34	111321
2014-01-22 17:30:00+00	2014-01-22 17:30:00+00	2014-01-22 17:30:00+00	0	900.8	\N	\N	900.8	\N	\N	\N	\N	68	34	111323
2014-06-12 15:43:00+00	2014-06-12 15:43:00+00	2014-06-12 15:43:00+00	0	900.3	\N	\N	900.3	\N	\N	\N	\N	68	34	111325
2014-08-26 15:06:00+00	2014-08-26 15:06:00+00	2014-08-26 15:06:00+00	0	901.14	\N	\N	901.14	\N	\N	\N	\N	68	34	111327
2014-12-10 16:40:00+00	2014-12-10 16:40:00+00	2014-12-10 16:40:00+00	0	901.2	\N	\N	901.2	\N	\N	\N	\N	68	34	111329
2015-03-06 16:41:00+00	2015-03-06 16:41:00+00	2015-03-06 16:41:00+00	0	901.08	\N	\N	901.08	\N	\N	\N	\N	68	34	111331
2015-09-09 15:32:00+00	2015-09-09 15:32:00+00	2015-09-09 15:32:00+00	0	900.69	\N	\N	900.69	\N	\N	\N	\N	68	34	111333
2015-12-15 16:23:00+00	2015-12-15 16:23:00+00	2015-12-15 16:23:00+00	0	900.55	\N	\N	900.55	\N	\N	\N	\N	68	34	111335
2016-03-03 17:51:00+00	2016-03-03 17:51:00+00	2016-03-03 17:51:00+00	0	900.5	\N	\N	900.5	\N	\N	\N	\N	68	34	111337
2016-05-16 15:18:00+00	2016-05-16 15:18:00+00	2016-05-16 15:18:00+00	0	900.34	\N	\N	900.34	\N	\N	\N	\N	68	34	111339
2016-08-24 17:22:00+00	2016-08-24 17:22:00+00	2016-08-24 17:22:00+00	0	900.5	\N	\N	900.5	\N	\N	\N	\N	68	34	111341
2017-01-30 17:23:00+00	2017-01-30 17:23:00+00	2017-01-30 17:23:00+00	0	900.11	\N	\N	900.11	\N	\N	\N	\N	68	34	111343
2017-05-16 15:36:00+00	2017-05-16 15:36:00+00	2017-05-16 15:36:00+00	0	899.94	\N	\N	899.94	\N	\N	\N	\N	68	34	111345
2017-07-24 16:25:00+00	2017-07-24 16:25:00+00	2017-07-24 16:25:00+00	0	900.26	\N	\N	900.26	\N	\N	\N	\N	68	34	111347
2017-11-28 16:59:00+00	2017-11-28 16:59:00+00	2017-11-28 16:59:00+00	0	900.06	\N	\N	900.06	\N	\N	\N	\N	68	34	111349
2018-03-07 16:37:00+00	2018-03-07 16:37:00+00	2018-03-07 16:37:00+00	0	900.03	\N	\N	900.03	\N	\N	\N	\N	68	34	111351
2018-06-12 14:11:00+00	2018-06-12 14:11:00+00	2018-06-12 14:11:00+00	0	899.95	\N	\N	899.95	\N	\N	\N	\N	68	34	111353
2018-08-29 16:11:00+00	2018-08-29 16:11:00+00	2018-08-29 16:11:00+00	0	900.1	\N	\N	900.1	\N	\N	\N	\N	68	34	111355
2018-12-03 16:44:00+00	2018-12-03 16:44:00+00	2018-12-03 16:44:00+00	0	899.97	\N	\N	899.97	\N	\N	\N	\N	68	34	111357
2019-03-14 17:22:00+00	2019-03-14 17:22:00+00	2019-03-14 17:22:00+00	0	899.87	\N	\N	899.87	\N	\N	\N	\N	68	34	111359
2019-06-24 15:05:00+00	2019-06-24 15:05:00+00	2019-06-24 15:05:00+00	0	899.91	\N	\N	899.91	\N	\N	\N	\N	68	34	111361
2019-08-23 14:49:00+00	2019-08-23 14:49:00+00	2019-08-23 14:49:00+00	0	899.78	\N	\N	899.78	\N	\N	\N	\N	68	34	111363
2019-12-30 16:40:00+00	2019-12-30 16:40:00+00	2019-12-30 16:40:00+00	0	899.72	\N	\N	899.72	\N	\N	\N	\N	68	34	111365
2020-02-26 17:08:00+00	2020-02-26 17:08:00+00	2020-02-26 17:08:00+00	0	900.13	\N	\N	900.13	\N	\N	\N	\N	68	34	111367
2007-12-14 07:00:00+00	2007-12-14 07:00:00+00	2007-12-14 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172570
2008-04-30 07:00:00+00	2008-04-30 07:00:00+00	2008-04-30 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172572
2008-06-26 07:00:00+00	2008-06-26 07:00:00+00	2008-06-26 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172574
2008-08-08 07:00:00+00	2008-08-08 07:00:00+00	2008-08-08 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172576
2008-10-02 07:00:00+00	2008-10-02 07:00:00+00	2008-10-02 07:00:00+00	0	5429	\N	\N	5429	\N	\N	\N	\N	77	39	172578
2008-11-24 07:00:00+00	2008-11-24 07:00:00+00	2008-11-24 07:00:00+00	0	5429	\N	\N	5429	\N	\N	\N	\N	77	39	172580
2009-03-05 07:00:00+00	2009-03-05 07:00:00+00	2009-03-05 07:00:00+00	0	5429	\N	\N	5429	\N	\N	\N	\N	77	39	172582
2009-04-14 07:00:00+00	2009-04-14 07:00:00+00	2009-04-14 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172584
2009-06-25 07:00:00+00	2009-06-25 07:00:00+00	2009-06-25 07:00:00+00	0	5429	\N	\N	5429	\N	\N	\N	\N	77	39	172586
2010-03-04 07:00:00+00	2010-03-04 07:00:00+00	2010-03-04 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172588
2010-07-12 07:00:00+00	2010-07-12 07:00:00+00	2010-07-12 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172590
2010-10-28 07:00:00+00	2010-10-28 07:00:00+00	2010-10-28 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172592
2011-03-03 07:00:00+00	2011-03-03 07:00:00+00	2011-03-03 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172594
2011-06-08 07:00:00+00	2011-06-08 07:00:00+00	2011-06-08 07:00:00+00	0	5426	\N	\N	5426	\N	\N	\N	\N	77	39	172596
2014-11-11 07:00:00+00	2014-11-11 07:00:00+00	2014-11-11 07:00:00+00	0	5429	\N	\N	5429	\N	\N	\N	\N	77	39	172598
2016-11-04 07:00:00+00	2016-11-04 07:00:00+00	2016-11-04 07:00:00+00	0	5428	\N	\N	5428	\N	\N	\N	\N	77	39	172600
2017-11-08 07:00:00+00	2017-11-08 07:00:00+00	2017-11-08 07:00:00+00	0	5427	\N	\N	5427	\N	\N	\N	\N	77	39	172602
2018-11-07 07:00:00+00	2018-11-07 07:00:00+00	2018-11-07 07:00:00+00	0	5427	\N	\N	5427	\N	\N	\N	\N	77	39	172604
2019-11-12 07:00:00+00	2019-11-12 07:00:00+00	2019-11-12 07:00:00+00	0	5427	\N	\N	5427	\N	\N	\N	\N	77	39	172606
2007-12-14 07:00:00+00	2007-12-14 07:00:00+00	2007-12-14 07:00:00+00	0	98.1	\N	\N	98.1	\N	\N	\N	\N	78	39	172569
2008-04-30 07:00:00+00	2008-04-30 07:00:00+00	2008-04-30 07:00:00+00	0	98.27	\N	\N	98.27	\N	\N	\N	\N	78	39	172571
2008-06-26 07:00:00+00	2008-06-26 07:00:00+00	2008-06-26 07:00:00+00	0	98.1	\N	\N	98.1	\N	\N	\N	\N	78	39	172573
2008-08-08 07:00:00+00	2008-08-08 07:00:00+00	2008-08-08 07:00:00+00	0	98.07	\N	\N	98.07	\N	\N	\N	\N	78	39	172575
2008-10-02 07:00:00+00	2008-10-02 07:00:00+00	2008-10-02 07:00:00+00	0	97.28	\N	\N	97.28	\N	\N	\N	\N	78	39	172577
2008-11-24 07:00:00+00	2008-11-24 07:00:00+00	2008-11-24 07:00:00+00	0	97.31	\N	\N	97.31	\N	\N	\N	\N	78	39	172579
2009-03-05 07:00:00+00	2009-03-05 07:00:00+00	2009-03-05 07:00:00+00	0	97.43	\N	\N	97.43	\N	\N	\N	\N	78	39	172581
2009-04-14 07:00:00+00	2009-04-14 07:00:00+00	2009-04-14 07:00:00+00	0	98.2	\N	\N	98.2	\N	\N	\N	\N	78	39	172583
2009-06-25 07:00:00+00	2009-06-25 07:00:00+00	2009-06-25 07:00:00+00	0	97.4	\N	\N	97.4	\N	\N	\N	\N	78	39	172585
2010-03-04 07:00:00+00	2010-03-04 07:00:00+00	2010-03-04 07:00:00+00	0	98.37	\N	\N	98.37	\N	\N	\N	\N	78	39	172587
2010-07-12 07:00:00+00	2010-07-12 07:00:00+00	2010-07-12 07:00:00+00	0	98.11	\N	\N	98.11	\N	\N	\N	\N	78	39	172589
2010-10-28 07:00:00+00	2010-10-28 07:00:00+00	2010-10-28 07:00:00+00	0	98.22	\N	\N	98.22	\N	\N	\N	\N	78	39	172591
2011-03-03 07:00:00+00	2011-03-03 07:00:00+00	2011-03-03 07:00:00+00	0	98.01	\N	\N	98.01	\N	\N	\N	\N	78	39	172593
2011-06-08 07:00:00+00	2011-06-08 07:00:00+00	2011-06-08 07:00:00+00	0	99.66	\N	\N	99.66	\N	\N	\N	\N	78	39	172595
2014-11-11 07:00:00+00	2014-11-11 07:00:00+00	2014-11-11 07:00:00+00	0	96.54	\N	\N	96.54	\N	\N	\N	\N	78	39	172597
2016-11-04 07:00:00+00	2016-11-04 07:00:00+00	2016-11-04 07:00:00+00	0	98	\N	\N	98	\N	\N	\N	\N	78	39	172599
2017-11-08 07:00:00+00	2017-11-08 07:00:00+00	2017-11-08 07:00:00+00	0	98.85	\N	\N	98.85	\N	\N	\N	\N	78	39	172601
2018-11-07 07:00:00+00	2018-11-07 07:00:00+00	2018-11-07 07:00:00+00	0	99.24	\N	\N	99.24	\N	\N	\N	\N	78	39	172603
2019-11-12 07:00:00+00	2019-11-12 07:00:00+00	2019-11-12 07:00:00+00	0	99.42	\N	\N	99.42	\N	\N	\N	\N	78	39	172605
1980-01-09 12:00:00+00	1980-01-09 12:00:00+00	1980-01-09 12:00:00+00	0	4282	\N	\N	4282	\N	\N	\N	\N	79	40	172608
1981-01-09 12:00:00+00	1981-01-09 12:00:00+00	1981-01-09 12:00:00+00	0	4279	\N	\N	4279	\N	\N	\N	\N	79	40	172610
1982-01-08 12:00:00+00	1982-01-08 12:00:00+00	1982-01-08 12:00:00+00	0	4284	\N	\N	4284	\N	\N	\N	\N	79	40	172612
1983-01-07 12:00:00+00	1983-01-07 12:00:00+00	1983-01-07 12:00:00+00	0	4285	\N	\N	4285	\N	\N	\N	\N	79	40	172614
1984-01-16 12:00:00+00	1984-01-16 12:00:00+00	1984-01-16 12:00:00+00	0	4286	\N	\N	4286	\N	\N	\N	\N	79	40	172616
1985-01-10 12:00:00+00	1985-01-10 12:00:00+00	1985-01-10 12:00:00+00	0	4286	\N	\N	4286	\N	\N	\N	\N	79	40	172618
1986-01-10 12:00:00+00	1986-01-10 12:00:00+00	1986-01-10 12:00:00+00	0	4287	\N	\N	4287	\N	\N	\N	\N	79	40	172620
1987-01-13 12:00:00+00	1987-01-13 12:00:00+00	1987-01-13 12:00:00+00	0	4288	\N	\N	4288	\N	\N	\N	\N	79	40	172622
1988-01-11 12:00:00+00	1988-01-11 12:00:00+00	1988-01-11 12:00:00+00	0	4288	\N	\N	4288	\N	\N	\N	\N	79	40	172624
1988-09-16 12:00:00+00	1988-09-16 12:00:00+00	1988-09-16 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172626
1988-12-15 12:00:00+00	1988-12-15 12:00:00+00	1988-12-15 12:00:00+00	0	4288	\N	\N	4288	\N	\N	\N	\N	79	40	172628
1989-01-07 12:00:00+00	1989-01-07 12:00:00+00	1989-01-07 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172630
1989-03-16 12:00:00+00	1989-03-16 12:00:00+00	1989-03-16 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172632
1989-05-16 12:00:00+00	1989-05-16 12:00:00+00	1989-05-16 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172634
1990-01-04 12:00:00+00	1990-01-04 12:00:00+00	1990-01-04 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172636
1990-01-12 12:00:00+00	1990-01-12 12:00:00+00	1990-01-12 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172638
1990-12-14 12:00:00+00	1990-12-14 12:00:00+00	1990-12-14 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172640
1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	1991-01-03 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172642
1991-01-16 12:00:00+00	1991-01-16 12:00:00+00	1991-01-16 12:00:00+00	0	4289	\N	\N	4289	\N	\N	\N	\N	79	40	172644
1991-06-14 12:00:00+00	1991-06-14 12:00:00+00	1991-06-14 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172646
1991-07-31 12:00:00+00	1991-07-31 12:00:00+00	1991-07-31 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172648
1991-12-17 12:00:00+00	1991-12-17 12:00:00+00	1991-12-17 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172650
1992-01-03 12:00:00+00	1992-01-03 12:00:00+00	1992-01-03 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172652
1992-03-17 12:00:00+00	1992-03-17 12:00:00+00	1992-03-17 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172654
1992-08-21 12:00:00+00	1992-08-21 12:00:00+00	1992-08-21 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172656
1992-12-15 12:00:00+00	1992-12-15 12:00:00+00	1992-12-15 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172658
1993-01-05 12:00:00+00	1993-01-05 12:00:00+00	1993-01-05 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172660
1993-01-15 12:00:00+00	1993-01-15 12:00:00+00	1993-01-15 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172662
1993-03-12 12:00:00+00	1993-03-12 12:00:00+00	1993-03-12 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172664
1994-01-04 12:00:00+00	1994-01-04 12:00:00+00	1994-01-04 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172666
1994-08-22 12:00:00+00	1994-08-22 12:00:00+00	1994-08-22 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172668
1995-01-06 12:00:00+00	1995-01-06 12:00:00+00	1995-01-06 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172670
1996-01-11 12:00:00+00	1996-01-11 12:00:00+00	1996-01-11 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172672
1996-03-14 12:00:00+00	1996-03-14 12:00:00+00	1996-03-14 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172674
1996-08-09 12:00:00+00	1996-08-09 12:00:00+00	1996-08-09 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172676
1996-09-29 12:00:00+00	1996-09-29 12:00:00+00	1996-09-29 12:00:00+00	0	4290	\N	\N	4290	\N	\N	\N	\N	79	40	172678
1996-10-03 12:00:00+00	1996-10-03 12:00:00+00	1996-10-03 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172680
1996-12-17 12:00:00+00	1996-12-17 12:00:00+00	1996-12-17 12:00:00+00	0	4291	\N	\N	4291	\N	\N	\N	\N	79	40	172682
1997-03-13 12:00:00+00	1997-03-13 12:00:00+00	1997-03-13 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172684
1997-05-22 12:00:00+00	1997-05-22 12:00:00+00	1997-05-22 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172686
1997-06-12 12:00:00+00	1997-06-12 12:00:00+00	1997-06-12 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172688
1997-09-17 12:00:00+00	1997-09-17 12:00:00+00	1997-09-17 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172690
1997-10-03 12:00:00+00	1997-10-03 12:00:00+00	1997-10-03 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172692
1997-12-16 12:00:00+00	1997-12-16 12:00:00+00	1997-12-16 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172694
1998-03-20 12:00:00+00	1998-03-20 12:00:00+00	1998-03-20 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172696
1998-03-31 12:00:00+00	1998-03-31 12:00:00+00	1998-03-31 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172698
1998-10-02 12:00:00+00	1998-10-02 12:00:00+00	1998-10-02 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172700
1998-12-04 21:14:00+00	1998-12-04 21:14:00+00	1998-12-04 21:14:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172702
1999-03-05 12:00:00+00	1999-03-05 12:00:00+00	1999-03-05 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172704
1999-03-25 18:00:00+00	1999-03-25 18:00:00+00	1999-03-25 18:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172706
1999-05-04 16:15:00+00	1999-05-04 16:15:00+00	1999-05-04 16:15:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172708
1999-07-06 12:00:00+00	1999-07-06 12:00:00+00	1999-07-06 12:00:00+00	0	4292	\N	\N	4292	\N	\N	\N	\N	79	40	172710
1999-10-13 16:00:00+00	1999-10-13 16:00:00+00	1999-10-13 16:00:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172712
1999-10-15 17:45:00+00	1999-10-15 17:45:00+00	1999-10-15 17:45:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172714
2000-02-07 22:45:00+00	2000-02-07 22:45:00+00	2000-02-07 22:45:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172716
2000-05-02 14:15:00+00	2000-05-02 14:15:00+00	2000-05-02 14:15:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172718
2000-07-31 19:30:00+00	2000-07-31 19:30:00+00	2000-07-31 19:30:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172720
2000-10-10 19:10:00+00	2000-10-10 19:10:00+00	2000-10-10 19:10:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172722
2000-10-27 20:17:00+00	2000-10-27 20:17:00+00	2000-10-27 20:17:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172724
2001-01-09 21:00:00+00	2001-01-09 21:00:00+00	2001-01-09 21:00:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172726
2001-03-28 23:30:00+00	2001-03-28 23:30:00+00	2001-03-28 23:30:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172728
2001-04-26 21:00:00+00	2001-04-26 21:00:00+00	2001-04-26 21:00:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172730
2001-05-29 18:00:00+00	2001-05-29 18:00:00+00	2001-05-29 18:00:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172732
2001-06-26 20:20:00+00	2001-06-26 20:20:00+00	2001-06-26 20:20:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172734
2001-07-27 20:03:00+00	2001-07-27 20:03:00+00	2001-07-27 20:03:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172736
2001-10-02 20:07:00+00	2001-10-02 20:07:00+00	2001-10-02 20:07:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172738
2001-11-19 21:50:00+00	2001-11-19 21:50:00+00	2001-11-19 21:50:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172740
2002-08-14 12:00:00+00	2002-08-14 12:00:00+00	2002-08-14 12:00:00+00	0	4293	\N	\N	4293	\N	\N	\N	\N	79	40	172742
2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	2003-02-19 12:00:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172744
2003-07-08 12:00:00+00	2003-07-08 12:00:00+00	2003-07-08 12:00:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172746
2004-02-24 16:30:00+00	2004-02-24 16:30:00+00	2004-02-24 16:30:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172748
2004-08-21 12:00:00+00	2004-08-21 12:00:00+00	2004-08-21 12:00:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172750
2006-02-23 19:45:00+00	2006-02-23 19:45:00+00	2006-02-23 19:45:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172752
2006-09-13 20:30:00+00	2006-09-13 20:30:00+00	2006-09-13 20:30:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172754
2007-05-22 19:20:00+00	2007-05-22 19:20:00+00	2007-05-22 19:20:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172756
2007-09-20 19:45:00+00	2007-09-20 19:45:00+00	2007-09-20 19:45:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172758
2008-03-12 23:10:00+00	2008-03-12 23:10:00+00	2008-03-12 23:10:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172760
2008-09-25 18:39:00+00	2008-09-25 18:39:00+00	2008-09-25 18:39:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172762
2009-10-26 16:25:00+00	2009-10-26 16:25:00+00	2009-10-26 16:25:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172764
2010-02-21 19:23:00+00	2010-02-21 19:23:00+00	2010-02-21 19:23:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172766
2010-08-28 17:30:00+00	2010-08-28 17:30:00+00	2010-08-28 17:30:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172768
2012-01-24 19:30:00+00	2012-01-24 19:30:00+00	2012-01-24 19:30:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172770
2012-04-16 19:42:00+00	2012-04-16 19:42:00+00	2012-04-16 19:42:00+00	0	4294	\N	\N	4294	\N	\N	\N	\N	79	40	172772
2013-01-29 20:15:00+00	2013-01-29 20:15:00+00	2013-01-29 20:15:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172774
2015-01-26 22:10:00+00	2015-01-26 22:10:00+00	2015-01-26 22:10:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172776
2016-01-28 16:50:00+00	2016-01-28 16:50:00+00	2016-01-28 16:50:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172778
2016-08-18 18:00:00+00	2016-08-18 18:00:00+00	2016-08-18 18:00:00+00	0	4296	\N	\N	4296	\N	\N	\N	\N	79	40	172780
2017-02-16 21:30:00+00	2017-02-16 21:30:00+00	2017-02-16 21:30:00+00	0	4296	\N	\N	4296	\N	\N	\N	\N	79	40	172782
2017-07-25 23:10:00+00	2017-07-25 23:10:00+00	2017-07-25 23:10:00+00	0	4296	\N	\N	4296	\N	\N	\N	\N	79	40	172784
2018-12-05 20:07:00+00	2018-12-05 20:07:00+00	2018-12-05 20:07:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172786
2020-01-14 21:05:00+00	2020-01-14 21:05:00+00	2020-01-14 21:05:00+00	0	4295	\N	\N	4295	\N	\N	\N	\N	79	40	172788
1954-09-10 12:00:00+00	1954-09-10 12:00:00+00	1954-09-10 12:00:00+00	0	4	\N	\N	4	\N	\N	\N	\N	2	1	1
1985-08-01 12:00:00+00	1985-08-01 12:00:00+00	1985-08-01 12:00:00+00	0	74.58	\N	\N	74.58	\N	\N	\N	\N	2	1	3
2002-05-24 12:00:00+00	2002-05-24 12:00:00+00	2002-05-24 12:00:00+00	0	67.24	\N	\N	67.24	\N	\N	\N	\N	2	1	5
2003-03-12 12:00:00+00	2003-03-12 12:00:00+00	2003-03-12 12:00:00+00	0	32.73	\N	\N	32.73	\N	\N	\N	\N	2	1	7
2004-03-03 15:18:00+00	2004-03-03 15:18:00+00	2004-03-03 15:18:00+00	0	28.89	\N	\N	28.89	\N	\N	\N	\N	2	1	9
2006-02-16 14:28:00+00	2006-02-16 14:28:00+00	2006-02-16 14:28:00+00	0	70.82	\N	\N	70.82	\N	\N	\N	\N	2	1	11
2007-02-07 21:55:00+00	2007-02-07 21:55:00+00	2007-02-07 21:55:00+00	0	60.77	\N	\N	60.77	\N	\N	\N	\N	2	1	13
2008-03-05 23:00:00+00	2008-03-05 23:00:00+00	2008-03-05 23:00:00+00	0	61.73	\N	\N	61.73	\N	\N	\N	\N	2	1	15
2009-03-25 20:50:00+00	2009-03-25 20:50:00+00	2009-03-25 20:50:00+00	0	50.57	\N	\N	50.57	\N	\N	\N	\N	2	1	17
2011-03-10 22:15:00+00	2011-03-10 22:15:00+00	2011-03-10 22:15:00+00	0	37.36	\N	\N	37.36	\N	\N	\N	\N	2	1	19
2012-03-15 17:45:00+00	2012-03-15 17:45:00+00	2012-03-15 17:45:00+00	0	34.85	\N	\N	34.85	\N	\N	\N	\N	2	1	21
2013-04-04 18:00:00+00	2013-04-04 18:00:00+00	2013-04-04 18:00:00+00	0	77.61	\N	\N	77.61	\N	\N	\N	\N	2	1	23
2014-03-19 00:00:00+00	2014-03-19 00:00:00+00	2014-03-19 00:00:00+00	0	70.49	\N	\N	70.49	\N	\N	\N	\N	2	1	25
2016-02-24 19:30:00+00	2016-02-24 19:30:00+00	2016-02-24 19:30:00+00	0	68.91	\N	\N	68.91	\N	\N	\N	\N	2	1	27
2016-08-11 17:00:00+00	2016-08-11 17:00:00+00	2016-08-11 17:00:00+00	0	49.34	\N	\N	49.34	\N	\N	\N	\N	2	1	29
2017-08-01 20:30:00+00	2017-08-01 20:30:00+00	2017-08-01 20:30:00+00	0	50.6	\N	\N	50.6	\N	\N	\N	\N	2	1	31
2019-12-13 21:26:00+00	2019-12-13 21:26:00+00	2019-12-13 21:26:00+00	0	79.26	\N	\N	79.26	\N	\N	\N	\N	2	1	33
2011-03-15 07:00:00+00	2011-03-15 07:00:00+00	2011-03-15 07:00:00+00	0	6780	\N	\N	6780	\N	\N	\N	\N	3	2	36
2011-06-03 07:00:00+00	2011-06-03 07:00:00+00	2011-06-03 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	38
2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	2011-06-13 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	40
2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	2011-09-08 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	42
2011-12-14 07:00:00+00	2011-12-14 07:00:00+00	2011-12-14 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	44
2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	2012-03-14 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	46
2012-06-05 07:00:00+00	2012-06-05 07:00:00+00	2012-06-05 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	48
2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	2012-11-30 07:00:00+00	0	6778	\N	\N	6778	\N	\N	\N	\N	3	2	50
2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	2013-06-05 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	52
2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	2013-09-05 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	54
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	56
2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	2014-03-03 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	58
2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	2014-06-03 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	60
2014-08-04 07:00:00+00	2014-08-04 07:00:00+00	2014-08-04 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	62
2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	2014-09-01 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	64
2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	2014-12-08 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	66
2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	2015-06-01 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	68
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	70
2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	2016-09-07 07:00:00+00	0	6778	\N	\N	6778	\N	\N	\N	\N	3	2	72
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	6779	\N	\N	6779	\N	\N	\N	\N	3	2	74
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	76
2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	2019-10-23 07:00:00+00	0	6777	\N	\N	6777	\N	\N	\N	\N	3	2	78
2012-11-07 07:00:00+00	2012-11-07 07:00:00+00	2012-11-07 07:00:00+00	0	15.55	\N	\N	15.55	\N	\N	\N	\N	8	4	123
2013-02-25 07:00:00+00	2013-02-25 07:00:00+00	2013-02-25 07:00:00+00	0	17.22	\N	\N	17.22	\N	\N	\N	\N	8	4	125
2013-06-11 07:00:00+00	2013-06-11 07:00:00+00	2013-06-11 07:00:00+00	0	6.86	\N	\N	6.86	\N	\N	\N	\N	8	4	127
2013-08-30 07:00:00+00	2013-08-30 07:00:00+00	2013-08-30 07:00:00+00	0	15.09	\N	\N	15.09	\N	\N	\N	\N	8	4	129
2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	2013-12-18 07:00:00+00	0	14.84	\N	\N	14.84	\N	\N	\N	\N	8	4	131
2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	2014-03-04 07:00:00+00	0	17.49	\N	\N	17.49	\N	\N	\N	\N	8	4	133
2014-06-24 07:00:00+00	2014-06-24 07:00:00+00	2014-06-24 07:00:00+00	0	9.29	\N	\N	9.29	\N	\N	\N	\N	8	4	135
2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	2014-09-02 07:00:00+00	0	14.88	\N	\N	14.88	\N	\N	\N	\N	8	4	137
2014-12-11 07:00:00+00	2014-12-11 07:00:00+00	2014-12-11 07:00:00+00	0	16.68	\N	\N	16.68	\N	\N	\N	\N	8	4	139
2015-03-18 07:00:00+00	2015-03-18 07:00:00+00	2015-03-18 07:00:00+00	0	16.99	\N	\N	16.99	\N	\N	\N	\N	8	4	141
2015-06-02 07:00:00+00	2015-06-02 07:00:00+00	2015-06-02 07:00:00+00	0	13.09	\N	\N	13.09	\N	\N	\N	\N	8	4	143
2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	2015-08-26 07:00:00+00	0	15.09	\N	\N	15.09	\N	\N	\N	\N	8	4	145
2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	2016-09-06 07:00:00+00	0	13.05	\N	\N	13.05	\N	\N	\N	\N	8	4	147
2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	2017-10-23 07:00:00+00	0	16.28	\N	\N	16.28	\N	\N	\N	\N	8	4	149
2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	2018-12-05 07:00:00+00	0	17.29	\N	\N	17.29	\N	\N	\N	\N	8	4	151
2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	2019-10-22 07:00:00+00	0	16.42	\N	\N	16.42	\N	\N	\N	\N	8	4	153
2011-01-25 20:50:00+00	2011-01-25 20:50:00+00	2011-01-25 20:50:00+00	0	22.17	\N	\N	22.17	\N	\N	\N	\N	18	9	511
2011-05-25 15:13:00+00	2011-05-25 15:13:00+00	2011-05-25 15:13:00+00	0	22.74	\N	\N	22.74	\N	\N	\N	\N	18	9	513
2011-06-22 19:40:00+00	2011-06-22 19:40:00+00	2011-06-22 19:40:00+00	0	22.86	\N	\N	22.86	\N	\N	\N	\N	18	9	515
2011-07-26 18:30:00+00	2011-07-26 18:30:00+00	2011-07-26 18:30:00+00	0	22.81	\N	\N	22.81	\N	\N	\N	\N	18	9	517
2011-09-01 19:00:00+00	2011-09-01 19:00:00+00	2011-09-01 19:00:00+00	0	22.85	\N	\N	22.85	\N	\N	\N	\N	18	9	519
2011-11-08 23:15:00+00	2011-11-08 23:15:00+00	2011-11-08 23:15:00+00	0	22.81	\N	\N	22.81	\N	\N	\N	\N	18	9	521
2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	2011-12-06 17:00:00+00	0	23.01	\N	\N	23.01	\N	\N	\N	\N	18	9	523
2012-01-10 18:06:00+00	2012-01-10 18:06:00+00	2012-01-10 18:06:00+00	0	23.23	\N	\N	23.23	\N	\N	\N	\N	18	9	525
2012-02-08 00:30:00+00	2012-02-08 00:30:00+00	2012-02-08 00:30:00+00	0	23.38	\N	\N	23.38	\N	\N	\N	\N	18	9	527
2012-03-06 23:30:00+00	2012-03-06 23:30:00+00	2012-03-06 23:30:00+00	0	23.35	\N	\N	23.35	\N	\N	\N	\N	18	9	529
2012-04-12 19:00:00+00	2012-04-12 19:00:00+00	2012-04-12 19:00:00+00	0	23.61	\N	\N	23.61	\N	\N	\N	\N	18	9	531
2012-05-09 00:00:00+00	2012-05-09 00:00:00+00	2012-05-09 00:00:00+00	0	23.73	\N	\N	23.73	\N	\N	\N	\N	18	9	533
2012-08-14 22:00:00+00	2012-08-14 22:00:00+00	2012-08-14 22:00:00+00	0	22.26	\N	\N	22.26	\N	\N	\N	\N	18	9	535
2012-10-09 16:50:00+00	2012-10-09 16:50:00+00	2012-10-09 16:50:00+00	0	22.21	\N	\N	22.21	\N	\N	\N	\N	18	9	537
2013-02-27 18:30:00+00	2013-02-27 18:30:00+00	2013-02-27 18:30:00+00	0	22.32	\N	\N	22.32	\N	\N	\N	\N	18	9	539
2013-04-03 14:05:00+00	2013-04-03 14:05:00+00	2013-04-03 14:05:00+00	0	22.64	\N	\N	22.64	\N	\N	\N	\N	18	9	541
2013-07-09 22:40:00+00	2013-07-09 22:40:00+00	2013-07-09 22:40:00+00	0	23.01	\N	\N	23.01	\N	\N	\N	\N	18	9	543
2013-12-10 21:55:00+00	2013-12-10 21:55:00+00	2013-12-10 21:55:00+00	0	20.31	\N	\N	20.31	\N	\N	\N	\N	18	9	545
2016-08-12 18:00:00+00	2016-08-12 18:00:00+00	2016-08-12 18:00:00+00	0	17.1	\N	\N	17.1	\N	\N	\N	\N	18	9	547
2018-02-06 18:29:00+00	2018-02-06 18:29:00+00	2018-02-06 18:29:00+00	0	20.11	\N	\N	20.11	\N	\N	\N	\N	18	9	549
2019-12-12 22:23:00+00	2019-12-12 22:23:00+00	2019-12-12 22:23:00+00	0	21.59	\N	\N	21.59	\N	\N	\N	\N	18	9	551
1981-09-21 12:00:00+00	1981-09-21 12:00:00+00	1981-09-21 12:00:00+00	0	417	\N	\N	417	\N	\N	\N	\N	22	11	609
1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	1983-04-01 12:00:00+00	0	424.83	\N	\N	424.83	\N	\N	\N	\N	22	11	611
1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	1983-10-27 12:00:00+00	0	428.79	\N	\N	428.79	\N	\N	\N	\N	22	11	613
1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	1984-06-28 12:00:00+00	0	433.39	\N	\N	433.39	\N	\N	\N	\N	22	11	615
1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	1984-07-25 12:00:00+00	0	433.87	\N	\N	433.87	\N	\N	\N	\N	22	11	617
1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	1984-08-16 12:00:00+00	0	434.11	\N	\N	434.11	\N	\N	\N	\N	22	11	619
1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	1985-02-21 12:00:00+00	0	436.48	\N	\N	436.48	\N	\N	\N	\N	22	11	621
1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	1985-05-08 12:00:00+00	0	437.17	\N	\N	437.17	\N	\N	\N	\N	22	11	623
1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	1985-07-18 12:00:00+00	0	438.83	\N	\N	438.83	\N	\N	\N	\N	22	11	625
1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	1985-10-10 12:00:00+00	0	439.61	\N	\N	439.61	\N	\N	\N	\N	22	11	627
1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	1985-11-22 12:00:00+00	0	440.04	\N	\N	440.04	\N	\N	\N	\N	22	11	629
1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	1986-02-04 12:00:00+00	0	440.76	\N	\N	440.76	\N	\N	\N	\N	22	11	631
1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	1986-10-07 12:00:00+00	0	443.68	\N	\N	443.68	\N	\N	\N	\N	22	11	633
1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	1987-02-10 12:00:00+00	0	444.53	\N	\N	444.53	\N	\N	\N	\N	22	11	635
1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	1987-10-05 12:00:00+00	0	446.68	\N	\N	446.68	\N	\N	\N	\N	22	11	637
1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	1988-03-10 12:00:00+00	0	448.83	\N	\N	448.83	\N	\N	\N	\N	22	11	639
1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	1988-10-27 12:00:00+00	0	451.64	\N	\N	451.64	\N	\N	\N	\N	22	11	641
1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	1989-04-27 12:00:00+00	0	453.34	\N	\N	453.34	\N	\N	\N	\N	22	11	643
1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	1989-10-31 12:00:00+00	0	453.98	\N	\N	453.98	\N	\N	\N	\N	22	11	645
1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	1990-05-18 12:00:00+00	0	455.78	\N	\N	455.78	\N	\N	\N	\N	22	11	647
1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	1992-02-25 12:00:00+00	0	462.36	\N	\N	462.36	\N	\N	\N	\N	22	11	649
1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	1997-02-24 12:00:00+00	0	469.57	\N	\N	469.57	\N	\N	\N	\N	22	11	651
2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	2002-02-22 12:00:00+00	0	468.58	\N	\N	468.58	\N	\N	\N	\N	22	11	653
2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	2003-03-13 12:00:00+00	0	467.8	\N	\N	467.8	\N	\N	\N	\N	22	11	655
2004-03-03 22:19:00+00	2004-03-03 22:19:00+00	2004-03-03 22:19:00+00	0	469.43	\N	\N	469.43	\N	\N	\N	\N	22	11	657
2005-03-07 23:05:00+00	2005-03-07 23:05:00+00	2005-03-07 23:05:00+00	0	470.47	\N	\N	470.47	\N	\N	\N	\N	22	11	659
2006-02-14 16:13:00+00	2006-02-14 16:13:00+00	2006-02-14 16:13:00+00	0	469.99	\N	\N	469.99	\N	\N	\N	\N	22	11	661
2007-02-13 21:26:00+00	2007-02-13 21:26:00+00	2007-02-13 21:26:00+00	0	469.36	\N	\N	469.36	\N	\N	\N	\N	22	11	663
2008-03-04 22:35:00+00	2008-03-04 22:35:00+00	2008-03-04 22:35:00+00	0	470.31	\N	\N	470.31	\N	\N	\N	\N	22	11	665
2009-03-26 14:40:00+00	2009-03-26 14:40:00+00	2009-03-26 14:40:00+00	0	469.04	\N	\N	469.04	\N	\N	\N	\N	22	11	667
2010-03-17 22:30:00+00	2010-03-17 22:30:00+00	2010-03-17 22:30:00+00	0	469.16	\N	\N	469.16	\N	\N	\N	\N	22	11	669
2011-03-09 22:25:00+00	2011-03-09 22:25:00+00	2011-03-09 22:25:00+00	0	469.59	\N	\N	469.59	\N	\N	\N	\N	22	11	671
2012-03-13 20:35:00+00	2012-03-13 20:35:00+00	2012-03-13 20:35:00+00	0	469.83	\N	\N	469.83	\N	\N	\N	\N	22	11	673
2013-04-04 23:30:00+00	2013-04-04 23:30:00+00	2013-04-04 23:30:00+00	0	469.34	\N	\N	469.34	\N	\N	\N	\N	22	11	675
2014-03-20 21:45:00+00	2014-03-20 21:45:00+00	2014-03-20 21:45:00+00	0	466.21	\N	\N	466.21	\N	\N	\N	\N	22	11	677
2015-02-28 20:45:00+00	2015-02-28 20:45:00+00	2015-02-28 20:45:00+00	0	464.85	\N	\N	464.85	\N	\N	\N	\N	22	11	679
2016-02-25 00:15:00+00	2016-02-25 00:15:00+00	2016-02-25 00:15:00+00	0	464.1	\N	\N	464.1	\N	\N	\N	\N	22	11	681
2016-08-10 22:00:00+00	2016-08-10 22:00:00+00	2016-08-10 22:00:00+00	0	463.09	\N	\N	463.09	\N	\N	\N	\N	22	11	683
2017-08-03 01:02:00+00	2017-08-03 01:02:00+00	2017-08-03 01:02:00+00	0	463.78	\N	\N	463.78	\N	\N	\N	\N	22	11	685
2018-02-08 20:09:00+00	2018-02-08 20:09:00+00	2018-02-08 20:09:00+00	0	462.26	\N	\N	462.26	\N	\N	\N	\N	22	11	687
2019-03-07 20:26:00+00	2019-03-07 20:26:00+00	2019-03-07 20:26:00+00	0	461.65	\N	\N	461.65	\N	\N	\N	\N	22	11	689
2020-01-08 18:01:00+00	2020-01-08 18:01:00+00	2020-01-08 18:01:00+00	0	461.7	\N	\N	461.7	\N	\N	\N	\N	22	11	691
1993-09-21 12:00:00+00	1993-09-21 12:00:00+00	1993-09-21 12:00:00+00	0	39.38	\N	\N	39.38	\N	\N	\N	\N	26	13	771
1994-05-22 12:00:00+00	1994-05-22 12:00:00+00	1994-05-22 12:00:00+00	0	39.05	\N	\N	39.05	\N	\N	\N	\N	26	13	773
1994-09-18 12:00:00+00	1994-09-18 12:00:00+00	1994-09-18 12:00:00+00	0	39.42	\N	\N	39.42	\N	\N	\N	\N	26	13	775
1995-05-22 12:00:00+00	1995-05-22 12:00:00+00	1995-05-22 12:00:00+00	0	39.47	\N	\N	39.47	\N	\N	\N	\N	26	13	777
1995-09-11 12:00:00+00	1995-09-11 12:00:00+00	1995-09-11 12:00:00+00	0	39.59	\N	\N	39.59	\N	\N	\N	\N	26	13	779
1996-05-28 12:00:00+00	1996-05-28 12:00:00+00	1996-05-28 12:00:00+00	0	39.82	\N	\N	39.82	\N	\N	\N	\N	26	13	781
1996-09-03 12:00:00+00	1996-09-03 12:00:00+00	1996-09-03 12:00:00+00	0	40	\N	\N	40	\N	\N	\N	\N	26	13	783
1997-03-11 12:00:00+00	1997-03-11 12:00:00+00	1997-03-11 12:00:00+00	0	40.1	\N	\N	40.1	\N	\N	\N	\N	26	13	785
1997-05-20 12:00:00+00	1997-05-20 12:00:00+00	1997-05-20 12:00:00+00	0	40.16	\N	\N	40.16	\N	\N	\N	\N	26	13	787
1997-09-08 12:00:00+00	1997-09-08 12:00:00+00	1997-09-08 12:00:00+00	0	39.07	\N	\N	39.07	\N	\N	\N	\N	26	13	789
1998-05-19 12:00:00+00	1998-05-19 12:00:00+00	1998-05-19 12:00:00+00	0	38.59	\N	\N	38.59	\N	\N	\N	\N	26	13	791
1998-08-31 12:00:00+00	1998-08-31 12:00:00+00	1998-08-31 12:00:00+00	0	38.94	\N	\N	38.94	\N	\N	\N	\N	26	13	793
1999-06-07 12:00:00+00	1999-06-07 12:00:00+00	1999-06-07 12:00:00+00	0	37.78	\N	\N	37.78	\N	\N	\N	\N	26	13	795
1999-11-17 12:00:00+00	1999-11-17 12:00:00+00	1999-11-17 12:00:00+00	0	37.53	\N	\N	37.53	\N	\N	\N	\N	26	13	797
2000-05-31 12:00:00+00	2000-05-31 12:00:00+00	2000-05-31 12:00:00+00	0	37.85	\N	\N	37.85	\N	\N	\N	\N	26	13	799
2000-11-14 12:00:00+00	2000-11-14 12:00:00+00	2000-11-14 12:00:00+00	0	38.38	\N	\N	38.38	\N	\N	\N	\N	26	13	801
2001-05-21 12:00:00+00	2001-05-21 12:00:00+00	2001-05-21 12:00:00+00	0	38.37	\N	\N	38.37	\N	\N	\N	\N	26	13	803
2001-11-06 12:00:00+00	2001-11-06 12:00:00+00	2001-11-06 12:00:00+00	0	38.78	\N	\N	38.78	\N	\N	\N	\N	26	13	805
2002-05-14 12:00:00+00	2002-05-14 12:00:00+00	2002-05-14 12:00:00+00	0	38.92	\N	\N	38.92	\N	\N	\N	\N	26	13	807
2006-07-18 22:50:00+00	2006-07-18 22:50:00+00	2006-07-18 22:50:00+00	0	37.97	\N	\N	37.97	\N	\N	\N	\N	26	13	809
2007-03-05 20:48:00+00	2007-03-05 20:48:00+00	2007-03-05 20:48:00+00	0	37.99	\N	\N	37.99	\N	\N	\N	\N	26	13	811
2007-08-07 20:00:00+00	2007-08-07 20:00:00+00	2007-08-07 20:00:00+00	0	37.96	\N	\N	37.96	\N	\N	\N	\N	26	13	813
2008-03-26 00:40:00+00	2008-03-26 00:40:00+00	2008-03-26 00:40:00+00	0	36.86	\N	\N	36.86	\N	\N	\N	\N	26	13	815
2008-08-11 19:00:00+00	2008-08-11 19:00:00+00	2008-08-11 19:00:00+00	0	37.24	\N	\N	37.24	\N	\N	\N	\N	26	13	817
2009-03-24 14:03:00+00	2009-03-24 14:03:00+00	2009-03-24 14:03:00+00	0	37.34	\N	\N	37.34	\N	\N	\N	\N	26	13	819
2009-08-03 19:30:00+00	2009-08-03 19:30:00+00	2009-08-03 19:30:00+00	0	37.72	\N	\N	37.72	\N	\N	\N	\N	26	13	821
2010-03-16 17:10:00+00	2010-03-16 17:10:00+00	2010-03-16 17:10:00+00	0	37.87	\N	\N	37.87	\N	\N	\N	\N	26	13	823
2010-09-01 18:30:00+00	2010-09-01 18:30:00+00	2010-09-01 18:30:00+00	0	38.15	\N	\N	38.15	\N	\N	\N	\N	26	13	825
2011-01-25 15:15:00+00	2011-01-25 15:15:00+00	2011-01-25 15:15:00+00	0	38.02	\N	\N	38.02	\N	\N	\N	\N	26	13	827
2011-06-21 19:30:00+00	2011-06-21 19:30:00+00	2011-06-21 19:30:00+00	0	37.81	\N	\N	37.81	\N	\N	\N	\N	26	13	829
2012-03-15 22:00:00+00	2012-03-15 22:00:00+00	2012-03-15 22:00:00+00	0	38.16	\N	\N	38.16	\N	\N	\N	\N	26	13	831
2013-04-08 18:30:00+00	2013-04-08 18:30:00+00	2013-04-08 18:30:00+00	0	37.98	\N	\N	37.98	\N	\N	\N	\N	26	13	833
2014-08-08 17:00:00+00	2014-08-08 17:00:00+00	2014-08-08 17:00:00+00	0	36.43	\N	\N	36.43	\N	\N	\N	\N	26	13	835
2015-02-24 21:15:00+00	2015-02-24 21:15:00+00	2015-02-24 21:15:00+00	0	35.6	\N	\N	35.6	\N	\N	\N	\N	26	13	837
2016-02-22 16:30:00+00	2016-02-22 16:30:00+00	2016-02-22 16:30:00+00	0	32.24	\N	\N	32.24	\N	\N	\N	\N	26	13	839
2016-07-26 20:00:00+00	2016-07-26 20:00:00+00	2016-07-26 20:00:00+00	0	33.48	\N	\N	33.48	\N	\N	\N	\N	26	13	841
2017-03-29 21:50:00+00	2017-03-29 21:50:00+00	2017-03-29 21:50:00+00	0	34.08	\N	\N	34.08	\N	\N	\N	\N	26	13	843
2018-02-06 15:13:00+00	2018-02-06 15:13:00+00	2018-02-06 15:13:00+00	0	34.67	\N	\N	34.67	\N	\N	\N	\N	26	13	845
2018-12-19 20:37:00+00	2018-12-19 20:37:00+00	2018-12-19 20:37:00+00	0	35.39	\N	\N	35.39	\N	\N	\N	\N	26	13	847
2019-12-12 15:35:00+00	2019-12-12 15:35:00+00	2019-12-12 15:35:00+00	0	35.99	\N	\N	35.99	\N	\N	\N	\N	26	13	849
1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	894
1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	896
1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	898
1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	900
1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	902
1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	904
1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	906
1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	908
1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	910
1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	912
1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	914
1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	916
1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	918
1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	920
1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	922
1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	924
1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	926
1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	928
1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	930
1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	932
1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	934
1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	936
1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	938
1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	940
1998-06-28 00:00:00+00	1998-06-28 00:00:00+00	1998-06-28 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	942
1998-06-29 00:00:00+00	1998-06-29 00:00:00+00	1998-06-29 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	944
1998-06-30 00:00:00+00	1998-06-30 00:00:00+00	1998-06-30 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	946
1998-07-01 00:00:00+00	1998-07-01 00:00:00+00	1998-07-01 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	948
1998-07-02 00:00:00+00	1998-07-02 00:00:00+00	1998-07-02 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	950
1998-07-03 00:00:00+00	1998-07-03 00:00:00+00	1998-07-03 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	952
1998-07-04 00:00:00+00	1998-07-04 00:00:00+00	1998-07-04 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	954
1998-07-05 00:00:00+00	1998-07-05 00:00:00+00	1998-07-05 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	956
1998-07-06 00:00:00+00	1998-07-06 00:00:00+00	1998-07-06 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	958
1998-07-07 00:00:00+00	1998-07-07 00:00:00+00	1998-07-07 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	960
1998-07-08 00:00:00+00	1998-07-08 00:00:00+00	1998-07-08 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	962
1998-07-09 00:00:00+00	1998-07-09 00:00:00+00	1998-07-09 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	964
1998-07-10 00:00:00+00	1998-07-10 00:00:00+00	1998-07-10 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	966
1998-07-11 00:00:00+00	1998-07-11 00:00:00+00	1998-07-11 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	968
1998-07-12 00:00:00+00	1998-07-12 00:00:00+00	1998-07-12 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	970
1998-07-13 00:00:00+00	1998-07-13 00:00:00+00	1998-07-13 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	972
1998-07-14 00:00:00+00	1998-07-14 00:00:00+00	1998-07-14 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	974
1998-07-15 00:00:00+00	1998-07-15 00:00:00+00	1998-07-15 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	976
1998-07-16 00:00:00+00	1998-07-16 00:00:00+00	1998-07-16 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	978
1998-07-17 00:00:00+00	1998-07-17 00:00:00+00	1998-07-17 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	980
1998-07-18 00:00:00+00	1998-07-18 00:00:00+00	1998-07-18 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	982
1998-07-19 00:00:00+00	1998-07-19 00:00:00+00	1998-07-19 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	984
1998-07-20 00:00:00+00	1998-07-20 00:00:00+00	1998-07-20 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	986
1998-07-21 00:00:00+00	1998-07-21 00:00:00+00	1998-07-21 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	988
1998-07-22 00:00:00+00	1998-07-22 00:00:00+00	1998-07-22 00:00:00+00	0	4941	\N	\N	4941	\N	\N	\N	\N	29	15	990
1998-07-24 00:00:00+00	1998-07-24 00:00:00+00	1998-07-24 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	992
1998-07-25 00:00:00+00	1998-07-25 00:00:00+00	1998-07-25 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	994
1998-07-26 00:00:00+00	1998-07-26 00:00:00+00	1998-07-26 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	996
1998-07-27 00:00:00+00	1998-07-27 00:00:00+00	1998-07-27 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	998
1998-07-28 00:00:00+00	1998-07-28 00:00:00+00	1998-07-28 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1000
1998-07-29 00:00:00+00	1998-07-29 00:00:00+00	1998-07-29 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1002
1998-07-30 00:00:00+00	1998-07-30 00:00:00+00	1998-07-30 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1004
1998-07-31 00:00:00+00	1998-07-31 00:00:00+00	1998-07-31 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1006
1998-08-01 00:00:00+00	1998-08-01 00:00:00+00	1998-08-01 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1008
1998-08-02 00:00:00+00	1998-08-02 00:00:00+00	1998-08-02 00:00:00+00	0	4944	\N	\N	4944	\N	\N	\N	\N	29	15	1010
1998-08-03 00:00:00+00	1998-08-03 00:00:00+00	1998-08-03 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1012
1998-08-04 00:00:00+00	1998-08-04 00:00:00+00	1998-08-04 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1014
1998-08-05 00:00:00+00	1998-08-05 00:00:00+00	1998-08-05 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1016
1998-08-06 00:00:00+00	1998-08-06 00:00:00+00	1998-08-06 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1018
1998-08-07 00:00:00+00	1998-08-07 00:00:00+00	1998-08-07 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1020
1998-08-08 00:00:00+00	1998-08-08 00:00:00+00	1998-08-08 00:00:00+00	0	4943	\N	\N	4943	\N	\N	\N	\N	29	15	1022
1998-08-09 00:00:00+00	1998-08-09 00:00:00+00	1998-08-09 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1024
1998-08-10 00:00:00+00	1998-08-10 00:00:00+00	1998-08-10 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1026
1998-08-11 00:00:00+00	1998-08-11 00:00:00+00	1998-08-11 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1028
1998-08-12 00:00:00+00	1998-08-12 00:00:00+00	1998-08-12 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1030
1998-08-13 00:00:00+00	1998-08-13 00:00:00+00	1998-08-13 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1032
1998-08-14 00:00:00+00	1998-08-14 00:00:00+00	1998-08-14 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1034
1998-08-15 00:00:00+00	1998-08-15 00:00:00+00	1998-08-15 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1036
1998-08-16 00:00:00+00	1998-08-16 00:00:00+00	1998-08-16 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1038
1998-08-17 00:00:00+00	1998-08-17 00:00:00+00	1998-08-17 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1040
1998-08-18 00:00:00+00	1998-08-18 00:00:00+00	1998-08-18 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1042
1998-08-19 00:00:00+00	1998-08-19 00:00:00+00	1998-08-19 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1044
1998-08-20 00:00:00+00	1998-08-20 00:00:00+00	1998-08-20 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1046
1998-08-21 00:00:00+00	1998-08-21 00:00:00+00	1998-08-21 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1048
1998-08-22 00:00:00+00	1998-08-22 00:00:00+00	1998-08-22 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1050
1998-08-23 00:00:00+00	1998-08-23 00:00:00+00	1998-08-23 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1052
1998-08-24 00:00:00+00	1998-08-24 00:00:00+00	1998-08-24 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1054
1998-08-25 00:00:00+00	1998-08-25 00:00:00+00	1998-08-25 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1056
1998-08-26 00:00:00+00	1998-08-26 00:00:00+00	1998-08-26 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1058
1998-08-27 00:00:00+00	1998-08-27 00:00:00+00	1998-08-27 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1060
1998-08-28 00:00:00+00	1998-08-28 00:00:00+00	1998-08-28 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1062
1998-08-29 00:00:00+00	1998-08-29 00:00:00+00	1998-08-29 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1064
1998-08-30 00:00:00+00	1998-08-30 00:00:00+00	1998-08-30 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1066
1998-08-31 00:00:00+00	1998-08-31 00:00:00+00	1998-08-31 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1068
1998-09-01 00:00:00+00	1998-09-01 00:00:00+00	1998-09-01 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1070
1998-09-02 00:00:00+00	1998-09-02 00:00:00+00	1998-09-02 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1072
1998-09-03 00:00:00+00	1998-09-03 00:00:00+00	1998-09-03 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1074
1998-09-04 00:00:00+00	1998-09-04 00:00:00+00	1998-09-04 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1076
1998-09-05 00:00:00+00	1998-09-05 00:00:00+00	1998-09-05 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1078
1998-09-06 00:00:00+00	1998-09-06 00:00:00+00	1998-09-06 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1080
1998-09-07 00:00:00+00	1998-09-07 00:00:00+00	1998-09-07 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1082
1998-09-08 00:00:00+00	1998-09-08 00:00:00+00	1998-09-08 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1084
1998-09-09 00:00:00+00	1998-09-09 00:00:00+00	1998-09-09 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1086
1998-09-10 00:00:00+00	1998-09-10 00:00:00+00	1998-09-10 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1088
1998-09-11 00:00:00+00	1998-09-11 00:00:00+00	1998-09-11 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1090
1998-09-12 00:00:00+00	1998-09-12 00:00:00+00	1998-09-12 00:00:00+00	0	4942	\N	\N	4942	\N	\N	\N	\N	29	15	1092
1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	1998-06-04 00:00:00+00	0	493.64	\N	\N	493.64	\N	\N	\N	\N	30	15	893
1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	1998-06-05 00:00:00+00	0	493.67	\N	\N	493.67	\N	\N	\N	\N	30	15	895
1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	1998-06-06 00:00:00+00	0	493.78	\N	\N	493.78	\N	\N	\N	\N	30	15	897
1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	1998-06-07 00:00:00+00	0	493.71	\N	\N	493.71	\N	\N	\N	\N	30	15	899
1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	1998-06-08 00:00:00+00	0	493.75	\N	\N	493.75	\N	\N	\N	\N	30	15	901
1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	1998-06-09 00:00:00+00	0	493.78	\N	\N	493.78	\N	\N	\N	\N	30	15	903
1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	1998-06-10 00:00:00+00	0	493.89	\N	\N	493.89	\N	\N	\N	\N	30	15	905
1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	1998-06-11 00:00:00+00	0	493.84	\N	\N	493.84	\N	\N	\N	\N	30	15	907
1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	1998-06-12 00:00:00+00	0	493.95	\N	\N	493.95	\N	\N	\N	\N	30	15	909
1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	1998-06-13 00:00:00+00	0	493.97	\N	\N	493.97	\N	\N	\N	\N	30	15	911
1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	1998-06-14 00:00:00+00	0	493.91	\N	\N	493.91	\N	\N	\N	\N	30	15	913
1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	1998-06-15 00:00:00+00	0	493.93	\N	\N	493.93	\N	\N	\N	\N	30	15	915
1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	1998-06-16 00:00:00+00	0	493.96	\N	\N	493.96	\N	\N	\N	\N	30	15	917
1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	1998-06-17 00:00:00+00	0	494	\N	\N	494	\N	\N	\N	\N	30	15	919
1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	1998-06-18 00:00:00+00	0	494.13	\N	\N	494.13	\N	\N	\N	\N	30	15	921
1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	1998-06-19 00:00:00+00	0	494.24	\N	\N	494.24	\N	\N	\N	\N	30	15	923
1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	1998-06-20 00:00:00+00	0	494.27	\N	\N	494.27	\N	\N	\N	\N	30	15	925
1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	1998-06-21 00:00:00+00	0	494.3	\N	\N	494.3	\N	\N	\N	\N	30	15	927
1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	1998-06-22 00:00:00+00	0	494.34	\N	\N	494.34	\N	\N	\N	\N	30	15	929
1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	1998-06-23 00:00:00+00	0	494.46	\N	\N	494.46	\N	\N	\N	\N	30	15	931
1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	1998-06-24 00:00:00+00	0	494.5	\N	\N	494.5	\N	\N	\N	\N	30	15	933
1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	1998-06-25 00:00:00+00	0	494.53	\N	\N	494.53	\N	\N	\N	\N	30	15	935
1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	1998-06-26 00:00:00+00	0	494.64	\N	\N	494.64	\N	\N	\N	\N	30	15	937
1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	1998-06-27 00:00:00+00	0	494.68	\N	\N	494.68	\N	\N	\N	\N	30	15	939
1998-06-28 00:00:00+00	1998-06-28 00:00:00+00	1998-06-28 00:00:00+00	0	494.71	\N	\N	494.71	\N	\N	\N	\N	30	15	941
1998-06-29 00:00:00+00	1998-06-29 00:00:00+00	1998-06-29 00:00:00+00	0	494.94	\N	\N	494.94	\N	\N	\N	\N	30	15	943
1998-06-30 00:00:00+00	1998-06-30 00:00:00+00	1998-06-30 00:00:00+00	0	494.97	\N	\N	494.97	\N	\N	\N	\N	30	15	945
1998-07-01 00:00:00+00	1998-07-01 00:00:00+00	1998-07-01 00:00:00+00	0	495.1	\N	\N	495.1	\N	\N	\N	\N	30	15	947
1998-07-02 00:00:00+00	1998-07-02 00:00:00+00	1998-07-02 00:00:00+00	0	495.22	\N	\N	495.22	\N	\N	\N	\N	30	15	949
1998-07-03 00:00:00+00	1998-07-03 00:00:00+00	1998-07-03 00:00:00+00	0	495.45	\N	\N	495.45	\N	\N	\N	\N	30	15	951
1998-07-04 00:00:00+00	1998-07-04 00:00:00+00	1998-07-04 00:00:00+00	0	495.48	\N	\N	495.48	\N	\N	\N	\N	30	15	953
1998-07-05 00:00:00+00	1998-07-05 00:00:00+00	1998-07-05 00:00:00+00	0	495.51	\N	\N	495.51	\N	\N	\N	\N	30	15	955
1998-07-06 00:00:00+00	1998-07-06 00:00:00+00	1998-07-06 00:00:00+00	0	495.64	\N	\N	495.64	\N	\N	\N	\N	30	15	957
1998-07-07 00:00:00+00	1998-07-07 00:00:00+00	1998-07-07 00:00:00+00	0	495.67	\N	\N	495.67	\N	\N	\N	\N	30	15	959
1998-07-08 00:00:00+00	1998-07-08 00:00:00+00	1998-07-08 00:00:00+00	0	495.79	\N	\N	495.79	\N	\N	\N	\N	30	15	961
1998-07-09 00:00:00+00	1998-07-09 00:00:00+00	1998-07-09 00:00:00+00	0	495.82	\N	\N	495.82	\N	\N	\N	\N	30	15	963
1998-07-10 00:00:00+00	1998-07-10 00:00:00+00	1998-07-10 00:00:00+00	0	495.84	\N	\N	495.84	\N	\N	\N	\N	30	15	965
1998-07-11 00:00:00+00	1998-07-11 00:00:00+00	1998-07-11 00:00:00+00	0	495.87	\N	\N	495.87	\N	\N	\N	\N	30	15	967
1998-07-12 00:00:00+00	1998-07-12 00:00:00+00	1998-07-12 00:00:00+00	0	495.91	\N	\N	495.91	\N	\N	\N	\N	30	15	969
1998-07-13 00:00:00+00	1998-07-13 00:00:00+00	1998-07-13 00:00:00+00	0	495.93	\N	\N	495.93	\N	\N	\N	\N	30	15	971
1998-07-14 00:00:00+00	1998-07-14 00:00:00+00	1998-07-14 00:00:00+00	0	495.94	\N	\N	495.94	\N	\N	\N	\N	30	15	973
1998-07-15 00:00:00+00	1998-07-15 00:00:00+00	1998-07-15 00:00:00+00	0	495.99	\N	\N	495.99	\N	\N	\N	\N	30	15	975
1998-07-16 00:00:00+00	1998-07-16 00:00:00+00	1998-07-16 00:00:00+00	0	496.02	\N	\N	496.02	\N	\N	\N	\N	30	15	977
1998-07-17 00:00:00+00	1998-07-17 00:00:00+00	1998-07-17 00:00:00+00	0	496.03	\N	\N	496.03	\N	\N	\N	\N	30	15	979
1998-07-18 00:00:00+00	1998-07-18 00:00:00+00	1998-07-18 00:00:00+00	0	495.96	\N	\N	495.96	\N	\N	\N	\N	30	15	981
1998-07-19 00:00:00+00	1998-07-19 00:00:00+00	1998-07-19 00:00:00+00	0	495.78	\N	\N	495.78	\N	\N	\N	\N	30	15	983
1998-07-20 00:00:00+00	1998-07-20 00:00:00+00	1998-07-20 00:00:00+00	0	495.63	\N	\N	495.63	\N	\N	\N	\N	30	15	985
1998-07-21 00:00:00+00	1998-07-21 00:00:00+00	1998-07-21 00:00:00+00	0	495.64	\N	\N	495.64	\N	\N	\N	\N	30	15	987
1998-07-22 00:00:00+00	1998-07-22 00:00:00+00	1998-07-22 00:00:00+00	0	495.57	\N	\N	495.57	\N	\N	\N	\N	30	15	989
1998-07-24 00:00:00+00	1998-07-24 00:00:00+00	1998-07-24 00:00:00+00	0	495.22	\N	\N	495.22	\N	\N	\N	\N	30	15	991
1998-07-25 00:00:00+00	1998-07-25 00:00:00+00	1998-07-25 00:00:00+00	0	494.64	\N	\N	494.64	\N	\N	\N	\N	30	15	993
1998-07-26 00:00:00+00	1998-07-26 00:00:00+00	1998-07-26 00:00:00+00	0	494.27	\N	\N	494.27	\N	\N	\N	\N	30	15	995
1998-07-27 00:00:00+00	1998-07-27 00:00:00+00	1998-07-27 00:00:00+00	0	493.5	\N	\N	493.5	\N	\N	\N	\N	30	15	997
1998-07-28 00:00:00+00	1998-07-28 00:00:00+00	1998-07-28 00:00:00+00	0	493.03	\N	\N	493.03	\N	\N	\N	\N	30	15	999
1998-07-29 00:00:00+00	1998-07-29 00:00:00+00	1998-07-29 00:00:00+00	0	492.86	\N	\N	492.86	\N	\N	\N	\N	30	15	1001
1998-07-30 00:00:00+00	1998-07-30 00:00:00+00	1998-07-30 00:00:00+00	0	492.78	\N	\N	492.78	\N	\N	\N	\N	30	15	1003
1998-07-31 00:00:00+00	1998-07-31 00:00:00+00	1998-07-31 00:00:00+00	0	492.91	\N	\N	492.91	\N	\N	\N	\N	30	15	1005
1998-08-01 00:00:00+00	1998-08-01 00:00:00+00	1998-08-01 00:00:00+00	0	493.16	\N	\N	493.16	\N	\N	\N	\N	30	15	1007
1998-08-02 00:00:00+00	1998-08-02 00:00:00+00	1998-08-02 00:00:00+00	0	493.34	\N	\N	493.34	\N	\N	\N	\N	30	15	1009
1998-08-03 00:00:00+00	1998-08-03 00:00:00+00	1998-08-03 00:00:00+00	0	493.54	\N	\N	493.54	\N	\N	\N	\N	30	15	1011
1998-08-04 00:00:00+00	1998-08-04 00:00:00+00	1998-08-04 00:00:00+00	0	493.74	\N	\N	493.74	\N	\N	\N	\N	30	15	1013
1998-08-05 00:00:00+00	1998-08-05 00:00:00+00	1998-08-05 00:00:00+00	0	493.92	\N	\N	493.92	\N	\N	\N	\N	30	15	1015
1998-08-06 00:00:00+00	1998-08-06 00:00:00+00	1998-08-06 00:00:00+00	0	494.06	\N	\N	494.06	\N	\N	\N	\N	30	15	1017
1998-08-07 00:00:00+00	1998-08-07 00:00:00+00	1998-08-07 00:00:00+00	0	494.19	\N	\N	494.19	\N	\N	\N	\N	30	15	1019
1998-08-08 00:00:00+00	1998-08-08 00:00:00+00	1998-08-08 00:00:00+00	0	494.34	\N	\N	494.34	\N	\N	\N	\N	30	15	1021
1998-08-09 00:00:00+00	1998-08-09 00:00:00+00	1998-08-09 00:00:00+00	0	494.51	\N	\N	494.51	\N	\N	\N	\N	30	15	1023
1998-08-10 00:00:00+00	1998-08-10 00:00:00+00	1998-08-10 00:00:00+00	0	494.64	\N	\N	494.64	\N	\N	\N	\N	30	15	1025
1998-08-11 00:00:00+00	1998-08-11 00:00:00+00	1998-08-11 00:00:00+00	0	494.71	\N	\N	494.71	\N	\N	\N	\N	30	15	1027
1998-08-12 00:00:00+00	1998-08-12 00:00:00+00	1998-08-12 00:00:00+00	0	494.86	\N	\N	494.86	\N	\N	\N	\N	30	15	1029
1998-08-13 00:00:00+00	1998-08-13 00:00:00+00	1998-08-13 00:00:00+00	0	494.95	\N	\N	494.95	\N	\N	\N	\N	30	15	1031
1998-08-14 00:00:00+00	1998-08-14 00:00:00+00	1998-08-14 00:00:00+00	0	494.98	\N	\N	494.98	\N	\N	\N	\N	30	15	1033
1998-08-15 00:00:00+00	1998-08-15 00:00:00+00	1998-08-15 00:00:00+00	0	495.01	\N	\N	495.01	\N	\N	\N	\N	30	15	1035
1998-08-16 00:00:00+00	1998-08-16 00:00:00+00	1998-08-16 00:00:00+00	0	495.04	\N	\N	495.04	\N	\N	\N	\N	30	15	1037
1998-08-17 00:00:00+00	1998-08-17 00:00:00+00	1998-08-17 00:00:00+00	0	495.1	\N	\N	495.1	\N	\N	\N	\N	30	15	1039
1998-08-18 00:00:00+00	1998-08-18 00:00:00+00	1998-08-18 00:00:00+00	0	495.19	\N	\N	495.19	\N	\N	\N	\N	30	15	1041
1998-08-19 00:00:00+00	1998-08-19 00:00:00+00	1998-08-19 00:00:00+00	0	495.35	\N	\N	495.35	\N	\N	\N	\N	30	15	1043
1998-08-20 00:00:00+00	1998-08-20 00:00:00+00	1998-08-20 00:00:00+00	0	495.4	\N	\N	495.4	\N	\N	\N	\N	30	15	1045
1998-08-21 00:00:00+00	1998-08-21 00:00:00+00	1998-08-21 00:00:00+00	0	495.41	\N	\N	495.41	\N	\N	\N	\N	30	15	1047
1998-08-22 00:00:00+00	1998-08-22 00:00:00+00	1998-08-22 00:00:00+00	0	495.41	\N	\N	495.41	\N	\N	\N	\N	30	15	1049
1998-08-23 00:00:00+00	1998-08-23 00:00:00+00	1998-08-23 00:00:00+00	0	495.35	\N	\N	495.35	\N	\N	\N	\N	30	15	1051
1998-08-24 00:00:00+00	1998-08-24 00:00:00+00	1998-08-24 00:00:00+00	0	495.26	\N	\N	495.26	\N	\N	\N	\N	30	15	1053
1998-08-25 00:00:00+00	1998-08-25 00:00:00+00	1998-08-25 00:00:00+00	0	495.24	\N	\N	495.24	\N	\N	\N	\N	30	15	1055
1998-08-26 00:00:00+00	1998-08-26 00:00:00+00	1998-08-26 00:00:00+00	0	495.18	\N	\N	495.18	\N	\N	\N	\N	30	15	1057
1998-08-27 00:00:00+00	1998-08-27 00:00:00+00	1998-08-27 00:00:00+00	0	495.09	\N	\N	495.09	\N	\N	\N	\N	30	15	1059
1998-08-28 00:00:00+00	1998-08-28 00:00:00+00	1998-08-28 00:00:00+00	0	495.1	\N	\N	495.1	\N	\N	\N	\N	30	15	1061
1998-08-29 00:00:00+00	1998-08-29 00:00:00+00	1998-08-29 00:00:00+00	0	495.13	\N	\N	495.13	\N	\N	\N	\N	30	15	1063
1998-08-30 00:00:00+00	1998-08-30 00:00:00+00	1998-08-30 00:00:00+00	0	495.09	\N	\N	495.09	\N	\N	\N	\N	30	15	1065
1998-08-31 00:00:00+00	1998-08-31 00:00:00+00	1998-08-31 00:00:00+00	0	495.04	\N	\N	495.04	\N	\N	\N	\N	30	15	1067
1998-09-01 00:00:00+00	1998-09-01 00:00:00+00	1998-09-01 00:00:00+00	0	495.01	\N	\N	495.01	\N	\N	\N	\N	30	15	1069
1998-09-02 00:00:00+00	1998-09-02 00:00:00+00	1998-09-02 00:00:00+00	0	494.98	\N	\N	494.98	\N	\N	\N	\N	30	15	1071
1998-09-03 00:00:00+00	1998-09-03 00:00:00+00	1998-09-03 00:00:00+00	0	494.97	\N	\N	494.97	\N	\N	\N	\N	30	15	1073
1998-09-04 00:00:00+00	1998-09-04 00:00:00+00	1998-09-04 00:00:00+00	0	495.01	\N	\N	495.01	\N	\N	\N	\N	30	15	1075
1998-09-05 00:00:00+00	1998-09-05 00:00:00+00	1998-09-05 00:00:00+00	0	495.03	\N	\N	495.03	\N	\N	\N	\N	30	15	1077
1998-09-06 00:00:00+00	1998-09-06 00:00:00+00	1998-09-06 00:00:00+00	0	495.03	\N	\N	495.03	\N	\N	\N	\N	30	15	1079
1998-09-07 00:00:00+00	1998-09-07 00:00:00+00	1998-09-07 00:00:00+00	0	495	\N	\N	495	\N	\N	\N	\N	30	15	1081
1998-09-08 00:00:00+00	1998-09-08 00:00:00+00	1998-09-08 00:00:00+00	0	494.96	\N	\N	494.96	\N	\N	\N	\N	30	15	1083
1998-09-09 00:00:00+00	1998-09-09 00:00:00+00	1998-09-09 00:00:00+00	0	494.91	\N	\N	494.91	\N	\N	\N	\N	30	15	1085
1998-09-10 00:00:00+00	1998-09-10 00:00:00+00	1998-09-10 00:00:00+00	0	494.93	\N	\N	494.93	\N	\N	\N	\N	30	15	1087
1998-09-11 00:00:00+00	1998-09-11 00:00:00+00	1998-09-11 00:00:00+00	0	494.95	\N	\N	494.95	\N	\N	\N	\N	30	15	1089
1998-09-12 00:00:00+00	1998-09-12 00:00:00+00	1998-09-12 00:00:00+00	0	495	\N	\N	495	\N	\N	\N	\N	30	15	1091
1999-09-21 00:00:00+00	1999-09-21 00:00:00+00	1999-09-21 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15676
1999-09-22 00:00:00+00	1999-09-22 00:00:00+00	1999-09-22 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15678
1999-09-23 00:00:00+00	1999-09-23 00:00:00+00	1999-09-23 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15680
1999-09-24 00:00:00+00	1999-09-24 00:00:00+00	1999-09-24 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15682
1999-09-25 00:00:00+00	1999-09-25 00:00:00+00	1999-09-25 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15684
1999-09-26 00:00:00+00	1999-09-26 00:00:00+00	1999-09-26 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15686
1999-09-27 00:00:00+00	1999-09-27 00:00:00+00	1999-09-27 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15688
1999-09-28 00:00:00+00	1999-09-28 00:00:00+00	1999-09-28 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15690
1999-09-29 00:00:00+00	1999-09-29 00:00:00+00	1999-09-29 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15692
1999-09-30 00:00:00+00	1999-09-30 00:00:00+00	1999-09-30 00:00:00+00	0	5015	\N	\N	5015	\N	\N	\N	\N	31	16	15694
1999-10-01 00:00:00+00	1999-10-01 00:00:00+00	1999-10-01 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15696
1999-10-02 00:00:00+00	1999-10-02 00:00:00+00	1999-10-02 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15698
1999-10-03 00:00:00+00	1999-10-03 00:00:00+00	1999-10-03 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15700
1999-10-04 00:00:00+00	1999-10-04 00:00:00+00	1999-10-04 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15702
1999-10-05 00:00:00+00	1999-10-05 00:00:00+00	1999-10-05 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15704
1999-10-06 00:00:00+00	1999-10-06 00:00:00+00	1999-10-06 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15706
1999-10-07 00:00:00+00	1999-10-07 00:00:00+00	1999-10-07 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15708
1999-10-08 00:00:00+00	1999-10-08 00:00:00+00	1999-10-08 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15710
1999-10-09 00:00:00+00	1999-10-09 00:00:00+00	1999-10-09 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15712
1999-10-10 00:00:00+00	1999-10-10 00:00:00+00	1999-10-10 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15714
1999-10-11 00:00:00+00	1999-10-11 00:00:00+00	1999-10-11 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15716
1999-10-12 00:00:00+00	1999-10-12 00:00:00+00	1999-10-12 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15718
1999-10-13 00:00:00+00	1999-10-13 00:00:00+00	1999-10-13 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15720
1999-10-14 00:00:00+00	1999-10-14 00:00:00+00	1999-10-14 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15722
1999-10-15 00:00:00+00	1999-10-15 00:00:00+00	1999-10-15 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15724
1999-10-16 00:00:00+00	1999-10-16 00:00:00+00	1999-10-16 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15726
1999-10-17 00:00:00+00	1999-10-17 00:00:00+00	1999-10-17 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15728
1999-10-18 00:00:00+00	1999-10-18 00:00:00+00	1999-10-18 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15730
1999-10-19 00:00:00+00	1999-10-19 00:00:00+00	1999-10-19 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15732
1999-10-20 00:00:00+00	1999-10-20 00:00:00+00	1999-10-20 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15734
1999-10-21 00:00:00+00	1999-10-21 00:00:00+00	1999-10-21 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15736
1999-10-22 00:00:00+00	1999-10-22 00:00:00+00	1999-10-22 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15738
1999-10-23 00:00:00+00	1999-10-23 00:00:00+00	1999-10-23 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15740
1999-10-24 00:00:00+00	1999-10-24 00:00:00+00	1999-10-24 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15742
1999-10-25 00:00:00+00	1999-10-25 00:00:00+00	1999-10-25 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15744
1999-10-26 00:00:00+00	1999-10-26 00:00:00+00	1999-10-26 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15746
1999-10-27 00:00:00+00	1999-10-27 00:00:00+00	1999-10-27 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15748
1999-10-28 00:00:00+00	1999-10-28 00:00:00+00	1999-10-28 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15750
1999-10-29 00:00:00+00	1999-10-29 00:00:00+00	1999-10-29 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15752
1999-10-30 00:00:00+00	1999-10-30 00:00:00+00	1999-10-30 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15754
1999-10-31 00:00:00+00	1999-10-31 00:00:00+00	1999-10-31 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15756
1999-11-01 00:00:00+00	1999-11-01 00:00:00+00	1999-11-01 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15758
1999-11-02 00:00:00+00	1999-11-02 00:00:00+00	1999-11-02 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15760
1999-11-03 00:00:00+00	1999-11-03 00:00:00+00	1999-11-03 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15762
1999-11-04 00:00:00+00	1999-11-04 00:00:00+00	1999-11-04 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15764
1999-11-05 00:00:00+00	1999-11-05 00:00:00+00	1999-11-05 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15766
1999-11-06 00:00:00+00	1999-11-06 00:00:00+00	1999-11-06 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15768
1999-11-07 00:00:00+00	1999-11-07 00:00:00+00	1999-11-07 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15770
1999-11-08 00:00:00+00	1999-11-08 00:00:00+00	1999-11-08 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15772
1999-11-09 00:00:00+00	1999-11-09 00:00:00+00	1999-11-09 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15774
1999-11-10 00:00:00+00	1999-11-10 00:00:00+00	1999-11-10 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15776
1999-11-11 00:00:00+00	1999-11-11 00:00:00+00	1999-11-11 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15778
1999-11-12 00:00:00+00	1999-11-12 00:00:00+00	1999-11-12 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15780
1999-11-13 00:00:00+00	1999-11-13 00:00:00+00	1999-11-13 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15782
1999-11-14 00:00:00+00	1999-11-14 00:00:00+00	1999-11-14 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15784
1999-11-15 00:00:00+00	1999-11-15 00:00:00+00	1999-11-15 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15786
1999-11-16 00:00:00+00	1999-11-16 00:00:00+00	1999-11-16 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15788
1999-11-17 00:00:00+00	1999-11-17 00:00:00+00	1999-11-17 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15790
1999-11-18 00:00:00+00	1999-11-18 00:00:00+00	1999-11-18 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15792
1999-11-19 00:00:00+00	1999-11-19 00:00:00+00	1999-11-19 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15794
1999-11-20 00:00:00+00	1999-11-20 00:00:00+00	1999-11-20 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15796
1999-11-21 00:00:00+00	1999-11-21 00:00:00+00	1999-11-21 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15798
1999-11-22 00:00:00+00	1999-11-22 00:00:00+00	1999-11-22 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15800
1999-11-23 00:00:00+00	1999-11-23 00:00:00+00	1999-11-23 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15802
1999-11-24 00:00:00+00	1999-11-24 00:00:00+00	1999-11-24 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15804
1999-11-25 00:00:00+00	1999-11-25 00:00:00+00	1999-11-25 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15806
1999-11-26 00:00:00+00	1999-11-26 00:00:00+00	1999-11-26 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15808
1999-11-27 00:00:00+00	1999-11-27 00:00:00+00	1999-11-27 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15810
1999-11-28 00:00:00+00	1999-11-28 00:00:00+00	1999-11-28 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15812
1999-11-29 00:00:00+00	1999-11-29 00:00:00+00	1999-11-29 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15814
1999-11-30 00:00:00+00	1999-11-30 00:00:00+00	1999-11-30 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15816
1999-12-01 00:00:00+00	1999-12-01 00:00:00+00	1999-12-01 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15818
1999-12-02 00:00:00+00	1999-12-02 00:00:00+00	1999-12-02 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15820
1999-12-03 00:00:00+00	1999-12-03 00:00:00+00	1999-12-03 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15822
1999-12-04 00:00:00+00	1999-12-04 00:00:00+00	1999-12-04 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15824
1999-12-05 00:00:00+00	1999-12-05 00:00:00+00	1999-12-05 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15826
1999-12-06 00:00:00+00	1999-12-06 00:00:00+00	1999-12-06 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15828
1999-12-07 00:00:00+00	1999-12-07 00:00:00+00	1999-12-07 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15830
1999-12-08 00:00:00+00	1999-12-08 00:00:00+00	1999-12-08 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15832
1999-12-09 00:00:00+00	1999-12-09 00:00:00+00	1999-12-09 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15834
1999-12-10 00:00:00+00	1999-12-10 00:00:00+00	1999-12-10 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15836
1999-12-11 00:00:00+00	1999-12-11 00:00:00+00	1999-12-11 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15838
1999-12-12 00:00:00+00	1999-12-12 00:00:00+00	1999-12-12 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15840
1999-12-13 00:00:00+00	1999-12-13 00:00:00+00	1999-12-13 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15842
1999-12-14 00:00:00+00	1999-12-14 00:00:00+00	1999-12-14 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15844
1999-12-15 00:00:00+00	1999-12-15 00:00:00+00	1999-12-15 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15846
1999-12-16 00:00:00+00	1999-12-16 00:00:00+00	1999-12-16 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15848
1999-12-17 00:00:00+00	1999-12-17 00:00:00+00	1999-12-17 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15850
1999-12-18 00:00:00+00	1999-12-18 00:00:00+00	1999-12-18 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15852
1999-12-19 00:00:00+00	1999-12-19 00:00:00+00	1999-12-19 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15854
1999-12-20 00:00:00+00	1999-12-20 00:00:00+00	1999-12-20 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15856
1999-12-21 00:00:00+00	1999-12-21 00:00:00+00	1999-12-21 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15858
1999-12-22 00:00:00+00	1999-12-22 00:00:00+00	1999-12-22 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15860
1999-12-23 00:00:00+00	1999-12-23 00:00:00+00	1999-12-23 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15862
1999-12-24 00:00:00+00	1999-12-24 00:00:00+00	1999-12-24 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15864
1999-12-25 00:00:00+00	1999-12-25 00:00:00+00	1999-12-25 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15866
1999-12-26 00:00:00+00	1999-12-26 00:00:00+00	1999-12-26 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15868
1999-12-27 00:00:00+00	1999-12-27 00:00:00+00	1999-12-27 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15870
1999-12-28 00:00:00+00	1999-12-28 00:00:00+00	1999-12-28 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15872
1999-12-29 00:00:00+00	1999-12-29 00:00:00+00	1999-12-29 00:00:00+00	0	5016	\N	\N	5016	\N	\N	\N	\N	31	16	15874
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	194.22	\N	\N	194.22	\N	\N	\N	\N	70	35	111369
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	194.18	\N	\N	194.18	\N	\N	\N	\N	70	35	111371
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	194.17	\N	\N	194.17	\N	\N	\N	\N	70	35	111373
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	194.13	\N	\N	194.13	\N	\N	\N	\N	70	35	111375
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	194.18	\N	\N	194.18	\N	\N	\N	\N	70	35	111377
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	194.18	\N	\N	194.18	\N	\N	\N	\N	70	35	111379
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	194.19	\N	\N	194.19	\N	\N	\N	\N	70	35	111381
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	194.17	\N	\N	194.17	\N	\N	\N	\N	70	35	111383
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	194.12	\N	\N	194.12	\N	\N	\N	\N	70	35	111385
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	194.13	\N	\N	194.13	\N	\N	\N	\N	70	35	111387
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	194.16	\N	\N	194.16	\N	\N	\N	\N	70	35	111389
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	194.16	\N	\N	194.16	\N	\N	\N	\N	70	35	111391
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	194.11	\N	\N	194.11	\N	\N	\N	\N	70	35	111393
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	194.05	\N	\N	194.05	\N	\N	\N	\N	70	35	111395
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	194.06	\N	\N	194.06	\N	\N	\N	\N	70	35	111397
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	194.11	\N	\N	194.11	\N	\N	\N	\N	70	35	111399
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	194.12	\N	\N	194.12	\N	\N	\N	\N	70	35	111401
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	194.12	\N	\N	194.12	\N	\N	\N	\N	70	35	111403
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	194.14	\N	\N	194.14	\N	\N	\N	\N	70	35	111405
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	194.18	\N	\N	194.18	\N	\N	\N	\N	70	35	111407
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	194.18	\N	\N	194.18	\N	\N	\N	\N	70	35	111409
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	194.16	\N	\N	194.16	\N	\N	\N	\N	70	35	111411
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	194.12	\N	\N	194.12	\N	\N	\N	\N	70	35	111413
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	194.07	\N	\N	194.07	\N	\N	\N	\N	70	35	111415
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	194.01	\N	\N	194.01	\N	\N	\N	\N	70	35	111417
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	194.03	\N	\N	194.03	\N	\N	\N	\N	70	35	111419
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111421
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111423
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111425
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111427
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111429
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111431
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111433
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111435
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111437
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	193.86	\N	\N	193.86	\N	\N	\N	\N	70	35	111439
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	193.89	\N	\N	193.89	\N	\N	\N	\N	70	35	111441
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111443
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	193.84	\N	\N	193.84	\N	\N	\N	\N	70	35	111445
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111447
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111449
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111451
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111453
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111455
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111457
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111459
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111461
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111463
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111465
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111467
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111469
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111471
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111473
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111475
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111477
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111479
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111481
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	70	35	111483
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	70	35	111485
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	193.98	\N	\N	193.98	\N	\N	\N	\N	70	35	111487
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	193.98	\N	\N	193.98	\N	\N	\N	\N	70	35	111489
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111491
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111493
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	193.88	\N	\N	193.88	\N	\N	\N	\N	70	35	111495
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	193.86	\N	\N	193.86	\N	\N	\N	\N	70	35	111497
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	193.83	\N	\N	193.83	\N	\N	\N	\N	70	35	111499
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111501
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111503
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111505
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111507
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111509
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	193.99	\N	\N	193.99	\N	\N	\N	\N	70	35	111511
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	194.03	\N	\N	194.03	\N	\N	\N	\N	70	35	111513
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	194.01	\N	\N	194.01	\N	\N	\N	\N	70	35	111515
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	194.01	\N	\N	194.01	\N	\N	\N	\N	70	35	111517
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	194.03	\N	\N	194.03	\N	\N	\N	\N	70	35	111519
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	194.03	\N	\N	194.03	\N	\N	\N	\N	70	35	111521
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111523
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	193.89	\N	\N	193.89	\N	\N	\N	\N	70	35	111525
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	193.86	\N	\N	193.86	\N	\N	\N	\N	70	35	111527
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	193.92	\N	\N	193.92	\N	\N	\N	\N	70	35	111529
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	70	35	111531
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	193.9	\N	\N	193.9	\N	\N	\N	\N	70	35	111533
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111535
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111537
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111539
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	193.94	\N	\N	193.94	\N	\N	\N	\N	70	35	111541
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111543
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	193.95	\N	\N	193.95	\N	\N	\N	\N	70	35	111545
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	70	35	111547
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	193.93	\N	\N	193.93	\N	\N	\N	\N	70	35	111549
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111551
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	193.91	\N	\N	193.91	\N	\N	\N	\N	70	35	111553
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111555
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	193.98	\N	\N	193.98	\N	\N	\N	\N	70	35	111557
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	193.99	\N	\N	193.99	\N	\N	\N	\N	70	35	111559
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	193.98	\N	\N	193.98	\N	\N	\N	\N	70	35	111561
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	193.96	\N	\N	193.96	\N	\N	\N	\N	70	35	111563
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	193.97	\N	\N	193.97	\N	\N	\N	\N	70	35	111565
1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	1999-01-09 00:00:00+00	0	193.99	\N	\N	193.99	\N	\N	\N	\N	70	35	111567
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142610
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142612
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142614
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142616
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142618
1998-10-06 00:00:00+00	1998-10-06 00:00:00+00	1998-10-06 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142620
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	4873	\N	\N	4873	\N	\N	\N	\N	73	37	142622
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142624
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142626
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142628
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142630
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142632
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142634
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142636
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142638
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142640
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142642
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142644
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	4874	\N	\N	4874	\N	\N	\N	\N	73	37	142646
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142648
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142650
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142652
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142654
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142656
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142658
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	4875	\N	\N	4875	\N	\N	\N	\N	73	37	142660
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	4876	\N	\N	4876	\N	\N	\N	\N	73	37	142662
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	4876	\N	\N	4876	\N	\N	\N	\N	73	37	142664
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	4876	\N	\N	4876	\N	\N	\N	\N	73	37	142666
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	4876	\N	\N	4876	\N	\N	\N	\N	73	37	142668
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	4876	\N	\N	4876	\N	\N	\N	\N	73	37	142670
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	4877	\N	\N	4877	\N	\N	\N	\N	73	37	142672
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	4877	\N	\N	4877	\N	\N	\N	\N	73	37	142674
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	4877	\N	\N	4877	\N	\N	\N	\N	73	37	142676
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	4877	\N	\N	4877	\N	\N	\N	\N	73	37	142678
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	4877	\N	\N	4877	\N	\N	\N	\N	73	37	142680
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142682
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142684
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142686
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142688
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142690
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142692
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142694
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142696
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142698
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	4878	\N	\N	4878	\N	\N	\N	\N	73	37	142700
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142702
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142704
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142706
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142708
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142710
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142712
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142714
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142716
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142718
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142720
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142722
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142724
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142726
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142728
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142730
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142732
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142734
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142736
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142738
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142740
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142742
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142744
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142746
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142748
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142750
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142752
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142754
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142756
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142758
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142760
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	4879	\N	\N	4879	\N	\N	\N	\N	73	37	142762
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142764
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142766
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142768
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142770
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142772
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142774
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142776
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142778
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142780
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142782
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142784
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142786
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142788
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142790
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142792
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142794
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142796
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142798
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142800
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142802
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142804
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142806
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	4880	\N	\N	4880	\N	\N	\N	\N	73	37	142808
1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	1998-10-01 00:00:00+00	0	221.22	\N	\N	221.22	\N	\N	\N	\N	74	37	142609
1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	1998-10-02 00:00:00+00	0	221.11	\N	\N	221.11	\N	\N	\N	\N	74	37	142611
1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	1998-10-03 00:00:00+00	0	220.99	\N	\N	220.99	\N	\N	\N	\N	74	37	142613
1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	1998-10-04 00:00:00+00	0	220.83	\N	\N	220.83	\N	\N	\N	\N	74	37	142615
1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	1998-10-05 00:00:00+00	0	220.63	\N	\N	220.63	\N	\N	\N	\N	74	37	142617
1998-10-06 00:00:00+00	1998-10-06 00:00:00+00	1998-10-06 00:00:00+00	0	220.56	\N	\N	220.56	\N	\N	\N	\N	74	37	142619
1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	1998-10-07 00:00:00+00	0	220.52	\N	\N	220.52	\N	\N	\N	\N	74	37	142621
1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	1998-10-08 00:00:00+00	0	220.43	\N	\N	220.43	\N	\N	\N	\N	74	37	142623
1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	1998-10-09 00:00:00+00	0	220.31	\N	\N	220.31	\N	\N	\N	\N	74	37	142625
1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	1998-10-10 00:00:00+00	0	220.22	\N	\N	220.22	\N	\N	\N	\N	74	37	142627
1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	1998-10-11 00:00:00+00	0	220.21	\N	\N	220.21	\N	\N	\N	\N	74	37	142629
1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	1998-10-12 00:00:00+00	0	220.19	\N	\N	220.19	\N	\N	\N	\N	74	37	142631
1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	1998-10-13 00:00:00+00	0	220.09	\N	\N	220.09	\N	\N	\N	\N	74	37	142633
1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	1998-10-14 00:00:00+00	0	219.96	\N	\N	219.96	\N	\N	\N	\N	74	37	142635
1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	1998-10-15 00:00:00+00	0	219.82	\N	\N	219.82	\N	\N	\N	\N	74	37	142637
1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	1998-10-16 00:00:00+00	0	219.68	\N	\N	219.68	\N	\N	\N	\N	74	37	142639
1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	1998-10-17 00:00:00+00	0	219.64	\N	\N	219.64	\N	\N	\N	\N	74	37	142641
1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	1998-10-18 00:00:00+00	0	219.6	\N	\N	219.6	\N	\N	\N	\N	74	37	142643
1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	1998-10-19 00:00:00+00	0	219.51	\N	\N	219.51	\N	\N	\N	\N	74	37	142645
1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	1998-10-20 00:00:00+00	0	219.45	\N	\N	219.45	\N	\N	\N	\N	74	37	142647
1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	1998-10-21 00:00:00+00	0	219.41	\N	\N	219.41	\N	\N	\N	\N	74	37	142649
1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	1998-10-22 00:00:00+00	0	219.38	\N	\N	219.38	\N	\N	\N	\N	74	37	142651
1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	1998-10-23 00:00:00+00	0	219.27	\N	\N	219.27	\N	\N	\N	\N	74	37	142653
1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	1998-10-24 00:00:00+00	0	219.07	\N	\N	219.07	\N	\N	\N	\N	74	37	142655
1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	1998-10-25 00:00:00+00	0	218.83	\N	\N	218.83	\N	\N	\N	\N	74	37	142657
1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	1998-10-26 00:00:00+00	0	218.55	\N	\N	218.55	\N	\N	\N	\N	74	37	142659
1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	1998-10-27 00:00:00+00	0	218.41	\N	\N	218.41	\N	\N	\N	\N	74	37	142661
1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	1998-10-28 00:00:00+00	0	218.2	\N	\N	218.2	\N	\N	\N	\N	74	37	142663
1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	1998-10-29 00:00:00+00	0	218.04	\N	\N	218.04	\N	\N	\N	\N	74	37	142665
1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	1998-10-30 00:00:00+00	0	217.85	\N	\N	217.85	\N	\N	\N	\N	74	37	142667
1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	1998-10-31 00:00:00+00	0	217.66	\N	\N	217.66	\N	\N	\N	\N	74	37	142669
1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	1998-11-01 00:00:00+00	0	217.5	\N	\N	217.5	\N	\N	\N	\N	74	37	142671
1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	1998-11-02 00:00:00+00	0	217.25	\N	\N	217.25	\N	\N	\N	\N	74	37	142673
1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	1998-11-03 00:00:00+00	0	217.01	\N	\N	217.01	\N	\N	\N	\N	74	37	142675
1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	1998-11-04 00:00:00+00	0	216.77	\N	\N	216.77	\N	\N	\N	\N	74	37	142677
1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	1998-11-05 00:00:00+00	0	216.65	\N	\N	216.65	\N	\N	\N	\N	74	37	142679
1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	1998-11-06 00:00:00+00	0	216.48	\N	\N	216.48	\N	\N	\N	\N	74	37	142681
1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	1998-11-07 00:00:00+00	0	216.43	\N	\N	216.43	\N	\N	\N	\N	74	37	142683
1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	1998-11-08 00:00:00+00	0	216.38	\N	\N	216.38	\N	\N	\N	\N	74	37	142685
1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	1998-11-09 00:00:00+00	0	216.16	\N	\N	216.16	\N	\N	\N	\N	74	37	142687
1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	1998-11-10 00:00:00+00	0	216.1	\N	\N	216.1	\N	\N	\N	\N	74	37	142689
1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	1998-11-11 00:00:00+00	0	216	\N	\N	216	\N	\N	\N	\N	74	37	142691
1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	1998-11-12 00:00:00+00	0	215.87	\N	\N	215.87	\N	\N	\N	\N	74	37	142693
1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	1998-11-13 00:00:00+00	0	215.83	\N	\N	215.83	\N	\N	\N	\N	74	37	142695
1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	1998-11-14 00:00:00+00	0	215.69	\N	\N	215.69	\N	\N	\N	\N	74	37	142697
1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	1998-11-15 00:00:00+00	0	215.57	\N	\N	215.57	\N	\N	\N	\N	74	37	142699
1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	1998-11-16 00:00:00+00	0	215.39	\N	\N	215.39	\N	\N	\N	\N	74	37	142701
1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	1998-11-17 00:00:00+00	0	215.29	\N	\N	215.29	\N	\N	\N	\N	74	37	142703
1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	1998-11-18 00:00:00+00	0	215.18	\N	\N	215.18	\N	\N	\N	\N	74	37	142705
1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	1998-11-19 00:00:00+00	0	215.13	\N	\N	215.13	\N	\N	\N	\N	74	37	142707
1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	1998-11-20 00:00:00+00	0	215.16	\N	\N	215.16	\N	\N	\N	\N	74	37	142709
1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	1998-11-21 00:00:00+00	0	215.16	\N	\N	215.16	\N	\N	\N	\N	74	37	142711
1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	1998-11-22 00:00:00+00	0	215.09	\N	\N	215.09	\N	\N	\N	\N	74	37	142713
1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	1998-11-23 00:00:00+00	0	215.04	\N	\N	215.04	\N	\N	\N	\N	74	37	142715
1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	1998-11-24 00:00:00+00	0	214.99	\N	\N	214.99	\N	\N	\N	\N	74	37	142717
1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	1998-11-25 00:00:00+00	0	215.02	\N	\N	215.02	\N	\N	\N	\N	74	37	142719
1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	1998-11-26 00:00:00+00	0	215.04	\N	\N	215.04	\N	\N	\N	\N	74	37	142721
1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	1998-11-27 00:00:00+00	0	215.02	\N	\N	215.02	\N	\N	\N	\N	74	37	142723
1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	1998-11-28 00:00:00+00	0	215.02	\N	\N	215.02	\N	\N	\N	\N	74	37	142725
1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	1998-11-29 00:00:00+00	0	214.97	\N	\N	214.97	\N	\N	\N	\N	74	37	142727
1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	1998-11-30 00:00:00+00	0	214.98	\N	\N	214.98	\N	\N	\N	\N	74	37	142729
1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	1998-12-01 00:00:00+00	0	214.92	\N	\N	214.92	\N	\N	\N	\N	74	37	142731
1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	1998-12-02 00:00:00+00	0	214.78	\N	\N	214.78	\N	\N	\N	\N	74	37	142733
1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	1998-12-03 00:00:00+00	0	214.65	\N	\N	214.65	\N	\N	\N	\N	74	37	142735
1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	1998-12-04 00:00:00+00	0	214.63	\N	\N	214.63	\N	\N	\N	\N	74	37	142737
1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	1998-12-05 00:00:00+00	0	214.63	\N	\N	214.63	\N	\N	\N	\N	74	37	142739
1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	1998-12-06 00:00:00+00	0	214.63	\N	\N	214.63	\N	\N	\N	\N	74	37	142741
1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	1998-12-07 00:00:00+00	0	214.69	\N	\N	214.69	\N	\N	\N	\N	74	37	142743
1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	1998-12-08 00:00:00+00	0	214.71	\N	\N	214.71	\N	\N	\N	\N	74	37	142745
1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	1998-12-09 00:00:00+00	0	214.65	\N	\N	214.65	\N	\N	\N	\N	74	37	142747
1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	1998-12-10 00:00:00+00	0	214.68	\N	\N	214.68	\N	\N	\N	\N	74	37	142749
1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	1998-12-11 00:00:00+00	0	214.67	\N	\N	214.67	\N	\N	\N	\N	74	37	142751
1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	1998-12-12 00:00:00+00	0	214.67	\N	\N	214.67	\N	\N	\N	\N	74	37	142753
1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	1998-12-13 00:00:00+00	0	214.67	\N	\N	214.67	\N	\N	\N	\N	74	37	142755
1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	1998-12-14 00:00:00+00	0	214.62	\N	\N	214.62	\N	\N	\N	\N	74	37	142757
1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	1998-12-15 00:00:00+00	0	214.55	\N	\N	214.55	\N	\N	\N	\N	74	37	142759
1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	1998-12-16 00:00:00+00	0	214.51	\N	\N	214.51	\N	\N	\N	\N	74	37	142761
1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	1998-12-17 00:00:00+00	0	214.49	\N	\N	214.49	\N	\N	\N	\N	74	37	142763
1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	1998-12-18 00:00:00+00	0	214.15	\N	\N	214.15	\N	\N	\N	\N	74	37	142765
1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	1998-12-19 00:00:00+00	0	214.05	\N	\N	214.05	\N	\N	\N	\N	74	37	142767
1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	1998-12-20 00:00:00+00	0	213.99	\N	\N	213.99	\N	\N	\N	\N	74	37	142769
1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	1998-12-21 00:00:00+00	0	214.22	\N	\N	214.22	\N	\N	\N	\N	74	37	142771
1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	1998-12-22 00:00:00+00	0	214.24	\N	\N	214.24	\N	\N	\N	\N	74	37	142773
1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	1998-12-23 00:00:00+00	0	214.17	\N	\N	214.17	\N	\N	\N	\N	74	37	142775
1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	1998-12-24 00:00:00+00	0	214.27	\N	\N	214.27	\N	\N	\N	\N	74	37	142777
1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	1998-12-25 00:00:00+00	0	214.28	\N	\N	214.28	\N	\N	\N	\N	74	37	142779
1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	1998-12-26 00:00:00+00	0	214.21	\N	\N	214.21	\N	\N	\N	\N	74	37	142781
1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	1998-12-27 00:00:00+00	0	214.08	\N	\N	214.08	\N	\N	\N	\N	74	37	142783
1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	1998-12-28 00:00:00+00	0	214.08	\N	\N	214.08	\N	\N	\N	\N	74	37	142785
1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	1998-12-29 00:00:00+00	0	214.08	\N	\N	214.08	\N	\N	\N	\N	74	37	142787
1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	1998-12-30 00:00:00+00	0	213.99	\N	\N	213.99	\N	\N	\N	\N	74	37	142789
1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	1998-12-31 00:00:00+00	0	213.93	\N	\N	213.93	\N	\N	\N	\N	74	37	142791
1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	1999-01-01 00:00:00+00	0	213.81	\N	\N	213.81	\N	\N	\N	\N	74	37	142793
1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	1999-01-02 00:00:00+00	0	213.85	\N	\N	213.85	\N	\N	\N	\N	74	37	142795
1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	1999-01-03 00:00:00+00	0	213.96	\N	\N	213.96	\N	\N	\N	\N	74	37	142797
1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	1999-01-04 00:00:00+00	0	214.03	\N	\N	214.03	\N	\N	\N	\N	74	37	142799
1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	1999-01-05 00:00:00+00	0	214.02	\N	\N	214.02	\N	\N	\N	\N	74	37	142801
1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	1999-01-06 00:00:00+00	0	213.92	\N	\N	213.92	\N	\N	\N	\N	74	37	142803
1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	1999-01-07 00:00:00+00	0	213.87	\N	\N	213.87	\N	\N	\N	\N	74	37	142805
1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	1999-01-08 00:00:00+00	0	213.79	\N	\N	213.79	\N	\N	\N	\N	74	37	142807
\.


--
-- TOC entry 4853 (class 0 OID 19690)
-- Dependencies: 289
-- Data for Name: OBS_PROPERTIES; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."OBS_PROPERTIES" ("NAME", "DEFINITION", "DESCRIPTION", "PROPERTIES", "ID") FROM stdin;
Water Level Below Ground Surface	http://purl.org/iow/terms/c_5743b00a	The distance between the elevation of the ground surface and the elevation of the water level measured in a groundwater well	\N	1
Water Level relative to datum	http://purl.org/iow/terms/c_611d04d4	The distance between the elevation of a vertical datum and the elevation of the water level measured in a groundwater well	\N	2
Temperature	http://www.qudt.org/qudt/owl/1.0.0/quantity/Instances.html#Temperature	Temperature in situ	\N	4
Temperature	http://www.qudt.org/qudt/owl/1.0.0/quantity/Instances.html#Temperature	Temperature in situ	\N	3
\.


--
-- TOC entry 4857 (class 0 OID 19720)
-- Dependencies: 293
-- Data for Name: SENSORS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."SENSORS" ("NAME", "DESCRIPTION", "PROPERTIES", "ENCODING_TYPE", "METADATA", "ID") FROM stdin;
NGWMN Well	Monitoring well of the National Groundwater Monitoring Network	\N	text/plain	https://cida.usgs.gov/ngwmn/provider/NMBGMR/	1
Test Thermometer	Digital temperature and humidity sensor	\N	application/pdf	https://www.sparkfun.com/datasheets/Sensors/Temperature/DHT22.pdf	5
Test Thermometer	Digital temperature and humidity sensor	\N	application/pdf	https://www.sparkfun.com/datasheets/Sensors/Temperature/DHT22.pdf	4
\.


--
-- TOC entry 4859 (class 0 OID 19734)
-- Dependencies: 295
-- Data for Name: THINGS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."THINGS" ("NAME", "DESCRIPTION", "PROPERTIES", "ID") FROM stdin;
QU-004	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/QU-004", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 7524, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	5
354235108170703	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/354235108170703", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6757.7, "ThingDataProvider": "U.S. Geological Survey"}	6
354235108170702	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/354235108170702", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6757.1, "ThingDataProvider": "U.S. Geological Survey"}	7
364934108242601	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/364934108242601", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 5344.55, "ThingDataProvider": "U.S. Geological Survey"}	8
353700107563901	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/353700107563901", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6923.97, "ThingDataProvider": "U.S. Geological Survey"}	12
354915107191901	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/354915107191901", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6662, "ThingDataProvider": "U.S. Geological Survey"}	14
EB-220	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/EB-220", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6260, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	19
350923107522701	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/350923107522701", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6478, "ThingDataProvider": "U.S. Geological Survey"}	26
SA-0034	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/SA-0034", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 7198, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	23
351304107543701	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/351304107543701", "Aquifer": "Other aquifers", "ThingAlt": 6561, "ThingDataProvider": "U.S. Geological Survey"}	24
SA-0009	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/SA-0009", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 7050, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	25
SA-0076	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/SA-0076", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6978, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	27
MG-038	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/MG-038", "Aquifer": "Other aquifers", "ThingAlt": 6409, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	31
342107106530401	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/342107106530401", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4860, "ThingDataProvider": "U.S. Geological Survey"}	32
343753106430602	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/343753106430602", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4928, "ThingDataProvider": "U.S. Geological Survey"}	33
320230107013501	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/320230107013501", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4250, "ThingDataProvider": "U.S. Geological Survey"}	41
314723106420001	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/314723106420001", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4082, "ThingDataProvider": "U.S. Geological Survey"}	45
321332106443701	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/321332106443701", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 3861.5, "ThingDataProvider": "U.S. Geological Survey"}	46
TB-0029	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TB-0029", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4518, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	49
TB-0071	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TB-0071", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4591, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	50
SM-0049	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/SM-0049", "Aquifer": "Other aquifers", "ThingAlt": 9081, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	51
325115105321401	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/325115105321401", "Aquifer": "Other aquifers", "ThingAlt": 6855, "ThingDataProvider": "U.S. Geological Survey"}	52
332937105314501	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/332937105314501", "Aquifer": "Other aquifers", "ThingAlt": 6210, "ThingDataProvider": "U.S. Geological Survey"}	53
SM-0246	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/SM-0246", "Aquifer": "Other aquifers", "ThingAlt": 5262, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	54
324620104255001	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/324620104255001", "Aquifer": "Pecos River Basin alluvial aquifer", "ThingAlt": 3403, "ThingDataProvider": "U.S. Geological Survey"}	55
324940103365801	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/324940103365801", "Aquifer": "High Plains aquifer", "ThingAlt": 4127, "ThingDataProvider": "U.S. Geological Survey"}	57
330458103251001	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/330458103251001", "Aquifer": "High Plains aquifer", "ThingAlt": 4033, "ThingDataProvider": "U.S. Geological Survey"}	58
332115103403301	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/332115103403301", "Aquifer": "High Plains aquifer", "ThingAlt": 4338, "ThingDataProvider": "U.S. Geological Survey"}	59
TV-157	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TV-157", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6932, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	2
TV-196	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TV-196", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6696, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	3
354056106215801	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/354056106215801", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5797, "ThingDataProvider": "U.S. Geological Survey"}	17
354731106072002	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/354731106072002", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5960, "ThingDataProvider": "U.S. Geological Survey"}	18
353824106040902	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/353824106040902", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6365, "ThingDataProvider": "U.S. Geological Survey"}	20
354228106044902	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/354228106044902", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6390, "ThingDataProvider": "U.S. Geological Survey"}	21
353945105574502	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/353945105574502", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 6880, "ThingDataProvider": "U.S. Geological Survey"}	22
350603107485801	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/350603107485801", "Aquifer": "Other aquifers", "ThingAlt": 6433, "ThingDataProvider": "U.S. Geological Survey"}	28
MG-030	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/MG-030", "Aquifer": "Other aquifers", "ThingAlt": 6632, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	29
350306107263401	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/350306107263401", "Aquifer": "Other aquifers", "ThingAlt": 5947, "ThingDataProvider": "U.S. Geological Survey"}	30
351114106330602	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/351114106330602", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5453, "ThingDataProvider": "U.S. Geological Survey"}	38
321945106595001	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/321945106595001", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4463, "ThingDataProvider": "U.S. Geological Survey"}	42
314810106513601	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/314810106513601", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4121, "ThingDataProvider": "U.S. Geological Survey"}	43
321740106481001	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/321740106481001", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 3889.7, "ThingDataProvider": "U.S. Geological Survey"}	44
Test	Docker R Tester	{"uri": "https://geoconnex.us/iow/sta-demo/station/Test", "owner": "Kyle", "organisation": "Internet of Water"}	61
354017108445201	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/354017108445201_2"}	1
QU-100	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/QU-100", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 7286, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	4
364255108053202	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/364255108053202", "Aquifer": "Other aquifers", "ThingAlt": 5459.8, "ThingDataProvider": "U.S. Geological Survey"}	13
351821106333902	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/351821106333902", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5047, "ThingDataProvider": "U.S. Geological Survey"}	16
344431106393402	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/344431106393402", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5024, "ThingDataProvider": "U.S. Geological Survey"}	35
Test	Docker R Tester	{"uri": "https://geoconnex.us/iow/sta-demo/station/test0", "owner": "Kyle", "organisation": "Internet of Water"}	60
344431106393403	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/344431106393403", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5024.17, "ThingDataProvider": "U.S. Geological Survey"}	36
343347103345001	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/343347103345001", "Aquifer": "High Plains aquifer", "ThingAlt": 4589, "ThingDataProvider": "U.S. Geological Survey"}	40
322323106314701	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/322323106314701", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4627, "ThingDataProvider": "U.S. Geological Survey"}	47
362714103071201	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/362714103071201", "Aquifer": "Pecos River Basin alluvial aquifer", "ThingAlt": 2916, "ThingDataProvider": "U.S. Geological Survey"}	56
364826108234301	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/364826108234301", "Aquifer": "Other aquifers", "ThingAlt": 5264.47, "ThingDataProvider": "U.S. Geological Survey"}	9
364916108234301	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/364916108234301", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 5345.56, "ThingDataProvider": "U.S. Geological Survey"}	10
353659107564101	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/353659107564101", "Aquifer": "Colorado Plateaus aquifers", "ThingAlt": 6924, "ThingDataProvider": "U.S. Geological Survey"}	11
351040106482801	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/351040106482801", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5843, "ThingDataProvider": "U.S. Geological Survey"}	34
TB-0203	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TB-0203", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5526, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	39
TB-0084	Other	{"uri": "https://geoconnex.us/iow/sta-demo/station/TB-0084", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 4213, "ThingDataProvider": "New Mexico Bureau of Geology and Mineral Resources"}	48
351515106410402	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/351515106410402", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5437, "ThingDataProvider": "U.S. Geological Survey"}	15
350056106370102	Dedicated Monitoring/Observation	{"uri": "https://geoconnex.us/iow/sta-demo/station/350056106370102", "Aquifer": "Rio Grande aquifer system", "ThingAlt": 5094, "ThingDataProvider": "U.S. Geological Survey"}	37
\.


--
-- TOC entry 4861 (class 0 OID 19748)
-- Dependencies: 297
-- Data for Name: THINGS_LOCATIONS; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public."THINGS_LOCATIONS" ("THING_ID", "LOCATION_ID") FROM stdin;
5	5
6	6
7	7
8	8
12	12
14	14
19	19
26	26
23	23
24	24
25	25
27	27
31	31
32	32
33	33
41	41
45	45
46	46
49	49
50	50
51	51
52	52
53	53
54	54
55	55
57	57
58	58
59	59
2	2
3	3
17	17
18	18
20	20
21	21
22	22
28	28
29	29
30	30
38	38
42	42
43	43
44	44
61	61
1	1
4	4
13	13
16	16
35	35
60	60
36	36
40	40
47	47
56	56
9	9
10	10
11	11
34	34
39	39
48	48
15	15
37	37
\.


--
-- TOC entry 4843 (class 0 OID 19619)
-- Dependencies: 279
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
postgresFunctions.sql	scf	liquibase/core.xml	2022-12-02 16:06:32.45043	1	EXECUTED	8:1df6bb1dd0a742af1113f05743081a32	sqlFile		\N	4.12.0	\N	\N	9997192407
2021-01-01-datastreams-1	scf	liquibase/plugincoremodel/tableDatastreams.xml	2022-12-02 16:06:32.70121	2	EXECUTED	8:b794c72ee0ddba8e3cf9e1ea597b4340	createTable tableName=DATASTREAMS		\N	4.12.0	\N	\N	9997192631
2021-01-01-datastreams-2	scf	liquibase/plugincoremodel/tableDatastreams.xml	2022-12-02 16:06:32.71021	3	EXECUTED	8:7280464944bd850cc032a81ed4a3c3c7	addColumn tableName=DATASTREAMS		\N	4.12.0	\N	\N	9997192631
2021-01-01-datastreams-3	scf	liquibase/plugincoremodel/tableDatastreams.xml	2022-12-02 16:06:32.711514	4	MARK_RAN	8:e4ce2829219200cf80dd41f2874a009a	addColumn tableName=DATASTREAMS		\N	4.12.0	\N	\N	9997192631
2021-01-01-datastreams-4	scf	liquibase/plugincoremodel/tableDatastreams.xml	2022-12-02 16:06:32.720737	5	EXECUTED	8:203a0093138180f4ec2b32f067aabdd4	createIndex indexName=DATASTREAMS_OBS_PROPERTY_ID, tableName=DATASTREAMS; createIndex indexName=DATASTREAMS_SENSOR_ID, tableName=DATASTREAMS; createIndex indexName=DATASTREAMS_THING_ID, tableName=DATASTREAMS		\N	4.12.0	\N	\N	9997192631
2021-01-01-features-1	scf	liquibase/plugincoremodel/tableFeatures.xml	2022-12-02 16:06:32.726968	6	EXECUTED	8:660f67db3307cab397351384632d328b	createTable tableName=FEATURES		\N	4.12.0	\N	\N	9997192631
2021-01-01-features-2	scf	liquibase/plugincoremodel/tableFeatures.xml	2022-12-02 16:06:32.732048	7	EXECUTED	8:4374da152cdee1882ce18c5b93882da1	addColumn tableName=FEATURES		\N	4.12.0	\N	\N	9997192631
2021-01-01-features-3	scf	liquibase/plugincoremodel/tableFeatures.xml	2022-12-02 16:06:32.732983	8	MARK_RAN	8:b7e9c85c285f28e461713f0a5a1e912f	addColumn tableName=FEATURES		\N	4.12.0	\N	\N	9997192631
2021-01-01-histLocations-1	scf	liquibase/plugincoremodel/tableHistLocations.xml	2022-12-02 16:06:32.739341	9	EXECUTED	8:056ad2df65666333327fe821243fb0e4	createTable tableName=HIST_LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-histLocations-2	scf	liquibase/plugincoremodel/tableHistLocations.xml	2022-12-02 16:06:32.743846	10	EXECUTED	8:e39604ab7fc585885d0246956bff07d6	addColumn tableName=HIST_LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-histLocations-3	scf	liquibase/plugincoremodel/tableHistLocations.xml	2022-12-02 16:06:32.744764	11	MARK_RAN	8:7f45f341b27a27d73890d2be6a44e933	addColumn tableName=HIST_LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-histLocations-4	scf	liquibase/plugincoremodel/tableHistLocations.xml	2022-12-02 16:06:32.750771	12	EXECUTED	8:10e66b5cb137f503f4801a832f564511	createIndex indexName=HIST_LOCATIONS_THING_ID, tableName=HIST_LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-locations-1	scf	liquibase/plugincoremodel/tableLocations.xml	2022-12-02 16:06:32.756825	13	EXECUTED	8:97ddf4e25d3e4509a44e18ed961a0da1	createTable tableName=LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-locations-2	scf	liquibase/plugincoremodel/tableLocations.xml	2022-12-02 16:06:32.762078	14	EXECUTED	8:ca579a1ba98b2cc49e2eac745a636576	addColumn tableName=LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-locations-3	scf	liquibase/plugincoremodel/tableLocations.xml	2022-12-02 16:06:32.762981	15	MARK_RAN	8:2ba863c5b011c04d887cf8131b1afea1	addColumn tableName=LOCATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-locationsHistLocations	scf	liquibase/plugincoremodel/tableLocationsHistLocations.xml	2022-12-02 16:06:32.77385	16	EXECUTED	8:88b2d22f85cf13e6e24e625a79db1d62	createTable tableName=LOCATIONS_HIST_LOCATIONS; addPrimaryKey constraintName=LOCATIONS_HIST_LOCATIONS_PKEY, tableName=LOCATIONS_HIST_LOCATIONS; createIndex indexName=LOCATIONS_HIST_LOCATIONS_HIST_LOCATION_ID, tableName=LOCATIONS_HIST_LOCATIONS; cr...		\N	4.12.0	\N	\N	9997192631
2021-01-01-obsProperties-1	scf	liquibase/plugincoremodel/tableObsProperties.xml	2022-12-02 16:06:32.780289	17	EXECUTED	8:030dfc52537b0521955dddb020bda423	createTable tableName=OBS_PROPERTIES		\N	4.12.0	\N	\N	9997192631
2021-01-01-obsProperties-2	scf	liquibase/plugincoremodel/tableObsProperties.xml	2022-12-02 16:06:32.785286	18	EXECUTED	8:fa91056fcc5047639bfbe0bdccbc0d64	addColumn tableName=OBS_PROPERTIES		\N	4.12.0	\N	\N	9997192631
2021-01-01-obsProperties-3	scf	liquibase/plugincoremodel/tableObsProperties.xml	2022-12-02 16:06:32.786189	19	MARK_RAN	8:8f7fa9da4e634208a0eed9f330759b81	addColumn tableName=OBS_PROPERTIES		\N	4.12.0	\N	\N	9997192631
2021-01-01-observations-1	scf	liquibase/plugincoremodel/tableObservations.xml	2022-12-02 16:06:32.793236	20	EXECUTED	8:6526e2255db15181c1774bc23e11eda6	createTable tableName=OBSERVATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-observations-2	scf	liquibase/plugincoremodel/tableObservations.xml	2022-12-02 16:06:32.798792	21	EXECUTED	8:ea53f31fb995c9298e6e63a91247e2b3	addColumn tableName=OBSERVATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-observations-3	scf	liquibase/plugincoremodel/tableObservations.xml	2022-12-02 16:06:32.800228	22	MARK_RAN	8:353b4d5d13905e59100c7228e262eef6	addColumn tableName=OBSERVATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-observations-4	scf	liquibase/plugincoremodel/tableObservations.xml	2022-12-02 16:06:32.806539	23	EXECUTED	8:af30c2e66707d03a1e22f3d5ffee6bb1	createIndex indexName=OBSERVATIONS_DATASTREAM_ID, tableName=OBSERVATIONS; createIndex indexName=OBSERVATIONS_FEATURE_ID, tableName=OBSERVATIONS		\N	4.12.0	\N	\N	9997192631
2021-01-01-sensors-1	scf	liquibase/plugincoremodel/tableSensors.xml	2022-12-02 16:06:32.813723	24	EXECUTED	8:895463ab8d417dba1d725cfcfd534fda	createTable tableName=SENSORS		\N	4.12.0	\N	\N	9997192631
2021-01-01-sensors-2	scf	liquibase/plugincoremodel/tableSensors.xml	2022-12-02 16:06:32.82013	25	EXECUTED	8:d3c0fdd93f39a4c5e8d4d48794eaed3b	addColumn tableName=SENSORS		\N	4.12.0	\N	\N	9997192631
2021-01-01-sensors-3	scf	liquibase/plugincoremodel/tableSensors.xml	2022-12-02 16:06:32.821109	26	MARK_RAN	8:7793864b12aef84673b255ada3b48132	addColumn tableName=SENSORS		\N	4.12.0	\N	\N	9997192631
2021-01-01-things-1	scf	liquibase/plugincoremodel/tableThings.xml	2022-12-02 16:06:32.828685	27	EXECUTED	8:e703f1e464c3319ef0dcff200a5176f3	createTable tableName=THINGS		\N	4.12.0	\N	\N	9997192631
2021-01-01-things-2	scf	liquibase/plugincoremodel/tableThings.xml	2022-12-02 16:06:32.834325	28	EXECUTED	8:4037fa8d524968e70312450b03041969	addColumn tableName=THINGS		\N	4.12.0	\N	\N	9997192631
2021-01-01-things-3	scf	liquibase/plugincoremodel/tableThings.xml	2022-12-02 16:06:32.835718	29	MARK_RAN	8:4a2ee18ba9be58b91c0757a4c4a313cd	addColumn tableName=THINGS		\N	4.12.0	\N	\N	9997192631
2021-01-01-thingsLocations	scf	liquibase/plugincoremodel/tableThingsLocations.xml	2022-12-02 16:06:32.844718	30	EXECUTED	8:3e71f21ea9303b989e49880dc0e2e83b	createTable tableName=THINGS_LOCATIONS; addPrimaryKey constraintName=THINGS_LOCATIONS_PKEY, tableName=THINGS_LOCATIONS; createIndex indexName=THINGS_LOCATIONS_LOCATION_ID, tableName=THINGS_LOCATIONS; createIndex indexName=THINGS_LOCATIONS_THING_ID...		\N	4.12.0	\N	\N	9997192631
2021-01-01-foreignKeys	scf	liquibase/plugincoremodel/foreignKeys.xml	2022-12-02 16:06:32.917396	31	EXECUTED	8:e5f47e12dd22e4f77cebbbd5a7bb25dd	addForeignKeyConstraint baseTableName=DATASTREAMS, constraintName=DATASTREAMS_OBS_PROPERTY_ID_FKEY, referencedTableName=OBS_PROPERTIES; addForeignKeyConstraint baseTableName=DATASTREAMS, constraintName=DATASTREAMS_SENSOR_ID_FKEY, referencedTableNa...		\N	4.12.0	\N	\N	9997192631
2022-04-06-Index-OBS-DS_ID-ID	scf	liquibase/plugincoremodel/foreignKeys.xml	2022-12-02 16:06:32.930226	32	EXECUTED	8:99febd028c325ef71eb712dfb02d3f0a	createIndex indexName=OBS-DS_ID-ID, tableName=OBSERVATIONS		\N	4.12.0	\N	\N	9997192631
postgresTriggers.sql	scf	liquibase/plugincoremodel/tables.xml	2022-12-02 16:06:32.93914	33	EXECUTED	8:1b8766d0dec1b88d0bc9ea3034644020	sqlFile		\N	4.12.0	\N	\N	9997192631
\.


--
-- TOC entry 4842 (class 0 OID 19614)
-- Dependencies: 278
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- TOC entry 4458 (class 0 OID 18299)
-- Dependencies: 217
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: sensorthings
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- TOC entry 4461 (class 0 OID 19199)
-- Dependencies: 228
-- Data for Name: geocode_settings; Type: TABLE DATA; Schema: tiger; Owner: sensorthings
--

COPY tiger.geocode_settings (name, setting, unit, category, short_desc) FROM stdin;
\.


--
-- TOC entry 4462 (class 0 OID 19531)
-- Dependencies: 273
-- Data for Name: pagc_gaz; Type: TABLE DATA; Schema: tiger; Owner: sensorthings
--

COPY tiger.pagc_gaz (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- TOC entry 4463 (class 0 OID 19541)
-- Dependencies: 275
-- Data for Name: pagc_lex; Type: TABLE DATA; Schema: tiger; Owner: sensorthings
--

COPY tiger.pagc_lex (id, seq, word, stdword, token, is_custom) FROM stdin;
\.


--
-- TOC entry 4464 (class 0 OID 19551)
-- Dependencies: 277
-- Data for Name: pagc_rules; Type: TABLE DATA; Schema: tiger; Owner: sensorthings
--

COPY tiger.pagc_rules (id, rule, is_custom) FROM stdin;
\.


--
-- TOC entry 4459 (class 0 OID 19023)
-- Dependencies: 222
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: sensorthings
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.


--
-- TOC entry 4460 (class 0 OID 19035)
-- Dependencies: 223
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: sensorthings
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.


--
-- TOC entry 4874 (class 0 OID 0)
-- Dependencies: 281
-- Name: DATASTREAMS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."DATASTREAMS_ID_seq"', 1, false);


--
-- TOC entry 4875 (class 0 OID 0)
-- Dependencies: 283
-- Name: FEATURES_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."FEATURES_ID_seq"', 1, false);


--
-- TOC entry 4876 (class 0 OID 0)
-- Dependencies: 285
-- Name: HIST_LOCATIONS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."HIST_LOCATIONS_ID_seq"', 89, true);


--
-- TOC entry 4877 (class 0 OID 0)
-- Dependencies: 287
-- Name: LOCATIONS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."LOCATIONS_ID_seq"', 1, false);


--
-- TOC entry 4878 (class 0 OID 0)
-- Dependencies: 292
-- Name: OBSERVATIONS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."OBSERVATIONS_ID_seq"', 1, false);


--
-- TOC entry 4879 (class 0 OID 0)
-- Dependencies: 290
-- Name: OBS_PROPERTIES_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."OBS_PROPERTIES_ID_seq"', 1, false);


--
-- TOC entry 4880 (class 0 OID 0)
-- Dependencies: 294
-- Name: SENSORS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."SENSORS_ID_seq"', 1, false);


--
-- TOC entry 4881 (class 0 OID 0)
-- Dependencies: 296
-- Name: THINGS_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: sensorthings
--

SELECT pg_catalog.setval('public."THINGS_ID_seq"', 1, false);


--
-- TOC entry 4658 (class 2606 OID 19634)
-- Name: DATASTREAMS DATASTREAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."DATASTREAMS"
    ADD CONSTRAINT "DATASTREAMS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4660 (class 2606 OID 19651)
-- Name: FEATURES FEATURES_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."FEATURES"
    ADD CONSTRAINT "FEATURES_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4663 (class 2606 OID 19663)
-- Name: HIST_LOCATIONS HIST_LOCATIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."HIST_LOCATIONS"
    ADD CONSTRAINT "HIST_LOCATIONS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4669 (class 2606 OID 19687)
-- Name: LOCATIONS_HIST_LOCATIONS LOCATIONS_HIST_LOCATIONS_PKEY; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."LOCATIONS_HIST_LOCATIONS"
    ADD CONSTRAINT "LOCATIONS_HIST_LOCATIONS_PKEY" PRIMARY KEY ("LOCATION_ID", "HIST_LOCATION_ID");


--
-- TOC entry 4665 (class 2606 OID 19676)
-- Name: LOCATIONS LOCATIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."LOCATIONS"
    ADD CONSTRAINT "LOCATIONS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4676 (class 2606 OID 19711)
-- Name: OBSERVATIONS OBSERVATIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."OBSERVATIONS"
    ADD CONSTRAINT "OBSERVATIONS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4671 (class 2606 OID 19697)
-- Name: OBS_PROPERTIES OBS_PROPERTIES_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."OBS_PROPERTIES"
    ADD CONSTRAINT "OBS_PROPERTIES_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4678 (class 2606 OID 19727)
-- Name: SENSORS SENSORS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."SENSORS"
    ADD CONSTRAINT "SENSORS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4683 (class 2606 OID 19752)
-- Name: THINGS_LOCATIONS THINGS_LOCATIONS_PKEY; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."THINGS_LOCATIONS"
    ADD CONSTRAINT "THINGS_LOCATIONS_PKEY" PRIMARY KEY ("THING_ID", "LOCATION_ID");


--
-- TOC entry 4680 (class 2606 OID 19741)
-- Name: THINGS THINGS_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."THINGS"
    ADD CONSTRAINT "THINGS_pkey" PRIMARY KEY ("ID");


--
-- TOC entry 4653 (class 2606 OID 19618)
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- TOC entry 4654 (class 1259 OID 19641)
-- Name: DATASTREAMS_OBS_PROPERTY_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "DATASTREAMS_OBS_PROPERTY_ID" ON public."DATASTREAMS" USING btree ("OBS_PROPERTY_ID");


--
-- TOC entry 4655 (class 1259 OID 19642)
-- Name: DATASTREAMS_SENSOR_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "DATASTREAMS_SENSOR_ID" ON public."DATASTREAMS" USING btree ("SENSOR_ID");


--
-- TOC entry 4656 (class 1259 OID 19643)
-- Name: DATASTREAMS_THING_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "DATASTREAMS_THING_ID" ON public."DATASTREAMS" USING btree ("THING_ID");


--
-- TOC entry 4661 (class 1259 OID 19668)
-- Name: HIST_LOCATIONS_THING_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "HIST_LOCATIONS_THING_ID" ON public."HIST_LOCATIONS" USING btree ("THING_ID");


--
-- TOC entry 4666 (class 1259 OID 19688)
-- Name: LOCATIONS_HIST_LOCATIONS_HIST_LOCATION_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "LOCATIONS_HIST_LOCATIONS_HIST_LOCATION_ID" ON public."LOCATIONS_HIST_LOCATIONS" USING btree ("HIST_LOCATION_ID");


--
-- TOC entry 4667 (class 1259 OID 19689)
-- Name: LOCATIONS_HIST_LOCATIONS_LOCATION_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "LOCATIONS_HIST_LOCATIONS_LOCATION_ID" ON public."LOCATIONS_HIST_LOCATIONS" USING btree ("LOCATION_ID");


--
-- TOC entry 4672 (class 1259 OID 19805)
-- Name: OBS-DS_ID-ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "OBS-DS_ID-ID" ON public."OBSERVATIONS" USING btree ("DATASTREAM_ID", "ID");


--
-- TOC entry 4673 (class 1259 OID 19718)
-- Name: OBSERVATIONS_DATASTREAM_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "OBSERVATIONS_DATASTREAM_ID" ON public."OBSERVATIONS" USING btree ("DATASTREAM_ID");


--
-- TOC entry 4674 (class 1259 OID 19719)
-- Name: OBSERVATIONS_FEATURE_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "OBSERVATIONS_FEATURE_ID" ON public."OBSERVATIONS" USING btree ("FEATURE_ID");


--
-- TOC entry 4681 (class 1259 OID 19753)
-- Name: THINGS_LOCATIONS_LOCATION_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "THINGS_LOCATIONS_LOCATION_ID" ON public."THINGS_LOCATIONS" USING btree ("LOCATION_ID");


--
-- TOC entry 4684 (class 1259 OID 19754)
-- Name: THINGS_LOCATIONS_THING_ID; Type: INDEX; Schema: public; Owner: sensorthings
--

CREATE INDEX "THINGS_LOCATIONS_THING_ID" ON public."THINGS_LOCATIONS" USING btree ("THING_ID");


--
-- TOC entry 4695 (class 2620 OID 19811)
-- Name: OBSERVATIONS datastreams_actualization_delete; Type: TRIGGER; Schema: public; Owner: sensorthings
--

CREATE TRIGGER datastreams_actualization_delete AFTER DELETE ON public."OBSERVATIONS" FOR EACH ROW EXECUTE FUNCTION public.datastreams_update_delete();


--
-- TOC entry 4697 (class 2620 OID 19807)
-- Name: OBSERVATIONS datastreams_actualization_insert; Type: TRIGGER; Schema: public; Owner: sensorthings
--

CREATE TRIGGER datastreams_actualization_insert AFTER INSERT ON public."OBSERVATIONS" FOR EACH ROW EXECUTE FUNCTION public.datastreams_update_insert();


--
-- TOC entry 4696 (class 2620 OID 19809)
-- Name: OBSERVATIONS datastreams_actualization_update; Type: TRIGGER; Schema: public; Owner: sensorthings
--

CREATE TRIGGER datastreams_actualization_update AFTER UPDATE ON public."OBSERVATIONS" FOR EACH ROW EXECUTE FUNCTION public.datastreams_update_update();


--
-- TOC entry 4685 (class 2606 OID 19755)
-- Name: DATASTREAMS DATASTREAMS_OBS_PROPERTY_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."DATASTREAMS"
    ADD CONSTRAINT "DATASTREAMS_OBS_PROPERTY_ID_FKEY" FOREIGN KEY ("OBS_PROPERTY_ID") REFERENCES public."OBS_PROPERTIES"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4686 (class 2606 OID 19760)
-- Name: DATASTREAMS DATASTREAMS_SENSOR_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."DATASTREAMS"
    ADD CONSTRAINT "DATASTREAMS_SENSOR_ID_FKEY" FOREIGN KEY ("SENSOR_ID") REFERENCES public."SENSORS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4687 (class 2606 OID 19765)
-- Name: DATASTREAMS DATASTREAMS_THING_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."DATASTREAMS"
    ADD CONSTRAINT "DATASTREAMS_THING_ID_FKEY" FOREIGN KEY ("THING_ID") REFERENCES public."THINGS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4688 (class 2606 OID 19770)
-- Name: HIST_LOCATIONS HIST_LOCATIONS_THING_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."HIST_LOCATIONS"
    ADD CONSTRAINT "HIST_LOCATIONS_THING_ID_FKEY" FOREIGN KEY ("THING_ID") REFERENCES public."THINGS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4689 (class 2606 OID 19775)
-- Name: LOCATIONS_HIST_LOCATIONS LOCATIONS_HIST_LOCATIONS_HIST_LOCATION_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."LOCATIONS_HIST_LOCATIONS"
    ADD CONSTRAINT "LOCATIONS_HIST_LOCATIONS_HIST_LOCATION_ID_FKEY" FOREIGN KEY ("HIST_LOCATION_ID") REFERENCES public."HIST_LOCATIONS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4690 (class 2606 OID 19780)
-- Name: LOCATIONS_HIST_LOCATIONS LOCATIONS_HIST_LOCATIONS_LOCATION_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."LOCATIONS_HIST_LOCATIONS"
    ADD CONSTRAINT "LOCATIONS_HIST_LOCATIONS_LOCATION_ID_FKEY" FOREIGN KEY ("LOCATION_ID") REFERENCES public."LOCATIONS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4691 (class 2606 OID 19785)
-- Name: OBSERVATIONS OBSERVATIONS_DATASTREAM_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."OBSERVATIONS"
    ADD CONSTRAINT "OBSERVATIONS_DATASTREAM_ID_FKEY" FOREIGN KEY ("DATASTREAM_ID") REFERENCES public."DATASTREAMS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4692 (class 2606 OID 19790)
-- Name: OBSERVATIONS OBSERVATIONS_FEATURE_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."OBSERVATIONS"
    ADD CONSTRAINT "OBSERVATIONS_FEATURE_ID_FKEY" FOREIGN KEY ("FEATURE_ID") REFERENCES public."FEATURES"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4693 (class 2606 OID 19795)
-- Name: THINGS_LOCATIONS THINGS_LOCATIONS_LOCATION_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."THINGS_LOCATIONS"
    ADD CONSTRAINT "THINGS_LOCATIONS_LOCATION_ID_FKEY" FOREIGN KEY ("LOCATION_ID") REFERENCES public."LOCATIONS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4694 (class 2606 OID 19800)
-- Name: THINGS_LOCATIONS THINGS_LOCATIONS_THING_ID_FKEY; Type: FK CONSTRAINT; Schema: public; Owner: sensorthings
--

ALTER TABLE ONLY public."THINGS_LOCATIONS"
    ADD CONSTRAINT "THINGS_LOCATIONS_THING_ID_FKEY" FOREIGN KEY ("THING_ID") REFERENCES public."THINGS"("ID") ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2022-12-02 16:12:07 UTC

--
-- PostgreSQL database dump complete
--

